#coding: utf-8 
import re
import os
from os import path
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split


def read_config(param_file):
    work_path = path.dirname( path.abspath(__file__) )
    os.chdir(work_path)
    with open(param_file, 'r') as f:
        for line in f:
            line = re.sub(r'\s|\n', '', line)
            if len(line) == 0 or line[0] == '#':
                continue
            line = line.split("=")

            if line[0] == 'url':
                youtube_url = str(line[1]) + '=' + str(line[2]) 
            else:
                raise 'invalid keyword: ' + line[0]
         
    return youtube_url


def get_path():
    work_path = path.dirname( path.abspath(__file__) )
    os.chdir(work_path)
    dir_base = os.path.abspath('..\\') 
    #dir_base = work_path + '..\\'
    return dir_base


def split_data(data):
    data_tra, data_test = train_test_split(data, test_size=0.25, shuffle=False)
    return data_tra, data_test

def set_model(mode):
    if mode == 'RF':
        model = RandomForestRegressor(n_jobs=-1, random_state=2525)    
    return model

url = read_config('set.ini')
dir_base = get_path()
df = pd.read_csv(dir_base + '\\input\\data_preprocessed.csv', index_col=0)
print(df)

data_tra, data_val = split_data(df.values)
df_tra = pd.DataFrame(data_tra)
df_val = pd.DataFrame(data_val)
df_tra.to_csv(dir_base + "\\output\\tra.csv")
df_val.to_csv(dir_base + "\\output\\val.csv")

X_tra = data_tra[:, 1:]
y_tra = data_tra[:, 0]
X_val = data_val[:, 1:]
y_val = data_val[:, 0]

model = set_model('RF')
model.fit(X_tra, y_tra)
y_pre = model.predict(X_val)

df_y_pre = pd.DataFrame(np.vstack([y_pre, y_val]), columns=['y_pre','y_act'])
print(df_y_pre)
df_y_pre.to_csv(dir_base + "\\output\\predict.csv")