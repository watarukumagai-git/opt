#coding: utf-8 
import re
import os
from os import path
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor


def read_config(param_file):
    work_path = path.dirname( path.abspath(__file__) )
    os.chdir(work_path)
    with open(param_file, 'r') as f:
        for line in f:
            line = re.sub(r'\s|\n', '', line)
            if len(line) == 0 or line[0] == '#':
                continue
            line = line.split("=")

            if line[0] == 'url':
                youtube_url = str(line[1]) + '=' + str(line[2]) 
            else:
                raise 'invalid keyword: ' + line[0]
         
    return youtube_url


def get_path():
    work_path = path.dirname( path.abspath(__file__) )
    os.chdir(work_path)
    dir_base = os.path.abspath('..\\') 
    #dir_base = work_path + '..\\'
    return dir_base


def get_df():
    idx_list = [i for i in range(0, 5)]
    name_list = [str(i) for i in range(0, 4)]
    df = pd.DataFrame(np.zeros((len(idx_list), len(name_list))), index=idx_list, columns=name_list)
    return df


url = read_config('set.ini')
dir_base = get_path()
df = pd.read_csv(dir_base + '\\input\\input.csv', index_col=0)
print(df)
#df = get_df()
df.to_csv(dir_base + "\\input\\data_preprocessed.csv")