#coding: utf-8 
import glob
import os
from os import path

import pandas as pd
from tabula import read_pdf

def my_makedirs(path):
    if not os.path.isdir(path):
        os.makedirs(path)

def get_dir(dir_base):
    input_dir = dir_base + '\\input'
    output_dir = dir_base + '\\output'
    my_makedirs(input_dir)
    my_makedirs(output_dir)
    return input_dir, output_dir

def get_file_list(dir):
    file_list = glob.glob(dir)
    for i, file in enumerate(file_list):
        file_list[i] = file.rsplit('\\', 1)[1]
    print(file_list)
    return file_list

def to_strhour(hour):
    if hour < 10:
        str_hour = '0' +str(hour)
    else:
        str_hour =  str(hour)
    return str_hour

def to_strmonth(month):
    if month < 10:
        str_month = '0' +str(month)
    else:
        str_month =  str(month)
    return str_month

def get_month_list(master_df):
    df = master_df['yyyy/mm/dd'].str.split('/', expand=True)
    df = df[0] + '/' + df[1]
    all_month_list = set(list(df.values))
    return all_month_list

def get_HHMM(df):
    strftime = '%Y%m'
    df_ = df.copy()
    df_['timestamp'] = df_.index
    start_HHMM = df_['timestamp'].dt.strftime(strftime).head(1).values[0]
    end_HHMM = df_['timestamp'].dt.strftime(strftime).tail(1).values[0]
    return start_HHMM, end_HHMM

def get_df_master(inout_dir, file_list):
    # 202301-202312
    df_master_2023 = pd.read_csv(inout_dir[0] + '\\' + file_list[0], index_col=0, encoding = "shift-jis", parse_dates=True)
    # 202401-20240620
    df_master_2024 = pd.read_csv(inout_dir[0] + '\\' + file_list[1], index_col=0, encoding = "shift-jis", parse_dates=True)
    df_master = pd.concat([df_master_2023, df_master_2024], axis=0)
    df_master = df_master.loc[:, ['時刻コード', 'システムプライス(円/kWh)', 'エリアプライス東京(円/kWh)', 'エリアプライス中国(円/kWh)', '約定総量(kWh)']]
    df_master['no'] = range(1, len(df_master.index) + 1)
    df_master['yyyy/mm/dd'] = df_master.index
    df_master.index = df_master['no']
    df_master = df_master.drop('no', axis=1)
    df_master = df_master.rename(columns={'時刻コード': 'time_code', 'システムプライス(円/kWh)': 'system_price [yen/kWh]', 
                                        'エリアプライス東京(円/kWh)': 'tokyo_area_price [yen/kWh]', 'エリアプライス中国(円/kWh)': 'chugoku_area_price [yen/kWh]', 
                                        '約定総量(kWh)': 'contruct amount [kWh]'})

    time_code_list = range(1, 48 + 1)
    time_range = []
    for i in range(0, 24):
        time_range.append(to_strhour(i) + ':00')
        time_range.append(to_strhour(i) + ':30')
    time_dict = dict(zip(time_code_list, time_range))
    df_master['HH:MM'] = df_master.loc[:, 'time_code'].map(time_dict)
    df_master = df_master.drop('time_code', axis=1)

    df_master['yyyy/mm/dd'] = df_master['yyyy/mm/dd'].dt.strftime('%Y-%m-%d')
    df_master['timestamp'] = df_master.loc[:, 'yyyy/mm/dd'].values + ' ' + df_master.loc[:, 'HH:MM']
    df_master.index = pd.to_datetime(df_master['timestamp'])
    df_master = df_master.drop('timestamp', axis=1)

    # timezone average
    timezone_dict = {'morning': ('8:00:00', '12:30:00'),
                     'afternoon': ('13:00:00', '15:30:00'),
                     'evening': ('16:00:00', '21:30:00'),
                     'night': ('22:00:00', '7:30:00'),
                     }
    df_master['timezone'] = 'night'
    for (timezone, between) in timezone_dict.items():
        time_index = df_master.between_time(between[0], between[1]).index
        df_master.loc[time_index, 'timezone'] = timezone
    df_master = df_master.reindex(columns=['yyyy/mm/dd', 'HH:MM', 'timezone', 'system_price [yen/kWh]', 'tokyo_area_price [yen/kWh]', 'chugoku_area_price [yen/kWh]', 'contruct amount [kWh]'])

    (head_HHMM, tail_HHMM) = get_HHMM(df_master)
    df_master.to_csv(inout_dir[1] + '\\spot_price_' + head_HHMM + '-' + tail_HHMM + '_30min.csv')
    print(df_master)
    return df_master, head_HHMM, tail_HHMM

dir_base = path.dirname( path.abspath(__file__) )
dfs = read_pdf(dir_base + "\\address.pdf", pages="6-10", lattice=True, encoding = "shift-jis")
output_dir = dir_base + '\\output'
my_makedirs(output_dir)
for i, df in enumerate(dfs):
    print()
    df.to_csv(output_dir + "\\list_" + str(i) + ".csv")

inout_dir = get_dir(dir_base)
file_list = get_file_list(inout_dir[0] + '\\*')

(df_master, head_HHMM, tail_HHMM) = get_df_master(inout_dir, file_list)
d_order = {'morning': 0, 'afternoon': 1, 'evening': 2, 'night': 3}

clm_list = [('HH:MM', '30min'), ('timezone', 'timezone')]
period_list = [('yyyy/mm', '%Y-%m', 'month', 'M'), ('yyyy', '%Y', 'year', 'Y')]
file_head = inout_dir[1] + '\\spot_price_' + head_HHMM + '-' + tail_HHMM

for strftime1, strftime2, period, resample in period_list:
    # all average
    df_all = df_master.resample(resample, label='left').mean()
    df_all.to_csv(file_head + '_' + period + '.csv')

for clm, name in clm_list:
    # all average in each time
    df_all_30min = df_master.groupby(clm).mean()
    if clm == 'timezone':
        df_all_30min = df_all_30min.reindex(index=['night', 'morning', 'afternoon', 'evening'])
    df_all_30min.to_csv(file_head + '_' + name + '_all.csv')

    for strftime1, strftime2, period, resample in period_list:
        # all average in each month, year
        df_period = df_master.copy()
        df_period['timestamp'] = df_period.index
        df_period[strftime1] = df_period['timestamp'].dt.strftime(strftime2)
        #if clm == 'timezone' and strftime1 == 'yyyy/mm':
        #    df_period['yyyy'] = df_period['timestamp'].dt.strftime('%Y')
        df_period = df_period.groupby(by=[strftime1, clm], sort=False).mean()
        #if clm == 'timezone':
        #    if strftime1 == 'yyyy/mm':
        #        df_period = df_period.sort_values(by=['yyyy', strftime1, clm], key=lambda col: col.map(d_order))
        #    else:
        #        df_period = df_period.sort_values(by=[strftime1, clm], key=lambda col: col.map(d_order))
        df_period.to_csv(file_head + '_' + name + '_' + period + '.csv')

print('finish')