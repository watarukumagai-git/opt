#coding: utf-8 
import glob
import os
from os import path
import csv

import pandas as pd
from tabula import read_pdf

def my_makedirs(path):
    if not os.path.isdir(path):
        os.makedirs(path)

def get_dir(dir_base):
    input_dir = dir_base + '\\input'
    output_dir = dir_base + '\\output'
    my_makedirs(input_dir)
    my_makedirs(output_dir)
    return input_dir, output_dir

def get_file_list(dir):
    file_list = glob.glob(dir)
    for i, file in enumerate(file_list):
        file_list[i] = file.rsplit('\\', 1)[1]
    print(file_list)
    return file_list

def text_csv_converter(datas): # datasはテキストファイルの場所
    # 保存するCSVファイルの場所
    file_csv = datas.replace("txt", "csv")
   
    # テキストファイルを開く
    with open(datas)as rf:
        # 書き込むＣＳＶファイルを開く
        with open(file_csv, "w")as wf:
            # テキストを１行ずつ読み込む
            # テキストの１行を要素としたlistになる
            readfile = rf.readlines()
           
            for read_text in readfile:
                # listに分割
                read_text = read_text.split()
                # csvに書き込む
                writer = csv.writer(wf, delimiter=',')
                writer.writerow(read_text)

dir_base = path.dirname( path.abspath(__file__) )
dfs = read_pdf(dir_base + "\\address.pdf", pages="6-10", lattice=True, encoding = "shift-jis")
output_dir = dir_base + '\\output0'
my_makedirs(output_dir)
for i, df in enumerate(dfs):
    print('count = ' + str(i))
    if i == 0:
        print(df.columns[0])
        print(df)
        #df.to_csv(output_dir + "\\list_" + str(i) + ".csv", line_terminator='\r')
        filename = output_dir + "\\list_" + str(i) + ".txt" 
        with open(filename, 'w') as f:
            f.write(df.columns[0])
        #text_csv_converter(filename)
    else:
        if df0.columns[0] != df.columns[0]:
            print(df.columns[0])
            print(df)
            filename = output_dir + "\\list_" + str(i) + ".txt" 
            df.to_csv(filename, index=False, sep='\t', encoding = "shift-jis")
    df0 = df.copy()


print('finish')