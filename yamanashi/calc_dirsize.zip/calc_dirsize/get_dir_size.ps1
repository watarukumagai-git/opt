﻿function GetDirSize{
    param (
        [Parameter(Mandatory = $true)]
        [string]$dirPath
    )

   # パスを出力します。
   Write-Host "calculate $dirPath Total size"

   # 合計サイズを保存するための変数を0で初期化します。
   $totalSize = 0
   
   # Get-ChildItem コマンドを使って、指定したディレクトリ内のすべてのアイテムを取得します。
   Get-ChildItem $dirPath -File -Recurse | ForEach-Object {
       try {
           # ファイルのサイズ（$_Length）をGB単位で取得し、それを合計サイズに加算します。
           $totalSize += $_.Length / 1GB
       } catch {
           # エラーが発生した場合の処理です。
           if ($_.Exception -is [System.UnauthorizedAccessException]) {
               Write-Host "-Error: Access is denied $($_.FullName)"
           } elseif ($_.Exception -is [System.IO.IOException]) {
               Write-Host "$($_.FullName) -Error: The directory is in use."
           } else {
               Write-Host "$($_.FullName) -Error: An unexpected error occurred."
           }
       }
   }
   
   # 桁数4で丸め
   $totalSize = [Math]::Round($totalSize, 4, [System.MidpointRounding]::AwayFromZero)
   # 合計サイズを出力します。
   Write-Host "$totalSize GB Total size"
   return $totalSize
}
