﻿function GetExcelFilePath{
    param (
        [Parameter(Mandatory = $true)]$fileName,
        $visible = $false
    )
   #Excelを開く
   $excel = New-Object -ComObject Excel.Application
   $book = $null
   $excel.Visible = $visible
   $excel.DisplayAlerts = $false
   #ブックを開く
   $FullPath = (Get-ChildItem -Path $filename).FullName
   $book = $excel.Workbooks.Open($FullPath)
   #シートの移動（1番目に移動）
   $currentSheet = $book.Sheets(1)
   $currentSheet.Move($book.Sheets(1))

   #セルの文字列を取得 D3:D100形式
   $dirPaths = $currentSheet.Range("D3:D100")
   $dirSizes = $currentSheet.Range("E3:E100")
   return $dirPaths, $dirSizes, $excel, $book, $currentSheet
}
