﻿$excelFileName = "bibi移行データ調査.xlsx"
. .\get_excel_filepath.ps1
$dirPaths, $dirSizes, $excel, $book, $currentSheet = GetExcelFilePath($excelFileName)

. .\get_dir_size.ps1
for ($i = 1; $i -le 100; $i++) {
  try {
      Write-Host "No. $i"
      $text1 = $currentSheet.Cells.Item(2 + $i,4).Text
      $text2 = $currentSheet.Cells.Item(2 + $i,5).Text
      if ($text1 -ne "" -and $text2 -eq "") {
          $dirPath = $dirPaths[$i].Text
          Write-Host "Path: $dirPath"
          $result = GetDirSize($dirPath)
          $currentSheet.Cells.Item(2 + $i,5).Value = $result
          $book.Save()
      }
      else {
          Write-Host "Path: $text1"
          Write-Host "Size: $text2"
      }
  } catch {
      Write-Host $Error[0]
  }
}
[void]$book.Close($false)
[void]$excel.Quit()
[void][System.Runtime.Interopservices.Marshal]::ReleaseComObject($excel)