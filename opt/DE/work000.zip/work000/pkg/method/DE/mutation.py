#coding: utf-8
import numpy as np
import pandas as pd
import random as rnd

class mutation_class:
    def __init__(self, F, x_):
        self.x = x_.copy()
        (self.m, self.N) = x_.shape
        self.F = F

    def rand(self, num_diff=1):
        child = np.copy(self.x)
        if num_diff == 1:
            idx_ori = np.arange(self.m)
            for i in range(0, self.m):
                idx = np.delete(idx_ori, np.where(idx_ori == i))
                r = np.random.choice(idx, size=3, replace=False)
                y = self.x[r[0],:]
                child[i, :] = y + self.F*(self.x[r[1],:] - self.x[r[2],:])
        return child

    def CP(self, rho, obj, num_diff=1):
        # obj: (m,), rank
        child = np.copy(self.x)
        num_better = np.max([self.m*rho, 2]).astype(int)
        better_idx = np.where(obj < num_better)[0]
        p = np.random.choice(better_idx, size=self.m, replace=True)
        if num_diff == 1:
            idx_ori = np.arange(self.m)
            for i in range(0, self.m):
                idx = np.delete(idx_ori, np.where(idx_ori == i))
                r = np.random.choice(idx, size=2, replace=False)
                y = self.x[i, :] + self.F*(self.x[p[i],:] - self.x[i,:])
                child[i, :] = y + self.F*(self.x[r[0],:] - self.x[r[1],:])
        return child