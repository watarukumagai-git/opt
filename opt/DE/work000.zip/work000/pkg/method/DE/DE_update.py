#coding: utf-8
import numpy as np
import pandas as pd
import random as rnd
import math
from ...sub_pkg.get_eval import get_obj_class
from ...sub_pkg.get_eval import get_vio_class
from ...sub_pkg.get_eval import scaling_class
from .crossover import crossover_class
from .mutation import mutation_class

class DE_class:
    def __init__(self, m, N, F, C, rho, mutation_type, crossover_type):
        self.mutation_type = mutation_type
        self.crossover_type = crossover_type
        self.rho = rho
        self.m = m
        self.N = N
        self.F = F
        self.C = C
    
    def modified_x(self, x_, x_ul, type_mod='round'):
        if type_mod == 'round':
            x_ = np.where(x_<x_ul[0,:], x_ul[0,:], x_)
            x_ = np.where(x_>x_ul[1,:], x_ul[1,:], x_)
        elif type_mod == 'reflect':
            x_ = np.where(x_<x_ul[0,:], x_ul[0,:] + np.abs(x_-x_ul[0,:]), x_)
            x_ = np.where(x_>x_ul[1,:], x_ul[1,:] - np.abs(x_ul[1,:]-x_), x_)
        elif type_mod == 'torus':
            x_ = np.where(x_<x_ul[0,:], x_ul[1,:] - np.abs(x_-x_ul[0,:]), x_)
            x_ = np.where(x_>x_ul[1,:], x_ul[0,:] + np.abs(x_ul[1,:]-x_), x_)
        elif type_mod == 'none':
            x_ = np.copy(x_)
        return x_
    
    def neighbor_gene(self, x_, obj_, x_ul):
  	    # x_: (m, N)
	    # obj_: (m,)
        num_diff = 1
        
        #mutation
        mutate = mutation_class(self.F, x_)
        if self.mutation_type == 'rand1':
            u = mutate.rand(num_diff=num_diff)
        elif self.mutation_type == 'CP1':
            u = mutate.CP(self.rho, obj_, num_diff=num_diff)


        #crossover
        xover = crossover_class(self.C, x_, u)
        if self.crossover_type == 'uniform':
            u = xover.Uniform()
        
        #modify
        mod_x = self.modified_x(u,x_ul,type_mod='round')
        
        return mod_x

    
    def S(self, obj, each_vio, fitness_type):
        # obj : (m, ), f  or (m, 2), [f, sum_v]
        # each_vio : (m, const), [v1, v2,,,,]
        # S : (m,)

        def _ranking(ele):
            rank = ele.argsort().argsort()
            return rank

        if fitness_type == 'object':
            if obj.ndim > 1:
                S = np.sum(0.5*obj, axis=1)
            else:
                S = obj
        elif fitness_type == 'MCR' and obj.ndim > 1:
            if each_vio.shape[1] > 1:
                eachvrank = np.array([_ranking(each_vio[:, i]) for i in range(0, each_vio.shape[1])])
                vrank = np.sum(eachvrank, axis=1)
                num_eachv = np.sum(np.where(each_vio > 0, 1, 0), axis=1)
            else:
                vrank = _ranking(each_vio[:, 0])
                num_eachv = np.where(each_vio[:, 0] > 0, 1, 0)
            numrank = _ranking(num_eachv)
            if np.any(obj[:, 1]==0):
                frank = _ranking(obj[:, 0])
                S = frank + vrank + numrank
            else:
                S = vrank + numrank
            S = _ranking(S)
        else:
            S = 0
        return S


    def selection(self, prob, x, obj, each_vio, x_nei):
        # calculate objective function and constraint violation of xnei
        # obj_nei: [f, f_eval, v_sum, v_eval]
        obj_nei = np.zeros((self.m, 4))
        obj_nei[:, 0] = get_obj_class().get_obj(prob, x_nei)
        (obj_nei[:, 2], each_vio_nei) = get_vio_class().get_vio(prob, x_nei)
        obj_nei[:, [1,3]] = obj_nei[:, [0,2]].copy()

        total_x = np.concatenate([x, x_nei])
        total_obj = np.concatenate([obj, obj_nei])
        total_each_vio = np.concatenate([each_vio, each_vio_nei])

        fitness = self.S(total_obj[:, [0,2]], total_each_vio, 'MCR')

        idx = np.where(fitness < self.m)
        if len(idx) > self.m:
            idx = idx[:self.m]
        x = np.squeeze(total_x[idx,:])
        obj = np.squeeze(total_obj[idx,:])
        each_vio = total_each_vio[idx,:][0]
        return x, obj, each_vio
    

    def DE_update(self, prob, x, obj, each_vio):
        # neiborhood generation
        fitness = self.S(obj, each_vio, fitness_type='MCR')
        x_nei = self.neighbor_gene(x, fitness, prob.x_ul)

        # survival choice
        (x, obj, each_vio) = self.selection(prob, x, obj, each_vio, x_nei)

        return x, obj, each_vio