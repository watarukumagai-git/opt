#coding: utf-8
import numpy as np
import pandas as pd
import random as rnd
import math

class weight_update_class:
    def __init__(self, m):
        self.m = m
        self.t = int(np.floor(0.8*m))

    def update_weight(self, alpha):
        delta = pow(10,-15)
        i_array = np.arange(self.m)/(self.m-1)
        # alpha is scalar
        if np.isscalar(alpha):
            # w (m, 2)
            w = alpha*i_array
            w = np.where(w==0, delta, w)
            w = w[:, np.newaxis]
            w = np.hstack((w, np.zeros((self.m, 1))))
            w[:, 1] = 1 - w[:, 0]
        # alpha is array (sample)
        else:
            # w (m, sample)
            w = np.dot(i_array[:, np.newaxis],alpha[:, np.newaxis].T)
            w = np.where(w==0, delta, w)
        return w

    def count_dominant(self, s, f):
        def superiority(f, s):
            num_obj = f.shape[0]
            m_ = f.shape[1]
            jj = np.arange(m_).tolist()
            jj.remove(s)
            a = np.where((f[0, s]>=f[0, jj]) & (f[1, s]>=f[1, jj]) & ((f[0, s]>f[0, jj]) | (f[1, s]>f[1, jj])), 1, 0)
            return a

        non_dominant_flag = superiority(f, s)
        if np.any(non_dominant_flag) == 1:
            dom = len(non_dominant_flag[non_dominant_flag == 1])
        else:
            dom = 0
        return dom

    
    def update_alpha(self, alpha_old, obj):
        gamma_u = 1.001
        gamma_d = 0.999
        # obj : (m, 2)
        # flag1 = 0 : x^s not in P, (f(s),v(s)) is dominant
        # flag1 = 1 : x^s in P,     (f(s),v(s)) is non-dominant
        # flag2 = 0 : x^t not in F
        # flag2 = 1 : x^t in F
        s = np.random.randint(0, self.m)
        dom = self.count_dominant(s, obj.T)

        # x^s is non-dominant and x^t not in F
        if dom == 0 and obj[self.t, 1] > 0:
            alpha = gamma_d * alpha_old
            alpha = np.max( [0.0, alpha] )
        else:
            alpha = gamma_u * alpha_old
            alpha = np.min( [1.0, alpha] )
        return alpha
    
