work000
MCR and DE
start 20220625
sphere, benchmark
min-max scaling
multi-run
trajectry in (f,v)