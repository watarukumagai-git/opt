#coding: utf-8
import numpy as np
import pandas as pd
import random as rnd
import math

class w_update_class:
    def __init__(self, m, iter_max, x_ul):
        self.m = m
        self.wmax = 1.0
        self.wmin = 0.5
        self.delta_w = 0.1

        xwidth = np.abs(np.max(x_ul[:, 1]) - np.min(x_ul[:, 0]))
        Istart = 0.25*xwidth
        Iend = 0.001*xwidth
        self.ideal_act = np.array([Istart*(Iend/Istart)**(iter/iter_max) for iter in range(0, iter_max)])

    def activity(self, v):
        # v: (m, N)
        return 1/(self.m*math.sqrt(v.shape[1]))*np.linalg.norm(v, axis=1, ord=2).sum()

    def update_w(self, w, v, iter):
        act = self.activity(v)
        if act <= self.ideal_act[iter]:
            w = np.min([w+self.delta_w, self.wmax])
        else:
            w = np.max([w-self.delta_w, self.wmin])
        return w    
