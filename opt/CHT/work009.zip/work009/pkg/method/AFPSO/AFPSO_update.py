#coding: utf-8
import numpy as np
import pandas as pd
import random as rnd
import math
from ...subpkg.get_eval import get_obj_class
from ...subpkg.get_eval import get_vio_class
from ...subpkg.get_eval import scaling_class
from ..modify_x import Modx

class x_update_class:
    def __init__(self, m, N, w):
        self.m = m
        self.N = N
        self.c1 = 1.4999
        self.c2 = 1.4999
        self.w = w
                
    def solution_update(self, x, v, x_pbest, x_gbest):
        r1 = np.random.rand(self.N)
        r2 = np.random.rand(self.N)
        v = self.w*v + self.c1*r1*(x_pbest-x) + self.c2*r2*(x_gbest-x)
        x = x + v
        return x, v

    def selection(self, prob, x, each_vio, x_pbest, obj_pbest):
        def get_scaling(prob, ori_value):
            values_eval_add = scaling_class().scaling_values(prob, ori_value)
            return values_eval_add[:self.m], values_eval_add[-1]

        # calculate objective function and constraint violation of xnei
        # obj_nei: [f, f_eval, v_sum, v_eval]
        # get obj: (m)
        obj = np.zeros(self.m, 4)
        obj[:, 0] = get_obj_class().get_obj(prob, x)
        # get vio_sum: (m)
        # each_vio: (m, g_num)
        type_vio = 'sum'
        (obj[:, 2], each_vio) = get_vio_class().get_vio(prob, x, type_vio)
        obj[:, [1,3]] = obj[:, [0,2]].copy()
        obj[:, 0] = obj[:, 0] + obj[:, 2]

        bool_ = np.where(obj_pbest[:, 0] > obj[:, 0])
        # obj_pbest: (m, 4)
        x_pbest[bool_, :] = x[bool_, :].copy()
        obj_pbest[bool_, :] = obj[bool_, :].copy()
        idx_gbest = np.argmin(obj_pbest, axis=0)
        x_gbest = x[idx_gbest, :].copy()
        obj_gbest = obj_pbest[idx_gbest, :].copy()
        return x, obj, each_vio, x_pbest, obj_pbest, x_gbest, obj_gbest
    

    def AFPSO_update(self, prob, x, obj, each_vio, x_pbest, obj_pbest, x_gbest):
        # mod_type: round, reflect, torus
        mod_type = 'reflect'
        mod = Modx(prob.load_pro.x_ul, type_mod=mod_type)
        
        (x,v) = self.solution_update(x, v, x_pbest, x_gbest)

        # modify
        x = mod.modified_x(x)

        # survival choice
        (x, obj, each_vio, x_pbest, obj_pbest, x_gbest, obj_gbest) = self.selection(prob, x, x_pbest, obj_pbest)
        return x, obj, each_vio, x_pbest, obj_pbest, x_gbest, obj_gbest