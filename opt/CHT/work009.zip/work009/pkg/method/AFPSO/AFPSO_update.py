#coding: utf-8
import numpy as np
from ...subpkg.get_eval import get_obj_class
from ..modify_x import Modx

class x_update_class:
    def __init__(self, m, N, w, alg_type):
        self.m = m
        self.N = N
        self.c1 = 1.4999
        self.c2 = 1.4999
        self.w = w
        self.alg_type = alg_type
                
    def solution_update(self, x, v, x_pbest, x_gbest, mod):
        r1 = np.random.rand(self.N)
        r2 = np.random.rand(self.N)
        if self.alg_type == 1:
            v = self.w*v + self.c1*r1*(x_pbest-x) + self.c2*r2*(x_gbest-x)
        elif self.alg_type == 2:
            C = np.cov(x_pbest.T)
            C = np.where(C<0, 0, C)
            (eigenvalue, A) = np.linalg.eig(C)
            L1 = np.dot(np.dot(A,np.diag(r1)),A.T)
            L2 = np.dot(np.dot(A,np.diag(r2)),A.T)
            for i in range(0, self.m):
                v[i, :] = self.w*v[i, :] + self.c1*np.dot(L1, x_pbest[i, :]-x[i, :]) + self.c2*np.dot(L2, x_gbest-x[i, :])
        x = x + v
        return x, v

    def selection(self, prob, x, x_pbest, obj_pbest):
        # calculate objective function and constraint violation of xnei
        # obj_nei: [f, f_eval, v_sum, v_eval]
        # get obj: (m)
        obj = get_obj_class().get_obj(prob, x)

        bool_ = np.where(obj_pbest > obj)
        # obj_pbest: (m, 4)
        x_pbest[bool_, :] = x[bool_, :].copy()
        obj_pbest[bool_] = obj[bool_].copy()
        idx_gbest = np.argmin(obj_pbest, axis=0)
        x_gbest = x[idx_gbest, :].copy()
        obj_gbest = obj_pbest[idx_gbest].copy()
        return x, obj, x_pbest, obj_pbest, x_gbest, obj_gbest
    

    def AFPSO_update(self, prob, x, obj, v, x_pbest, obj_pbest, x_gbest):        
        # mod_type: round, reflect, torus
        mod_type = 'none'
        mod = Modx(prob.x_ul, type_mod=mod_type)
        (x,v) = self.solution_update(x, v, x_pbest, x_gbest,mod)
        # modify
        x = mod.modified_x(x)
        # survival choice
        (x, obj, x_pbest, obj_pbest, x_gbest, obj_gbest) = self.selection(prob, x, x_pbest, obj_pbest)
        return x, obj, v, x_pbest, obj_pbest, x_gbest, obj_gbest