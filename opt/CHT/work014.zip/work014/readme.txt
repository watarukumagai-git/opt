work014
PSO and MOEA/D
benchmark
gbest only handling

# condition
Time = 12
N = 72
g_num = 36
xmin = 0
xmin = 3

# objective function
f(x) = (x1[t] + x4[t]).sum(t=1:Time)

# constraint function (facility)
g1(x[t]) = x1[t] + x2[t] - x3[t]; t=1:Time
g2(x[t]) = x4[t] + x5[t] - x6[t]; t=1:Time

# constraint function (demand)
g3(x[t]) = x3[t] + x6[t] - demand[t]; t=1:Time

# inequality constraints (facility)
-0.5 <= g1(x[t]) <= 0.5; t=1:Time
-0.5 <= g2(x[t]) <= 0.5; t=1:Time
v1(x[t]) = max(near(-0.5-g1(x[t]) or g1(x[t])-0.5) or 0)
v2(x[t]) = max(near(-0.5-g2(x[t]) or g2(x[t])-0.5) or 0)

# inequality constraints (demand)
 2.99 <= g3(x[t])+3 <= 3.01; t=1:Time
-0.01 <= g3(x[t])   <= 0.01; t=1:Time
v3(x[t]) = max(near(-0.01-g3(x[t]) or g3(x[t])-0.01) or 0)

# infeasible optimum
f(x*) = 0
xn[t]* = 0
g1(x*[t]) = 0
g2(x*[t]) = 0
g3(x*[t]) = -3
v1(x*[t]) = 0
v2(x*[t]) = 0
v3(x*[t]) = 2.99

# feasible optimum
x1[t] = 1
x2[t] = 1
x3[t] = 1.5
x4[t] = 1
x5[t] = 1
x6[t] = 1.5
f(x*) = 1*2*12 = 24
g1(x*[t]) = 0.5
g2(x*[t]) = 0.5
g3(x*[t]) = 1.5 + 1.5 - 3 = 0
v1(x*[t]) = 0
v2(x*[t]) = 0
v3(x*[t]) = 0

x1[t] = 0.9975
x2[t] = 0.9975
x3[t] = 1.495
x4[t] = 0.9975
x5[t] = 0.9975
x6[t] = 1.495
f(x*) = 0.9975*2*12 = 23.94
g1(x*[t]) = 0.9975 + 0.9975 - 1.495 = 0.5
g2(x*[t]) = 0.9975 + 0.9975 - 1.495 = 0.5
g3(x*[t]) = 1.495 + 1.495 - 3 = -0.01
v1(x*[t]) = 0
v2(x*[t]) = 0
v3(x*[t]) = 0