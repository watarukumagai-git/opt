#coding: utf-8
import numpy as np
from ....subpkg.get_eval import Superior

class x_update_class:
    def __init__(self, m, N, w, alg_type):
        self.m = m
        self.N = N
        self.c1 = 1.4999
        self.c2 = 1.4999
        self.w = w
        self.alg_type = alg_type
        self.cov_update_bool = True
                
    def solution_update(self, x_, v_, x_pbest_, x_gbest_, mod):
        def _get_P(X):
            (eigenvalue, P_) = np.linalg.eig(np.cov(X))
            if np.any(eigenvalue<=0):
                delta = pow(10, -16)
                eigenvalue = np.where(eigenvalue<=0, delta, eigenvalue)
                C_mod = np.dot(np.dot(P_,np.diag(eigenvalue)),P_.T)
                (eigenvalue, P_) = np.linalg.eig(C_mod)
                print('C is modified because its eigenvalue includes negative.')
            P_ = P_[np.argsort(-eigenvalue), :]
            return P_

        r1 = np.random.rand(self.N)
        r2 = np.random.rand(self.N)
        if self.alg_type == 1:
            v_ = self.w*v_ + self.c1*r1*(x_pbest_-x_) + self.c2*r2*(x_gbest_-x_)
        elif self.alg_type == 2:
            if self.cov_update_bool:
                self.P = _get_P(x_pbest_.T)
            L1 = np.dot(np.dot(self.P,np.diag(r1)),self.P.T)
            L2 = np.dot(np.dot(self.P,np.diag(r2)),self.P.T)
            v_ = self.w*v_ + self.c1*np.dot(L1, (x_pbest_-x_).T).T + self.c2*np.dot(L2, (x_gbest_-x_).T).T
        #v_ = mod.modified_x(v_)
        x_ = x_ + v_
        return x_, v_


    def selection(self, prob, x__, obj__, x_pbest__, obj_pbest__, x_gbest__, obj_gbest__, mod):
        idx_ = Superior().get_sup_idx_array(obj_pbest__, obj__, prob.eval_type)
        if len(idx_) > 0:
            x_pbest__[idx_, :] = x__[idx_, :].copy()
            obj_pbest__[idx_, :] = obj__[idx_, :].copy()

            # gbest update
            idx_gbest = Superior().get_min_idx_array(obj_pbest__, prob.eval_type)
            x_gbest_pre = x_pbest__[idx_gbest, :].copy()
            #x_gbest_pre = mod.modified_x(x_gbest_pre)
            #obj_gbest_pre = Superior().eval_scaler(prob, x_gbest_pre)
            obj_gbest_pre = obj_pbest__[idx_gbest, :].copy()
            #if Superior().get_sup_bool_sca(obj_gbest__, obj_gbest_pre, prob.eval_type):
            if obj_gbest__[prob.eval_type-1] > obj_gbest_pre[prob.eval_type-1]:
                x_gbest__ = x_gbest_pre.copy()
                obj_gbest__ = obj_gbest_pre.copy()
        return x_pbest__, obj_pbest__, x_gbest__, obj_gbest__
    

    def PSO_update(self, prob, x, v, x_pbest, obj_pbest, x_gbest, obj_gbest, mod):
        (x_,v_) = self.solution_update(x, v, x_pbest, x_gbest, mod)
        # obj: (m, 3)
        obj_ = Superior().eval_scaler(prob, x)
        # survival choice
        (x_pbest_, obj_pbest_, x_gbest_, obj_gbest_) = self.selection(prob, x_, obj_, x_pbest, obj_pbest, x_gbest, obj_gbest, mod)
        if self.alg_type == 2 and (x_pbest_ == x_pbest).all:
            self.cov_update_bool = False
        return x_, obj_, v_, x_pbest_, obj_pbest_, x_gbest_, obj_gbest_