#coding: utf-8
import numpy as np
from .PSO_v_update import PSO_v_update_class
from ....subpkg.get_eval import Superior

class x_update_class:
    def __init__(self, m, N, w, alg_type):
        self.m = m
        self.N = N
        self.c1 = 1.4955
        self.c2 = self.c1
        self.alg_type = alg_type
        self.cov_update_bool = True
        self.w = w
                
    def solution_update(self, x_, v_, x_pbest_, x_gbest_, mod):
        PSO_instance = PSO_v_update_class(self.w, self.c1, self.c2)
        if self.alg_type == 1:
            v__ = PSO_instance.PSO_v_update(x_, v_, x_pbest_, x_gbest_)
        elif self.alg_type == 2:
            if self.cov_update_bool:
                self.P = PSO_instance.get_P(x_pbest_.T)
            v__ = PSO_instance.CRIPSO_v_update(x_, v_, x_pbest_, x_gbest_, self.P)
        #v_ = mod.modified_x(v_)
        x__ = x_ + v__
        return x__, v__

    def selection(self, prob, x__, obj__, x_pbest__, obj_pbest__, x_gbest__, obj_gbest__):
        idx_ = Superior().get_sup_idx_array(obj_pbest__, obj__, prob.eval_type)
        if len(idx_) > 0:
            obj_pbest__[idx_, :] = obj__[idx_, :].copy()
            x_pbest__[idx_, :] = x__[idx_, :].copy()

            idx_gbest = Superior().get_min_idx_array(obj_pbest__, prob.eval_type)
            obj_gbest_pre = obj_pbest__[idx_gbest, :].copy()
            x_gbest_pre = x_pbest__[idx_gbest, :].copy()
            if Superior().get_sup_bool_sca(obj_gbest__, obj_gbest_pre, prob.eval_type):
                obj_gbest__ = obj_gbest_pre.copy()
                x_gbest__ = x_gbest_pre.copy()
        return x_pbest__, obj_pbest__, x_gbest__, obj_gbest__

    def PSO_update(self, prob, x, v, x_pbest, obj_pbest, x_gbest, obj_gbest, mod):
        (x_, v_) = self.solution_update(x, v, x_pbest, x_gbest, mod)
        obj_ = Superior().eval_scaler(prob, x_)

        (x_pbest_, obj_pbest_, x_gbest_, obj_gbest_) = self.selection(prob, x_, obj_, x_pbest, obj_pbest, x_gbest, obj_gbest)
        if self.alg_type == 2:
            self.cov_update_bool = (x_pbest_ != x_pbest).any
        return x_, obj_, v_, x_pbest_, obj_pbest_, x_gbest_, obj_gbest_