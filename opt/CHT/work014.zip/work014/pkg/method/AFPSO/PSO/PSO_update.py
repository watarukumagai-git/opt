#coding: utf-8
import numpy as np
from ....subpkg.get_eval import Superior
from ....subpkg.get_eval import get_obj_class
from ....subpkg.get_eval import get_vio_class

class x_update_class:
    def __init__(self, m, N, w, alg_type):
        self.m = m
        self.N = N
        self.c1 = 1.4955
        #self.c1 = 0.4955
        self.c2 = self.c1
        self.w = w
        self.alg_type = alg_type
        self.cov_update_bool = True
                
    def solution_update(self, x_, v_, x_pbest_, x_gbest_, mod):
        def _get_P(X):
            (eigenvalue, P_) = np.linalg.eig(np.cov(X))
            if np.any(eigenvalue<=0):
                delta = pow(10, -16)
                eigenvalue = np.where(eigenvalue<=0, delta, eigenvalue)
                C_mod = np.dot(np.dot(P_,np.diag(eigenvalue)),P_.T)
                (eigenvalue, P_) = np.linalg.eig(C_mod)
                print('C is modified because its eigenvalue includes negative.')
            P_ = P_[np.argsort(-eigenvalue), :]
            return P_

        v__ = np.zeros((self.m, self.N))
        r = np.random.rand(self.m, self.N, 2)
        if self.alg_type == 1:
            v__ = self.w*v_ + self.c1*r[:, :, 0]*(x_pbest_-x_) + self.c2*r[:, :, 1]*(x_gbest_-x_)
        elif self.alg_type == 2:
            if self.cov_update_bool:
                self.P = _get_P(x_pbest_.T)
            for i in range(0, self.m):
                L1 = np.dot(np.dot(self.P,np.diag(r[i, :, 0])),self.P.T)
                L2 = np.dot(np.dot(self.P,np.diag(r[i, :, 1])),self.P.T)
                v__[i, :] = self.w*v_[i, :] + self.c1*np.dot(L1, (x_pbest_[i, :]-x_[i, :]).T).T + self.c2*np.dot(L2, (x_gbest_-x_[i, :]).T).T
        #v_ = mod.modified_x(v_)
        x__ = x_ + v__
        return x__, v__


    def selection_(self, prob, x__, obj__, x_pbest__, obj_pbest__, x_gbest__, obj_gbest__, mod):
        #idx_ = Superior().get_sup_idx_array(obj_pbest__, obj__, prob.eval_type)
        idx_ = np.where(obj_pbest__[:, prob.eval_type-1] > obj__[:, prob.eval_type-1])[0]
        if len(idx_) > 0:
            x_pbest__[idx_, :] = x__[idx_, :].copy()
            obj_pbest__[idx_, :] = obj__[idx_, :].copy()

            # gbest update
            #idx_gbest = Superior().get_min_idx_array(obj_pbest__, prob.eval_type)
            #x_gbest_pre = mod.modified_x(x_gbest_pre)
            #obj_gbest_pre = Superior().eval_scaler(prob, x_gbest_pre)
            idx_gbest = np.argmin(obj_pbest__[:, prob.eval_type-1])
            x_gbest_pre = x_pbest__[idx_gbest, :].copy()
            obj_gbest_pre = obj_pbest__[idx_gbest, :].copy()
            #if Superior().get_sup_bool_sca(obj_gbest__, obj_gbest_pre, prob.eval_type):
            if obj_gbest__[prob.eval_type-1] > obj_gbest_pre[prob.eval_type-1]:
                x_gbest__ = x_gbest_pre.copy()
                obj_gbest__ = obj_gbest_pre.copy()
        return x_pbest__, obj_pbest__, x_gbest__, obj_gbest__
    
    def selection(self, prob, x__, obj__, x_pbest__, obj_pbest__):
        # calculate objective function and constraint violation of xnei
        # obj_nei: [f, f_eval, v_sum, v_eval]
        # get obj: (m)
        bool_ = np.where(obj_pbest__[:, prob.eval_type-1] > obj__[:, prob.eval_type-1])
        # obj_pbest: (m, 4)
        x_pbest__[bool_, :] = x__[bool_, :].copy()
        obj_pbest__[bool_, :] = obj__[bool_, :].copy()
        idx_gbest = np.argmin(obj_pbest__[:, prob.eval_type-1])
        x_gbest = x__[idx_gbest, :].copy()
        obj_gbest = obj_pbest__[idx_gbest, :].copy()
        return x_pbest__, obj_pbest__, x_gbest, obj_gbest

    def PSO_update(self, prob, x, v, x_pbest, obj_pbest, x_gbest, obj_gbest, mod):
        (x_,v_) = self.solution_update(x, v, x_pbest, x_gbest, mod)
        # obj: (m, 3)
        #obj_ = Superior().eval_scaler(prob, x)
        obj_ = np.zeros((self.m, 3))
        obj_[:, 0] = get_obj_class().get_obj(prob, x_)
        obj_[:, 1] = get_vio_class().get_each_vio(prob, x_)
        obj_[:, 2] = obj_[:, 1] + obj_[:, 0]
        # survival choice
        #(x_pbest_, obj_pbest_, x_gbest_, obj_gbest_) = self.selection(prob, x_, obj_, x_pbest, obj_pbest, x_gbest, obj_gbest, mod)
        (x_pbest_, obj_pbest_, x_gbest_, obj_gbest_) = self.selection(prob, x_, obj_, x_pbest, obj_pbest)
        if self.alg_type == 2 and (x_pbest_ == x_pbest).all:
            self.cov_update_bool = False
        return x_, obj_, v_, x_pbest_, obj_pbest_, x_gbest_, obj_gbest_