#coding: utf-8
import numpy as np
from ....subpkg.get_eval import get_obj_class
from ....subpkg.get_eval import get_vio_class

class x_update_class:
    def __init__(self, m, N, w, alg_type):
        self.m = m
        self.N = N
        self.c1 = 1.4999
        self.c2 = 1.4999
        self.w = w
        self.alg_type = alg_type
                
    def solution_update(self, x, v, x_pbest, x_gbest):
        r1 = np.random.rand(self.N)
        r2 = np.random.rand(self.N)
        if self.alg_type == 1:
            v = self.w*v + self.c1*r1*(x_pbest-x) + self.c2*r2*(x_gbest-x)
        elif self.alg_type == 2:
            C = np.cov(x_pbest.T)
            C = np.where(C<0, 0, C)
            (eigenvalue, A) = np.linalg.eig(C)
            L1 = np.dot(np.dot(A,np.diag(r1)),A.T)
            L2 = np.dot(np.dot(A,np.diag(r2)),A.T)
            for i in range(0, self.m):
                v[i, :] = self.w*v[i, :] + self.c1*np.dot(L1, x_pbest[i, :]-x[i, :]) + self.c2*np.dot(L2, x_gbest-x[i, :])
        x = x + v
        return x, v

    def eval_scaler(self, prob, x):
        if x.ndim > 1:
            obj = np.zeros((x.shape[0], 3))
            obj[:, 0] = get_obj_class().get_obj(prob, x)
            (obj[:, 1], each_vio) = get_vio_class().get_vio(prob, x)
            obj[:, 2] = obj[:, 0] + obj[:, 1]
        else:
            obj = np.zeros(3)
            obj[0] = get_obj_class().get_obj(prob, x)
            (obj[1], each_vio) = get_vio_class().get_vio(prob, x)
            obj[2] = obj[0] + obj[1]
        return obj

    def selection(self, prob, x, obj, x_pbest, obj_pbest, x_gbest, obj_gbest, mod):
        # obj_nei: [f, f_eval, v_sum, v_eval]
        bool_ = np.where(obj_pbest[:, 2] > obj[:, 2])
        x_pbest[bool_, :] = x[bool_, :].copy()
        obj_pbest[bool_, :] = obj[bool_, :].copy()

        # gbest update
        x_gbest_pre = mod.modified_x(x_pbest[np.argmin(obj_pbest[:, 2], axis=0), :])
        obj_gbest_pre = self.eval_scaler(prob, x_gbest_pre)
        if obj_gbest[2] > obj_gbest_pre[2]:
            x_gbest = x_gbest_pre.copy()
            obj_gbest = obj_gbest_pre.copy()
        return x_pbest, obj_pbest, x_gbest, obj_gbest
    

    def PSO_update(self, prob, x, v, x_pbest, obj_pbest, x_gbest, obj_gbest, mod):        
        (x,v) = self.solution_update(x, v, x_pbest, x_gbest)
        # obj: (m, 2)
        obj = self.eval_scaler(prob, x)
        # survival choice
        (x_pbest, obj_pbest, x_gbest, obj_gbest) = self.selection(prob, x, obj, x_pbest, obj_pbest, x_gbest, obj_gbest, mod)
        return x, obj, v, x_pbest, obj_pbest, x_gbest, obj_gbest