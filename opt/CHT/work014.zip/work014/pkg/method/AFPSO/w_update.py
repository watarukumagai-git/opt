#coding: utf-8
import numpy as np
import math

class w_update_class:
    def __init__(self, m, iter_max, x_ul):
        self.m = m
        self.N = x_ul.shape[0]
        self.wmax = 1.0
        #self.wmax = 0.729
        self.wmin = 0.5
        self.delta_w = 0.1

        # linear, exp
        ideal_type = 'exp'
        #xwidth = np.abs(np.max(x_ul[:, 1]) - np.min(x_ul[:, 0]))
        xwidth = np.linalg.norm(x_ul[:, 1] - x_ul[:, 0], ord=2)/math.sqrt(self.N)
        Istart = 0.25*xwidth
        Iend = 0.001*xwidth
        iter_box =np.arange(iter_max)
        if ideal_type == 'linear':
            iter_end = 0.95 * iter_max
            self.ideal_act = Istart*(1-iter_box/iter_end)
            self.ideal_act = np.where(self.ideal_act<0, 0, self.ideal_act)
        elif ideal_type == 'exp':
            self.ideal_act = np.array([Istart*(Iend/Istart)**(iter/iter_max) for iter in iter_box])


    def update_w(self, w_, v, iter):
        def _activity(self, v_):
            # v: (m, N)
            return np.linalg.norm(v_, axis=1, ord=2).mean()/math.sqrt(self.N)
        act = _activity(self, v)
        #w = w_
        w = w_ + np.sign(self.ideal_act[iter] - act)*self.delta_w
        if w > self.wmax:
            w = self.wmax
        elif w < self.wmin:
            w = self.wmin
        return w, act