#coding: utf-8
import numpy as np
import math

class Function:
    def __init__(self, problem_type, N, scaling_type, d_exp):
        self.problem_type = problem_type
        self.N = N
        self.scaling_type = scaling_type
        self.d = pow(10, d_exp)
        self.x_ul = np.ones((self.N, 2))
        self.x_ul[:, 0] = -5 * self.x_ul[:, 0]
        self.x_ul[:, 1] = 5 * self.x_ul[:, 1]

    def basis_func(self, func_type, x):
        # x: (N,)
        if func_type == 1:
            return np.power(x, 2)
        if func_type == 2:
            return np.cos(2*np.pi*x)

    def get_opt(self):
        if self.problem_type <= 3:
            x_opt = 1-math.sqrt(self.d)*np.ones(self.N)
        elif self.problem_type == 4:
            x_opt = 0.25-math.sqrt(self.d)*np.ones(self.N)
        else:
            x_opt = np.zeros(self.N)
            print('problem number is not preset.')
        f_opt = (x_opt[0])**2
        return x_opt, f_opt

    def basis_func(self, func_type, x, c):
        # x: (N,)
        # c: (N,)
        # func_type 1: sphere
        if func_type == 1:
            f =  np.sum(np.power(x-c, 2))/self.N
        elif func_type == 2:
            f =  np.sum(np.power(x, 4)) - 16 * np.sum(np.power(x, 2)) + 5 * np.sum(x)
        return f

    def object_function(self, x__):
        if self.problem_type <= 4:
            return np.sum(self.basis_func(1, x__))/self.N

    def get_oneside_vio(self, g_equal, lower, upper):
        return np.where((lower + upper)/2>=g_equal, lower - g_equal, g_equal - upper)

    def relax_const(self, eval_const, x, coef, lower, upper):
        """
        relax for constarint functions.

        Parameters
        ----------
        eval_const : object
            constraint function
        x : double (num_feat, Time)
            solution
        coef : double (num_feat+1,)
            coefficient and bias for x
        lower : double (Time,)
            lower for x
        upper : double (Time,)
            upper for x

        Returns
        -------
        g_inequal : double (Time,)
            inequality constarints relaxed by lower/upper
        """
        # g_equal: (Time,)
        if x.ndim > 1:
            g_equal = np.array([eval_const(1, x[:, t], coef) for t in range(0, x.shape[1])]).T
        else:
            g_equal = np.array([eval_const(1, x[t], coef[t]) for t in range(0, len(x))])
        g_inequal = self.get_oneside_vio(g_equal, lower, upper)
        return g_inequal

    def get_vio_minmax(self, x__):
        # x__ : (N,)
        g_minmax = self.get_oneside_vio(x__, self.load_pro.x_ul[:,0], self.load_pro.x_ul[:,1])
        return g_minmax

    def constraint_function(self, x__):
        def _g1(x__, d):
            return np.sum(self.basis_func(1, x__-1))/self.N - d

        if self.problem_type == 1:
            a = _g1(x__, self.d)
            return a
        elif self.problem_type == 2:
            a = _g1(x__, self.d)
            return math.exp(10*a)-1
        elif self.problem_type == 3:
            a = _g1(x__, self.d)
            return np.sign(a) * np.power(abs(a), 1/4)
        elif self.problem_type == 4:
            a = - np.sum(self.basis_func(2, x__ - 0.25))/self.N
            return a + self.basis_func(2, math.sqrt(self.d))
        else:
            return a