# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
import math
import os
from os import path
import matplotlib.pyplot as plt
plt.rcParams['font.family'] = 'Times New Roman'

def scaled_trend(figure_label, x, y, fig_file_name):
    x_label_name = figure_label[0]
    y_label_name = figure_label[1]
    #y_min = figure_label[2]
    #y_max = figure_label[3]
    m = y.shape[1]
    cmap = plt.get_cmap("jet")

    fig = plt.figure(figsize=(6,4))
    fig.patch.set_facecolor('white')
    ax = fig.add_subplot(1,1,1)
    for i in range(0, m):
        clist = float(i)/m
        ax.plot(x, y[:, i], fillstyle='none', marker='.', markersize = 1, markeredgewidth=0.1, markeredgecolor=cmap(clist), lw=0)
        #ax.plot(x, y[:, i], fillstyle='none', marker='.', markeredgewidth=0.2, markeredgecolor=cmap(clist), lw=0.5)

    ax.set_xlabel(x_label_name, fontsize=16)
    ax.set_ylabel(y_label_name, fontsize=16)
    ax.tick_params(labelsize=12)
    #ax.set_ylim([y_min, y_max])

    plt.tick_params(labelsize=12, direction = "in")
    plt.tight_layout()
    plt.savefig(fig_file_name, bbox_inches="tight")


def get_path(path_):
    work_path = path.dirname( path.abspath(__file__) )
    os.chdir(work_path)
    #work_path = os.path.abspath('..\\..\\') 
    dir_base = work_path + '\\output\\pro1\\' + path_
    return dir_base


alg_type = 2
path_ = 'alg_type' + str(alg_type) + '\\eval_type4'
run_max = 1
dir_base = get_path(path_)


figure_label1 = ["iteration: $k$", "$F$"]
figure_label2 = ["iteration: $k$", "$Cr$"]

df = pd.read_csv(dir_base + '\\file\\C_run0.csv', index_col=0)
iter_max = len(df)
m = df.shape[1]

for run in range(0, run_max):
    F_box = pd.read_csv(dir_base + '\\file\\F_run' + str(run) + '.csv', index_col=0).values
    C_box = pd.read_csv(dir_base + '\\file\\C_run' + str(run) + '.csv', index_col=0).values
    
    fig_file_name = dir_base + '\\fig\\F_run'+ str(run) + '.png'
    scaled_trend(figure_label1, 
                 range(0, iter_max), 
                 F_box, 
                 fig_file_name)

    fig_file_name = dir_base + '\\fig\\C_run'+ str(run) + '.png'
    scaled_trend(figure_label2, 
                 range(0, iter_max), 
                 C_box, 
                 fig_file_name)