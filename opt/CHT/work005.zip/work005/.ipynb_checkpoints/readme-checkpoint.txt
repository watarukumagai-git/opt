work005
MOEA/D and adaptive weight
start 20220514
sphere, benchmark
min-max scaling
multi-run
trajectry in (f,v)