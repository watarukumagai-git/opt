#coding: utf-8
import numpy as np
import random as rnd
import math

class LoadProblemClass:
    def __init__(self, problem_type_, flag_pattern_):
        self.problem_type = problem_type_
        self.flag_pattern = flag_pattern_
        self.g_num = 0
        self.deadtime = 0


    def load_problem(self, param_df):
        Time_start = 15
        self.delta_t = 8
        self.Time = self.delta_t-1 + Time_start

        (no_cost, self.no_feat_fac, num_equ_fac, self.no_feat_demand, self.no_feat_storage) = self.get_problem_parameter()
        
        # bigdim: 6 * (8 + 1) = 48
        self.bigN = self.num_feat_total * self.delta_t
        print('delta_t =', self.delta_t)

        # upper/lower/pattern
        min_clm = [i + '_Min' for i in self.ID_list]
        max_clm = [i + '_Max' for i in self.ID_list]
        pattern_clm = [i + '_Pattern' for i in self.ID_list]
        demand_clm = [i + '_Demand' for i in self.ID_list]
        seedflag_clm = [i + '_SeedFlag' for i in self.ID_list]
        if self.delta_t == 1:
            min_df = param_df.loc[Time_start, min_clm]
            max_df = param_df.loc[Time_start, max_clm]
            self.pattern = param_df.loc[Time_start, pattern_clm].values
            self.seedflag = param_df.loc[Time_start, seedflag_clm].values
        else:
            min_df = param_df.loc[Time_start:self.Time, min_clm]
            max_df = param_df.loc[Time_start:self.Time, max_clm]
            self.pattern = param_df.loc[Time_start:self.Time, pattern_clm].values
            self.seedflag = param_df.loc[Time_start:self.Time, seedflag_clm].values

        # index_array: (num_free, 2), [row_index, column_index] (num_feat, delta_t)
        index_array = list(zip(*np.where(self.seedflag.T==0)))
        self.N = len(index_array)

        # [x1[0],x1[1],x1[2],x2[0],x2[1],x2[1],....]
        self.pattern = self.pattern.T.reshape(self.bigN)
        self.seedflag = self.seedflag.T.reshape(self.bigN)

        # [min, max]
        self.bigx_ul = np.ones((self.bigN, 2))
        self.bigx_ul[:,0] = min_df.values.T.reshape(self.bigN)
        self.bigx_ul[:,1] = max_df.values.T.reshape(self.bigN)

        # [min, max]
        if np.any(self.seedflag==1):
            idx = np.where(self.seedflag == 0)
            self.x_ul = self.bigx_ul[idx,:][0]
        else:
            self.x_ul = self.bigx_ul


        # cost: (num_feat_total, Time)
        # ['ID300', 'ID310', 'ID320', 'ID330', 'ID350']
        c = np.zeros((self.num_feat_total, self.delta_t))
        #c = c.reshape(self.N)
        #    c[0*33:1*33] = 1036881
        #    c[1*33:2*33] = 0
        #    c[2*33:3*33] = 445.41
        #    c[3*33:4*33] = 320.51
        #    c[4*33:5*33] = 85.047
        #    c[5*33:6*33] = 463.584

        # facility coef: (num_fac, num_unit_feat)
        fac_coef = [[float(item) for item in iteml] for iteml in self.no_feat_fac]
        # facility coef: (num_fac, num_equ_fac, num_unit_feat)
        for i in range(0, self.num_fac):
            if i == 0:
                fac_coef[i] = np.array([-0.512, 1.110, -0.363, -11.76])
            elif i == 1:
                fac_coef[i] = np.array([12.4189728599085, 0, 0.254164912405956, 0.223068753791219, 3.69971072950631, -829.8])

        # demand: (num_demand, Time)
        demand = np.zeros((self.num_demand, self.delta_t))
        if self.delta_t == 1:
            for i in range(0, self.num_demand):
                for j in self.no_feat_demand[i]:
                    demand[i, :] = param_df.loc[Time_start-1, demand_clm[j]]
        else:
            for i in range(0, self.num_demand):
                for j in self.no_feat_demand[i]:
                    demand[i, :] = param_df.loc[Time_start-1:self.Time-1, demand_clm[j]].values.T

        return c, demand, fac_coef


    def get_problem_parameter(self):
        # x1: ID300
        # x2: ID310
        # x3: ID320
        # x4: ID330
        # x5: ID350
        if self.problem_type <= 6:
            self.num_feat_total = 5
            no_cost = [1, 2, 3, 4]
            no_feat_fac = [[1, 2, 3],
                           [0, 1, 2, 3, 4]]
            num_equ_fac = [1, 1]
            no_feat_demand = [[0]]
            no_feat_storage = []
            self.ID_list = ['ID300', 'ID310', 'ID320', 'ID330', 'ID350']
            self.deadtime = [14, 19, 16, 14, 19]
            self.no_diff = [0, 1, 2, 3, 4]
        else:
            self.num_feat_total = 1
            no_cost = []
            no_feat_fac = []
            no_feat_demand = []
            no_feat_storage = []
            self.ID_list = []
            self.deadtime = []

        # num_feature at facility
        self.num_fac = len(no_feat_fac)
        # num_feature at demand
        self.num_demand = len(no_feat_demand)
        # num_feature at storage
        self.num_storage = len(no_feat_storage)

        return no_cost, no_feat_fac, num_equ_fac, no_feat_demand, no_feat_storage