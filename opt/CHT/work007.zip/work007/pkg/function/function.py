#coding: utf-8
import numpy as np
import random as rnd
import math

class Function:
    def __init__(self, load_pro, scaling_type, cost, demand, fac_coef):
        self.load_pro = load_pro
        self.problem_type = load_pro.problem_type
        self.N = load_pro.N
        self.scaling_type = scaling_type
        self.g_num = 0
        self.cost = cost
        self.demand = demand
        self.fac_coef = fac_coef
        if self.problem_type == 1 or self.problem_type == 2:
            diff_min = [-1, -0.1, -1.12135469418, -1.73241069435, -5.4145845649, -0.06]
            diff_max = [1, 0.1, 1.0093494688464, 2.029696457169, 5.6462835057309, 0.06]
            self.epsilon_fac = [0.4608, 0.391646879364331, 3.6861]
        elif self.problem_type == 3 or self.problem_type == 4:
            diff_min = [-1, -0.1, -1.12135469418, -1.73241069435, -5.4145845649, -0.06]
            diff_max = [1, 0.1, 1.0093494688464, 2.029696457169, 5.6462835057309, 0.06]
            self.epsilon_fac = [0.4608, 0.391646879364331, 0.1]
        elif self.problem_type == 5 or self.problem_type == 6:
            diff_min = [-1, -0.1, -1.12135469418, -1.73241069435, -5.4145845649, -0.06]
            diff_max = [1, 0.1, 1.0093494688464, 2.029696457169, 5.6462835057309, 0.06]
            self.epsilon_fac = [0.4608, 0.391646879364331, 3.6861]
        self.diff_minmax = [[i, j] for i, j in zip(diff_min, diff_max)]
    
    def convert_x_to_schedule(self, x_):
        # x: (N, 1)
        # schedule: (num_feat_total, delta_t)
        if np.any(self.load_pro.seedflag==1):
            schedule = np.where(self.load_pro.seedflag, self.load_pro.pattern, -999)
            schedule[schedule == -999] = x_
            schedule = schedule.reshape(self.load_pro.num_feat_total, self.load_pro.delta_t)
        else:
            schedule = x_.reshape(self.load_pro.num_feat_total, self.load_pro.delta_t)
        return schedule

    def convert_schedule_to_x(self, schedule):
        # schedule: (num_feat_total, delta_t)
        # x: (N, 1)
        if np.any(self.load_pro.seedflag==1):
            x_ = np.delete(schedule.reshape(self.N), np.where(self.load_pro.seedflag == 1))
        else:
            x_ = schedule.reshape(self.N)
        return x_

    def get_opt(self):
        if self.problem_type == 1 or self.problem_type == 2 or self.problem_type == 3:
            ep_f1_list = [0.5, 0.01, 0]
            ep_f1 = ep_f1_list[self.problem_type-1]
            ep_f2 = 0.1
            ep_d = 0.01
            de = 3
            eta = (de-ep_d)/6
            x_opt = np.zeros((self.load_pro.num_feat_total, self.load_pro.Time))
            for i in range(0, self.load_pro.num_feat_total):
                if i == 0 or i == 3:
                    x_opt[i, :] = 2*eta - (2*ep_f1 + ep_f2)/3
                elif i == 1 or i == 4:
                    x_opt[i, :] = eta + (ep_f2 - ep_f1)/3
                else:
                    x_opt[i, :] = 3*eta
            #obj_opt = 15.12, 22.96, 23.12
            obj_opt = (x_opt[0, :] + x_opt[3, :]).sum()
            x_opt = x_opt.reshape(self.N)
        else:
            obj_opt = 0
            x_opt = np.zeros(self.N)
            print('problem number is not preset.')
        return obj_opt, x_opt

    def basis_func(self, func_type, x, c):
        # x: (N,)
        # c: (N,) or (N+1,)
        # func_type 1: linear
        if func_type == 1:
            if x.ndim >= 1:
                if len(c) == len(x):
                    f =  np.sum(c*x)
                else:
                    f =  np.sum(c[:-1]*x) + c[-1]
            else:
                f = c*x
        return f

    def object_function(self, x__):
        def _penalty(x_2D, pcoef):
            pattern_2D = self.load_pro.pattern.reshape(self.load_pro.num_feat_total, self.load_pro.delta_t)
            target = np.array([pattern_2D[1, t] if t <= self.load_pro.deadtime[1]+1 else self.demand[0, t] for t in range(0, self.load_pro.delta_t) ])
            pepsilon = [0.01]
            g = pcoef * np.sum(self.get_vio_demand(x_2D[1,:], np.ones(self.load_pro.delta_t), pepsilon, target))
            return np.max([g, 0])

        # input
        # x__: (N_, )
        # output
        # f: float
        c = self.cost.reshape(self.load_pro.bigN)
        x_2D = self.convert_x_to_schedule(x__)
        f1 = self.basis_func(1, x_2D.reshape(self.load_pro.bigN), c)

        # ID100 penalty for target
        pcoef = np.power(10, 2)
        f2 = _penalty(x_2D, pcoef)
        f = f1 + f2
        return f

    def get_oneside_vio(self, g_equal, lower, upper):
        return np.where((lower + upper)/2>=g_equal, lower - g_equal, g_equal - upper)

    def relax_const(self, eval_const, x, coef, lower, upper):
        """
        relax for constarint functions.

        Parameters
        ----------
        eval_const : object
            constraint function
        x : double (num_feat, Time)
            solution
        coef : double (num_feat+1,)
            coefficient and bias for x
        lower : double (Time,)
            lower for x
        upper : double (Time,)
            upper for x

        Returns
        -------
        g_inequal : double (Time,)
            inequality constarints relaxed by lower/upper
        """
        # g_equal: (Time,)
        if x.ndim > 1:
            g_equal = np.array([eval_const(1, x[:, t], coef) for t in range(0, x.shape[1])]).T
        else:
            g_equal = np.array([eval_const(1, x[t], coef[t]) for t in range(0, len(x))])
        g_inequal = self.get_oneside_vio(g_equal, lower, upper)
        return g_inequal

    def get_vio_minmax(self, x__):
        # x__ : (N,)
        g_minmax = self.get_oneside_vio(x__, self.load_pro.x_ul[:,0], self.load_pro.x_ul[:,1])
        return g_minmax

    def get_vio_fac(self, x_2D, coef, epsilon):
        # x_2D: (num_feat, Time)
        # coef: (num_feat+1,)
        lower = -epsilon*np.ones(x_2D.shape[1])
        upper = epsilon*np.ones(x_2D.shape[1])
        # g_inequal : (Time,)
        g_inequal = self.relax_const(self.basis_func, x_2D, coef, lower, upper)
        return g_inequal

    def get_vio_demand(self, x_2D, coef, epsilon, demand):
        # x_2D: (num_feat, Time)
        # coef: (num_feat,)
        # demand: (Time,)
        lower = np.array([demand[t] - epsilon[0] for t in range(0,self.load_pro.delta_t)])
        upper = np.array([demand[t] + epsilon[0] for t in range(0,self.load_pro.delta_t)])
        # g_inequal : (Time,)
        g_inequal = self.relax_const(self.basis_func, x_2D, coef, lower, upper)
        return g_inequal

    def get_vio_diff(self, x_diff, diff_minmax):
        # x_diff: (Time-1,)
        # diff_minmax: [diff_min, diff_max]
        lower = diff_minmax[0]*np.ones(len(x_diff))
        upper = diff_minmax[1]*np.ones(len(x_diff))
        # g_inequal : (Time-1,)
        g_inequal = self.get_oneside_vio(x_diff, lower, upper)
        return g_inequal

    def constraint_function(self, x__):
        def _flatten_list(l):
            for el in l:
                if isinstance(el, list):
                    yield from _flatten_list(el)
                else:
                    yield el        

        def _get_const_facility(x_2D, epsilon_fac, diff_flag=[0]*self.load_pro.num_fac):
            # facility coef: array-(num_fac, each_coef)
            # g_fac : (Time*num_fac,)
            g_fac = []
            for j in range(0, self.load_pro.num_fac):
                idx_x = self.load_pro.no_feat_fac[j]
                if diff_flag[j] == 0:
                    fac_l = list(_flatten_list(self.get_vio_fac(x_2D[idx_x, :], self.fac_coef[j], epsilon_fac[j])))
                    g_fac.append(fac_l)
                else:
                    # x[t+1] - x[t], t=1,...,Time-1
                    x_diff = np.diff(x_2D[idx_x, :], axis=1, n=1)
                    fac_l = list(_flatten_list(self.get_vio_fac(x_diff+50, self.fac_coef[j], epsilon_fac[j])))
                    g_fac.append(fac_l)
            return np.array(list(_flatten_list(g_fac)))

        def _get_const_demand(x_2D, epsilon_demand, coef_demand):
            # demand: (num_demand, Time)
            # g_demand : (Time*num_demand,)
            g_demand = []
            for j in range(0, self.load_pro.num_demand):
                idx_x = self.load_pro.no_feat_demand[j]
                g_demand.append(self.get_vio_demand(x_2D[idx_x, :], coef_demand[j, :], epsilon_demand, self.demand[j, :]))
            return np.array(g_demand[0])

        def _get_const_diff(x_2D, epsilon_diff):
            g_diff = []
            for idx in self.load_pro.no_diff:
                x_diff = np.diff(x_2D[idx, :], n=1)
                diff_l = list(self.get_vio_diff(x_diff, epsilon_diff[idx]))
                g_diff.append(diff_l)
            return np.array(list(_flatten_list(g_diff)))


        if self.problem_type <= 6:
            # (num_feat_total, delta_t)
            x_2D = self.convert_x_to_schedule(x__)

            # facility_violation
            # g1(x[t]) = (x2[t]-x2[t-1]+50) + (x3[t]-x3[t-1]+50) + (x4[t]-x4[t-1]+50) + b; t=2:Time
            # g2(x[t]) = (x1[t]-x1[t-1]+50) + (x2[t]-x2[t-1]+50) + (x3[t]-x3[t-1]+50) + (x4[t]-x4[t-1]+50) + (x5[t]-x5[t-1]+50) + b; t=2:Time
            # g3(x[t]) = x0[t] + x1[t] + b; t=1:Time
            g_fac = _get_const_facility(x_2D, self.epsilon_fac, [1, 1, 0])


            # diff_violation
            g_diff = _get_const_diff(x_2D, self.diff_minmax)

            # because x is modified upper/lower
            # gminmax = self.get_vio_minmax(x__)
            # g = np.concatenate([gminmax, g_fac, g_demand])
            g = np.ravel(np.concatenate([g_fac, g_diff]))
        else:
            g = [0]
        return g