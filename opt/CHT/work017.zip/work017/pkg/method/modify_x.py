#coding: utf-8
import re
import numpy as np

class Modx:
    def __init__(self, x_ul, type_mod='round'):
        self.type_mod = type_mod
        self.x_ul = x_ul
            
    def modified_x(self, x_):
        def _round(x_, x_ul):
            x_ = np.where(x_<x_ul[:,0], x_ul[:,0], x_)
            x_ = np.where(x_>x_ul[:,1], x_ul[:,1], x_)
            return x_
        def _reflect(x_, x_ul):
            x_ = np.where(x_<x_ul[:,0], x_ul[:,0] + np.abs(x_-x_ul[:,0]), x_)
            x_ = np.where(x_>x_ul[:,1], x_ul[:,1] - np.abs(x_ul[:,1]-x_), x_)
            return x_
        def _torus(x_, x_ul):
            x_ = np.where(x_<x_ul[:,0], x_ul[:,1] - np.abs(x_-x_ul[:,0]), x_)
            x_ = np.where(x_>x_ul[:,1], x_ul[:,0] + np.abs(x_ul[:,1]-x_), x_)
            return x_

        if self.type_mod == 'none':
            x_ = np.copy(x_)
        else:
            while (x_ < self.x_ul[:, 0]).any() or (x_ > self.x_ul[:, 1]).any():
                if self.type_mod == 'round':
                    x_ = _round(x_, self.x_ul)
                elif self.type_mod == 'reflect':
                    x_ = _reflect(x_, self.x_ul)
                elif self.type_mod == 'torus':
                    x_ = _torus(x_, self.x_ul)
        return x_