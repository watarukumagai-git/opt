#coding: utf-8
import numpy as np

class PSO_v_update_class:
    def __init__(self, w, c1, c2):
        self.w = w
        self.c1 = c1
        self.c2 = c2
                
    def PSO_v_update(self, x_, v_, x_pbest_, x_gbest_):
        r = np.random.rand(x_.shape[0], x_.shape[1], 2)
        v_ = self.w*v_ + self.c1*r[:, :, 0]*(x_pbest_-x_) + self.c2*r[:, :, 1]*(x_gbest_-x_)
        return v_

    def get_P(self, X):
        C = np.cov(X)
        #(eigenvalue, P_) = np.linalg.eig(C)
        (eigenvalue, P_) = np.linalg.eigh(C)
        if np.any(eigenvalue<=0):
            #C and P are modified because its eigenvalue includes negative.
            delta = pow(10, -16)
            eigenvalue = np.where(eigenvalue<=0, delta, eigenvalue)
            C_mod = np.dot(np.dot(P_,np.diag(eigenvalue)),P_.T)
            #(eigenvalue, P_) = np.linalg.eig(C_mod)
            (eigenvalue, P_) = np.linalg.eigh(C_mod)
        P_ = P_[np.argsort(-eigenvalue), :]
        return P_

    def CRIPSO_v_update(self, x_, v_, x_pbest_, x_gbest_, P):
        m = x_.shape[0]
        N = x_.shape[1]
        r = np.random.rand(m, N, 2)
        v__ = np.zeros((m, N))
        for i in range(0, m):
            L1 = np.dot(np.dot(P,np.diag(r[i, :, 0])),P.T)
            L2 = np.dot(np.dot(P,np.diag(r[i, :, 1])),P.T)
            v__[i, :] = self.w*v_[i, :] + self.c1*np.dot(L1, (x_pbest_[i, :]-x_[i, :]).T).T + self.c2*np.dot(L2, (x_gbest_-x_[i, :]).T).T
        return v__
