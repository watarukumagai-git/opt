#coding: utf-8
import numpy as np
import pandas as pd
import os
from os import path
import gc

from .import_data import import_data_class
from ..method.AFPSO.PSO import PSO_update
from ..method.AFPSO.w_update import w_update_class
from ..method.MOEAD.GA import GA_update
from ..method.MOEAD.weight_update import weight_update_class
from ..method.modify_x import Modx
from .get_eval import Superior

class get_sol_loop_class:
    def main_loop(self, prob, alg_para, run, start_time):
        # get parameters
        # problem parameters
        N = prob.N
        problem_type = prob.problem_type
        # algorithm parameters
        PSO_type = alg_para[0]
        MOEAD_type = alg_para[1]
        eval_type = alg_para[2]
        iter_max = alg_para[3]
        m = alg_para[4]

        pre_iter_max = int(iter_max*1.0)

        # 1. databox gene
        obj = np.zeros((m, 3))
        obj_box = np.zeros((m, iter_max))
        # [obj, vio_sum]
        obj_vio_pbest_box = np.zeros((m, 2, iter_max))
        # w_box: [w, act]
        w_box = np.zeros((2, iter_max))

        # obj_gbest_box: [obj, vio_sum, obj_eval]
        obj_gbest_box = np.zeros((3, iter_max))

        # 2. initial solution
        data = import_data_class().get_dataset(run, 2)
        #x = data[0:m, 0:N]*(prob.xmax-prob.xmin) + prob.xmin
        # x_ul: (N, 2), [min, max]
        x = data[:m, :N]*(prob.load_pro.x_ul[:, 1]-prob.load_pro.x_ul[:, 0]) + prob.load_pro.x_ul[:, 0]
        v = data[:m, N:2*N]*(prob.load_pro.x_ul[:, 1]-prob.load_pro.x_ul[:, 0]) + prob.load_pro.x_ul[:, 0]

        del data
        gc.collect()


        work_path = path.dirname( path.abspath(__file__) )
        os.chdir(work_path)
        dir_name = path.abspath('..\\') + '\\function\\'


        # get obj: (m, 4)
        (obj, each_vio) = Superior().eval_scaler(prob, x)
        # get vio_sum: (m)
        # each_vio: (m, g_num)

        # vio = sigma_{j=1, L} orm_j
        # vio_eval = sigma_{j=1, L} orm_j
        # vio_eval = sigma_{j=1, L} (orm_max - orm_j / orm_max - orm_min)
        # orm_max = max_{i=1,...,m} orm_j
        # orm_min = min_{i=1,...,m} orm_j
        # orm_j : (m, L) [0, g_j(x)]

        # mod_type: round, reflect, torus
        mod_type = 'reflect'
        mod = Modx(prob.load_pro.x_ul, type_mod=mod_type)

        x_pbest = x.copy()
        obj_pbest = obj.copy()
        idx_gbest = Superior().get_min_idx_array(obj_pbest, prob.eval_type)
        x_gbest = mod.modified_x(x_pbest[idx_gbest, :].copy())
        (obj_gbest, each_vio_gbest) = Superior().eval_scaler(prob, x_gbest)
        print('PSO inital obj_gbest = ', obj_gbest)

        iter = 0

        # 3. iteration loop        
        PSO_w_update_instance = w_update_class(m, pre_iter_max, prob.load_pro.x_ul)
        if PSO_type <= 2:
            w = PSO_w_update_instance.wmax
        elif PSO_type == 3:
            w = 0.729
        PSO_x_update_instance = PSO_update.x_update_class(m, N, w, PSO_type)

        
        while ((iter <= iter_max-1) and (len(np.where(obj_pbest[:, 1] == 0)[0]) < 2)):
            # 4. solution update
            (x, obj, v, x_pbest, obj_pbest, each_vio, x_gbest, obj_gbest) = PSO_x_update_instance.PSO_update(prob, x, v, x_pbest, obj_pbest, each_vio, x_gbest, obj_gbest, mod)
            if PSO_type <= 2:
                # 5. update w
                (PSO_x_update_instance.w, act) = PSO_w_update_instance.update_w(PSO_x_update_instance.w, v, iter)
                w_box[0, iter] = PSO_x_update_instance.w
                w_box[1, iter] = act
                        
            # other data update
            if prob.eval_type <= 3:
                clm = Superior().get_clm(prob.eval_type)
                obj_box[:, iter] = obj[:, clm].copy()
                obj_vio_pbest_box[:, 0, iter] = obj_pbest[:, clm].copy()
            else:
                obj_box[:, iter] = obj[:, 0].copy()
                obj_vio_pbest_box[:, :, iter] = obj_pbest[:, [0,1]].copy()
            obj_gbest_box[:, iter] = obj_gbest.copy()

            iter = iter + 1


        print('iter = ', iter)
        print('MOEA/D inital obj_pbest= ', obj_pbest)
        print('MOEA/D inital obj_gbest = ', obj_gbest)

        MOEAD_w_update_instance = weight_update_class(m)
        #alpha = 1.0
        alpha = 0.5
        w = MOEAD_w_update_instance.update_weight(alpha)
        MOEAD_x_update_instance = GA_update.x_update_class(m, N, w)

        while (iter <= iter_max - 1):
            # 4. solution update
            (x_pbest, obj_pbest, each_vio) = MOEAD_x_update_instance.GA_update(prob, x_pbest, obj_pbest, each_vio, mod)

            # 5. update alpha and weight vector
            alpha = MOEAD_w_update_instance.update_alpha(alpha, obj_pbest[:, [0,1]])
            MOEAD_w_update_instance.w = MOEAD_w_update_instance.update_weight(alpha)
            
            # other data update
            idx_ = Superior().get_sup_idx_array(obj_gbest, obj_pbest, 4)
            if len(idx_) > 0:
                idx_gbest = Superior().get_min_idx_array(obj_pbest, 4)
                x_gbest = x_pbest[idx_gbest, :].copy()
                obj_gbest = obj_pbest[idx_gbest, :].copy()

            #idx_cbest = Superior().get_min_idx_array(obj_pbest, 4)
            #obj_cbest = obj_pbest[idx_cbest, :].copy()
            #if Superior().get_sup_bool_sca(obj_gbest, obj_cbest, 4):
            #    x_gbest = x_pbest[idx_cbest, :].copy()
            #    obj_gbest = obj_cbest.copy()

            if prob.eval_type <= 3:
                clm = Superior().get_clm(prob.eval_type)
                obj_vio_pbest_box[:, 0, iter] = obj_pbest[:, clm].copy()
            else:
                obj_vio_pbest_box[:, :, iter] = obj_pbest[:, [0,1]].copy()

            w_box[0, iter] = alpha
            obj_gbest_box[:, iter] = obj_gbest.copy()

            iter = iter + 1

        return obj_vio_pbest_box, x_gbest, obj_gbest_box, w_box