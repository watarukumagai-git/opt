#coding: utf-8
import numpy as np
import math

class Function:
    def __init__(self, problem_type, N, DE_type, d_exp, eval_type, params_list):
        self.problem_type = problem_type
        self.N = N
        self.PSO_type = DE_type
        self.eval_type = eval_type
        self.d = pow(10, d_exp)
        self.x_ul = np.ones((self.N, 2))
        self.x_ul[:, 0] = -5 * self.x_ul[:, 0]
        self.x_ul[:, 1] = 5 * self.x_ul[:, 1]
        self.c = params_list[0]
        self.e = params_list[1]

    def get_opt(self):
        x_opt = (self.e-math.sqrt(self.d))*np.ones(self.N)
        f_opt = ((self.e-self.c)-math.sqrt(self.d))**2
        return x_opt, f_opt

    def object_function(self, x__):
        return np.power(x__-self.c, 2).mean()

    def constraint_function(self, x__):
        return np.power(x__-self.e, 2).mean() - self.d