#coding: utf-8
import numpy as np
import math

class Function:
    def __init__(self, problem_type, N, DE_type, d_exp, eval_type, params_list):
        self.problem_type = problem_type
        self.N = N
        self.PSO_type = DE_type
        self.eval_type = eval_type
        self.d = pow(10, d_exp)
        self.x_ul = np.ones((self.N, 2))
        self.x_ul[:, 0] = -5 * self.x_ul[:, 0]
        self.x_ul[:, 1] = 5 * self.x_ul[:, 1]
        self.c = params_list[0]
        self.e = params_list[1]

    def get_opt(self):
        t = 1/(2*self.c)
        #x0 = self.e-t+math.sqrt(self.d)
        x0 = self.e-t
        x_opt = -x0*np.ones(self.N)
        f_opt = self.object_function(x_opt)
        return x_opt, f_opt

    def object_function(self, x__):
        return np.power(x__+5, 2).mean()

    def constraint_function(self, x__):
        def _cos(x__):
            return -1.0 * np.cos(2.0*self.c*np.pi*x__)
        def phi_unit(x__):
            if np.abs(x__) < self.e:
                f = _cos(x__)
            else:
                f = x__**2
            return f
        def phi(x__):
            f = np.power(x__, 2)
            idx_ = np.where(np.abs(x__) < self.e)
            f[idx_] = _cos(x__[idx_])
            #f[idx_] = -1.0 * np.cos(2.0*self.c*np.pi*x__[idx_])
            return f
        return phi(x__).mean() - phi_unit(math.sqrt(self.d))