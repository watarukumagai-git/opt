#coding: utf-8
import numpy as np
import pandas as pd
import os
from os import path
import gc

from .import_data import import_data_class
from ..method.AFPSO.PSO.PSO_update import x_update_class
from ..method.AFPSO.w_update import w_update_class
from ..method.modify_x import Modx
from .get_eval import Superior
from .figure_save import figure_save_class

class get_sol_loop_class:
    def main_loop(self, prob, alg_para, run, start_time):
        # get parameters
        # problem parameters
        N = prob.N
        problem_type = prob.problem_type
        # algorithm parameters
        PSO_type = alg_para[0]
        iter_max = alg_para[2]
        m = alg_para[3]

        # 1. databox gene
        obj = np.zeros((m, 3))
        obj_box = np.zeros((m, iter_max))
        obj_pbest_box = np.zeros((m, iter_max))
        # w_box: [w, act]
        w_box = np.zeros((2, iter_max))

        # obj_gbest_box: [obj, vio_sum, obj_eval]
        obj_gbest_box = np.zeros((3, iter_max))

        # 2. initial solution
        data = import_data_class().get_dataset(run, 2)
        #x = data[0:m, 0:N]*(prob.xmax-prob.xmin) + prob.xmin
        # x_ul: (N, 2), [min, max]
        x = data[:m, :N]*(prob.load_pro.x_ul[:, 1]-prob.load_pro.x_ul[:, 0]) + prob.load_pro.x_ul[:, 0]
        v = data[:m, N:2*N]*(prob.load_pro.x_ul[:, 1]-prob.load_pro.x_ul[:, 0]) + prob.load_pro.x_ul[:, 0]

        del data
        gc.collect()


        work_path = path.dirname( path.abspath(__file__) )
        os.chdir(work_path)
        dir_name = path.abspath('..\\') + '\\function\\'


        # get obj: (m, 4)
        obj = Superior().eval_scaler(prob, x)
        # get vio_sum: (m)
        # each_vio: (m, g_num)

        # vio = sigma_{j=1, L} orm_j
        # vio_eval = sigma_{j=1, L} orm_j
        # vio_eval = sigma_{j=1, L} (orm_max - orm_j / orm_max - orm_min)
        # orm_max = max_{i=1,...,m} orm_j
        # orm_min = min_{i=1,...,m} orm_j
        # orm_j : (m, L) [0, g_j(x)]

        # mod_type: round, reflect, torus
        mod_type = 'reflect'
        mod = Modx(prob.load_pro.x_ul, type_mod=mod_type)

        iter = 0

        x_pbest = x.copy()
        obj_pbest = obj.copy()
        idx_gbest = Superior().get_min_idx_array(obj_pbest, prob.eval_type)
        x_gbest = mod.modified_x(x_pbest[idx_gbest, :].copy())
        obj_gbest = Superior().eval_scaler(prob, x_gbest)
        print(obj_gbest)

        # 3. iteration loop        
        PSO_w_update_instance = w_update_class(m, iter_max, prob.load_pro.x_ul)
        if PSO_type <= 2:
            w = PSO_w_update_instance.wmax
        elif PSO_type == 3:
            w = 0.729
        PSO_x_update_instance = x_update_class(m, N, w, PSO_type)

        
        while True:
            # 4. solution update
            (x, obj, v, x_pbest, obj_pbest, x_gbest, obj_gbest) = PSO_x_update_instance.PSO_update(prob, x, v, x_pbest, obj_pbest, x_gbest, obj_gbest, mod)
            if PSO_type <= 2:
                # 5. update w
                (PSO_x_update_instance.w, act) = PSO_w_update_instance.update_w(PSO_x_update_instance.w, v, iter)
                w_box[0, iter] = PSO_x_update_instance.w
                w_box[1, iter] = act
                        
            # other data update
            if prob.eval_type <= 3:
                clm = Superior().get_clm(prob.eval_type)
                obj_box[:, iter] = obj[:, clm].copy()
                obj_pbest_box[:, iter] = obj_pbest[:, clm].copy()
            else:
                obj_box[:, iter] = obj[:, 1].copy()
                obj_pbest_box[:, iter] = obj_pbest[:, 1].copy()
            obj_gbest_box[:, iter] = obj_gbest.copy()

            # 6. check termination
            if iter == iter_max - 1:
                break
            else:
                iter = iter + 1

        return x_pbest, obj_pbest_box, x_gbest, obj_gbest_box, w_box