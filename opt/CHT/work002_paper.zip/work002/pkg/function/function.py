#coding: utf-8
import numpy as np
import math

class Function:
    def __init__(self, problem_type, N, scaling_type, d_exp):
        self.problem_type = problem_type
        self.N = N
        self.scaling_type = scaling_type
        self.d = pow(10, d_exp)
        self.x_ul = np.ones((self.N, 2))
        self.x_ul[:, 0] = -5 * self.x_ul[:, 0]
        self.x_ul[:, 1] = 5 * self.x_ul[:, 1]

    def basis_func(self, func_type, x):
        # x: (N,)
        if func_type == 1:
            return np.power(x, 2)
        if func_type == 2:
            return np.cos(2*np.pi*x)

    def get_opt(self):
        if self.problem_type <= 3:
            x_opt = 1-math.sqrt(self.d)*np.ones(self.N)
        elif self.problem_type == 4:
            x_opt = 0.25-math.sqrt(self.d)*np.ones(self.N)
        f_opt = (x_opt[0])**2
        return x_opt, f_opt

    def object_function(self, x__):
        if self.problem_type <= 4:
            return np.sum(self.basis_func(1, x__))/self.N

    def constraint_function(self, x__):
        def _g1(x__, d):
            return np.sum(self.basis_func(1, x__-1))/self.N - d

        if self.problem_type == 1:
            a = _g1(x__, self.d)
            return a
        elif self.problem_type == 2:
            a = _g1(x__, self.d)
            return math.exp(10*a)-1
        elif self.problem_type == 3:
            a = _g1(x__, self.d)
            return np.sign(a) * np.power(abs(a), 1/4)
        elif self.problem_type == 4:
            a = - np.sum(self.basis_func(2, x__ - 0.25))/self.N
            return a + self.basis_func(2, math.sqrt(self.d))