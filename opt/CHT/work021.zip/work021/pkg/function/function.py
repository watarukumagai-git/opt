#coding: utf-8
import numpy as np
import math

class Function:
    def __init__(self, problem_type, N, DE_type, d_exp, eval_type):
        self.problem_type = problem_type
        self.N = N
        self.PSO_type = DE_type
        self.eval_type = eval_type
        self.d = pow(10, d_exp)
        self.x_ul = np.ones((self.N, 2))
        self.x_ul[:, 0] = -5 * self.x_ul[:, 0]
        self.x_ul[:, 1] = 5 * self.x_ul[:, 1]

    def get_opt(self):
        if self.problem_type <= 3:
            x_opt = (1-math.sqrt(self.d))*np.ones(self.N)
        elif self.problem_type == 4:
            x_opt = (0.25-math.sqrt(self.d))*np.ones(self.N)
        else:
            x_opt = np.zeros(self.N)
            print('problem number is not preset.')
        f_opt = pow(x_opt[0], 2)
        return x_opt, f_opt

    def object_function(self, x__):
        if self.problem_type <= 4:
            return np.power(x__, 2).mean()

    def constraint_function(self, x__):
        def _g1(x__):
            return np.power(x__-1, 2).mean() - self.d
        def _g4(x__):
            return np.cos(2*np.pi*(x__-0.25)).mean() - math.cos(2*math.pi*math.sqrt(self.d))

        if self.problem_type == 1:
            return _g1(x__)
        elif self.problem_type == 2:
            return np.exp(10*_g1(x__))-1
        elif self.problem_type == 3:
            a = _g1(x__)
            return np.sign(a) * pow(abs(a), 1/4)
        elif self.problem_type == 4:
            return -1*_g4(x__)
        else:
            return 0