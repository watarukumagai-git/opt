#coding: utf-8
import numpy as np
import pandas as pd
import random as rnd
import math

class mutation_class:
    def __init__(self, x__):
        self.x__ = x__.copy()
        self.N = len(x__)

    def PM(self, Pmu, x_ul):
        eps = 20
        theta = np.random.rand(self.N)        
        idx3 = np.where(theta > Pmu)
        
        if len(idx3[0]) != self.N:
            d = np.zeros(self.N)
            r = np.random.rand(self.N)
            idx1 = np.where((theta <= Pmu)&(r < 0.5))
            idx2 = np.where((theta <= Pmu)&(r >= 0.5))
            d[idx1] = np.power(2*r[idx1], 1/float(1+eps)) - 1
            d[idx2] = 1 - np.power(2-2*r[idx2], 1/float(1+eps))
            child = self.x__ + d * np.abs(x_ul[:, 1]-x_ul[:, 0])
            child[idx3] = self.x__[idx3]
        else:
            child = np.copy(self.x__)
        return child