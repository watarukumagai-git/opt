# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
import os
from os import path
import matplotlib.pyplot as plt
plt.rcParams['font.family'] = 'Times New Roman'

def scaled_trend(figure_label, x, y, fig_file_name):
    x_label_name = figure_label[0]
    y_label_name = figure_label[1]
    y_min = figure_label[2]
    y_max = figure_label[3]
    m = y.shape[1]
    cmap = plt.get_cmap("jet")

    fig = plt.figure(figsize=(6,4))
    fig.patch.set_facecolor('white')
    ax = fig.add_subplot(1,1,1)
    for i in range(0, m):
        clist=float(i)/m
        ax.plot(x, y[:, i], fillstyle='none', marker='.', markersize = 1, markeredgewidth=0.1, markeredgecolor=cmap(clist), lw=0)
        #ax.plot(x, y[:, i], fillstyle='none', marker='.', markeredgewidth=0.2, markeredgecolor=cmap(clist), lw=0.5)

    ax.set_xlabel(x_label_name, fontsize=16)
    ax.set_ylabel(y_label_name, fontsize=16)
    ax.tick_params(labelsize=12)
    ax.set_ylim([y_min, y_max])

    plt.tick_params(labelsize=12, direction = "in")
    plt.tight_layout()
    plt.savefig(fig_file_name, bbox_inches="tight")

def scaled_scatter(figure_label, x, y, fig_file_name):
    x_label_name = figure_label[0]
    y_label_name = figure_label[1]
    x_min = figure_label[2]
    x_max = figure_label[3]
    y_min = figure_label[4]
    y_max = figure_label[5]
    m = y.shape[1]
    cmap = plt.get_cmap("jet")

    fig = plt.figure(figsize=(5,5))
    fig.patch.set_facecolor('white')
    ax = fig.add_subplot(1,1,1)
    for i in range(0, m):
        clist=float(i)/m
        ax.scatter(x[:, i], y[:, i], c='none', marker='.', s = 1, linewidth=0.1, edgecolors=cmap(clist))

    ax.set_xlabel(x_label_name, fontsize=16)
    ax.set_ylabel(y_label_name, fontsize=16)
    ax.tick_params(labelsize=12)
    #ax.set_xlim([x_min, x_max])
    #ax.set_ylim([y_min, y_max])

    plt.tick_params(labelsize=12, direction = "in")
    plt.tight_layout()
    plt.savefig(fig_file_name, bbox_inches="tight")

def get_path(problem_type):
    work_path = path.dirname( path.abspath(__file__) )
    os.chdir(work_path)
    #work_path = os.path.abspath('..\\..\\') 
    dir_base = work_path + '\\output\\pro' + str(problem_type)
    return dir_base


problem_type = 4
run_max = 1
dir_base = get_path(problem_type)


figure_label1 = ["iteration: $k$", "scaled $f(x)$", 0, 1]
figure_label2 = ["iteration: $k$", "scaled $v(x)$", 0, 1]
figure_label3 = ["scaled $f(x)$", "scaled $v(x)$", 0, 1, 0, 1]
df = pd.read_csv(dir_base + '\\file\\obj_vio_run0.csv', index_col=0)
obj_box = df.filter(like='scaled_obj', axis=1).values
iter_max = len(df)
m = obj_box.shape[1]

for run in range(0, run_max):
    df = pd.read_csv(dir_base + '\\file\\obj_vio_run' + str(run) + '.csv', index_col=0)
    obj_box = df.filter(like='scaled_obj', axis=1).values
    vio_box = df.filter(like='scaled_vio', axis=1).values
    
    # scaled obj and vio trend
    fig_file_name = dir_base + '\\fig\\scaled_obj_'+ str(run) + '.png'
    scaled_trend(figure_label1, 
                 range(0, iter_max), 
                 obj_box, 
                 fig_file_name)

    # scaled obj and vio trend
    fig_file_name = dir_base + '\\fig\\scaled_vio_'+ str(run) + '.png'
    scaled_trend(figure_label2, 
                 range(0, iter_max), 
                 vio_box, 
                 fig_file_name)

    fig_file_name = dir_base + '\\fig\\scaled_scatter_'+ str(run) + '.png'
    scaled_scatter(figure_label3, 
                   obj_box, 
                   vio_box, 
                   fig_file_name)
