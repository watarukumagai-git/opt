#coding: utf-8
import numpy as np
from .crossover import crossover_class
from .mutation import mutation_class
from ....subpkg.get_eval import Superior

class x_update_class:
    def __init__(self, m, N):
        self.m = m
        self.N = N
        self.mutation_type = 'CP1'
        self.crossover_type = 'uniform'
        self.rho = 0.05

    def neighbor_gene(self, prob, x_, obj_, mod):
  	    # x_: (m, N)
	    # obj_: (m,)
        num_diff = 1
        
        #mutation
        mutate = mutation_class(self.F, x_)
        if self.mutation_type == 'rand1':
            u = mutate.rand(num_diff=num_diff)
        elif self.mutation_type == 'CP1':
            num_better = np.max([self.m*self.rho, 2]).astype(int)
            idx_rank = Superior().get_rank(obj_, prob.eval_type)
            better_idx = idx_rank[:num_better]
            u = mutate.CP(better_idx, num_diff=num_diff)

        #crossover
        xover = crossover_class(self.C, x_, u)
        if self.crossover_type == 'uniform':
            u = xover.Uniform()
        
        #modify
        mod_x = mod.modified_x(u)
        
        return mod_x

    def selection(self, prob, x__, obj__, each_vio__, x_nei__, obj_nei__, each_vio_nei__):
        update_idx_ = Superior().get_sup_idx_array(obj__, obj_nei__, prob.eval_type)
        if len(update_idx_) > 0:
            x__[update_idx_, :] = x_nei__[update_idx_, :].copy()
            obj__[update_idx_, :] = obj_nei__[update_idx_, :].copy()
            each_vio__[update_idx_, :] = each_vio_nei__[update_idx_, :].copy()
        return x__, obj__, each_vio__, update_idx_

    def DE_update(self, prob, x, obj, each_vio, mod):
        x_nei = self.neighbor_gene(prob, x, obj, mod)
        (obj_nei, each_vio_nei) = Superior().eval_scaler(prob, x_nei)
        (x_, obj_, each_vio_, update_idx_) = self.selection(prob, x, obj, each_vio, x_nei, obj_nei, each_vio_nei)
        if prob.DE_type == 2:
            self.update_idx_ = update_idx_
        return x_, obj_, each_vio_