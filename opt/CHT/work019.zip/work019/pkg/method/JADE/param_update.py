#coding: utf-8
import numpy as np
import math

class param_update_class:
    def __init__(self, m):
        self.m = m
        self.mu_F = 0.9
        self.mu_C = 0.5
        self.sigma_F = 0.1
        self.sigma_C = 0.1
        self.c = 0.1

    def update_param(self, s_F, s_C):
        def _cauchy(mu_F, sigma_F, array):
            m = len(array)
            onethird_m = m//3
            F = np.zeros(self.m)
            random_onethird_idx = np.random.choice(array, size=onethird_m, replace=False).tolist()
            idx_ = [i for i in range(0, m) if i in random_onethird_idx]
            idx_not = list(set(range(0, m)) - set(idx_))
            F[idx_] = 1.2 * np.random.rand(len(idx_))
            F[idx_not] = np.random.normal(mu_F, sigma_F, len(idx_not))
            return F
        if len(s_F) > 0:
            self.mu_F = (1-self.c)*self.mu_F + self.c*(np.sum(np.power(s_F, 2))/np.sum(s_F))
        if len(s_C) > 0:
            self.mu_C = (1-self.c)*self.mu_C + self.c*np.mean(s_C)
        F = _cauchy(self.mu_F, self.sigma_F, np.arange(0, self.m))
        C = np.random.normal(self.mu_C, self.sigma_C, self.m)
        F = np.where(F>1, 1, F)
        F = np.where(F<=0, 0.1, F)
        C = np.where(C>1, 1, C)
        C = np.where(C<=0, 0.1, C)
        return F, C