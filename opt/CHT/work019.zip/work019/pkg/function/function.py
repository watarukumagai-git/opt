#coding: utf-8
import numpy as np

class Function:
    def __init__(self, load_pro, DE_type, scaling_type, cost, demand, fac_coef, eval_type):
        self.load_pro = load_pro
        self.problem_type = load_pro.problem_type
        self.N = load_pro.N
        self.DE_type = DE_type
        self.scaling_type = scaling_type
        self.eval_type = eval_type
        self.g_num = 0
        self.cost = cost
        self.demand = demand
        self.fac_coef = fac_coef
        if self.problem_type == 1:
            diff_min = [-0.1, -1.12135469418, -1.73241069435, -5.4145845649, -0.06]
            diff_max = [0.1, 1.0093494688464, 2.029696457169, 5.6462835057309, 0.06]
            self.epsilon_fac = [0.4608, 0.391646879364331]
        self.diff_minmax = [[i, j] for i, j in zip(diff_min, diff_max)]
    
    def convert_x_to_schedule(self, x_):
        # x: (N, 1)
        # schedule: (num_feat_total, delta_t)
        if np.any(self.load_pro.seedflag==1):
            schedule = np.where(self.load_pro.seedflag, self.load_pro.pattern, -999)
            schedule[schedule == -999] = x_
            schedule = schedule.reshape(self.load_pro.num_feat_total, self.load_pro.delta_t)
        else:
            schedule = x_.reshape(self.load_pro.num_feat_total, self.load_pro.delta_t)
        return schedule

    def convert_schedule_to_x(self, schedule):
        # schedule: (num_feat_total, delta_t)
        # x: (N, 1)
        if np.any(self.load_pro.seedflag==1):
            x_ = np.delete(schedule.reshape(self.N), np.where(self.load_pro.seedflag == 1))
        else:
            x_ = schedule.reshape(self.N)
        return x_

    def basis_func(self, func_type, x, c):
        # x: (N,)
        # c: (N,) or (N+1,)
        # func_type 1: linear
        if func_type == 1:
            if x.ndim >= 1:
                if len(c) == len(x):
                    f =  np.sum(c*x)
                else:
                    f =  np.sum(c[:-1]*x) + c[-1]
            else:
                f = c*x
        return f

    def object_function(self, x__):
        def _penalty(x_2D, pcoef):
            pattern_2D = self.load_pro.pattern.reshape(self.load_pro.num_feat_total, self.load_pro.delta_t)
            target = np.where(np.arange(self.load_pro.delta_t) <= self.load_pro.deadtime[0]+1, pattern_2D[0, :], self.demand[0, :])
            #target = np.array([pattern_2D[0, t] if t <= self.load_pro.deadtime[0]+1 else self.demand[0, t] for t in range(0, self.load_pro.delta_t) ])
            pepsilon = [0.01]
            g = self.get_vio_demand(x_2D[0,:], np.ones(self.load_pro.delta_t), pepsilon, target)
            g = np.where(g<0, 0, g)
            return pcoef * g.sum()

        # input
        # x__: (N_, )
        # output
        # f: float
        c = self.cost.reshape(self.load_pro.bigN)
        x_2D = self.convert_x_to_schedule(x__)
        f1 = self.basis_func(1, x_2D.reshape(self.load_pro.bigN), c)

        # ID100 penalty for target
        pcoef = pow(10, -1)
        f2 = _penalty(x_2D, pcoef)
        f = f1 + f2
        return f

    def get_oneside_vio(self, g_equal, lower, upper):
        return np.where((lower + upper)/2>=g_equal, lower - g_equal, g_equal - upper)

    def relax_const(self, x, coef, lower, upper):
        """
        relax for constarint functions.

        Parameters
        ----------
        eval_const : object
            constraint function
        x : double (num_feat, Time)
            solution
        coef : double (num_feat+1,)
            coefficient and bias for x
        lower : double (Time,)
            lower for x
        upper : double (Time,)
            upper for x

        Returns
        -------
        g_inequal : double (Time,)
            inequality constarints relaxed by lower/upper
        """
        # g_equal: (Time,)
        if x.ndim > 1:
            if len(coef) == x.shape[0]:
                g_equal = np.dot(coef, x)
            elif len(coef) == x.shape[0]+1:
                g_equal = np.dot(coef[:-1], x) + coef[-1]
        else:
            if len(coef) == len(x):
                g_equal = coef*x
            elif len(coef) == len(x) + 1:
                g_equal = coef[:-1]*x + coef[-1]
        g_inequal = self.get_oneside_vio(g_equal, lower, upper)
        return g_inequal

    def get_vio_minmax(self, x__):
        # x__ : (N,)
        return self.get_oneside_vio(x__, self.load_pro.x_ul[:,0], self.load_pro.x_ul[:,1])

    def get_vio_fac(self, x_2D, coef, epsilon):
        # x_2D: (num_feat, Time)
        # coef: (num_feat+1,)
        lower = -epsilon*np.ones(x_2D.shape[1])
        upper = epsilon*np.ones(x_2D.shape[1])
        # g_inequal : (Time,)
        g_inequal = self.relax_const(x_2D, coef, lower, upper)
        return g_inequal

    def get_vio_demand(self, x_2D, coef, epsilon, demand):
        # x_2D: (num_feat, Time)
        # coef: (num_feat,)
        # demand: (Time,)
        lower = demand - epsilon[0]
        upper = demand + epsilon[0]
        #lower = np.array([demand[t] - epsilon[0] for t in range(0,self.load_pro.delta_t)])
        #upper = np.array([demand[t] + epsilon[0] for t in range(0,self.load_pro.delta_t)])
        # g_inequal : (Time,)
        g_inequal = self.relax_const(x_2D, coef, lower, upper)
        return g_inequal

    def get_vio_diff(self, x_diff, diff_minmax):
        # x_diff: (Time-1,)
        # diff_minmax: [diff_min, diff_max]
        lower = diff_minmax[0]*np.ones(len(x_diff))
        upper = diff_minmax[1]*np.ones(len(x_diff))
        # g_inequal : (Time-1,)
        g_inequal = self.get_oneside_vio(x_diff, lower, upper)
        return g_inequal

    def constraint_function(self, x__):
        def _flatten_list(l):
            for el in l:
                if isinstance(el, list):
                    yield from _flatten_list(el)
                else:
                    yield el        

        def _get_const_facility(x_2D, epsilon_fac, diff_flag=[0]*self.load_pro.num_fac):
            # facility coef: array-(num_fac, each_coef)
            # g_fac : (Time*num_fac,)
            if any(i == 0 for i in diff_flag):
                for (j, idx_x) in enumerate(self.load_pro.no_feat_fac):
                    X = x_2D[idx_x, :]
                    if diff_flag[j] == 1:
                        # x[t+1] - x[t], t=1,...,Time-1
                        X = np.diff(X, axis=1, n=1) + 50
                    unit_fac = self.get_vio_fac(X, self.fac_coef[j], epsilon_fac[j])
                    if j == 0:
                        g_fac = unit_fac
                    else:
                        g_fac = np.concatenate([g_fac, unit_fac])
            elif all(i == 1 for i in diff_flag):
                for (j, idx_x) in enumerate(self.load_pro.no_feat_fac):
                    # x[t+1] - x[t], t=1,...,Time-1
                    X = np.diff(x_2D[idx_x, :], axis=1, n=1) + 50
                    unit_fac = self.get_vio_fac(X, self.fac_coef[j], epsilon_fac[j])
                    if j == 0:
                        g_fac = unit_fac
                    else:
                        g_fac = np.concatenate([g_fac, unit_fac])
            return g_fac

        def _get_const_demand(x_2D, epsilon_demand, coef_demand):
            # demand: (num_demand, Time)
            # g_demand : (Time*num_demand,)
            g_demand = []
            for j in range(0, self.load_pro.num_demand):
                idx_x = self.load_pro.no_feat_demand[j]
                g_demand.append(self.get_vio_demand(x_2D[idx_x, :], coef_demand[j, :], epsilon_demand, self.demand[j, :]))
            return np.array(g_demand[0])

        def _get_const_diff(x_2D, epsilon_diff):
            for (j, idx) in enumerate(self.load_pro.no_diff):
                x_diff = np.diff(x_2D[idx, :], n=1)
                unit_diff = self.get_vio_diff(x_diff, epsilon_diff[idx])
                if j == 0:
                    g_diff = unit_diff
                else:
                    g_diff = np.concatenate([g_diff, unit_diff])
            return g_diff


        if self.problem_type <= 6:
            # (num_feat_total, delta_t)
            x_2D = self.convert_x_to_schedule(x__)

            # facility_violation
            # g1(x[t]) = (x2[t]-x2[t-1]+50) + (x3[t]-x3[t-1]+50) + (x4[t]-x4[t-1]+50) + b; t=2:Time
            # g2(x[t]) = (x1[t]-x1[t-1]+50) + (x2[t]-x2[t-1]+50) + (x3[t]-x3[t-1]+50) + (x4[t]-x4[t-1]+50) + (x5[t]-x5[t-1]+50) + b; t=2:Time
            g_fac = _get_const_facility(x_2D, self.epsilon_fac, [1, 1])


            # diff_violation
            g_diff = _get_const_diff(x_2D, self.diff_minmax)

            # because x is modified upper/lower
            #gminmax = self.get_vio_minmax(x__)
            #g = np.ravel(np.concatenate([gminmax, g_fac, g_diff]))
            g = np.ravel(np.concatenate([g_fac, g_diff]))
        else:
            g = [0]
        return g