# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
import os
from os import path
import matplotlib.pyplot as plt
if "My Drive" not in os.getcwd():
  plt.rcParams['font.family'] = 'Times New Roman'

def scaled_trend(figure_label, x, y, fig_file_name):
    x_label_name = figure_label[0]
    y_label_name = figure_label[1]
    #y_min = figure_label[2]
    #y_max = figure_label[3]
    m = y.shape[1]
    cmap = plt.get_cmap("jet")

    fig = plt.figure(figsize=(6,4))
    fig.patch.set_facecolor('white')
    ax = fig.add_subplot(1,1,1)
    for i in range(0, m):
        clist = float(i)/m
        ax.plot(x, y[:, i], fillstyle='none', marker='.', markersize = 1, markeredgewidth=0.1, markeredgecolor=cmap(clist), lw=0)
        #ax.plot(x, y[:, i], fillstyle='none', marker='.', markeredgewidth=0.2, markeredgecolor=cmap(clist), lw=0.5)

    ax.set_xlabel(x_label_name, fontsize=16)
    ax.set_ylabel(y_label_name, fontsize=16)
    ax.tick_params(labelsize=12)
    #ax.set_ylim([y_min, y_max])

    plt.tick_params(labelsize=12, direction = "in")
    plt.tight_layout()
    plt.savefig(fig_file_name, bbox_inches="tight")

def scaled_scatter(figure_label, x, y, fig_file_name):
    x_label_name = figure_label[0]
    y_label_name = figure_label[1]
    #x_min = figure_label[2]
    #x_max = figure_label[3]
    #y_min = figure_label[4]
    #y_max = figure_label[5]
    m = y.shape[1]
    cmap = plt.get_cmap("jet")

    fig = plt.figure(figsize=(5,5))
    fig.patch.set_facecolor('white')
    ax = fig.add_subplot(1,1,1)
    for i in range(0, m):
        clist=float(i)/m
        ax.scatter(x[:, i], y[:, i], c='none', marker='.', s = 1, linewidth=0.1, edgecolors=cmap(clist))

    ax.set_xlabel(x_label_name, fontsize=16)
    ax.set_ylabel(y_label_name, fontsize=16)
    ax.tick_params(labelsize=12)
    #ax.set_xlim([x_min, x_max])
    #ax.set_ylim([y_min, y_max])

    plt.tick_params(labelsize=12, direction = "in")
    plt.tight_layout()
    plt.savefig(fig_file_name, bbox_inches="tight")

def get_path(path_):
    if "My Drive" not in os.getcwd():
        work_path = path.dirname( path.abspath(__file__) )
        os.chdir(work_path)
        #work_path = os.path.abspath('..\\..\\') 
        dir_base = work_path + '\\output\\pro1\\' + path_
    else:
        dir_base = os.getcwd() + '/output/pro1/' + path_
    return dir_base


alg_type = 1
run_max = 1

if "My Drive" not in os.getcwd():
    path_ = 'alg_type' + str(alg_type) + '\\eval_type4'
    dir_base = get_path(path_)
    file_base = dir_base + '\\file\\'
    fig_base = dir_base + '\\fig\\'
else:
    path_ = 'alg_type' + str(alg_type) + '/eval_type4'
    dir_base = get_path(path_)
    file_base = dir_base + '/file/'
    fig_base = dir_base + '/fig/'


figure_label1 = ["iteration: $k$", "$f(x)$"]
figure_label2 = ["iteration: $k$", "$v(x)$"]
figure_label3 = ["$f(x)$", "$v(x)$"]

df = pd.read_csv(file_base + 'obj_run0.csv', index_col=0)
iter_max = len(df)
m = df.shape[1]

for run in range(0, run_max):
    obj_box = pd.read_csv(file_base + 'obj_run' + str(run) + '.csv', index_col=0).values
    vio_box = pd.read_csv(file_base + 'vio_run' + str(run) + '.csv', index_col=0).values
    
    fig_file_name = fig_base + 'obj_'+ str(run) + '.png'
    scaled_trend(figure_label1, 
                 range(0, iter_max), 
                 obj_box, 
                 fig_file_name)

    fig_file_name = fig_base + 'vio_'+ str(run) + '.png'
    scaled_trend(figure_label2, 
                 range(0, iter_max), 
                 vio_box, 
                 fig_file_name)

    fig_file_name = fig_base + 'scatter_'+ str(run) + '.png'
    scaled_scatter(figure_label3, 
                   obj_box, 
                   vio_box, 
                   fig_file_name)