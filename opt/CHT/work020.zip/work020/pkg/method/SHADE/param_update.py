#coding: utf-8
import numpy as np
import math

class param_update_class:
    def __init__(self, m):
        self.m = m
        self.sigma_F = 0.1
        self.sigma_C = 0.1
        self.memory_size = 10
        self.set_F_C = np.zeros((self.memory_size, 2))*0.5

    def update_param(self, s_F, s_C):
        def _lehmar_mean(array):
            return (np.sum(np.power(array, 2))/np.sum(array))
        def _cauchy(mu, sigma, array):
            m = len(array)
            onethird_m = m//3
            F = np.zeros(self.m)
            random_onethird_idx = np.random.choice(array, size=onethird_m, replace=False).tolist()
            idx_ = [i for i in range(0, m) if i in random_onethird_idx]
            idx_not = list(set(range(0, m)) - set(idx_))
            F[idx_] = 1.2 * np.random.rand(len(idx_))
            for i in idx_not:
                F[i] = np.random.normal(mu[i], sigma)
            return F
        def _get_F(mu_F, sigma_F, array):
            F = _cauchy(mu_F, sigma_F, array)
            F = np.where(F>1, 1, F)
            F = np.where(F<=0, 0.1, F)
            return F
        def _get_C(mu_C, sigma_C, array):
            for i in array:
                C[i] = np.random.normal(mu_C[i], sigma_C)
            C = np.where(C>1, 1, C)
            C = np.where(C<=0, 0.1, C)
            return C
        idx = np.random.choice(np.arange(0, self.memory_size), (self.m,2))
        self.mu_F = self.set_F_C[idx[:,0], 0]
        self.mu_C = self.set_F_C[idx[:,1], 1]
        if len(s_F) > 0 or len(s_C) > 0:
            idx = np.random.randint(0,self.memory_size,2)
            if len(s_F) > 0:
                self.set_F_C[idx, 0] = _lehmar_mean(s_F)
            if len(s_C) > 0:
                self.set_F_C[idx, 1] = _lehmar_mean(s_C)
        F = _get_F(self.mu_F, self.sigma_F, np.arange(0, self.m))
        C = _get_C(self.mu_C, self.sigma_C, np.arange(0, self.m))
        return F, C