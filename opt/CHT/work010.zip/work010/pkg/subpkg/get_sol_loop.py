#coding: utf-8
import numpy as np
import pandas as pd
import os
from os import path
import gc

from .import_data import import_data_class
from ..method.AFPSO.AFPSO_update import x_update_class
from ..method.w_update import w_update_class
from .get_eval import get_obj_class
from .get_eval import get_vio_class
from .figure_save import figure_save_class

class get_sol_loop_class:
    def get_rank(self, array_):
        clm = ["value", "rank"]
        df_ = pd.DataFrame(np.zeros((len(array_), 2)), columns=clm)
        df_[clm[0]] = array_
        list_ = list(set(list(array_)))
        list_.sort()
        rank = 0
        for ele_ in list_:
            df_.loc[df_[clm[0]]==ele_, clm[1]] = rank
            rank = rank + 1
        rank_ = df_[clm[1]].values
        return rank_
        
    def gbest_eval_(self, x, x_gbest, obj, vio, obj_gbest_current, iter):
        # obj: (m, 1)
        # vio: (m, 1)
        # obj_gbest_box: [obj, vio_sum]
        obj_cbest = min(obj)
        if iter == 0 or obj_cbest < obj_gbest_current[0]:
            cbest_i = np.argmin(obj)
            vio_cbest = vio[cbest_i]
            obj_gbest_array = np.array([obj_cbest, vio_cbest])
            x_gbest = x[cbest_i, :]
        else:
            obj_gbest_array = np.copy(obj_gbest_current)
        return x_gbest, obj_gbest_array

    
    def get_feas_gbest(self, obj_feas_gbest_old, obj_feas_cbest_new):
        feas_gbest_obj = obj_feas_gbest_old[0]
        feas_gbest_vio = obj_feas_gbest_old[1]
        feas_cbest_obj = obj_feas_cbest_new[0]
        feas_cbest_vio = obj_feas_cbest_new[1]

        flag_ = 0
        if feas_gbest_vio > 0:
            if feas_cbest_vio < feas_gbest_vio or (feas_cbest_obj < feas_gbest_obj and feas_cbest_vio == feas_gbest_vio):
                flag_ = 1
        else:
            if feas_cbest_obj < feas_gbest_obj and feas_cbest_vio == 0:
                flag_ = 1            
        return flag_
    
    
    def get_feas_cbest(self, obj):
        # obj: (m, 2) [obj, vio]
        #feas_flag = np.where(, 1, 0)
        #obj_df = pd.DataFrame(obj, columns = ["obj", "vio_sum"])
        #obj_df.loc[:, "num"] = np.arange(len(obj_df))
        # a feasible solution exists
        if (obj[:, 1]==0).any():
            # only feasible solution
            feas_idx = np.where(obj[:,1] == 0)
            #feas_df = obj_df.loc[obj_df["vio_sum"]==0, :]
            # index minimum objective function in feasible solution
            index_ = np.argmin(obj[feas_idx,0])
            #index_ = feas_df["obj"].idxmin()
        else:
            # index minimum violation
            index_ = np.argmin(obj[:,1])
            #index_ = obj_df["vio_sum"].idxmin()
        #num_feas_cbest = obj_df.loc[index_, "num"]
        num_feas_cbest = index_
        return obj[num_feas_cbest, :], index_

    
    def update_obj_feas_gbest_cbest(self, obj, obj_feas_gbest_old, iter):
        # obj_feas_gbest_cbest_box: [feas_gbest, feas_gbest_vio_sum, feas_cbest, feas_cbest_vio_sum]
        (obj_feas_cbest_new, num_feas_cbest) = self.get_feas_cbest(obj)
        if iter == 0:
            obj_feas_gbest_new = obj_feas_cbest_new
            update_flag = 0
        else:
            update_flag = self.get_feas_gbest(obj_feas_gbest_old, obj_feas_cbest_new)
            if update_flag == 1:
                obj_feas_gbest_new = obj_feas_cbest_new
            else:
                obj_feas_gbest_new = obj_feas_gbest_old
        return np.concatenate([obj_feas_gbest_new, obj_feas_cbest_new]), num_feas_cbest, update_flag

    
    def draw_figure(self, prob, x, x_feas_gbest, run, iter):
        # get path
        work_path = path.dirname( path.abspath(__file__) )
        os.chdir(work_path)
        work_path = os.path.abspath('..\\..\\') 
        dir_base = work_path + '\\output\\'

        (X, Y, obj_mesh_box, vio_mesh_box, feas_mesh_box, x_ul) = figure_save_class().get_contour_data(prob)
        # position in solution space
        figure_label2 = ["$x_1$", "$x_2$", "$xi$", "$xgbest$", x_ul[0, 0], x_ul[1, 0], x_ul[0, 1], x_ul[1, 1]]
        fig_file_name = dir_base + 'position_solution_space' + str(run) + '_iter'+ str(iter) + '.png'
        figure_save_class().scatter_solution_space(figure_label2, x[:, 0], x[:, 1], x_feas_gbest, X, Y, obj_mesh_box, feas_mesh_box, fig_file_name)


    def main_loop(self, prob, alg_para, run, start_time):
        # get parameters
        # problem parameters
        N = prob.N
        problem_type = prob.problem_type
        # algorithm parameters
        iter_max = alg_para[1]
        m = alg_para[2]

        # 1. databox gene
        # obj: [obj, obj_eval, vio_sum, vio_eval]
        obj_box = np.zeros((m, iter_max))
        obj_pbest_box = np.zeros((m, iter_max))
        obj_gbest_box = np.zeros(iter_max)
        # w_box: [w, act]
        w_box = np.zeros((2, iter_max))

        # 2. initial solution
        data = import_data_class().get_dataset(run, 2)
        #x = data[0:m, 0:N]*(prob.xmax-prob.xmin) + prob.xmin
        # x_ul: (N, 2), [min, max]
        x = data[:m, :N]*(prob.x_ul[:, 1]-prob.x_ul[:, 0]) + prob.x_ul[:, 0]
        v = data[:m, N:2*N]*(prob.x_ul[:, 1]-prob.x_ul[:, 0]) + prob.x_ul[:, 0]

        del data
        gc.collect()


        work_path = path.dirname( path.abspath(__file__) )
        os.chdir(work_path)
        dir_name = path.abspath('..\\') + '\\function\\'


        # get obj: (m)
        obj = get_obj_class().get_obj(prob, x)

        # vio = sigma_{j=1, L} orm_j
        # vio_eval = sigma_{j=1, L} orm_j
        # vio_eval = sigma_{j=1, L} (orm_max - orm_j / orm_max - orm_min)
        # orm_max = max_{i=1,...,m} orm_j
        # orm_min = min_{i=1,...,m} orm_j
        # orm_j : (m, L) [0, g_j(x)]

        x_pbest = x.copy()
        obj_pbest = obj.copy()
        idx_gbest = np.argmin(obj_pbest, axis=0)
        x_gbest = x[idx_gbest, :].copy()
        obj_gbest = obj_pbest[idx_gbest].copy()
        print(obj_gbest)

        iter = 0
        obj_box[:, iter] = np.copy(obj)
        obj_pbest_box[:, iter] = np.copy(obj_pbest)
        obj_gbest_box[iter] = obj_gbest

        # 3. iteration loop        
        w_update_instance = w_update_class(m, iter_max, prob.x_ul)
        w = 1.0
        x_update_instance = x_update_class(m, N, w)

        
        while True:
            # 4. solution update
            (x, obj, v, x_pbest, obj_pbest, x_gbest, obj_gbest) = x_update_instance.AFPSO_update(prob, x, obj, v, x_pbest, obj_pbest, x_gbest)
            # 5. update w
            (x_update_instance.w, act) = w_update_instance.update_w(x_update_instance.w, v, iter)
            
            # other data update
            obj_box[:, iter] = np.copy(obj)
            obj_pbest_box[:, iter] = np.copy(obj_pbest)
            obj_gbest_box[iter] = obj_gbest
            w_box[0, iter] = x_update_instance.w
            w_box[1, iter] = act

            # 6. check termination
            if iter == iter_max - 1:
                 break
            else:
                 iter = iter + 1
                 #now_time = time.time() 
                 #cal_time = now_time - start_time 
                 #print ("loop times: ", run)
                 #print ("calculation time = {:.2f} sec".format(cal_time))
                 #print ("gbest: ", obj_gbest_box[iter-1, :])
                 #print ("iteration: ", iter)

        return x_pbest, obj_pbest_box, x_gbest, obj_gbest_box, w_box