#coding: utf-8
import numpy as np
import random as rnd
import math

class Function:
    def __init__(self, load_pro, scaling_type, cost, demand, fac_coef):
        self.load_pro = load_pro
        self.problem_type = load_pro.problem_type
        self.N = load_pro.N
        self.scaling_type = scaling_type
        self.g_num = 0
        self.cost = cost
        self.demand = demand
        self.fac_coef = fac_coef

    def get_opt(self):
        if self.problem_type == 1 or self.problem_type == 2 or self.problem_type == 3:
            ep_f1_list = [0.5, 0.01, 0]
            ep_f1 = ep_f1_list[self.problem_type-1]
            ep_f2 = 0.1
            ep_d = 0.01
            de = 3
            eta = (de-ep_d)/6
            x_opt = np.zeros((self.load_pro.num_feat_total, self.load_pro.Time))
            for i in range(0, self.load_pro.num_feat_total):
                if i == 0 or i == 3:
                    x_opt[i, :] = 2*eta - (2*ep_f1 + ep_f2)/3
                elif i == 1 or i == 4:
                    x_opt[i, :] = eta + (ep_f2 - ep_f1)/3
                else:
                    x_opt[i, :] = 3*eta
            #obj_opt = 15.12, 22.96, 23.12
            obj_opt = (x_opt[0, :] + x_opt[3, :]).sum()
            x_opt = x_opt.reshape(self.N)
        else:
            obj_opt = 0
            x_opt = np.zeros(self.N)
            print('problem number is not preset.')
        return obj_opt, x_opt

    def basis_func(self, func_type, x, c):
        # x: (N,)
        # c: (N,) or (N+1,)
        # func_type 1: linear
        if func_type == 1:
            if x.ndim >= 1:
                if len(c) == len(x):
                    f =  np.sum(c*x)
                else:
                    f =  np.sum(c[:-1]*x) + c[-1]
            else:
                f = c*x
        return f

    def object_function(self, x__):
        # input
        # x__: (N_, )
        # output
        # f: float
        c = self.cost.reshape(len(x__))
        f1 = self.basis_func(1, x__, c)

        # ID100 penalty for target
        target = np.array([self.load_pro.pattern[1, t] if t <= self.load_pro.deadtime[1]+1 else self.demand[0, t] for t in range(0, self.load_pro.Time) ])
        x_2D = x__.reshape(self.load_pro.Time, self.load_pro.num_feat_total).T
        #pcoef = np.power(10, 8)
        pcoef = np.power(10, 3)
        pepsilon = [0.01]
        f2 = pcoef * np.sum(self.get_vio_demand(x_2D[1,:], np.ones(self.load_pro.Time), pepsilon, target))
        f = f1 + f2
        return f

    def get_oneside_vio(self, g_equal, lower, upper):
        return np.where((lower + upper)/2>=g_equal, lower - g_equal, g_equal - upper)

    def relax_const(self, eval_const, x, coef, lower, upper):
        """
        relax for constarint functions.

        Parameters
        ----------
        eval_const : object
            constraint function
        x : double (num_feat, Time)
            solution
        coef : double (num_feat+1,)
            coefficient and bias for x
        lower : double (Time,)
            lower for x
        upper : double (Time,)
            upper for x

        Returns
        -------
        g_inequal : double (Time,)
            inequality constarints relaxed by lower/upper
        """
        # g_equal: (Time,)
        if x.ndim > 1:
            g_equal = np.array([eval_const(1, x[:, t], coef) for t in range(0, x.shape[1])]).T
        else:
            g_equal = np.array([eval_const(1, x[t], coef[t]) for t in range(0, len(x))])
        g_inequal = self.get_oneside_vio(g_equal, lower, upper)
        return g_inequal

    def get_vio_minmax(self, x__):
        # x__ : (N,)
        g_minmax = self.get_oneside_vio(x__, self.load_pro.x_ul[:,0], self.load_pro.x_ul[:,1])
        return g_minmax

    def get_vio_fac(self, x_2D, coef, epsilon):
        # x_2D: (num_feat, Time)
        # coef: (num_feat+1,)
        lower = -epsilon*np.ones(x_2D.shape[1])
        upper = epsilon*np.ones(x_2D.shape[1])
        # g_inequal : (Time,)
        g_inequal = self.relax_const(self.basis_func, x_2D, coef, lower, upper)
        return g_inequal

    def get_vio_demand(self, x_2D, coef, epsilon, demand):
        # x_2D: (num_feat, Time)
        # coef: (num_feat,)
        # demand: (Time,)
        lower = np.array([demand[t] - epsilon[0] for t in range(0,self.load_pro.Time)])
        upper = np.array([demand[t] + epsilon[0] for t in range(0,self.load_pro.Time)])
        # g_inequal : (Time,)
        g_inequal = self.relax_const(self.basis_func, x_2D, coef, lower, upper)
        return g_inequal


    def constraint_function(self, x__):
        def _flatten_list(l):
            for el in l:
                if isinstance(el, list):
                    yield from _flatten_list(el)
                else:
                    yield el        

        def _get_const_facility(x_2D, epsilon_fac, diff_flag=[0]*self.load_pro.num_fac):
            # facility coef: array-(num_fac, num_unit_feat)
            # g_fac : (Time*num_fac,)
            g_fac = []
            for j in range(0, self.load_pro.num_fac):
                idx_x = self.load_pro.no_feat_fac[j]
                if diff_flag[j] == 0:
                    for i in range(0, len(self.fac_coef[j])):
                        fac_l = list(_flatten_list(self.get_vio_fac(x_2D[idx_x, :], self.fac_coef[j], epsilon_fac[j])))
                        g_fac.append(fac_l)
                else:
                    for i in range(0, len(self.fac_coef[j])):
                        # x[t+1] - x[t], t=1,...,Time-1
                        x_diff = np.diff(x_2D[idx_x, :], axis=1, n=1)
                        fac_l = list(_flatten_list(self.get_vio_fac(x_diff+50, self.fac_coef[j], epsilon_fac[j])))
                        g_fac.append(fac_l)
            return np.array(list(_flatten_list(g_fac)))

        def _get_const_demand(x_2D, epsilon_demand, coef_demand):
            # demand: (num_demand, Time)
            # g_demand : (Time*num_demand,)
            g_demand = []
            for j in range(0, self.load_pro.num_demand):
                idx_x = self.load_pro.no_feat_demand[j]
                g_demand.append(self.get_vio_demand(x_2D[idx_x, :], coef_demand[j, :], epsilon_demand, self.demand[j, :]))
            return np.array(g_demand[0])

        def _get_const_diff(x_2D, epsilon_diff, pattern, deadtime):
            g_diff = []
            for i in range(0, x_2D.shape[0]):
                c = [1, -pattern[i,deadtime[i]+1]]
                g_diff.append(self.get_vio_fac(x_2D[i, self.deadtime[i]:], c, epsilon_diff[i]))
            return np.array(g_diff)


        if self.problem_type == 1:
            epsilon_fac = [0.4608, 0.391646879364331, 3.6861]
            epsilon_demand = 0.01
            epsilon_diff = [0, 0, 5, 5, 5, 0.5]
        elif self.problem_type == 2:
            epsilon_fac = [1, 1, 4]
            epsilon_demand = 0.01
            epsilon_diff = [5, 5, 5, 5, 5, 5]
            
        if self.problem_type == 1 or self.problem_type == 2:
            x_2D = x__.reshape(self.load_pro.Time, self.load_pro.num_feat_total).T
            # facility_violation
            # g1(x[t]) = (x2[t]-x2[t-1]+50) + (x3[t]-x3[t-1]+50) + (x4[t]-x4[t-1]+50) + b; t=2:Time
            # g2(x[t]) = (x1[t]-x1[t-1]+50) + (x2[t]-x2[t-1]+50) + (x3[t]-x3[t-1]+50) + (x4[t]-x4[t-1]+50) + (x5[t]-x5[t-1]+50) + b; t=2:Time
            # g3(x[t]) = x0[t] + x1[t] + b; t=1:Time

            #g_fac = []
            #for j in range(0, 2):
            #    idx_x = self.load_pro.no_feat_fac[j]
            #    if j == 0 or j == 1:
            #        lower = -epsilon_fac[j]*np.ones(self.load_pro.Time-1)
            #        upper = epsilon_fac[j]*np.ones(self.load_pro.Time-1)
            #        g_equal = np.array([self.basis_func(1, x_2D[idx_x, t]-x_2D[idx_x, t-1]+50, self.fac_coef[j, 0, :]) for t in range(1, x_2D[idx_x,:].shape[1])])
            #    if j == 2:
            #        lower = -epsilon_fac[j]*np.ones(self.load_pro.Time)
            #        upper = epsilon_fac[j]*np.ones(self.load_pro.Time)
            #        g_equal = np.array([self.basis_func(1, x_2D[idx_x, t], self.fac_coef[j, 0, :]) for t in range(0, x_2D[idx_x,:].shape[1])])
            #    g_inequal = self.get_oneside_vio(g_equal, lower, upper)
            #    g_fac.append(g_inequal)
            g_fac = _get_const_facility(x_2D, epsilon_fac, [1, 1, 0])

            # demand_violation
            # g3(x[t]) = x1[t] - demand[t]; t=1:Time
            # -ep_d+demand[t] <= g3(x[t])+demand[t] <= ep_d+demand[t]; t=1:Time
            #coef_demand = np.ones((self.load_pro.num_demand, len(self.load_pro.no_feat_demand[0])))
            #g_demand = _get_const_demand(x_2D, epsilon_demand, coef_demand)

            # diff_violation
            idx = [2, 3, 4, 5]
            #g_diff = _get_const_diff(x_2D[idx, :], epsilon_diff[idx], self.load_pro.pattern[idx], self.load_pro.deadtime[idx])

            # because x is modified upper/lower
            # gminmax = self.get_vio_minmax(x__)
            # g = np.concatenate([gminmax, g_fac, g_demand])
            #g = np.ravel(np.concatenate([g_fac, g_demand, g_diff]))
            g = g_fac
        else:
            g = [0]
        return g