#coding: utf-8
import numpy as np
import random as rnd
import math

class LoadProblemClass:
    def __init__(self, problem_type_):
        self.problem_type = problem_type_
        self.x_ul = 0
        self.N = 0
        self.g_num = 0
        self.num_feat_total = 0
        self.num_fac = 0
        self.num_demand = 0
        self.num_storage = 0
        self.no_feas_fac = 0
        self.no_feat_demand = 0
        self.no_feat_storage = 0
        self.ID_list = 0
        self.xmin = 0
        self.xmax = 0


    def load_problem(self):
        # step
        self.Time = 4

        (no_cost, self.no_feat_fac, num_equ_fac, self.no_feat_demand, self.no_feat_storage) = self.get_problem_parameter()
        
        # dim
        self.N = self.num_feat_total * self.Time

        # upper/lower
        self.xmin = [49.9, 48.2675893056486, 44.5854154351011, 49.94]
        self.xmax = [50.1, 52.029696457169, 55.6462835057309, 50.06]
        self.x_ul = np.ones((self.N, 2))
        self.x_ul[:,0] = self.xmin
        self.x_ul[:,1] = self.xmax

        # cost: (num_feat_total, Time)
        c = np.zeros((self.num_feat_total, self.Time))
        for i in no_cost:
            c[i, :] = 0
        #c = c.reshape(self.N)
        #    c[0*24:1*24] = 1
        #    c[1*24:2*24] = 0
        #    c[2*24:3*24] = 0
        #    c[3*24:4*24] = 1
        #    c[4*24:5*24] = 0
        #    c[5*24:6*24] = 0

        # facility coef: (num_fac, num_unit_feat)
        fac_coef = np.array(self.no_feat_fac)
        num_unit_feat = fac_coef.shape[1]
        fac_coef = np.append(fac_coef, np.zeros((self.num_fac, num_unit_feat)), axis=0)
        fac_coef = np.reshape(fac_coef, (self.num_fac, -1, num_unit_feat))
        # facility coef: (num_fac, num_equ_fac, num_unit_feat)
        for i in range(0, self.num_fac):
            for j in range(0, num_equ_fac[i]):
                if j == 0:
                    fac_coef[i, j, 0] = -12.4189728599085
                    fac_coef[i, j, 1] = 0.254164912405956
                    fac_coef[i, j, 2] = 0.223068753791219
                    fac_coef[i, j, 3] = 3.69971072950631
                else:
                    fac_coef[i, j, 0] = 1
                    fac_coef[i, j, 1] = -2
                    fac_coef[i, j, 2] = 1
                    fac_coef[i, j, 3] = 0

        # demand: (num_demand, Time)
        demand = np.zeros((self.num_demand, self.Time))
        for i in range(0, self.num_demand):
            demand[i, :] = 3

        return c, demand, fac_coef


    def get_problem_parameter(self):
        # x0: ID302
        # x1: ID312
        # x2: ID322
        # x3: ID332
        # x4: ID352
        if self.problem_type == 1 or self.problem_type == 2 or self.problem_type == 3:
            self.num_feat_total = 4
            no_cost = [0, 1]
            no_feat_fac = [[0, 1, 2, 3]]
            num_equ_fac = [2]
            no_feat_demand = [[0]]
            no_feat_storage = []
            self.ID_list = ['ID302', 'ID322', 'ID332', 'ID352']
        else:
            self.num_feat_total = 1
            no_cost = []
            no_feat_fac = []
            no_feat_demand = []
            no_feat_storage = []
            self.ID_list = []

        # num_feature at facility
        self.num_fac = len(no_feat_fac)
        # num_feature at demand
        self.num_demand = len(no_feat_demand)
        # num_feature at storage
        self.num_storage = len(no_feat_storage)

        return no_cost, no_feat_fac, num_equ_fac, no_feat_demand, no_feat_storage