#coding: utf-8
import numpy as np
import random as rnd
import math

class LoadProblemClass:
    def __init__(self, problem_type_):
        self.problem_type = problem_type_
        self.x_ul = 0
        self.N = 0
        self.g_num = 0
        self.num_feat_total = 0
        self.num_fac = 0
        self.num_demand = 0
        self.num_storage = 0
        self.no_feas_fac = 0
        self.no_feat_demand = 0
        self.no_feat_storage = 0
        self.ID_list = 0
        self.pattern = 0
        self.deadtime = 0


    def load_problem(self, param_df):
        # step: 33
        #self.Time = 4*8+1
        # step: 13
        self.Time = 4*3+1

        (no_cost, self.no_feat_fac, num_equ_fac, self.no_feat_demand, self.no_feat_storage) = self.get_problem_parameter()
        
        # dim: 6 * 33 = 198
        # dim: 6 * 13 = 78
        self.N = self.num_feat_total * self.Time

        # upper/lower/pattern
        min_clm = [i + '_Min' for i in self.ID_list]
        max_clm = [i + '_Max' for i in self.ID_list]
        pattern_clm = [i + '_Pattern' for i in self.ID_list]
        demand_clm = [i + '_Demand' for i in self.ID_list]
        min_df = param_df.loc[:self.Time-1, min_clm]
        max_df = param_df.loc[:self.Time-1, max_clm]
        self.x_ul = np.ones((self.N, 2))
        self.x_ul[:,0] = min_df.values.reshape(self.N)
        self.x_ul[:,1] = max_df.values.reshape(self.N)
        self.pattern = param_df.loc[:self.Time-1, pattern_clm].values.T

        # cost: (num_feat_total, Time)
        # ['ID100', 'ID300', 'ID310', 'ID320', 'ID330', 'ID350']
        c = np.zeros((self.num_feat_total, self.Time))
        for i in no_cost:
            c[i, :] = 0
        #c = c.reshape(self.N)
        #    c[0*33:1*33] = 1036881
        #    c[1*33:2*33] = 0
        #    c[2*33:3*33] = 445.41
        #    c[3*33:4*33] = 320.51
        #    c[4*33:5*33] = 85.047
        #    c[5*33:6*33] = 463.584

        # facility coef: (num_fac, num_unit_feat)
        fac_coef = [[float(item) for item in iteml] for iteml in self.no_feat_fac]
        # facility coef: (num_fac, num_equ_fac, num_unit_feat)
        for i in range(0, self.num_fac):
            if i == 0:
                fac_coef[i] = np.array([-0.512, 1.110, -0.363, -11.76])
            elif i == 1:
                fac_coef[i] = np.array([12.4189728599085, 0, 0.254164912405956, 0.223068753791219, 3.69971072950631, -829.8])
            else:
                fac_coef[i] = np.array([36.74, 1.244, -102.56])

        # demand: (num_demand, Time)
        demand = np.zeros((self.num_demand, self.Time))
        for i in range(0, self.num_demand):
            for j in self.no_feat_demand[i]:
                demand[i, :] = param_df.loc[:self.Time-1, demand_clm[j]].values.T

        return c, demand, fac_coef


    def get_problem_parameter(self):
        # x0: ID100
        # x1: ID300
        # x2: ID310
        # x3: ID320
        # x4: ID330
        # x5: ID350
        if self.problem_type == 1 or self.problem_type == 2 or self.problem_type == 3:
            self.num_feat_total = 6
            no_cost = [0, 2, 3, 4, 5]
            no_feat_fac = [[2, 3, 4],
                           [1, 2, 3, 4, 5],
                           [0, 1]]
            num_equ_fac = [1, 1, 1]
            no_feat_demand = [[1]]
            no_feat_storage = []
            self.ID_list = ['ID100', 'ID300', 'ID310', 'ID320', 'ID330', 'ID350']
            self.deadtime = [0, 14, 19, 16, 14, 19]
        else:
            self.num_feat_total = 1
            no_cost = []
            no_feat_fac = []
            no_feat_demand = []
            no_feat_storage = []
            self.ID_list = []
            self.deadtime = []

        # num_feature at facility
        self.num_fac = len(no_feat_fac)
        # num_feature at demand
        self.num_demand = len(no_feat_demand)
        # num_feature at storage
        self.num_storage = len(no_feat_storage)

        return no_cost, no_feat_fac, num_equ_fac, no_feat_demand, no_feat_storage