#coding: utf-8
import numpy as np
import pandas as pd
import random as rnd
import math

class GA_class:
    # binary tournament compare
    def BT_comp(self, rank_):
        m_ = len(rank_)
        r1 = rnd.randint(0, m_-1)
        r2 = rnd.randint(0, m_-1)
        while r1 == r2:
            r2 = rnd.randint(0, m_-1)
        if rank_[r1] < rank_[r2]:
            yy = r1
        else:
            yy = r2
        return yy


    def binary_tournament(self, rank__):
        y1_ = self.BT_comp(rank__)
        y2_ = self.BT_comp(rank__)
        while y1_ == y2_:
            y2_ = self.BT_comp(rank__)
        return y1_, y2_


    def dominance_judgement(self, f1, f2):
        f_num = len(f1)
        # dominance flag
        # f1 >= f2: 0
        # f1 < f2: 1
        dominance_flag = 0
        d = 0
        for h in range(0, f_num):
            if f1[h] < f2[h]:
                d = d + 1
        if d == f_num:
            dominance_flag = 1
        return dominance_flag


    def non_dominated_sorting(self, f):
        # f: (m_, 2)
        m_ = len(f)
        f_num = len(f[0])
        # point index box
        point_index_box = list(range(0, m_))
        # rank saved box
        rank_saved_box = np.ones(m_)*float(m_)
        # rank
        rank = 0
        m_res_ = m_
        end_flag = 0
        while end_flag == 0:
            m_res_ = len(point_index_box)
            counter = np.zeros(m_res_)
            h = 0
            for i in point_index_box:
                for j in point_index_box:
                    if i != j:
                        # dominance flag
                        # 1: xj dominates xi (fj < fi)
                        # 0: xj does NOT dominate xi 
                        flag = self.dominance_judgement(f[j,:], f[i,:])
                        # xi is dominated by one xj
                        if flag == 1:
                            break
                        # xi is NOT dominated by one xj
                        else:
                            counter[h] = counter[h] + 1
                # xi is NOT dominates by all xj in X, and get a rank
                if counter[h] >= m_res_ - 1:
                    rank_saved_box[i] = rank
                h = h + 1
            # x in a rank are removed from X
            removed_index = np.where(rank_saved_box == rank)[0].tolist()
            for h in removed_index:
                point_index_box.remove(h)

            if len(point_index_box) == 0:
                end_flag = 1
            rank = rank + 1
            

        return rank_saved_box


    def cast_df(self, df_, columns_list_, type_list_):
        for i in range(0, len(columns_list_)):
            df_ = df_.astype({columns_list_[i]: type_list_[i]})
        return df_


    def subrank(self, rank__, obj___):
        m_ = len(rank__)
        # rank subrank box : (m_, 8)
        # rank subrank box : [rank, subrank, index, obj, vio_sum, rank_f_, rank_v_, subfit]
        rank_subrank_df = pd.DataFrame(rank__, columns=["main rank"])
        rank_subrank_df["subrank"] = np.zeros(m_)
        rank_subrank_df["index"] = np.arange(0, m_)
        obj_df = pd.DataFrame(obj___, columns=["obj", "vio_sum", "rank_f", "rank_v"])
        rank_subrank_df = pd.concat([rank_subrank_df, obj_df], axis = 1)
        rank_subrank_df["subfit"] = np.zeros(m_)

        type_list = ["int64", "int64", "int64", "float", "float", "int64", "int64", "float"]
        columns_list = list(rank_subrank_df.columns)
        rank_subrank_df = self.cast_df(rank_subrank_df, columns_list, type_list)

        #print("rank_subrank_df dtypes=", rank_subrank_df.dtypes)
        rank_max = rank_subrank_df["main rank"].max()

        for rank in range(0, rank_max+1):
            # rank subbox : (m_rank, 9) only a rank
            rank_subbox_df = rank_subrank_df[rank_subrank_df["main rank"] == rank].copy()
            if len(rank_subbox_df) == 1:
                rank_subbox_df["subfit"] = 0
                rank_subbox_df["subrank"] = 0
            else:
                # all solutions are infeasible
                if np.all(rank_subbox_df["vio_sum"] > 0) == 1:
                    rank_subbox_df["subfit"] = rank_subbox_df["rank_v"].copy()
                # one solution is feasible at least
                else:
                    # index_rank_vmin in the main rank
                    i_rank_vmin = rank_subbox_df["rank_v"].idxmin()

                    # feasible solution set
                    feas_df = rank_subrank_df[rank_subrank_df["vio_sum"] == 0]
                    #print("feasible solutions in the main rank=", feas_df)
                    i_ideal_cand = list(feas_df["index"].values)
                    # add i_rank_vmin to feas_index
                    i_ideal_cand.append(i_rank_vmin)
                    # delete same element in feas_index
                    i_ideal_cand = list(set(i_ideal_cand))

                    # Zrank: feasible solution set and vmin in the rank
                    ideal_cand_df = rank_subbox_df.loc[i_ideal_cand]
                    i_ideal = ideal_cand_df["obj"].idxmin()

                    # subfit
                    rank_subbox_df.loc[:,"subfit"] = rank_subbox_df.loc[i_ideal, "obj"] - rank_subbox_df.loc[:, "obj"]
                    rank_subbox_df.loc[:,"subfit"] = rank_subbox_df.loc[:, "subfit"].abs()
                    
                # get subrank sortindex in a rank
                rank_subbox_df["subindex"] = np.arange(0, len(rank_subbox_df))
                rank_subbox_df = rank_subbox_df.set_index("subindex")
                index_box = rank_subbox_df.sort_values("subfit").index.values
                rank_subbox_df = rank_subbox_df.loc[index_box, :]
                rank_subbox_df["subrank"] = np.arange(0, len(rank_subbox_df))
                rank_subbox_df.index = list(rank_subbox_df["index"].values)
                rank_subbox_df = rank_subbox_df.sort_index()
            rank_subrank_df.loc[rank_subrank_df["main rank"] == rank, "subrank"] = rank_subbox_df["subrank"].values
            rank_subrank_df.loc[rank_subrank_df["main rank"] == rank, "subfit"] = rank_subbox_df["subfit"].values

        rank_subrank_box = rank_subrank_df.values
        return rank_subrank_box[:, :3]



    def get_rank_NS_subrank(self, obj__):
        m_ = len(obj__)

        # Non-dominated Sorting
        # mainrank: (m_, 1)
        mainrank = self.non_dominated_sorting(obj__[:, :2])
        # rank_subrank_box: (m_, 3), [rank, subrank, index]
        rank_subrank_box = self.subrank(mainrank, obj__)

        # sorting based on subrank
        rank_subrank_df = pd.DataFrame(rank_subrank_box, columns=["main rank", "subrank", "index"])

        # sorting based on mainrank and subrank
        rank_subrank_df = rank_subrank_df.sort_values(["main rank", "subrank"])
        rank_subrank_df["fit"] = np.arange(0, m_)
        rank_subrank_df = rank_subrank_df.sort_index()

        # get fitness based on mainrank and subrank
        rank_fit_ = rank_subrank_df["fit"].values

        return rank_fit_


    def get_rank(self, array_):
        clm = ["value", "rank"]
        df_ = pd.DataFrame(np.zeros((len(array_), 2)), columns=clm)
        df_[clm[0]] = array_
        list_ = list(set(list(array_)))
        list_.sort()
        rank = 0
        for ele_ in list_:
            df_.loc[df_[clm[0]]==ele_, clm[1]] = rank
            rank = rank + len(df_.loc[df_[clm[0]]==ele_, clm[1]])
        rank_ = df_[clm[1]].values
        return rank_


    def sorting_rank(self, array_, rank):
        df = pd.DataFrame(array_)
        df["rank"] = rank
        df = df.sort_values("rank")
        df = df.drop("rank", axis=1)
        return df.values



    def GA_split_elitepoint(self, x_, obj_, flag_v_sum, alg_para):
        # get algorithm parameters
        #[alg_type, iter_max, m, m_c, Pcr, Pmu]
        m = alg_para[2]
        # m_c : num of top (not eliminated)
        m_c = alg_para[3]
        N = len(x_[0, :])
        del alg_para

        # m_can : num of candidate
        m_res = m - m_c
 
        rank_vio = np.copy(obj_[:, 3]).astype(np.int)

        # fitness is based on violation ranking
        if flag_v_sum == 1:
            rank_fit = self.get_rank(rank_vio)

        # fitness is based on Non-dominated Sorting and subrank
        else:
            rank_fit = self.get_rank_NS_subrank(obj_)

        # sorting based on fitness
        x_ = self.sorting_rank(x_, rank_fit)
        obj_ = self.sorting_rank(obj_, rank_fit)
        
        #x_ = x_[rank_fit, :]
        #obj_ = obj_[rank_fit, :]

        # top m_c saved as elite points
        if m_c == 1:
            tmp = np.copy(x_[0, :])
            tmp_f = np.copy(obj_[0, :])            
        else:
            tmp = np.copy(x_[:m_c, :])
            tmp_f = np.copy(obj_[:m_c, :])

        # x_res saved as residue points
        x_res = np.copy(x_[m_c:, :])
        obj_res = np.copy(obj_[m_c:, :])

        return x_res, obj_res, tmp, tmp_f


    def GA_neighbor_gene(self, x_res_, obj_res_, flag_v_sum, alg_para, x_ul):
        # get algorithm parameters
        #[alg_type, iter_max, m, Pcr, Pmu]
        m = alg_para[2]
        # m_c : num of top (not eliminated)
        m_c = alg_para[3]
        Pcr = alg_para[4]
        Pmu = alg_para[5]
        N = len(x_res_[0, :])
        del alg_para

        # m_can : num of candidate
        m_res = m - m_c
        m_can = 2 * m_res
 
        x_next = np.zeros((m_can, N))
        x_next_next = np.zeros((m_can, N))

        rank_vio = np.copy(obj_res_[:, 3]).astype(np.int)

        # fitness is based on violation ranking
        if flag_v_sum == 1:
            #print("rank vio in gene", rank_vio)
            rank_fit = self.get_rank(rank_vio)
            #rank_fit = np.argsort(rank_vio)

        # fitness is based on Non-dominated sorting and subrank
        else:
            rank_fit = self.get_rank_NS_subrank(obj_res_)
            #print("NS_rank in gene", rank_fit)

        # sorting based on fitness
        if len(rank_fit) == 1:
            x_res_ = x_res_[0]
            obj_res_ = obj_res_[0]
        else:
            x_res_ = self.sorting_rank(x_res_, rank_fit)
            obj_res_ = self.sorting_rank(obj_res_, rank_fit)
            #x_res_ = x_res_[rank_fit, :]
            #obj_res_ = obj_res_[rank_fit, :]
        #print("x_res")
        #print(x_res_)

        # x_next generate from x_res
        # crossover
        for i in range(0, m_res):
            # get 2 search points indexes
            (num1, num2) = self.binary_tournament(np.arange(0, m_res).T)
            j = int(2*i)
            (x_next[j, :], x_next[j+1, :]) = self.SBX(x_res_[num1, :], x_res_[num2, :], Pcr)
        #print("x_next")
        #print(x_next)

        # mutation
        for i in range(0, m_can):
            x_next_next[i, :] = self.PM(x_next[i, :], Pmu, x_ul)

        return x_next_next



    def GA_selection_tournament(self, x_, obj_, x_next, obj_next, alg_para):
        # get algorithm parameters
        #[alg_type, iter_max, m, "GA", Pcr, Pmu]
        m = alg_para[2]
        #tournament size
        Trs = alg_para[6]
        del alg_para
        X = np.concatenate((x_next, x_), axis = 0)
        obj_ref = np.concatenate((obj_next, obj_), axis=0)
        num_array = np.random.randint(0, 2*m-1,(m, Trs))
        for i in range(0, m):
            player = []
            player_num = []
            for j in range(0, Trs):
                player.append(obj_ref[num_array[i, j]])
                player_num.append(num_array[i, j])
            champ_num = np.argmin(player)
            champ_No = player_num[champ_num]
            obj_[i, 0] = obj_ref[champ_No]
            x_[i, :] = X[champ_No, :]
        return x_, obj_


    def GA_selection_elitism(self, x_, obj_, x_next_, obj_next_, tmp_, tmp_f_, flag_v_sum, alg_para):
        # get algorithm parameters
        #[alg_type, iter_max, m, "GA", Pcr, Pmu]
        m = alg_para[2]
        m_c = alg_para[3]
        m_can = len(x_next_[:, 0])
        m_res = m - m_c
        del alg_para

        # get object and violation sortindex
        # rank_vio: (m_can, 1)
        rank_vio = np.copy(obj_next_[:, 3]).astype(np.int)

        # fitenss is based on violation ranking
        if flag_v_sum == 1:
            #print("rank vio in selection", rank_vio)
            rank_fit = self.get_rank(rank_vio)
            #rank_fit = np.argsort(rank_vio)
 
        # fitenss is based on Non-dominated Sorting and subrank
        else:
            rank_fit = self.get_rank_NS_subrank(obj_next_)
            #print("NS_rank in selection", rank_fit)

        # x_next sorting based fitness
        #print("obj_next before in selection", obj_next_)
        x_next_ = self.sorting_rank(x_next_, rank_fit)
        obj_next_ = self.sorting_rank(obj_next_, rank_fit)
        #x_next_ = x_next_[rank_fit, :]
        #obj_next_ = obj_next_[rank_fit, :]
        #print("obj_next after in selection", obj_next_)


        # elitism selection
        # 1:m_c : saved elite points in parent solutions based on fitness
        # m_c+1 : elite points in children solutions based on fitness
        if m_c == 1:
            x_[0, :] = np.copy(tmp_)
            obj_[0, :] = np.copy(tmp_f_)            
        else:
            x_[:m_c, :] = np.copy(tmp_)
            obj_[:m_c, :] = np.copy(tmp_f_)

        x_[m_c:, :] = np.copy(x_next_[:m_res, :])
        obj_[m_c:, :] = np.copy(obj_next_[:m_res, :])

        #for i=0:m:
        #    if i<=m_c:
        #        x[i,:] = tmp[i,:]
        #        f[i] = tmp_f[i]
        #    else:
        #        x[i,:] = xnew[fit[i-m_c,3],:]
        #        f[i] = f1[fit[i-m_c,3]]


        return x_, obj_
