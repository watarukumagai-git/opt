#coding: utf-8
import numpy as np
import pandas as pd
import random as rnd
import math

class crossover_class:
    def __init__(self, x1_, x2_):
        self.x1_ = x1_.copy()
        self.x2_ = x2_.copy()
        self.N = len(x1_)

    def Uniform(self, Pcr):
        child = np.zeros(self.N)
        r = np.random.rand(self.N)
        # uniform crossover
        idx1 = np.where(r <= Pcr)
        idx2 = np.where(r > Pcr)
        child[idx1] = self.x2_[idx1]
        child[idx2] = self.x1_[idx2]
        return child


    def SBX(self, Pcr):
        eps = 20

        if rnd.random() <= Pcr:
            r = np.random.rand(self.N)
            B = np.zeros(self.N)
            idx1 = np.where(r <= 0.5)
            idx2 = np.where(r > 0.5)
            B[idx1] = np.power(2*r[idx1], 1/float(eps+1))
            B[idx2] = 1/(np.power(2-2*r[idx2], 1/float(1+eps)))
            child1 = 0.5*((np.ones(self.N)-B)*self.x1_+(np.ones(self.N)+B)*self.x2_)
            child2 = 0.5*((np.ones(self.N)+B)*self.x1_+(np.ones(self.N)-B)*self.x2_)
        else:
            child1 = np.copy(self.x1_)
            child2 = np.copy(self.x2_)

        return child1, child2
    
    
    def BLX_alpha(self, alpha):
        d = np.abs(self.x1_-self.x2_)
        MIN = np.min(np.stack([self.x1_, self.x2_]), axis=0)
        X = MIN - alpha*d  #0 - 0.25*d = -0.25*d
        Y = MIN + alpha*d  #0 + 0.25*d = 0.25*d
        xnew = X + np.random.rand(self.N)*(Y-X)  #-0.25*d + 0.5*0.5*d = -0.25*d + 0.25*d = 0
        return xnew

