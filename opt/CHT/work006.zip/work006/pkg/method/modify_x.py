#coding: utf-8
import numpy as np
import random as rnd

class Modx:
    def __init__(self, seedflag, pattern, type_mod='round'):
        self.type_mod = type_mod
        self.seedflag = seedflag
        self.pattern = pattern
            
    def modified_x(self, x_, x_ul):
        if self.type_mod == 'round':
            x_ = np.where(x_<x_ul[:,0], x_ul[:,0], x_)
            x_ = np.where(x_>x_ul[:,1], x_ul[:,1], x_)
        elif self.type_mod == 'reflect':
            x_ = np.where(x_<x_ul[:,0], x_ul[:,0] + np.abs(x_-x_ul[:,0]), x_)
            x_ = np.where(x_>x_ul[:,1], x_ul[:,1] - np.abs(x_ul[:,1]-x_), x_)
        elif self.type_mod == 'torus':
            x_ = np.where(x_<x_ul[:,0], x_ul[:,1] - np.abs(x_-x_ul[:,0]), x_)
            x_ = np.where(x_>x_ul[:,1], x_ul[:,0] + np.abs(x_ul[:,1]-x_), x_)
        elif self.type_mod == 'none':
            x_ = np.copy(x_)
        return x_

    def fix_pattern(self, x_):
        if np.any(self.seedflag==1):
            x_ = np.where(self.seedflag, self.pattern, x_)
        else:
            x_ = np.copy(x_)
        return x_