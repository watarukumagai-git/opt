#coding: utf-8
import numpy as np

class weight_update_class:
    def __init__(self, m):
        self.m = m
        self.learning_rate = 0.01
        self.mu = 1.0
        self.sigma = 0.05
        self.alpha_best = 0.5

    def update_weight(self, alpha):
        delta = pow(10,-15)
        w = np.zeros((self.m, 2))
        w[:,0] = alpha*(np.arange(self.m))/(self.m-1)
        w[:,0] = np.where(w[:,0]==0, delta, w[:,0])
        w[:,1] = 1 - w[:,0]
        return w
    
    def update_alpha(self, update_gbest):
        if update_gbest == True:
            self.alpha_best = self.alpha
        self.mu = (1-self.learning_rate)*self.mu + self.learning_rate*self.alpha_best
        self.alpha = np.random.normal(self.mu, self.sigma)
        self.alpha = np.clip(self.alpha, 0, 1)
        return self.alpha
