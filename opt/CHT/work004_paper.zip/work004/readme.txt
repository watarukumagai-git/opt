work002
MOEA/D and adaptive weight
start 20220727
min-max scaling
multi-run

angle between referent points