work003
SHADE
binary
benchmark: non-convex