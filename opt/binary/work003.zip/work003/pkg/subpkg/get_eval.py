#coding: utf-8
import numpy as np

class get_obj_class:
    def get_obj(self, prob, x_):
        # x_: (m, N)
        if x_.ndim > 1:
            # obj_: (m, 1)
            obj_ = np.array([prob.object_function(x_[i, :]) for i in range(0, x_.shape[0])])
        # x_: (N)
        else:
            # obj_: (1)
            obj_ = prob.object_function(x_)
        return obj_