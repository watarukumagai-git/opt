#coding: utf-8
import os
from os import path
import gc
import numpy as np

from .import_data import import_data_class
from ..method import JADE
from ..method import SHADE
from ..method.SHADE.DE.DE_update import x_update_class
from ..method.SHADE.param_update import param_update_class
from ..method.JADE.DE.DE_update import x_update_class
from ..method.JADE.param_update import param_update_class
from .get_eval import get_obj_class

def get_minmax_listindex(_l, type_='min'):
    if type_=='max':
        return _l.index(max(_l))
    if type_=='min':
        return _l.index(min(_l))

def get_minmax_arrayindex(_a, type_='min'):
    if type_=='max':
        return np.argmax(_a)
    if type_=='min':
        return np.argmin(_a)

class get_sol_loop_class:
    def main_loop(self, prob, alg_para, run, start_time):
        # get parameters
        # problem parameters
        N = prob.N
        num_bin = prob.num_bin
        num_con = prob.num_con

        # algorithm parameters
        DE_type = alg_para[0]
        iter_max = alg_para[1]
        m = alg_para[2]

        # 1. databox gene
        # obj: [obj]
        obj_box = np.zeros((m, iter_max))
        # obj_gbest_box: [obj]
        obj_gbest_box = np.zeros(iter_max)

        # 2. initial solution
        data = import_data_class().get_dataset(run, 2)
        #x = data[0:m, 0:N]*(prob.xmax-prob.xmin) + prob.xmin
        # x_ul: (N, 2), [min, max]
        if num_bin > 0:
            x = data[:m, :N]*(prob.x_ul[:, 1]-prob.x_ul[:, 0]) + prob.x_ul[:, 0]
            x[:, num_con:] = np.random.randint(0, 2, (m, num_bin))
        else:
            x = data[:m, :N]*(prob.x_ul[:, 1]-prob.x_ul[:, 0]) + prob.x_ul[:, 0]

        del data
        gc.collect()


        work_path = path.dirname( path.abspath(__file__) )
        os.chdir(work_path)


        # get obj: (m)
        obj = get_obj_class().get_obj(prob, x)    
        idx_gbest = get_minmax_arrayindex(obj, type_='min')
        x_gbest = x[idx_gbest]
        obj_gbest = obj[idx_gbest]
        print('inital obj_gbest = ', obj_gbest)

        # 3. iteration loop                
        iter = 0
        s_F = []
        s_C = []
        if DE_type == 1:
            DE_x_update_instance = JADE.DE.DE_update.x_update_class(m, N, num_con, num_bin)
            DE_param_update_instance = JADE.param_update.param_update_class(m)
            (DE_x_update_instance.F, DE_x_update_instance.C) = DE_param_update_instance.update_param(s_F, s_C)
        elif DE_type == 2:
            DE_x_update_instance = SHADE.DE.DE_update.x_update_class(m, N, num_con, num_bin)
            DE_param_update_instance = SHADE.param_update.param_update_class(m)
            (DE_x_update_instance.F, DE_x_update_instance.C) = DE_param_update_instance.update_param(s_F, s_C, iter)

        while (iter <= iter_max - 1):
            # 4. solution update
            (x, obj) = DE_x_update_instance.DE_update(prob, x, obj)
            s_F = DE_x_update_instance.F[DE_x_update_instance.update_idx_]
            s_C = DE_x_update_instance.C[DE_x_update_instance.update_idx_]
            if DE_type == 1:
                (DE_x_update_instance.F, DE_x_update_instance.C) = DE_param_update_instance.update_param(s_F, s_C)
            elif DE_type == 2:
                (DE_x_update_instance.F, DE_x_update_instance.C) = DE_param_update_instance.update_param(s_F, s_C, iter)
            idx_gbest = get_minmax_arrayindex(obj, type_='min')
            
            # other data update
            obj_box[:, iter] = obj.copy()
            if obj[idx_gbest] < obj_gbest: 
                x_gbest = x[idx_gbest]
                obj_gbest = obj[idx_gbest]
            obj_gbest_box[iter] = obj_gbest.copy()

            iter = iter + 1

        return obj_box, x_gbest, obj_gbest_box