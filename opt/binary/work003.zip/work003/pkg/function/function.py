#coding: utf-8
import numpy as np

class Function:
    def __init__(self, problem_type, N, DE_type, binary_rate):
        self.problem_type = problem_type
        self.N = N
        self.DE_type = DE_type
        self.binary_rate = binary_rate
        self.x_ul = np.ones((self.N, 2))
        self.x_ul[:, 0] = -5 * self.x_ul[:, 0]
        self.x_ul[:, 1] = 5 * self.x_ul[:, 1]
        self.num_bin = int(self.N * self.binary_rate)
        self.num_con = self.N - self.num_bin

    def get_opt(self):
        # fn_opt = -78.33233140754282*self.N
        xn_opt = -2.903534027771177
        x_opt = xn_opt * np.ones(self.N)
        if self.num_bin > 0:
            x_opt[self.num_con:] = 1
        f_opt = self.object_function(x_opt)
        return x_opt, f_opt

    def object_function(self, x__):
        return (np.power(x__, 4) - 16*np.power(x__, 2) + 5*x__).sum()
