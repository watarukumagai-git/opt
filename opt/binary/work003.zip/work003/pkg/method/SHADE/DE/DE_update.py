#coding: utf-8
import numpy as np
from .crossover import crossover_class, binary_crossover_class
from .mutation import mutation_class, binary_mutation_class
from ....subpkg.get_eval import get_obj_class

def get_array_rank(_a):
    return np.argsort(_a)

def get_list_rank(_l):
    return [sorted(_l).index(x) for x in _l]

class x_update_class:
    def __init__(self, m, N, num_con, num_bin):
        self.m = m
        self.N = N
        self.mutation_type = 'CP1'
        self.crossover_type = 'binomial'
        self.rho_min = 2/self.m
        self.rho_max = 0.2
        self.num_con = num_con
        self.num_bin = num_bin
        self.pm = 0.001

    def neighbor_gene(self, x_, obj_):
  	    # x_: (m, N)
	    # obj_: (m,)
        num_diff = 1

        if self.num_bin > 0:
            x_con = x_[:, :self.num_con]
            x_bin = x_[:, self.num_con:]

            # real mutation
            mutate = mutation_class(self.F, x_con)
            if self.mutation_type == 'rand1':
                u_con = mutate.rand(num_diff=num_diff)
            elif self.mutation_type == 'CP1':
                rho = np.random.rand(self.m)*(self.rho_max-self.rho_min) + self.rho_min
                idx_rank = get_array_rank(obj_)
                num_better = np.clip(self.m*rho, 2, None).astype(int)
                u_con = mutate.CP(idx_rank, num_better, num_diff=num_diff)
            
            # real crossover
            xover = crossover_class(self.C, x_con, u_con)
            if self.crossover_type == 'binomial':
                u_con = xover.binomial()

            # binary crossover
            xover = binary_crossover_class(x_bin)
            u_bin = xover.binomial()

            # binary mutation
            mutate = binary_mutation_class(self.pm, u_bin)
            u_bin = mutate.rand()

            u = np.concatenate([u_con, u_bin], axis=1)

        else:
            #mutation
            mutate = mutation_class(self.F, x_)
            if self.mutation_type == 'rand1':
                u = mutate.rand(num_diff=num_diff)
            elif self.mutation_type == 'CP1':
                rho = np.random.rand(self.m)*(self.rho_max-self.rho_min) + self.rho_min
                idx_rank = get_array_rank(obj_)
                num_better = np.clip(self.m*rho, 2, None).astype(int)
                u = mutate.CP(idx_rank, num_better, num_diff=num_diff)

            #crossover
            xover = crossover_class(self.C, x_, u)
            if self.crossover_type == 'binomial':
                u = xover.binomial()
        
        return u

    def selection(self, x__, obj__, x_nei__, obj_nei__):
        update_idx_ = np.where(obj__ > obj_nei__)[0]
        if len(update_idx_) > 0:
            x__[update_idx_, :] = x_nei__[update_idx_, :].copy()
            obj__[update_idx_] = obj_nei__[update_idx_].copy()
        return x__, obj__, update_idx_

    def DE_update(self, prob, x, obj):
        x_nei = self.neighbor_gene(x, obj)
        obj_nei = get_obj_class().get_obj(prob, x_nei)    
        (x_, obj_, update_idx_) = self.selection(x, obj, x_nei, obj_nei)
        if prob.DE_type == 2:
            self.update_idx_ = update_idx_
        return x_, obj_