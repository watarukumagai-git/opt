#coding: utf-8
import numpy as np

class crossover_class:
    def __init__(self, C, x1_, x2_):
        self.x1 = x1_.copy()
        self.x2 = x2_.copy()
        (self.m, self.N) = x1_.shape
        self.C = C*np.ones(self.m)

    def binomial(self):
        # theta: (m, N)
        theta = np.random.rand(self.m, self.N)
        lambda_ = np.random.randint(0, self.N, size=self.m)
        # binomial crossover
        child = np.copy(self.x1)
        for i in range(0, self.m):
            nidx = np.where(theta[i, :] <= self.C[i])
            child[i, nidx] = self.x2[i, nidx]
            child[i, lambda_[i]] = self.x2[i, lambda_[i]]
        return child
    
class binary_crossover_class:
    def __init__(self, x_):
        self.x_ = x_.copy()
        (self.m, self.N) = x_.shape
        self.C = 0.5

    def binomial(self):
        # theta: (m, N)
        theta = np.random.rand(self.m, self.N)
        child = np.copy(self.x_)
        for i in range(0, self.m):
            idx_ = np.random.choice(self.m-1, size=2, replace=False)
            nidx = np.where(theta[i, :] <= self.C)
            child[i, :] = self.x_[idx_[0], :]
            child[i, nidx] = self.x_[idx_[1], nidx]
        return child
    
    