work004
SHADE
binary & constraint
benchmark: non-convex