# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
import random
import time
import os
from os import path
import scipy as sp
import matplotlib.pyplot as plt

from pkg.build_model import build_model_class
from pkg.figure_save import figure_save_class
from pkg.make_data import make_data_class



def my_makedirs(path):
    if not os.path.isdir(path):
        os.makedirs(path)

def get_path():
    if "My Drive" in os.getcwd() or "root" in os.getcwd():
        dir_base = os.getcwd() + '/output'
        my_makedirs(dir_base)
        my_makedirs(dir_base + '/file')
        my_makedirs(dir_base + '/fig')
    else:
        work_path = path.dirname( path.abspath(__file__) )
        os.chdir(work_path)
        #work_path = os.path.abspath('..\\..\\') 
        dir_base = work_path + '\\output'
        my_makedirs(dir_base)
        my_makedirs(dir_base + "\\file")
        my_makedirs(dir_base + "\\fig")
    print(dir_base)
    return dir_base

def get_new_data(num_mesh, minmax):
    # minmax = [xmin, xmax, ymin, ymax, zmin, zmax]    
    x = np.linspace(minmax[0],minmax[1],num_mesh)
    y = np.linspace(minmax[2],minmax[3],num_mesh)
    z = np.linspace(minmax[4],minmax[5],num_mesh)
    X, Y, Z = np.meshgrid(x,y,z)
    new_X = np.concatenate([X.reshape(-1,1), Y.reshape(-1,1)], 1)
    new_X = np.concatenate([new_X, Z.reshape(-1,1)], 1)
    return new_X, z

# time start
time_start = time.time()
print ("started.")

# data load
ori_num_samples = 100
# 2次元データ用
# Curvature = 1
# Angle = 90
# Val = 1/Curvature/30
# DataNum = 200
# train_data, xlimsave = data_create(Curvature,Angle,0,Val,DataNum)

# 3次元データ用
sample = 1000
dim = 3
train_data = make_data(3, dim, sample).values
num_samples = len(train_data)
print("train data = ", train_data.shape)

print ("file import finished.")

# minmax = [xmin, xmax, ymin, ymax, zmin, zmax]
minmax = [-0.2, 1.0, -0.2, 1.0, -0.2, 1.0]
#minmax = [-0.5, 1.5, -0.5, 1.5, -0.2, 1.0]

# new data (grid positions in input space (2D))
num_mesh = int(num_samples/3)
(new_X, z) = get_new_data(num_mesh, minmax)
print("new_X = ", new_X.shape)


# scaling
(scaling, scaled) = make_data_class().scaling_scaled(new_X)
train_data = scaling(train_data)
new_X = scaling(new_X)

# get insctances of AE

#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#レイヤー設定
hidden_units = 3
epsilon = 0.5
layer_num = 6
incom_num = layer_num-1
node_num = 64
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
(transformed, encode_decode, history, model) = build_model_class().build_NN(train_data, hidden_units, layer_num, incom_num, node_num)
plot1 = history.history["loss"]
plot2 = history.history["val_loss"]

print ("training finished.")
time_end = time.time()
time_ = time_end - time_start
print("time = {:.2f} sec".format(time_))


# transform
train_z = transformed(train_data)
z = transformed(new_X)
print('z = ',z)
estimate_train_X = encode_decode(train_data)
predict_new_X = encode_decode(new_X)

print("train Z = ", train_z.shape)
print("new Z = ", z.shape)
print("estimate train X = ", estimate_train_X.shape)
print("predict new X = ", predict_new_X.shape)

feas_box = np.where((z>-1*epsilon) & (z<epsilon), 1, -1)

print ("transform finished.")
time_end = time.time()
time_ = time_end - time_start
print("time = {:.2f} sec".format(time_))



# get path
dir_base = get_path()


# rescaled
train_data = scaled(train_data)
new_X = scaled(new_X)
estimate_train_X = scaled(estimate_train_X)
predict_new_X = scaled(predict_new_X)

x_label_name = "$x_1$"
y_label_name = "$x_2$"
z_label_name = "$x_3$"

# figure save
# i-th principal component in grid positions of input space
for i in range(0, hidden_units):
    
    print("i=", i+1)

    # i-th principal component in grid positions of input space
    Z = z[:, i].reshape(num_mesh, num_mesh, num_mesh)
    #Z = [comp_scalar_pc([x,y], i) for (x,y) in zip(X,Y)]
    print('Z',np.shape(Z),'Y',np.shape(Y),'X',np.shape(X))

    # feas/infeas map
    F = feas_box[:, i].reshape(num_mesh, num_mesh, num_mesh)

    if np.all(Z!=0):
        fig_file_name = dir_base + "fig/AE_contour_PC" + str(i+1) + ".png"
        # figure_label = ['PC'+str(i+1), x_label_name, y_label_name, "train", xmin, xmax, ymin, ymax]
        figure_label = ['PC'+str(i+1), x_label_name, y_label_name,z_label_name, "train", xmin, xmax, ymin, ymax, zmin, zmax]
        # figure_save_class().principal_component_contourf_3D(figure_label, X, Y, Z, train_data, fig_file_name)
    else:
        print("all Z=0")
        print("contour skip")


    if np.all(F==1):
        print("all F=1")
        print("contourf skip")
    else:
        fig_file_name = dir_base + "fig/AE_contourf_PC" + str(i+1) + ".png"
        figure_label = ['PC'+str(i+1) + "_$\epsilon$=" + str(epsilon), x_label_name, y_label_name, z_label_name, "train", xmin, xmax, ymin, ymax, zmin, zmax]
        # figure_save_class().principal_component_contourf_3D(figure_label, X, Y, F, train_data, fig_file_name)
