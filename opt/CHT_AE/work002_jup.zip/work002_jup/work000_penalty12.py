# -*- coding: utf-8 -*-
# penalty: model1 + model2
import time
import os
from os import path
import copy
import numpy as np

from pkg.figure_save import figure_save_class

def my_makedirs(path):
    if not os.path.isdir(path):
        os.makedirs(path)

def get_path(folder):
    if "My Drive" in os.getcwd() or "root" in os.getcwd():
        dir_base = os.getcwd() + '/' + folder
        if folder == 'output':
            my_makedirs(dir_base)
            my_makedirs(dir_base + '/file')
            my_makedirs(dir_base + '/fig')
        dir_base = dir_base + '/'
    else:
        work_path = path.dirname( path.abspath(__file__) )
        os.chdir(work_path)
        #work_path = os.path.abspath('..\\..\\') 
        dir_base = work_path + '\\' + folder
        if folder == 'output':
            my_makedirs(dir_base)
            my_makedirs(dir_base + "\\file")
            my_makedirs(dir_base + "\\fig")
        dir_base = dir_base + '\\'
    print(dir_base)
    return dir_base

# time start
time_start = time.time()
print ("started.")

dir_base_input = get_path('input')
dir_base_output = get_path('output')

if "My Drive" in os.getcwd() or "root" in os.getcwd():
    dir_base_fig = dir_base_output + 'fig/'
    dir_base_file = dir_base_output + 'file/'
else:
    dir_base_fig = dir_base_output + 'fig\\'
    dir_base_file = dir_base_output + 'file\\'

# from .npy
train_data = np.load(dir_base_input + 'train_data.npy')
new_X = np.load(dir_base_input + 'new_X.npy')
save_penalty1 = np.load(dir_base_file + 'penalty_1.npy')
save_penalty2 = np.load(dir_base_file + 'penalty_2.npy')
print("train data = ", train_data.shape)
print("new X = ", new_X.shape)
print("save_penalty1 = ", save_penalty1.shape)
print("save_penalty2 = ", save_penalty2.shape)

minmax = [-0.2, 1.0, -0.2, 1.0, -0.2, 1.0]
label_name = ["$x_1$", "$x_2$", "$x_3$"]
epsilon1 = 0.1
epsilon2 = 0.15

mu = 0.5
multi_penalty = save_penalty1 + mu*save_penalty2
print("multi_penalty = ", multi_penalty.shape)

epsilon = epsilon1 + mu * epsilon2

plot_penalty = multi_penalty - epsilon
plot_penalty = np.clip(plot_penalty,0,None)
plot_penalty_place = -np.max(plot_penalty)/2
plot_penalty = np.where(plot_penalty == 0, plot_penalty_place, plot_penalty)

# penalty save
save_penalty = copy.deepcopy(multi_penalty)
# to .npy
np.save(dir_base_file + 'penalty_12', multi_penalty)
print ("save penalty finished.")

# figure save
fig_file_name = dir_base_fig + "AE_scatter_penalty_12.png"
figure_label = [label_name] + ["train", "new", "train(output)", "new(output)"] + [minmax]
# y1 = new_X, y2 = train_data, y3 = plot_penalty
figure_save_class().trend_3D_4(figure_label, new_X, train_data, plot_penalty, fig_file_name)

time_end = time.time()
time_ = time_end - time_start
print("time = {:.2f} sec".format(time_))
print("figuresave finished.")