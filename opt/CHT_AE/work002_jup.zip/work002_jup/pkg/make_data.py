# -*- coding: utf-8 -*-
import random

import numpy as np
import pandas as pd
from sklearn import datasets
from sklearn.preprocessing import MinMaxScaler

class make_data_class:
    def __init__(self, data_type, dim):
        self.data_type = data_type
        self.dim = dim
        
    #3D data create begin
    #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    #              3次元データ作成
    #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    def make_data(self, sample):
        def _sphere(dim, sample):
            # z: (sample, dim)
            z = np.random.randn(sample, dim)
            r = np.linalg.norm(z, axis= 1).reshape(sample, 1)
            return np.divide(z,r)
        def _uniform(dim, sample, range):
            r = np.random.random((sample, dim))
            return (range[1]-range[0])*r+range[0]

        if self.data_type==1:
            # s: (sample, dim)
            s = _sphere(self.dim, sample)
        elif self.data_type==2:
            r1 = 0
            r2 = 1
            # s: (sample, dim)
            s = _sphere(self.dim, sample)
            # r: (sample, dim)
            r = _uniform(self.dim, sample, [r1, r2])
            r = np.power(r, 1./self.dim)
            s = s*r
        elif self.data_type==3:
            #%%%%%%%%%%%%%%%%%%パラメータ設定%%%%%%%%%%%%%%%%%%
            #r1 = 0.05
            #r2 = 1
            r1 = 1
            r2 = 1
            # s: (sample, dim)
            s = _sphere(self.dim, sample)
            # r: (sample, dim)
            r = _uniform(self.dim, sample, [r1, r2])
            r = np.power(r, 1./self.dim)
            s = s*r
        s_df = pd.DataFrame(s)
        # piece
        for i in range(0, self.dim):
            s_df = s_df[s_df.loc[:, i]>0]
        return s_df

    #3D data create end


    #2D data create begin
    #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    #              2次元データ作成
    #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    def get_rotated(X, t, deg=False):
        def rotation_matrix_2D(t):
            R = np.array([[np.cos(t), -np.sin(t)],
                        [np.sin(t),  np.cos(t)]])
            return R

        # if deg == True, degree
        # if deg == False, radian
        if deg == True:
            t = np.deg2rad(t)

        R = rotation_matrix_2D(t)

        return  np.dot(X, R)

    def ori_datasets(type_, samples_, features_):
        if type_ == 1:
            # features = 2
            data, target = datasets.make_moons(n_samples=samples_, random_state=123)
            target_list = np.unique(target)
            ori_new_data = data[target==target_list[0], :]
            ori_new_data[:, 1] = ori_new_data[:, 1] - 0.5
            new_data = np.concatenate([ori_new_data, ori_new_data, ori_new_data])
            for i in range(0,3):
                random.seed(i)
                new_data[i*len(ori_new_data):(i+1)*len(ori_new_data), 1] = ori_new_data[:, 1] + np.random.randn(len(ori_new_data))*0.1
            new_data = get_rotated(new_data, np.pi/6)
        return new_data

    def scaling_scaled(self, data_0):
        scaler = MinMaxScaler(feature_range=(0, 1))
        scaler.fit(data_0)
        min_ = scaler.data_min_
        max_ = scaler.data_max_
        def scaling(data):
            array_scaler = scaler.transform(data)
            return array_scaler
        def scaled(data):
            array_unscaler = scaler.inverse_transform(data)
            return array_unscaler
        return scaling, scaled

    def arc_func(CoM,Radius,x):
        y = np.sqrt(Radius**2 - ((x - CoM[0])**2)) + CoM[1]
        # print(Radius**2,((x - CoM[0])**2) )
        return y

    def circle_param(Curvature,Angle):
        CoM = np.zeros(2)
        if Curvature == 0:
            Radius = 1/(Curvature+0.0001)
        else:
            Radius = 1/Curvature
        x = Radius * np.cos(np.pi/2 - Angle/360*2*np.pi/2)
        y1 = Radius * np.sin(np.pi/2 - Angle/360*2*np.pi/2)
        y2 = Radius
        xlim = x
        CoM[0] = 0
        CoM[1] = -(y1 + y2) / 2
        return CoM, Radius, xlim    

    def rotation(Data,CoM):
        rt = 3
        temp = (Data[:,0] - CoM[0]) * np.sin(np.pi*rt/4) - (Data[:,1] - CoM[1]) * np.cos(np.pi*rt/4) + CoM[0]
        Data[:,1] = (Data[:,0] - CoM[0]) * np.cos(np.pi*rt/4) + (Data[:,1] - CoM[1]) * np.sin(np.pi*rt/4) + CoM[1]
        Data[:,0] = temp
        # print(Data)
        xmedium = np.max(Data[:,0]) + np.min(Data[:,0])
        ymedium = np.max(Data[:,1]) + np.min(Data[:,1])
        Data[:,0] -= xmedium/2
        Data[:,1] -= ymedium/2

        return Data

    def data_create(Curvature,Angle,Mean,Val,DataNum):
        Data = np.zeros(DataNum*2).reshape(-1,2)
        CoM, Radius, xlim = circle_param(Curvature,Angle)
        Data[:,0] = (np.random.rand(DataNum) - 0.5) * 2 * xlim
        Data[:,1] = arc_func(CoM,Radius,Data[:,0])
        Data = rotation(Data,CoM)
        Data[:,0] += np.random.normal(Mean,Val,(DataNum,))
        Data[:,1] += np.random.normal(Mean,Val,(DataNum,))

        return Data, xlim
    #2D data create end
