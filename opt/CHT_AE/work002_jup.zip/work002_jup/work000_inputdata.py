# -*- coding: utf-8 -*-
import time
import os
from os import path
import numpy as np

from pkg.make_data import make_data_class

def my_makedirs(path):
    if not os.path.isdir(path):
        os.makedirs(path)

def get_path(folder):
    if "My Drive" in os.getcwd() or "root" in os.getcwd():
        dir_base = os.getcwd() + '/' + folder + '/'
        my_makedirs(dir_base)
    else:
        work_path = path.dirname( path.abspath(__file__) )
        os.chdir(work_path)
        #work_path = os.path.abspath('..\\..\\') 
        dir_base = work_path + '\\' + folder + '\\'
        my_makedirs(dir_base)
    print(dir_base)
    return dir_base

def get_new_data(num_mesh, minmax):
    # minmax = [xmin, xmax, ymin, ymax, zmin, zmax]    
    x = np.linspace(minmax[0],minmax[1],num_mesh)
    y = np.linspace(minmax[2],minmax[3],num_mesh)
    z = np.linspace(minmax[4],minmax[5],num_mesh)
    X, Y, Z = np.meshgrid(x,y,z)
    new_X = np.concatenate([X.reshape(-1,1), Y.reshape(-1,1)], 1)
    new_X = np.concatenate([new_X, Z.reshape(-1,1)], 1)
    return new_X, z


# time start
time_start = time.time()
print ("started.")

# data load
ori_num_samples = 100
# 2次元データ用
# Curvature = 1
# Angle = 90
# Val = 1/Curvature/30
# DataNum = 200
# train_data, xlimsave = data_create(Curvature,Angle,0,Val,DataNum)

# 3次元データ用
dim = 3
MK = make_data_class(3, dim)

sample = 1000
train_data = MK.make_data(sample).values
num_samples = len(train_data)
print("train data = ", train_data.shape)

print ("file import finished.")

# minmax = [xmin, xmax, ymin, ymax, zmin, zmax]
minmax = [-0.2, 1.0, -0.2, 1.0, -0.2, 1.0]
#minmax = [-0.5, 1.5, -0.5, 1.5, -0.2, 1.0]

# new data (grid positions in input space (2D))
num_mesh = int(num_samples/3)
(new_X, z) = get_new_data(num_mesh, minmax)
print("new_X = ", new_X.shape)

dir_base = get_path('input')

# to .npy
np.save(dir_base + 'train_data', train_data)
np.save(dir_base + 'new_X', new_X)
np.save(dir_base + 'z', z)

print ("input data saved.")

time_end = time.time()
time_ = time_end - time_start
print("time = {:.2f} sec".format(time_))