# -*- coding: utf-8 -*-
import time
import os
from os import path
import copy
import numpy as np

from keras import models
from pkg.figure_save import figure_save_class

if "My Drive" in os.getcwd() or "MyDrive" in os.getcwd() or "root" in os.getcwd():
    separator = '/'
else:
    separator = '\\'


def my_makedirs(path):
    if not os.path.isdir(path):
        os.makedirs(path)

def get_path(folder):
    if "My Drive" in os.getcwd() or "root" in os.getcwd():
        work_path = os.getcwd()
    else:
        work_path = path.dirname( path.abspath(__file__) )
        os.chdir(work_path)
        #work_path = os.path.abspath('..\\..\\') 
    dir_base = work_path + separator + folder
    if folder == 'output':
        my_makedirs(dir_base)
        my_makedirs(dir_base + separator + 'file')
        my_makedirs(dir_base + separator + 'fig')
    dir_base = dir_base + separator
    print(dir_base)
    return dir_base

# time start
time_start = time.time()
print ("started.")

minmax = [-0.2, 1.0, -0.2, 1.0, -0.2, 1.0]
label_name = ["$x_1$", "$x_2$", "$x_3$"]

dir_base_input = get_path('input')
dir_base_output = get_path('output')

dir_base_fig = dir_base_output + 'fig' + separator
dir_base_file = dir_base_output + 'file' + separator


# from .npy
train_data = np.load(dir_base_input + 'train_data.npy')

# load AE model
NNmodel = models.load_model(dir_base_input + 'AE-1.h5')
print("train data = ", train_data.shape)

# predict
new_X = np.zeros((3, 3))
predict_new_X = NNmodel.predict(new_X, verbose=0)
print(predict_new_X)

## penalty calculation
dif = new_X - predict_new_X
penalty = np.sqrt(sum(map(lambda i: i**2, dif.T)))
print(penalty.shape)

epsilon1 = 0.1
plot_penalty = penalty - epsilon1
plot_penalty = np.clip(plot_penalty,0,None)
print(plot_penalty)
plot_penalty_place = -np.max(plot_penalty)/2
plot_penalty = np.where(plot_penalty == 0, plot_penalty_place, plot_penalty)

# penalty save
save_penalty = copy.deepcopy(penalty)
# to .npy
np.save(dir_base_file + 'penalty_1', penalty)
print ("save penalty finished.")

# figure save
fig_file_name = dir_base_fig + "AE_scatter_penalty_1.png"
figure_label = [label_name] + ["train", "new", "train(output)", "new(output)"] + [minmax]
# y1 = new_X, y2 = train_data, y3 = plot_penalty
figure_save_class().trend_3D_4(figure_label, new_X, train_data, plot_penalty, fig_file_name)


time_end = time.time()
time_ = time_end - time_start
print("time = {:.2f} sec".format(time_))
print("figuresave finished.")