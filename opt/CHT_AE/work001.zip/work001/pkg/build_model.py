# -*- coding: utf-8 -*-
import keras
from keras import models
from keras.models import Sequential
from keras.layers import BatchNormalization
from keras.layers.core import Dense, Activation, Dropout
from keras import regularizers


class build_model_class:
    def __init__(self, hidden_units, layer_num, incom_num, node_num):
        self.hidden_units = hidden_units
        self.layer_num = layer_num
        self.incom_num = incom_num
        self.node_num = node_num

    def build_NN(self, X_train):
        #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        #              ネットワーク構築
        #%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        # input and output units
        in_neurons = X_train.shape[1]
        # input and output units
        out_neurons = X_train.shape[1]
        # hidden units
        hidden_neurons = self.hidden_units

        #%%%%%%%%%%%%%%%%%%パラメータ設定begin%%%%%%%%%%%%%%%%%%
        num_of_training_epochs = 1500 #エポック数

        # 10~20
        minibatch_size = 20 #ミニバッチ数

        # 1:rmsprop, 2:adam
        optimizertype = 2

        #活性化関数
        # actfunc1 = 'relu'
        # actfunc1 = 'gelu'
        # actfunc1 = 'elu'
        actfunc1 = 'PReLU'
        # actfunc1 = 'sigmoid'
        # actfunc1 = 'selu'
        # actfunc1 = 'tanh'
        # actfunc2 = 'sigmoid'
        # actfunc2 = 'gelu'
        actfunc2 = 'tanh'
        # actfunc2 = 'elu'
        # actfunc2 = 'PReLU'
        # actfunc2 = 'selu'
        # actfunc2 = 'identity'



        if optimizertype == 1:
            optimizer = 'rmsprop'
        elif optimizertype == 2:
            optimizer = 'adam'
            #optimizer = 'Adamax'

        #損失関数
        #loss_fn = tf.keras.losses.MeanAbsolutePercentageError()
        # loss_fn = "mean_squared_logarithmic_error"
        # loss_fn = "mean_absolute_error"
        # loss_fn = "cosine_similarity"
        # loss_fn = "log_cosh"
        loss_fn = 'mean_squared_error'

        model = Sequential()
        reg_mean = 0.0 #各ノード印加外乱平均値確率
        dropout_pct = 0.1 #ドロップアウト確率
        #%%%%%%%%%%%%%%%%%%パラメータ設定end%%%%%%%%%%%%%%%%%%
        # model.add(Dense(hidden_neurons, input_shape=(in_neurons,),activity_regularizer=keras.regularizers.l1(0.1)))
        if self.layer_num == 1:
            model.add(Dense(hidden_neurons, input_shape=(in_neurons,)))
            model.add(Activation(actfunc1))
            model.add(BatchNormalization())
            model.add(Dense(out_neurons))
            if actfunc2 != 'identity':
                model.add(Activation(actfunc2))
            model.summary()
        else:
            for it in range(self.layer_num):
                if it == 0:
                    model.add(Dense(self.node_num, input_shape=(in_neurons,),activity_regularizer=keras.regularizers.l1(reg_mean)))
                    model.add(BatchNormalization())
                    model.add(Activation(actfunc1))
                    model.add(Dropout(dropout_pct))
                    # model.add(BatchNormalization())
                elif it < self.incom_num:
                    model.add(Dense(self.node_num, input_shape=(self.node_num,),activity_regularizer=keras.regularizers.l1(reg_mean)))
                    model.add(BatchNormalization())
                    model.add(Activation(actfunc1))
                    model.add(Dropout(dropout_pct))
                    # model.add(BatchNormalization())
                elif it == self.incom_num:
                    model.add(Dense(hidden_neurons, input_shape=(self.node_num,),activity_regularizer=keras.regularizers.l1(reg_mean)))
                    # model.add(BatchNormalization())
                    model.add(Activation(actfunc1))
                    # model.add(BatchNormalization())
                else:
                    model.add(Dense(hidden_neurons, input_shape=(hidden_neurons,),activity_regularizer=keras.regularizers.l1(reg_mean)))
                    # model.add(BatchNormalization())
                    model.add(Activation(actfunc1))
                    # model.add(BatchNormalization())

            # model.add(BatchNormalization())
            layer_decode = (self.layer_num-1)*4 + 1
            for it in range(self.layer_num):
                if it < (self.layer_num - self.incom_num -1):
                    model.add(Dense(hidden_neurons, input_shape=(hidden_neurons,),activity_regularizer=keras.regularizers.l1(reg_mean)))
                    model.add(BatchNormalization())
                    model.add(Activation(actfunc1))
                    model.add(Dropout(dropout_pct))
                    # model.add(BatchNormalization())
                elif it == (self.layer_num - self.incom_num -1):
                    model.add(Dense(self.node_num, input_shape=(hidden_neurons,),activity_regularizer=keras.regularizers.l1(reg_mean)))
                    model.add(BatchNormalization())
                    model.add(Activation(actfunc1))
                    model.add(Dropout(dropout_pct))
                    # model.add(BatchNormalization())
                elif it < self.layer_num -1:
                    model.add(Dense(self.node_num, input_shape=(self.node_num,),activity_regularizer=keras.regularizers.l1(reg_mean)))
                    model.add(BatchNormalization())
                    model.add(Activation(actfunc1))
                    model.add(Dropout(dropout_pct))
                    # model.add(BatchNormalization())    
                else:
                    model.add(Dense(out_neurons))
                    if actfunc2 != 'identity':
                        layer_decode += 1
                        model.add(Activation(actfunc2))
            model.summary()

        model.compile(loss=loss_fn, optimizer=optimizer)
        history = model.fit(X_train, X_train, batch_size=minibatch_size, epochs=num_of_training_epochs, validation_split=0.05)

        self.encoder = models.clone_model(model)
        self.encoder.compile(loss=loss_fn, optimizer=optimizer)
        self.encoder.set_weights(model.get_weights())
        # delete final layer
        # self.encoder.pop()
        for it in range(layer_decode):
            self.encoder.pop()
        # self.encoder.summary()
        
        return history, model

    def transformed(self, new_X):
        z = self.encoder.predict(new_X, verbose=0)
        return z

    def encode_decode(self, model, new_X):
        outputX = model.predict(new_X, verbose=0)
        return outputX
