#coding: utf-8
import numpy as np
import math
import os
from os import path
from keras import models


class Function:
    def __init__(self, dir_base, problem_type, DE_type, d_exp, eval_type):
        self.problem_type = problem_type
        self.PSO_type = DE_type
        self.eval_type = eval_type
        self.d = pow(10, d_exp)
        filename_list = ['train_data.npy', 'AE-1.h5']
        #(self.data, self.model) = self.get_parameter(dir_base, filename_list)
        self.data = self.get_parameter(dir_base, filename_list)
        self.N = self.data.shape[1]
        self.x_ul = np.ones((self.N, 2))
        self.x_ul[:, 0] = 0 * self.x_ul[:, 0]
        self.x_ul[:, 1] = 1 * self.x_ul[:, 1]

    #def get_parameter(self, dir_base, filename_list):
    #    train_data = np.load(dir_base + filename_list[0])
    #    print('train data = ', train_data.shape)
    #    # load AE model
    #    NNmodel = models.load_model(dir_base + filename_list[1])
    #    return train_data, NNmodel

    def get_parameter(self, dir_base, filename_list):
        train_data = np.load(dir_base + filename_list[0])
        self.path = dir_base + filename_list[1]
        return train_data

    def get_opt(self):
        x_opt = (1-math.sqrt(self.d))*np.ones(self.N)
        #f_opt = pow(x_opt[0], 2)
        f_opt = 0
        return x_opt, f_opt

    def object_function(self, x__):
        c = 0
        if self.problem_type <= 4:
            return np.power(x__-c, 2).mean()

    def constraint_function(self, x__):
        def calc_penalty(new_X):
            #new_X = new_X.reshape((self.N, 1))
            # load AE model
            NNmodel = models.load_model(self.path)
            #predict_new_X = NNmodel.predict(new_X, verbose=0)
            predict_new_X = new_X
            dif = new_X - predict_new_X
            penalty = np.sqrt(sum(map(lambda i: i**2, dif.T)))
            return penalty
        
        def _g1(x__, c):
            return calc_penalty(x__-c) - self.d

        if self.problem_type == 1:
            return _g1(x__, 0)
        else:
            return 0