#coding: utf-8 
import os
import numpy as np
import pandas as pd
import datetime
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import matplotlib.cm as cm
if "My Drive" not in os.getcwd() and "MyDrive" not in os.getcwd() and "root" not in os.getcwd():
    plt.rcParams['font.family'] = 'Times New Roman'

class figure_save_class:
    def principal_component_contour(self, figure_label, X, Y, Z, train_data, fig_file_name):
        title_name = figure_label[0]
        x_label_name = figure_label[1]
        y_label_name = figure_label[2]
        label_name = figure_label[3]
        xmin = figure_label[4]
        xmax = figure_label[5]
        ymin = figure_label[6]
        ymax = figure_label[7]

        fig = plt.figure(figsize=(6,5))
        ax = fig.add_subplot(1,1,1)

        con = ax.contour(X, Y, Z, 20, linewidths=0.75, cmap=cm.jet)
        ax.scatter(train_data[:, 0], train_data[:, 1], s=4, label=label_name)
        cbar = fig.colorbar(con)

        ax.set_xlim(xmin, xmax)
        ax.set_ylim(ymin, ymax)
        ax.set_title(title_name)
        ax.set_xlabel(x_label_name, fontsize=16)
        ax.set_ylabel(y_label_name, fontsize=16)
        ax.tick_params(direction = "in")

        plt.legend(loc='upper right', fontsize=12)
        plt.tick_params(labelsize=12)
        plt.tight_layout()
        plt.savefig(fig_file_name)
        plt.close()

    
    def principal_component_contourf_3D(self, figure_label, X, Y, Z, train_data, fig_file_name):
        title_name = figure_label[0]
        x_label_name = figure_label[1]
        y_label_name = figure_label[2]
        z_label_name = figure_label[3]
        label_name = figure_label[4]
        xmin = figure_label[5]
        xmax = figure_label[6]
        ymin = figure_label[7]
        ymax = figure_label[8]
        zmin = figure_label[9]
        zmax = figure_label[10]

        fig = plt.figure(figsize=(5,5))
        ax = fig.add_subplot(1,1,1, projection='3d')

        # ax.contourf(X, Y, Z, alpha=0.4, cmap='Greys')
        
        # ax.plot_surface(X, Y, Z.reshape(1,-1))
        ax.scatter(train_data[:, 0], train_data[:, 1], train_data[:, 2], s=4, label=label_name)

        ax.set_xlim(xmin, xmax)
        ax.set_ylim(ymin, ymax)
        ax.set_zlim(zmin, zmax)
        ax.set_title(title_name)
        ax.set_xlabel(x_label_name, fontsize=16)
        ax.set_ylabel(y_label_name, fontsize=16)
        ax.set_zlabel(z_label_name, fontsize=16)
        ax.tick_params(direction = "in")

        plt.legend(loc='upper right', fontsize=12)
        plt.tick_params(labelsize=12)
        plt.tight_layout()
        plt.savefig(fig_file_name)
        plt.close()


    def twoD_plot(self, figure_label, x1, x2, fig_file_name):
        title_name = figure_label[0]
        x_label_name = figure_label[1]
        y_label_name = figure_label[2]
        label_name = figure_label[3]
        xmin = figure_label[4]
        xmax = figure_label[5]
        ymin = figure_label[6]
        ymax = figure_label[7]

        fig = plt.figure(figsize=(5,5))
        ax = fig.add_subplot(1,1,1)
        ax.scatter(x1, x2, s=4, label=label_name)

        ax.set_xlim([xmin, xmax])
        ax.set_ylim([ymin, ymax])
        ax.set_xlabel(x_label_name, fontsize=16)
        ax.set_ylabel(y_label_name, fontsize=16)
        ax.tick_params(direction = "in")

        plt.legend(loc='upper right', fontsize=12)
        plt.tick_params(labelsize=12)
        plt.tight_layout()
        plt.savefig(fig_file_name)
        plt.close()

    def twoD_plot_3D(self, figure_label, x1, x2, x3, fig_file_name):
        title_name = figure_label[0]
        x_label_name = figure_label[1]
        y_label_name = figure_label[2]
        z_label_name = figure_label[3]
        label_name = figure_label[4]
        xmin = figure_label[5]
        xmax = figure_label[6]
        ymin = figure_label[7]
        ymax = figure_label[8]
        zmin = figure_label[9]
        zmax = figure_label[10]

        fig = plt.figure(figsize=(5,5))
        ax = fig.add_subplot(1,1,1, projection='3d')
        ax.scatter(x1, x2, x3, s=4, label=label_name)

        ax.set_xlim([xmin, xmax])
        ax.set_ylim([ymin, ymax])
        ax.set_zlim([zmin, zmax])
        ax.set_xlabel(x_label_name, fontsize=16)
        ax.set_ylabel(y_label_name, fontsize=16)
        ax.set_zlabel(z_label_name, fontsize=16)
        ax.tick_params(direction = "in")

        plt.legend(loc='upper right', fontsize=12)
        plt.tick_params(labelsize=12)
        plt.tight_layout()
        plt.savefig(fig_file_name)
        plt.close()

    def scatter_decode_data(self, figure_label, x1, x2, z1, z2, fig_file_name):
        x_label_name = figure_label[0]
        y_label_name = figure_label[1]
        label1_name = figure_label[2]
        label2_name = figure_label[3]
        label3_name = figure_label[4]
        label4_name = figure_label[5]
        xmin = figure_label[6]
        xmax = figure_label[7]
        ymin = figure_label[8]
        ymax = figure_label[9]

        fig = plt.figure(figsize=(5,5))
        ax = fig.add_subplot(1,1,1)
        ax.scatter(x2[:,0], x2[:,1], s=2, facecolor='None', edgecolors='orange', lw=0.3, label=label2_name)
        ax.scatter(x1[:,0], x1[:,1], marker='o', s=4, facecolor='None', edgecolors='blue', label=label1_name)
        ax.scatter(z2[:,0], z2[:,1], s=2, facecolor='None', edgecolors='green', lw=0.3, label=label4_name)
        ax.scatter(z1[:,0], z1[:,1], marker='o', s=4, facecolor='None', edgecolors='red', label=label3_name)

        ax.set_xlim([xmin, xmax])
        ax.set_ylim([ymin, ymax])
        ax.set_xlabel(x_label_name, fontsize=16)
        ax.set_ylabel(y_label_name, fontsize=16)
        ax.tick_params(direction = "in")

        plt.legend(loc='lower left', fontsize=12)
        plt.tick_params(labelsize=12)
        plt.tight_layout()
        plt.savefig(fig_file_name)
        plt.close()

    def scatter_decode_data_3D(self, figure_label, x1, x2, z1, z2, fig_file_name):
        x_label_name = figure_label[0]
        y_label_name = figure_label[1]
        z_label_name = figure_label[2]
        label1_name = figure_label[3]
        label2_name = figure_label[4]
        label3_name = figure_label[5]
        label4_name = figure_label[6]
        xmin = figure_label[7]
        xmax = figure_label[8]
        ymin = figure_label[9]
        ymax = figure_label[10]
        zmin = figure_label[11]
        zmax = figure_label[12]

        fig = plt.figure(figsize=(5,5))
        ax = fig.add_subplot(1,1,1, projection='3d')
        ax.scatter(x2[:,0], x2[:,1], x2[:,2], s=2, facecolor='None', edgecolors='orange', lw=0.3, label=label2_name)
        ax.scatter(x1[:,0], x1[:,1], x1[:,2], marker='o', s=4, facecolor='None', edgecolors='blue', label=label1_name)
        ax.scatter(z2[:,0], z2[:,1], z2[:,2], s=2, facecolor='None', edgecolors='green', lw=0.3, label=label4_name)
        ax.scatter(z1[:,0], z1[:,1], z1[:,2], marker='o', s=4, facecolor='None', edgecolors='red', label=label3_name)

        ax.set_xlim([xmin, xmax])
        ax.set_ylim([ymin, ymax])
        ax.set_zlim([zmin, zmax])
        ax.set_xlabel(x_label_name, fontsize=16)
        ax.set_ylabel(y_label_name, fontsize=16)
        ax.set_zlabel(z_label_name, fontsize=16)
        ax.tick_params(direction = "in")

        plt.legend(loc='lower left', fontsize=12)
        plt.tick_params(labelsize=12)
        plt.tight_layout()
        plt.savefig(fig_file_name)
        plt.close()

    def scatter_feature_2D(self, figure_label, z1, z2, train_z1, train_z2, fig_file_name):
        title_name = figure_label[0]
        x_label_name = figure_label[1]
        y_label_name = figure_label[2]
        label1_name = figure_label[3]
        label2_name = figure_label[4]

        fig = plt.figure(figsize=(5,5))
        ax = fig.add_subplot(1,1,1)
        ax.scatter(z1, z2, s=2, facecolor='None', edgecolors='orange', lw=0.3, label=label1_name)
        ax.scatter(train_z1, train_z2, marker='o', s=4, label=label2_name)

        ax.set_xlabel(x_label_name, fontsize=16)
        ax.set_ylabel(y_label_name, fontsize=16)
        ax.tick_params(direction = "in")
        ax.set_title(title_name)

        plt.legend(loc='upper right', fontsize=12)
        plt.tick_params(labelsize=12)
        plt.tight_layout()
        plt.savefig(fig_file_name)
        plt.close()

    def scatter_feature_2D_3D(self, figure_label, z1, z2, train_z1, train_z2, fig_file_name):
        title_name = figure_label[0]
        x_label_name = figure_label[1]
        y_label_name = figure_label[2]
        z_label_name = figure_label[3]
        label1_name = figure_label[4]
        label2_name = figure_label[5]

        fig = plt.figure(figsize=(5,5))
        ax = fig.add_subplot(1,1,1 , projection='3d')
        ax.scatter(z1, z2, s=2, facecolor='None', edgecolors='orange', lw=0.3, label=label1_name)
        ax.scatter(train_z1, train_z2, marker='o', s=4, label=label2_name)

        ax.set_xlabel(x_label_name, fontsize=16)
        ax.set_ylabel(y_label_name, fontsize=16)
        ax.set_zlabel(z_label_name, fontsize=16)
        ax.tick_params(direction = "in")
        ax.set_title(title_name)

        plt.legend(loc='upper right', fontsize=12)
        plt.tick_params(labelsize=12)
        plt.tight_layout()
        plt.savefig(fig_file_name)
        plt.close()

    def trend1(self, figure_label, y1, y2, fig_file_name):
        x_label_name = figure_label[0]
        y_label_name = figure_label[1]
        y1_legend_name = figure_label[2]
        y2_legend_name = figure_label[3]
        xmin = 0
        xmax = len(y1)

        fig = plt.figure(figsize=(6,4))
        ax = fig.add_subplot(1,1,1)
        ax.plot(y1, "C0", label=y1_legend_name, lw=0.5)
        ax.plot(y2, "C1", label=y2_legend_name, lw=0.5)
        ax.set_xlabel(x_label_name, fontsize=16)
        ax.set_ylabel(y_label_name, fontsize=16)
        ax.tick_params(direction = "in")
        ax.grid(linestyle='dashdot')

        ax.set_xlim([xmin, xmax])

        ax.legend(loc='upper right')
        plt.tick_params(labelsize=12)
        plt.tight_layout()
        plt.savefig(fig_file_name, bbox_inches="tight")
        plt.close()
    
    def trend1_3D(self, figure_label, y1, y2, fig_file_name):
        x_label_name = figure_label[0]
        y_label_name = figure_label[1]
        y1_legend_name = figure_label[2]
        y2_legend_name = figure_label[3]
        xmin = 0
        xmax = len(y1)

        fig = plt.figure(figsize=(6,4))
        ax = fig.add_subplot(1,1,1)
        ax.plot(y1, "C0", label=y1_legend_name, lw=0.5)
        ax.plot(y2, "C1", label=y2_legend_name, lw=0.5)
        ax.set_xlabel(x_label_name, fontsize=16)
        ax.set_ylabel(y_label_name, fontsize=16)
        ax.tick_params(direction = "in")
        ax.grid(linestyle='dashdot')

        ax.set_xlim([xmin, xmax])

        ax.legend(loc='upper right')
        plt.tick_params(labelsize=12)
        plt.tight_layout()
        plt.savefig(fig_file_name, bbox_inches="tight")
        plt.close()
        
    def draw_scatter_chart(df, fig_file_name):
        fig = plt.figure(figsize=(6,6))
        fig.patch.set_facecolor('white')

        if df.values.shape[1] == 3:
            x1 = df.loc[:,0].values
            x2 = df.loc[:,1].values
            x3 = df.loc[:,2].values
            ax = fig.add_subplot(1,1,1, projection='3d')
            ax.scatter(x1, x2, x3, marker="o", s=8, alpha=0.8)
            # plot angle
            # ax.view_init(elev=60, azim=120)
            ax.set_xlabel('x1', fontsize=10)
            ax.set_ylabel('x2', fontsize=10)
            ax.set_zlabel('x3', fontsize=10)

        elif df.values.shape[1] == 2:
            x1 = df.loc[:,0].values
            x2 = df.loc[:,1].values
            ax = fig.add_subplot(1,1,1)        
            ax.scatter(x1, x2, s=10)
            ax.set_xlabel('x1', fontsize=10)
            ax.set_ylabel('x2', fontsize=10)

        ax.tick_params(direction = "in")
        plt.tick_params(labelsize=8)
        plt.tight_layout()
        plt.savefig(fig_file_name, bbox_inches="tight")
        plt.close()

        
    def trend_3D_1(self, figure_label, y1, y2, fig_file_name):
        label_name = figure_label[0]
        label1_name = figure_label[1]
        label2_name = figure_label[2]
        label3_name = figure_label[3]
        label4_name = figure_label[4]
        minmax = figure_label[5]
        
        x_label_name = label_name[0]
        y_label_name = label_name[1]
        z_label_name = label_name[2]
        xmin = minmax[0]
        xmax = minmax[1]
        ymin = minmax[2]
        ymax = minmax[3]
        zmin = minmax[4]
        zmax = minmax[5]
        
        # y1 = train_data
        # y2 = estimate_train_X

        fig = plt.figure()
        ax = fig.add_subplot(1,1,1, projection='3d')
        ax.scatter(y1[:,0], y1[:,1], y1[:,2], marker='o', s=4, edgecolors='blue', label=label1_name)
        ax.scatter(y2[:,0], y2[:,1], y2[:,2], marker='o', s=4, edgecolors='red', label=label3_name)

        ax.set_xlim([xmin, xmax])
        ax.set_ylim([ymin, ymax])
        ax.set_zlim([zmin, zmax])
        ax.set_xlabel(x_label_name, fontsize=16)
        ax.set_ylabel(y_label_name, fontsize=16)
        ax.set_zlabel(z_label_name, fontsize=16)
        ax.tick_params(direction = "in")

        plt.legend(loc='lower left', fontsize=12)
        plt.tick_params(labelsize=12)
        plt.tight_layout()
        plt.savefig(fig_file_name, bbox_inches="tight")
        plt.close()

        
    def trend_3D_2(self, figure_label, y1, y2, y3, fig_file_name):
        label_name = figure_label[0]
        label1_name = figure_label[1]
        label2_name = figure_label[2]
        label3_name = figure_label[3]
        label4_name = figure_label[4]
        minmax = figure_label[5]
        
        x_label_name = label_name[0]
        y_label_name = label_name[1]
        z_label_name = label_name[2]
        xmin = minmax[0]
        xmax = minmax[1]
        ymin = minmax[2]
        ymax = minmax[3]
        zmin = minmax[4]
        zmax = minmax[5]
        
        # y1 = train_data
        # y2 = predict_new_X
        # y3 = estimate_train_X

        fig = plt.figure()
        ax = fig.add_subplot(1,1,1, projection='3d')
        ax.scatter(y1[:,0], y1[:,1], y1[:,2], marker='o', s=4, edgecolors='blue', label=label1_name)
        ax.scatter(y2[:,0], y2[:,1], y2[:,2], s=0.02, edgecolors='green', lw=0.3, label=label4_name)
        ax.scatter(y3[:,0], y3[:,1], y3[:,2], marker='o', s=4, edgecolors='red', label=label3_name)

        ax.set_xlim([xmin, xmax])
        ax.set_ylim([ymin, ymax])
        ax.set_zlim([zmin, zmax])
        ax.set_xlabel(x_label_name, fontsize=16)
        ax.set_ylabel(y_label_name, fontsize=16)
        ax.set_zlabel(z_label_name, fontsize=16)
        ax.tick_params(direction = "in")

        plt.legend(loc='lower left', fontsize=12)
        plt.tick_params(labelsize=12)
        plt.tight_layout()
        plt.savefig(fig_file_name, bbox_inches="tight")
        plt.close()
        
        
    def trend_3D_3(self, figure_label, y1, y2, fig_file_name):
        label_name = figure_label[0]
        label1_name = figure_label[1]
        label2_name = figure_label[2]
        label3_name = figure_label[3]
        label4_name = figure_label[4]
        minmax = figure_label[5]
        
        x_label_name = label_name[0]
        y_label_name = label_name[1]
        z_label_name = label_name[2]
        xmin = minmax[0]
        xmax = minmax[1]
        ymin = minmax[2]
        ymax = minmax[3]
        zmin = minmax[4]
        zmax = minmax[5]
        
        # y1 = new_X
        # y2 = predict_new_X

        fig = plt.figure()
        ax = fig.add_subplot(1,1,1, projection='3d')
        ax.scatter(y1[:,0], y1[:,1], y1[:,2], s=0.1, edgecolors='orange', lw=0.3, label=label2_name)
        ax.scatter(y2[:,0], y2[:,1], y2[:,2], s=0.02, edgecolors='green', lw=0.3, label=label4_name)

        ax.set_xlim([xmin, xmax])
        ax.set_ylim([ymin, ymax])
        ax.set_zlim([zmin, zmax])
        ax.set_xlabel(x_label_name, fontsize=16)
        ax.set_ylabel(y_label_name, fontsize=16)
        ax.set_zlabel(z_label_name, fontsize=16)
        ax.tick_params(direction = "in")

        plt.legend(loc='lower left', fontsize=12)
        plt.tick_params(labelsize=12)
        plt.tight_layout()
        plt.savefig(fig_file_name, bbox_inches="tight")
        plt.close()

        
    def trend_3D_4(self, figure_label, y1, y2, y3, fig_file_name):
        label_name = figure_label[0]
        label1_name = figure_label[1]
        label2_name = figure_label[2]
        label3_name = figure_label[3]
        label4_name = figure_label[4]
        minmax = figure_label[5]
        
        x_label_name = label_name[0]
        y_label_name = label_name[1]
        z_label_name = label_name[2]
        xmin = minmax[0]
        xmax = minmax[1]
        ymin = minmax[2]
        ymax = minmax[3]
        zmin = minmax[4]
        zmax = minmax[5]
        
        # y1 = new_X
        # y2 = train_data
        # y3 = plot_penalty

        #fig = plt.figure(figsize=(5,5,5))
        #ax = fig.add_subplot(1,1,1, projection='3d')
        fig = plt.figure()
        ax = fig.add_subplot(projection='3d')
        #ax.scatter(y1[:,0], y1[:,1], y1[:,2], s=0.1, c=y3, cmap='jet', lw=0.5, label=label2_name)
        ax.scatter(y1[:,0], y1[:,1], y1[:,2], s=0.1, cmap='jet', lw=0.5, label=label2_name)
        ax.scatter(y2[:,0], y2[:,1], y2[:,2], marker='o', s=4, edgecolors='blue', label=label1_name)

        ax.set_xlim([xmin, xmax])
        ax.set_ylim([ymin, ymax])
        ax.set_zlim([zmin, zmax])
        ax.set_xlabel(x_label_name, fontsize=16)
        ax.set_ylabel(y_label_name, fontsize=16)
        ax.set_zlabel(z_label_name, fontsize=16)
        ax.tick_params(direction = "in")

        plt.legend(loc='lower left', fontsize=12)
        plt.tick_params(labelsize=12)
        plt.tight_layout()
        plt.savefig(fig_file_name, bbox_inches="tight")
        plt.close()
