#coding: utf-8
import os
from os import path
import datetime
import traceback
import tkinter as tk
from tkinter import messagebox

def my_makedirs(path):
    if not os.path.isdir(path):
        os.makedirs(path)

def setting_window():
    class Application(tk.Frame):
        def __init__(self, hv, master=None):
            super().__init__(master)
            horz = hv[0]
            vert = hv[1]
            self.value_list = []

            # window
            self.master.title('Config for Predict')
            self.master.geometry(str(horz)+ 'x' + str(vert))

            self.default_entry_text1 = tk.StringVar(value='0') 
            self.default_entry_text21 = tk.StringVar()
            self.default_entry_text22 = tk.StringVar()
            self.default_entry_text31 = tk.StringVar()
            self.default_entry_text32 = tk.StringVar()
            self.int_Val1 = tk.IntVar(value=1)
            self.PLS_entry_text = tk.StringVar(value='2')
            self.RF_entry_text1 = tk.StringVar(value='100')
            self.RF_entry_text2 = tk.StringVar(value='None')
            self.RF_entry_text3 = tk.StringVar(value='2')


        def _default_setting(self, relx_s, rely_s):
            DefaultLabel1 = tk.Label(self.master, text='[GENERAL]')
            DefaultLabel21 = tk.Label(self.master, text=' - x list = ')
            DefaultEditBox1 = tk.Entry(self.master, width=20, textvariable = self.default_entry_text1)
            DefaultLabel22 = tk.Label(self.master, text='   * x list should be assigned as column number of variable x in the input file, e.g., 0, 1, 3 are assigned as x1, x2, x4.')
            DefaultLabel31 = tk.Label(self.master, text=' - training period :   from ')
            DefaultEditBox21 = tk.Entry(self.master, width=20, textvariable = self.default_entry_text21)
            DefaultLabel32 = tk.Label(self.master, text=', to ')
            DefaultEditBox22 = tk.Entry(self.master, width=20, textvariable = self.default_entry_text22)
            DefaultLabel41 = tk.Label(self.master, text=' - perdict period  :   from ')
            DefaultEditBox31 = tk.Entry(self.master, width=20, textvariable = self.default_entry_text31)
            DefaultLabel42 = tk.Label(self.master, text=', to ')
            DefaultEditBox32 = tk.Entry(self.master, width=20, textvariable = self.default_entry_text32)
            DefaultLabel5 = tk.Label(self.master, text=' - modeling mode : ')
            DefaultRadioBox1 = tk.Radiobutton(self.master, text='Random Forest', value=1, variable=self.int_Val1)
            DefaultRadioBox2 = tk.Radiobutton(self.master, text='PLS', value=2, variable=self.int_Val1)
            DefaultRadioBox3 = tk.Radiobutton(self.master, text='MLR', value=3, variable=self.int_Val1)

            # General
            DefaultLabel1.place(relx = relx_s, rely = rely_s, anchor = tk.NW)
            # xlist
            DefaultLabel21.place(relx = relx_s, rely = rely_s + 0.05, anchor = tk.NW)
            DefaultEditBox1.place(relx = relx_s + 0.2, rely = rely_s + 0.05, anchor = tk.NW)
            DefaultLabel22.place(relx = relx_s, rely = rely_s + 0.1, anchor = tk.NW)
            # training period
            DefaultLabel31.place(relx = relx_s, rely = rely_s + 0.15, anchor = tk.NW)
            DefaultEditBox21.place(relx = relx_s + 0.2, rely = rely_s + 0.15, anchor = tk.NW)
            DefaultLabel32.place(relx = relx_s + 0.4, rely = rely_s + 0.15, anchor = tk.NW)
            DefaultEditBox22.place(relx = relx_s + 0.45, rely = rely_s + 0.15, anchor = tk.NW)
            # predict period
            DefaultLabel41.place(relx = relx_s, rely = rely_s + 0.2, anchor = tk.NW)
            DefaultEditBox31.place(relx = relx_s + 0.2, rely = rely_s + 0.2, anchor = tk.NW)
            DefaultLabel42.place(relx = relx_s + 0.4, rely = rely_s + 0.2, anchor = tk.NW)
            DefaultEditBox32.place(relx = relx_s + 0.45, rely = rely_s + 0.2, anchor = tk.NW)
            # modeling mode
            DefaultLabel5.place(relx = relx_s, rely = rely_s + 0.25, anchor = tk.NW)
            DefaultRadioBox1.place(relx = relx_s + 0.2, rely = rely_s + 0.3, anchor = tk.NW)
            DefaultRadioBox2.place(relx = relx_s + 0.4, rely = rely_s + 0.3, anchor = tk.NW)
            DefaultRadioBox3.place(relx = relx_s + 0.6, rely = rely_s + 0.3, anchor = tk.NW)
        
        def _PLS_setting(self, relx_s, rely_s):
            PLSLabel1 = tk.Label(self.master, text='[PLS]')
            PLSLabel2 = tk.Label(self.master, text=' - NumLV = ')
            PLSEditBox1 = tk.Entry(self.master, width=10, textvariable = self.PLS_entry_text)
            PLSLabel3 = tk.Label(self.master, text=' (default = 2 and should be within the range [1, number of variables].)')
            PLSLabel4 = tk.Label(self.master, text='     * NumLV is the number of latent variables.')

            # PLS
            PLSLabel1.place(relx = relx_s, rely = rely_s + 0.35, anchor = tk.NW)
            # NumLV
            PLSLabel2.place(relx = relx_s, rely = rely_s + 0.4, anchor = tk.NW)
            PLSEditBox1.place(relx = relx_s + 0.2, rely = rely_s + 0.4, anchor = tk.NW)
            PLSLabel3.place(relx = relx_s + 0.3, rely = rely_s + 0.4, anchor = tk.NW)
            PLSLabel4.place(relx = relx_s, rely = rely_s + 0.45, anchor = tk.NW)
        
        def _RF_setting(self, relx_s, rely_s):
            RFLabel1 = tk.Label(self.master, text='[RANDOM FOREST]')
            RFLabel21 = tk.Label(self.master, text=' - NumTree = ')
            RFEditBox1 = tk.Entry(self.master, width=10, textvariable = self.RF_entry_text1)
            RFLabel22 = tk.Label(self.master, text=' (default = 100 and should be >= number of variables.)')
            RFLabel23 = tk.Label(self.master, text='     * NumTree is the number of trees in the forest.')
            RFLabel31 = tk.Label(self.master, text=' - MaxDepth = ')
            RFEditBox2 = tk.Entry(self.master, width=10, textvariable = self.RF_entry_text2)
            RFLabel32 = tk.Label(self.master, text=' (default = None and should be >= 1 or None.)')
            RFLabel33 = tk.Label(self.master, text='     * MaxDepth is the maximum depth of the tree.')
            RFLabel41 = tk.Label(self.master, text=' - MinSamplesSplit = ')
            RFEditBox3 = tk.Entry(self.master, width=10, textvariable = self.RF_entry_text3)
            RFLabel42 = tk.Label(self.master, text=' (default = 2 and should be >= 2)')
            RFLabel43 = tk.Label(self.master, text='     * MinSamplesSplit is the minimum number of samples required to split an internal node in each leaf.')

            # RF
            RFLabel1.place(relx = relx_s, rely = rely_s + 0.5, anchor = tk.NW)
            # NumTree
            RFLabel21.place(relx = relx_s, rely = rely_s + 0.55, anchor = tk.NW)
            RFEditBox1.place(relx = relx_s + 0.2, rely = rely_s + 0.55, anchor = tk.NW)
            RFLabel22.place(relx = relx_s + 0.3, rely = rely_s + 0.55, anchor = tk.NW)
            RFLabel23.place(relx = relx_s, rely = rely_s + 0.6, anchor = tk.NW)
            # MaxDepth
            RFLabel31.place(relx = relx_s, rely = rely_s + 0.65, anchor = tk.NW)
            RFEditBox2.place(relx = relx_s + 0.2, rely = rely_s + 0.65, anchor = tk.NW)
            RFLabel32.place(relx = relx_s + 0.3, rely = rely_s + 0.65, anchor = tk.NW)
            RFLabel33.place(relx = relx_s, rely = rely_s + 0.7, anchor = tk.NW)
            # MinSamplesSplit
            RFLabel41.place(relx = relx_s, rely = rely_s + 0.75, anchor = tk.NW)
            RFEditBox3.place(relx = relx_s + 0.2, rely = rely_s + 0.75, anchor = tk.NW)
            RFLabel42.place(relx = relx_s + 0.3, rely = rely_s + 0.75, anchor = tk.NW)
            RFLabel43.place(relx = relx_s, rely = rely_s + 0.8, anchor = tk.NW)

        def _button_setting(self):
            def _btn_clear():
                self.default_entry_text1.set('0')
                self.default_entry_text21.set('')
                self.default_entry_text22.set('')
                self.default_entry_text31.set('')
                self.default_entry_text32.set('')
                self.int_Val1.set('1')
                self.PLS_entry_text.set('2')
                self.RF_entry_text1.set('100')
                self.RF_entry_text2.set('None')
                self.RF_entry_text3.set('2')
                e_msg = 'clear/default config.'
                j_msg = '設定を空欄あるいはデフォルト値にクリアしました。'
                messagebox.showinfo('info msg',e_msg + '\n' + j_msg)

            def _btn_save():
                if self.int_Val1.get() == 1:
                    modelingmode = 'RF'
                elif self.int_Val1.get() == 2:
                    modelingmode = 'PLS'
                elif self.int_Val1.get() == 3:
                    modelingmode = 'MLR'

                self.value_list = ['[' + self.default_entry_text1.get() + ']', 
                                '[' + self.default_entry_text21.get() + ',' + self.default_entry_text22.get() + ']',
                                '[' + self.default_entry_text31.get() + ',' + self.default_entry_text32.get() + ']',
                                modelingmode, 
                                self.PLS_entry_text.get(), 
                                self.RF_entry_text1.get(), 
                                self.RF_entry_text2.get(), 
                                self.RF_entry_text3.get()]
                e_msg = 'save config.'
                j_msg = '設定を保存しました。'
                messagebox.showinfo('info msg', e_msg + '\n' + j_msg)

            def _btn_close():
                e_msg = 'Can I close this window? Did you save this config?'
                j_msg = 'ウィンドウを閉じて、設定ファイルを作成しても良いですか？設定は保存しましたか？'
                ret = messagebox.askyesno(title = 'check msg', message = e_msg + '\n' + j_msg)
                if ret == True:
                    self.master.destroy()

            # button
            button1 = tk.Button(self.master, text='clear/default', width=10, command=_btn_clear)
            button2 = tk.Button(self.master, text='save', width=10, command=_btn_save)
            button3 = tk.Button(self.master, text='close', width=10, command=_btn_close)
            # button
            button1.place(relx = 0.25, rely = 0.95, anchor = tk.CENTER)
            button2.place(relx = 0.5, rely = 0.95, anchor = tk.CENTER)
            button3.place(relx = 0.75, rely = 0.95, anchor = tk.CENTER)


    hv = [750, 550]
    root = tk.Tk()
    app = Application(hv=hv, master = root)
    relx_s = 0.05
    rely_s = 0.05
    app._default_setting(relx_s, rely_s)
    app._PLS_setting(relx_s, rely_s)
    app._RF_setting(relx_s, rely_s)
    app._button_setting()
    app.mainloop()
    if app.value_list[0] == '[]':
        print('x list is empty.')
    else:
        x_list = app.value_list[0]
    if app.value_list[1] == '[,]':
        print('training period is empty.')
    else:
        traperiod = app.value_list[1]
    if app.value_list[2] == '[,]':
        print('predict period is empty.')
    else:
        preperiod = app.value_list[2]
    modelingmode = app.value_list[3]
    NumLV = app.value_list[4]
    NumTree = app.value_list[5]
    MaxDepth = app.value_list[6]
    MinSamplesSplit = app.value_list[7]
    return modelingmode, x_list, traperiod, preperiod, NumLV, NumTree, MaxDepth, MinSamplesSplit

class Config:
    def __init__(self, modelingmode, work_path, x_list, traperiod, preperiod):
        self.modelingmode = modelingmode
        self.work_path = work_path
        self.x_list = x_list
        self.traperiod = traperiod
        self.preperiod = preperiod
    def save_config_MLR(self):
        f = open(self.work_path + '\\predict_config2.ini', 'w')
        f.write('[DEFAULT]\n')
        f.write('# x list (column number)\n')
        f.write('XList = ' + self.x_list + '\n\n')
        f.write('# training period\n')
        f.write('TraPeriod = ' + self.traperiod + '\n\n')
        f.write('# predict period\n')
        f.write('PrePeriod = ' + self.preperiod + '\n\n')
        f.write('# modeling mode\n')
        f.write('ModelingMode = ' + self.modelingmode)
        f.close()
    def save_config_PLS(self, NumLV=2):
        f = open(self.work_path + '\\predict_config2.ini', 'w')
        f.write('[DEFAULT]\n')
        f.write('# x list (column number)\n')
        f.write('XList = ' + self.x_list + '\n\n')
        f.write('# training period\n')
        f.write('TraPeriod = ' + self.traperiod + '\n\n')
        f.write('# predict period\n')
        f.write('PrePeriod = ' + self.preperiod + '\n\n')
        f.write('# modeling mode\n')
        f.write('ModelingMode = ' + self.modelingmode + '\n\n')
        f.write('[PLS]\n')
        f.write('# NumLV(integer): The number of latent variables\n')
        f.write('# default = 2\n')
        f.write('# Should be within the range [1, number of variables]\n')
        f.write('NumLV = ' + NumLV)
        f.close()
    def save_config_RF(self, NumTree=100, MaxDepth=None, MinSamplesSplit=2):
        f = open(self.work_path + '\\predict_config2.ini', 'w')
        f.write('[DEFAULT]\n')
        f.write('# x list (column number)\n')
        f.write('XList = ' + self.x_list + '\n\n')
        f.write('# training period\n')
        f.write('TraPeriod = ' + self.traperiod + '\n\n')
        f.write('# predict period\n')
        f.write('PrePeriod = ' + self.preperiod + '\n\n')
        f.write('# modeling mode\n')
        f.write('ModelingMode = ' + self.modelingmode + '\n\n')
        f.write('[RANDOMFOREST]\n')
        f.write('# NumTree(integer): The number of trees in the forest\n')
        f.write('# default = 100\n')
        f.write('# Should be >= number of the variables\n')
        f.write('NumTree = ' + NumTree + '\n\n')
        f.write('# MaxDepth(integer or None): the maximum depth of the tree\n')
        f.write('# default = None\n')
        f.write('# Should be >= 1 or None\n')
        f.write('MaxDepth = ' + MaxDepth + '\n\n')
        f.write('# MinSamplesSplit(integer): the minimum number of samples required to split an internal node in each leaf\n')
        f.write('# default = 2\n')
        f.write('# Should be >= 2\n')
        f.write('MinSamplesSplit = ' + MinSamplesSplit)
        f.close()


def main_calc(work_path):
    print('|--------------|')
    print('call setting window')
    (modelingmode, x_list, traperiod, preperiod, NumLV, NumTree, MaxDepth, MinSamplesSplit) = setting_window()
    print('|--------------|')

    print('|--------------|')
    print('save config file')
    Config_ini = Config(modelingmode, work_path, x_list, traperiod, preperiod)
    if modelingmode == 'MLR':
        Config_ini.save_config_MLR()
    elif modelingmode == 'PLS':
        Config_ini.save_config_PLS(NumLV)
    elif modelingmode == 'RF':
        Config_ini.save_config_RF(NumTree, MaxDepth, MinSamplesSplit)
    print('|--------------|')


def main(work_path):
    def _save_logfile(filename, msg1, msg2):
        f = open(filename, 'w')
        f.write(msg1)
        f.write(msg2)
        f.close()

    new_dir_path = work_path + '\\log'
    my_makedirs(new_dir_path)
    now_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%d')
    try:
        main_calc(work_path)
        e_mainmsg = 'Execution completed successfully.'
        e_msg = e_mainmsg + '\n' + 'Output the success message to log file.'
        j_msg = '実行を正常に完了しました。logファイルに成功メッセージを出力しました。'

    except Exception:
        e_mainmsg = 'Execution failed.'
        e_msg = e_mainmsg + '\n' + 'Output the error message to dumplog file.'
        e_mainmsg = e_mainmsg + '\n' + traceback.format_exc()
        j_msg = '実行に失敗しました。dumplogファイルにエラーメッセージを出力しました。'
        print('|--------------|')

    _save_logfile(new_dir_path + '\\log_config.txt', now_time + '\n', e_mainmsg)
    print(e_msg)
    messagebox.showinfo('info message', e_msg + '\n' + j_msg)
    print('finish')



directly_flag = True
if directly_flag:
    work_path = path.dirname( path.abspath(__file__) )
else:
    work_path = os.getcwd()
os.chdir(work_path)
print('work_path = ', work_path)
main(work_path)