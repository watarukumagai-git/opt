#coding: utf-8
import os
from os import path
import datetime
import traceback
import tkinter as tk
from tkinter import messagebox

def my_makedirs(path):
    if not os.path.isdir(path):
        os.makedirs(path)

def setting_window():
    class Application(tk.Frame):
        def __init__(self, hv, master=None):
            super().__init__(master)
            horz = hv[0]
            vert = hv[1]
            self.value_list = []

            # window
            self.master.title('Config for Preprocessing')
            self.master.geometry(str(horz)+ 'x' + str(vert))

            self.entry_text1 = tk.StringVar() 
            self.entry_text2 = tk.StringVar()
            self.entry_text3 = tk.StringVar()
            self.check_Val1 = tk.BooleanVar()
            self.int_Val1 = tk.IntVar()
            self.int_Val2 = tk.IntVar()
            self.int_Val3 = tk.IntVar()
            self.int_Val4 = tk.IntVar()

            # Default
            DefaultLabel1 = tk.Label(self.master, text='[DEFAULT]')
            DefaultLabel2 = tk.Label(self.master, text=' - x list = ')
            DefaultEditBox1 = tk.Entry(self.master, width=15, textvariable = self.entry_text1)
            DefaultLabel3 = tk.Label(self.master, text=' * x list should be assigned as column number of variable x in input the file, e.g., 0, 1, 3 are assigned as x1, x2, x4.')
            DefaultLabel4 = tk.Label(self.master, text=' - training period = ')
            DefaultEditBox2 = tk.Entry(self.master, width=15, textvariable = self.entry_text2)
            DefaultLabel5 = tk.Label(self.master, text=' - perdict period = ')
            DefaultEditBox3 = tk.Entry(self.master, width=15, textvariable = self.entry_text3)
            DefaultLabel6 = tk.Label(self.master, text=' - modeling mode = ')
            DefaultCheckBox1 = tk.Checkbutton(text='RF', variable=self.check_Val1)

            # PLS
            PLSLabel1 = tk.Label(self.master, text='[PLS]')
            PLSLabel2 = tk.Label(self.master, text=' - NumLV = ')
            PLSEditBox1 = tk.Entry(self.master, width=15, textvariable = self.entry_text4)
            PLSLabel3 = tk.Label(self.master, text=' * NumLV is the number of latent variables (default = 2) and should be within the range [1, number of variables].')

            # RF
            RFLabel1 = tk.Label(self.master, text='[RANDOM FOREST]')
            RFLabel2 = tk.Label(self.master, text=' - NumTree = ')
            RFEditBox1 = tk.Entry(self.master, width=15, textvariable = self.entry_text5)
            RFLabel3 = tk.Label(self.master, text=' * NumTree is the number of trees in the forest (default = 100) and should be within the range [1, number of variables].')
            RFLabel4 = tk.Label(self.master, text=' - MaxDepth = ')
            RFEditBox2 = tk.Entry(self.master, width=15, textvariable = self.entry_text6)
            RFLabel5 = tk.Label(self.master, text=' * MaxDepth is the maximum depth of the tree (default = None) and should be >= 1 or None.')
            RFLabel6 = tk.Label(self.master, text=' - MinSamplesSplit = ')
            RFEditBox3 = tk.Entry(self.master, width=15, textvariable = self.entry_text7)
            RFLabel7 = tk.Label(self.master, text=' * MinSamplesSplit is the minimum number of samples required to split an internal node in each leaf (default = 2) and should be >= 2')

            # button
            button1 = tk.Button(self.master, text='clear/default', width=10, command=self._btn_clear)
            button2 = tk.Button(self.master, text='save', width=10, command=self._btn_save)
            button3 = tk.Button(self.master, text='close', width=10, command=self._btn_close)

            relx_s = 0.05
            rely_s = 0.05
            # xlist
            DefaultLabel1.place(relx = relx_s, rely = rely_s, anchor = tk.NW)
            DefaultLabel2.place(relx = relx_s, rely = rely_s + 0.1, anchor = tk.NW)
            DefaultEditBox1.place(relx = relx_s + 0.2, rely = rely_s + 0.1, anchor = tk.NW)
            # training period
            DefaultLabel1.place(relx = relx_s, rely = rely_s, anchor = tk.NW)
            DefaultLabel2.place(relx = relx_s, rely = rely_s + 0.1, anchor = tk.NW)
            DefaultEditBox1.place(relx = relx_s + 0.2, rely = rely_s + 0.1, anchor = tk.NW)
            # training period
            DefaultLabel1.place(relx = relx_s, rely = rely_s, anchor = tk.NW)
            DefaultLabel2.place(relx = relx_s, rely = rely_s + 0.1, anchor = tk.NW)
            DefaultEditBox1.place(relx = relx_s + 0.2, rely = rely_s + 0.1, anchor = tk.NW)
            # modeling mode
            DefaultLabel1.place(relx = relx_s, rely = rely_s, anchor = tk.NW)
            DefaultCheckBox1.place(relx = relx_s, rely = rely_s + 0.1, anchor = tk.NW)
            # NumLV
            DefaultLabel1.place(relx = relx_s, rely = rely_s, anchor = tk.NW)
            DefaultLabel2.place(relx = relx_s, rely = rely_s + 0.1, anchor = tk.NW)
            DefaultEditBox1.place(relx = relx_s + 0.2, rely = rely_s + 0.1, anchor = tk.NW)
            # NumTree
            DefaultLabel1.place(relx = relx_s, rely = rely_s, anchor = tk.NW)
            DefaultLabel2.place(relx = relx_s, rely = rely_s + 0.1, anchor = tk.NW)
            DefaultEditBox1.place(relx = relx_s + 0.2, rely = rely_s + 0.1, anchor = tk.NW)
            # MaxDepth
            DefaultLabel1.place(relx = relx_s, rely = rely_s, anchor = tk.NW)
            DefaultLabel2.place(relx = relx_s, rely = rely_s + 0.1, anchor = tk.NW)
            DefaultEditBox1.place(relx = relx_s + 0.2, rely = rely_s + 0.1, anchor = tk.NW)
            # MinSamplesSplit
            DefaultLabel1.place(relx = relx_s, rely = rely_s, anchor = tk.NW)
            DefaultLabel2.place(relx = relx_s, rely = rely_s + 0.1, anchor = tk.NW)
            DefaultEditBox1.place(relx = relx_s + 0.2, rely = rely_s + 0.1, anchor = tk.NW)
            # button
            button1.place(relx = 0.25, rely = 0.9, anchor = tk.CENTER)
            button2.place(relx = 0.5, rely = 0.9, anchor = tk.CENTER)
            button3.place(relx = 0.75, rely = 0.9, anchor = tk.CENTER)

        def _btn_clear(self):
            self.entry_text1.set('')
            self.entry_text2.set('')
            self.entry_text3.set('')
            self.check_Val1.set('')
            self.int_Val1.set('2')
            self.int_Val2.set('100')
            self.int_Val3.set('')
            self.int_Val4.set('2')
            messagebox.showinfo('info msg','clear/default config.')

        def _btn_save(self):
            self.value_list = ['[' + self.entry_text1.get() + ']', 
                               '[' + self.entry_text2.get() + ']',
                               '[' + self.entry_text3.get() + ']',
                               self.check_Val1.get(), 
                               self.int_Val1.get(), 
                               self.int_Val2.get(), 
                               self.int_Val3.get(), 
                               self.int_Val4.get()]
            messagebox.showinfo('info msg','save config.')

        def _btn_close(self):
            ret = messagebox.askyesno(title = 'check msg', message = 'Can I close this window?')
            if ret == True:
                self.master.destroy()



    hv = [700, 400]
    root = tk.Tk()
    app = Application(hv=hv, master = root)
    app.mainloop()
    x_list = app.value_list[0]
    traperiod = app.value_list[1]
    preperiod = app.value_list[2]
    modelingmode = app.value_list[3]
    NumLV = app.value_list[4]
    NumTree = app.value_list[5]
    MaxDepth = app.value_list[6]
    MinSamplesSplit = app.value_list[7]
    return modelingmode, x_list, traperiod, preperiod, NumLV, NumTree, MaxDepth, MinSamplesSplit

class Config:
    def __init__(self, modelingmode, work_path, x_list, traperiod, preperiod):
        self.modelingmode = modelingmode
        self.work_path = work_path
        self.x_list = x_list
        self.traperiod = traperiod
        self.preperiod = preperiod
    def save_config_MLR(self):
        f = open(self.work_path + '\\preprocessing_config.ini', 'w')
        f.write('[DEFAULT]\n')
        f.write('# x list (column number)\n')
        f.write('XList = ' + self.x_list + '\n\n')
        f.write('# training period\n')
        f.write('TraPeriod = ' + self.traperiod + '\n\n')
        f.write('# predict period\n')
        f.write('PrePeriod = ' + self.preperiod + '\n\n')
        f.write('# modeling mode\n')
        f.write('ModelingMode = ' + self.modelingmode)
        f.close()
    def save_config_PLS(self, NumLV=2):
        f = open(self.work_path + '\\preprocessing_config.ini', 'w')
        f.write('[DEFAULT]\n')
        f.write('# x list (column number)\n')
        f.write('XList = ' + self.x_list + '\n\n')
        f.write('# training period\n')
        f.write('TraPeriod = ' + self.traperiod + '\n\n')
        f.write('# predict period\n')
        f.write('PrePeriod = ' + self.preperiod + '\n\n')
        f.write('# modeling mode\n')
        f.write('ModelingMode = ' + self.modelingmode + '\n\n')
        f.write('[PLS]\n')
        f.write('# NumLV(integer): The number of latent variables\n')
        f.write('# default = 2\n')
        f.write('# Should be within the range [1, number of variables]\n')
        f.write('NumLV = ' + NumLV)
        f.close()
    def save_config_RF(self, NumTree=100, MaxDepth=None, MinSamplesSplit=2):
        f = open(self.work_path + '\\preprocessing_config.ini', 'w')
        f.write('[DEFAULT]\n')
        f.write('# x list (column number)\n')
        f.write('XList = ' + self.x_list + '\n\n')
        f.write('# training period\n')
        f.write('TraPeriod = ' + self.traperiod + '\n\n')
        f.write('# predict period\n')
        f.write('PrePeriod = ' + self.preperiod + '\n\n')
        f.write('# modeling mode\n')
        f.write('ModelingMode = ' + self.modelingmode + '\n\n')
        f.write('[RANDOMFOREST]\n')
        f.write('# NumTree(integer): The number of trees in the forest\n')
        f.write('# default = 100\n')
        f.write('# Should be >= 1\n')
        f.write('NumTree = ' + NumTree + '\n\n')
        f.write('# MaxDepth(integer or None): the maximum depth of the tree\n')
        f.write('# default = None\n')
        f.write('# Should be >= 1 or None')
        f.write('MaxDepth = ' + MaxDepth + '\n\n')
        f.write('# MinSamplesSplit(integer): the minimum number of samples required to split an internal node in each leaf\n')
        f.write('# default = 2\n')
        f.write('# Should be >= 2\n')
        f.write('MinSamplesSplit = ' + MinSamplesSplit)
        f.close()


def main_calc(work_path):
    print('|--------------|')
    print('call setting window')
    (modelingmode, x_list, traperiod, preperiod, NumLV, NumTree, MaxDepth, MinSamplesSplit) = setting_window()
    print('|--------------|')

    print('|--------------|')
    print('save config file')
    Config = Config(modelingmode, work_path, x_list, traperiod, preperiod)
    if modelingmode == 'MLR':
        Config.save_config_MLR()
    elif modelingmode == 'PLS':
        Config.save_config_PLS(NumLV)
    elif modelingmode == 'RF':
        Config.save_config_RF(NumTree, MaxDepth, MinSamplesSplit)
    print('|--------------|')


def main(work_path):
    def _save_logfile(filename, msg1, msg2):
        f = open(filename, 'w')
        f.write(msg1)
        f.write(msg2)
        f.close()

    new_dir_path = work_path + '\\log'
    my_makedirs(new_dir_path)
    now_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%d')
    try:
        main_calc(work_path)
        mainmsg = 'Execution completed successfully.'
        msg = mainmsg + '\n' + 'Output the success message to log file.'

    except Exception:
        mainmsg = 'Execution failed.'
        msg = mainmsg + '\n' + 'Output the error message to dumplog file.'
        mainmsg = mainmsg + '\n' + traceback.format_exc()

    _save_logfile(new_dir_path + '\\log_config.txt', now_time + '\n', mainmsg)
    print(msg)
    messagebox.showinfo('info message', msg)
    print('finish')



directly_flag = True
if directly_flag:
    work_path = path.dirname( path.abspath(__file__) )
else:
    work_path = os.getcwd()
os.chdir(work_path)
print('work_path = ', work_path)
main(work_path)