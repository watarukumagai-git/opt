#coding: utf-8
import os
from os import path
import datetime
import traceback
import tkinter as tk
from tkinter import messagebox

def my_makedirs(path):
    if not os.path.isdir(path):
        os.makedirs(path)

def setting_window():
    class Application(tk.Frame):
        def __init__(self, hv, master=None):
            super().__init__(master)
            horz = hv[0]
            vert = hv[1]
            self.value_list = []

            # window
            self.master.title('Config for Preprocessing')
            self.master.geometry(str(horz)+ 'x' + str(vert))

            self.check_Val1 = tk.BooleanVar(value=True)
            self.check_Val2 = tk.BooleanVar()
            self.check_Val3 = tk.BooleanVar()
            self.entry_text1 = tk.StringVar(value=0) 
            self.entry_text2 = tk.StringVar(value=0)

        def _default_setting(self, relx_s, rely_s):
            DefaultLabel1 = tk.Label(self.master, text='[GENERAL]')
            CheckBox1 = tk.Checkbutton(text='split timestamp', variable=self.check_Val1)
            CheckBox2 = tk.Checkbutton(text='encode to label', variable=self.check_Val2)
            CheckBox3 = tk.Checkbutton(text='encode to onehot', variable=self.check_Val3)
            # General
            DefaultLabel1.place(relx = relx_s, rely = rely_s, anchor = tk.NW)
            CheckBox1.place(relx = relx_s, rely = rely_s + 0.1, anchor = tk.NW)
            CheckBox2.place(relx = relx_s + 0.3, rely = rely_s + 0.1, anchor = tk.NW)
            CheckBox3.place(relx = relx_s + 0.6, rely = rely_s + 0.1, anchor = tk.NW)

        def _EncodeLabel_setting(self, relx_s, rely_s):
            EncodeLabelLabel1 = tk.Label(self.master, text='[ENCODE LABEL]')
            EncodeLabelLabel2 = tk.Label(self.master, text=' - x list = ')
            EncodeLabelEditBox1 = tk.Entry(self.master, width=15, textvariable = self.entry_text1)
            EncodeLabelLabel3 = tk.Label(self.master, text='     * x list should be assigned as column number of variable x in input the file, e.g., 0, 1, 3 are assigned as x1, x2, x4.')

            # Encodelabel
            EncodeLabelLabel1.place(relx = relx_s, rely = rely_s + 0.25, anchor = tk.NW)
            EncodeLabelLabel2.place(relx = relx_s, rely = rely_s + 0.35, anchor = tk.NW)
            EncodeLabelEditBox1.place(relx = relx_s + 0.1, rely = rely_s + 0.35, anchor = tk.NW)
            EncodeLabelLabel3.place(relx = relx_s, rely = rely_s + 0.4, anchor = tk.NW)

        def _EncodeOnehot_setting(self, relx_s, rely_s):
            EncodeOnehotLabel1 = tk.Label(self.master, text='[ENCODE ONEHOT]')
            EncodeOnehotLabel2 = tk.Label(self.master, text=' - x list = ')
            EncodeOnehotEditBox1 = tk.Entry(self.master, width=15, textvariable = self.entry_text2)
            EncodeOnehotLabel3 = tk.Label(self.master, text='    * x list should be assigned as column number of variable x in input the file, e.g., 0, 1, 3 are assigned as x1, x2, x4.')

            # Encodeonehot
            EncodeOnehotLabel1.place(relx = relx_s, rely = rely_s + 0.55, anchor = tk.NW)
            EncodeOnehotLabel2.place(relx = relx_s, rely = rely_s + 0.65, anchor = tk.NW)
            EncodeOnehotEditBox1.place(relx = relx_s + 0.1, rely = rely_s + 0.65, anchor = tk.NW)
            EncodeOnehotLabel3.place(relx = relx_s, rely = rely_s + 0.7, anchor = tk.NW)

        def _button_setting(self):
            def _btn_clear():
                self.entry_text1.set('0')
                self.entry_text2.set('0')
                e_msg = 'clear/default config.'
                j_msg = '設定を空欄あるいはデフォルト値にクリアしました。'
                messagebox.showinfo('info msg',e_msg + '\n' + j_msg)

            def _btn_save():
                self.value_list = [self.check_Val1.get(), self.check_Val2.get(), self.check_Val3.get(), '[' + self.entry_text1.get() + ']', '[' + self.entry_text2.get() + ']']
                e_msg = 'save config.'
                j_msg = '設定を保存しました。'
                messagebox.showinfo('info msg', e_msg + '\n' + j_msg)

            def _btn_close():
                e_msg = 'Can I close this window? Did you save this config?'
                j_msg = 'ウィンドウを閉じて、設定ファイルを作成しても良いですか？設定は保存しましたか？'
                ret = messagebox.askyesno(title = 'check msg', message = e_msg + '\n' + j_msg)
                if ret == True:
                    self.master.destroy()

            button1 = tk.Button(self.master, text='clear/default', width=10, command=_btn_clear)
            button2 = tk.Button(self.master, text='save', width=10, command=_btn_save)
            button3 = tk.Button(self.master, text='close', width=10, command=_btn_close)

            # button
            button1.place(relx = 0.25, rely = 0.9, anchor = tk.CENTER)
            button2.place(relx = 0.5, rely = 0.9, anchor = tk.CENTER)
            button3.place(relx = 0.75, rely = 0.9, anchor = tk.CENTER)




    hv = [700, 400]
    root = tk.Tk()
    relx_s = 0.05
    rely_s = 0.05
    app = Application(hv=hv, master = root)
    app._default_setting(relx_s, rely_s)
    app._EncodeLabel_setting(relx_s, rely_s)
    app._EncodeOnehot_setting(relx_s, rely_s)
    app._button_setting()
    app.mainloop()
    flag_list = app.value_list[:3]
    if flag_list[1] == True and app.value_list[3] == '[]':
        print('encode label list is empty.')
    else:
        encode_label_list = app.value_list[3]
    if flag_list[2] == True and app.value_list[4] == '[]':
        print('encode onehot list is empty.')
    else:
        encode_onehot_list = app.value_list[4]
    return flag_list, encode_label_list, encode_onehot_list


def save_config(work_path, flag_list, encode_label_list, encode_onehot_list):
    f = open(work_path + '\\preprocessing_config.ini', 'w')
    f.write('[DEFAULT]\n')
    f.write('SplitTimestamp = ' + str(flag_list[0]) + '\n')
    f.write('EncodeLabel = ' + str(flag_list[1]) + '\n')
    f.write('EncodeOnehot = ' + str(flag_list[2]) + '\n\n')
    f.write('[ENCODELABEL]\n')
    f.write('# x list (column number)\n')
    f.write('XList = ' + encode_label_list + '\n\n')
    f.write('[ENCODEONEHOT]\n')
    f.write('# x list (column number)\n')
    f.write('XList = ' + encode_onehot_list)
    f.close()


def main_calc(work_path):
    print('|--------------|')
    print('call setting window')
    (flag_list, encode_label_list, encode_onehot_list) = setting_window()
    print('|--------------|')

    print('|--------------|')
    print('save config file')
    save_config(work_path, flag_list, encode_label_list, encode_onehot_list)
    print('|--------------|')


def main(work_path):
    def _save_logfile(filename, msg1, msg2):
        f = open(filename, 'w')
        f.write(msg1)
        f.write(msg2)
        f.close()

    new_dir_path = work_path + '\\log'
    my_makedirs(new_dir_path)
    now_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%d')
    try:
        main_calc(work_path)
        e_mainmsg = 'Execution completed successfully.'
        e_msg = e_mainmsg + '\n' + 'Output the success message to log file.'
        j_msg = '実行を正常に完了しました。logファイルに成功メッセージを出力しました。'

    except Exception:
        e_mainmsg = 'Execution failed.'
        e_msg = e_mainmsg + '\n' + 'Output the error message to dumplog file.'
        e_mainmsg = e_mainmsg + '\n' + traceback.format_exc()
        j_msg = '実行に失敗しました。dumplogファイルにエラーメッセージを出力しました。'
        print('|--------------|')

    _save_logfile(new_dir_path + '\\log_config.txt', now_time + '\n', e_mainmsg)
    print(e_msg)
    messagebox.showinfo('info message', e_msg + '\n' + j_msg)
    print('finish')



directly_flag = True
if directly_flag:
    work_path = path.dirname( path.abspath(__file__) )
else:
    work_path = os.getcwd()
os.chdir(work_path)
print('work_path = ', work_path)
main(work_path)