#coding: utf-8 
import os
from os import path
import datetime

import pandas as pd
import numpy as np

def my_makedirs(path):
    if not os.path.isdir(path):
        os.makedirs(path)


def get_path(direct_flag):
    if direct_flag:
        dir_base = path.dirname( path.abspath(__file__) )
    else:
        dir_base = os.getcwd()
    os.chdir(dir_base)
    print('dir_base = ', dir_base)
    return dir_base



def get_subs(clm_type):
    if clm_type == 'kind':
        subs = {
                'だいこん': 'Radish', 
                'かぶ': 'Turnip',
                'にんじん': 'Carrot',
                'ごぼう': 'Burdock', 
                'れんこん': 'Lotus_Root', 
                'キャベツ': 'Cabbage', 
                'レタス': 'Lettuce', 
                'はくさい': 'Chinese_Cabbage', 
                'こまつな': 'Komatsuna',
                'ほうれんそう': 'Spinach', 
                'ねぎ': 'Green_Onion', 
                'しゅんぎく': 'Crown_Daisy', 
                'ブロッコリー': 'Broccoli', 
                'きゅうり':'Cucumber', 
                'かぼちゃ':'Squash', 
                'なす':'Eggplant', 
                'トマト':'Tomato', 
                'ピーマン':'Green_Pepper',
                'じゃがいも':'Potato', 
                'さつまいも':'Sweet_Potato', 
                'さといも':'Taro', 
                'たまねぎ':'Onion', 
                'なましいたけ':'Shiitake', 
                'セルリー':'Celery', 
                'さやえんどう':'Field_Peas', 
                'なのはな':'Rape_Blossom',
                'たけのこ':'Bamboo_Shoot', 
                'ふき': 'Fuki', 
                'うど': 'Udo', 
                'そらまめ': 'Broad_Bean', 
                'アスパラガス': 'Asparagus', 
                'ピース': 'Peas', 
                'とうもろこし': 'Corn', 
                'いんげん': 'Kidney_Bean', 
                'えだまめ': 'Edamame',
                'うめ': 'Ume', 
                'まつたけ': 'Pine_Mushroom', 
                'オクラ': 'Okra', 
                'レイシにがうり': 'Bitter_Melon', 
                'みずな': 'Mizuna', 
                'ミニトマト':'Mini_Tomato', 
                'にら': 'Leek', 
                'えのきだけ': 'Enoki_Mushroom', 
                'しめじ': 'Shimeji_Mushroom'
                }
    elif clm_type == 'city':
        subs = {
                '青森':'Aomori', 
                '盛岡':'Morioka',
                '秋田':'Akita',
                '仙台':'Sendai', 
                '山形':'Yamagata', 
                '福島':'Fukushima',
                '水戸':'Mito',
                '宇都宮':'Utsunomiya',
                '前橋':'Maebashi', 
                '熊谷':'Kumagaya',
                '甲府':'Kofu', 
                '横浜':'Yokohama', 
                '千葉':'Chiba',
                '浜松':'Hamamatsu', 
                '長野':'Nagano', 
                '新潟':'Niigata', 
                '名古屋':'Nagoya', 
                '高松':'Takamatsu', 
                '徳島':'Tokushima', 
                '高知': 'Kochi',
                '松山': 'Matsuyama',
                '那覇': 'Naha',
                '鹿児島': 'Kagoshima',
                '宮崎': 'Miyazaki',
                '長崎': 'Nagasaki',
                '熊本': 'Kumamoto',
                '福岡': 'Fukuoka',
                '佐賀':'Saga',
                '和歌山': 'Wakayama',
                '神戸': 'Kobe',
                '帯広': 'Obihiro',
                '東京': 'Tokyo'
                }
    elif clm_type == 'area':
        subs = {
                '青森':'Aomori', 
                '岩手':'Iwate',
                '秋田':'Akita',
                '宮城':'Miyagi', 
                '山形':'Yamagata', 
                '福島':'Fukushima',
                '茨城':'Ibaraki',
                '栃木':'Tochigi',
                '群馬':'Gunma', 
                '埼玉':'Saitama',
                '山梨':'Yamanashi', 
                '神奈川':'Kanagawa', 
                '千葉':'Chiba',
                '静岡':'Shizuoka', 
                '長野':'Nagano', 
                '新潟':'Niigata', 
                '愛知':'Aichi', 
                '香川':'Kagawa', 
                '徳島':'Tokushima', 
                '高知': 'Kochi',
                '愛媛': 'Ehime',
                '沖縄': 'Okinawa',
                '鹿児島': 'Kagoshima',
                '宮崎': 'Miyazaki',
                '長崎': 'Nagasaki',
                '熊本': 'Kumamoto',
                '福岡': 'Fukuoka',
                '佐賀':'Saga',
                '和歌山': 'Wakayama',
                '兵庫': 'Hyogo',
                '北海道': 'Hokkaido',
                '東京':'Tokyo',
                '各地':'Japan',
                '中国':'China',
                'アメリカ':'USA',
                'カナダ':'Canada',
                'ニュージーランド':'NewZealand',
                'メキシコ':'Mexico',
                'トンガ':'Tonga'
                }
    elif clm_type == 'area_mapping':
        subs = {
                'Morioka':'Iwate',
                'Sendai':'Miyagi',
                'Hamamatsu':'Shizuoka',
                'Naha':'Okinawa',
                'Yokohama':'Kanagawa',
                'Nagoya':'Aichi',
                'Mito':'Ibaraki',
                'Obihiro':'Hokkaido',
                'Kobe':'Hyogo',
                'Takamatsu':'Kagawa',
                'Kumagaya':'Saitama',
                'Kofu':'Yamanashi',
                'Utsunomiya':'Tochigi',
                'Maebashi':'Gunma',
                'Matsuyama':'Ehime'
                }
    return subs

def clm_mapping(from_ls, clm_type):
    to_ls = from_ls.copy()
    if clm_type == 'area':
        for (jpn, eng) in get_subs(clm_type).items():
            to_ls = [jpn_item.replace(jpn, eng) for jpn_item in to_ls]
    elif clm_type == 'kind' or clm_type == 'city':
        for (jpn, eng) in get_subs(clm_type).items():
            to_ls = [jpn_item.replace(jpn, eng) if jpn_item.startswith(jpn) else jpn_item for jpn_item in to_ls]
    elif clm_type == 'area_mapping':
        for (city, area) in get_subs(clm_type).items():
            to_ls = [city_item.replace(city, area) for city_item in to_ls]
    return to_ls

def df_trans(df, filename):
    if filename == 'train' or filename == 'test':
        df['kind'] = df.index.tolist()
        df['kind'] = clm_mapping(df['kind'], 'kind')
        df['area'] = clm_mapping(df['area'], 'area')
    elif filename == 'weather':
        df['date'] = df.index.tolist()
        df['area'] = clm_mapping(df['area'], 'city')
        # city to area in weather
        df['area'] = clm_mapping(df['area'], 'area_mapping')
    
    df = df.reset_index(drop=True)

    if filename == 'weather':
        def trans_format(df):
            f_trans = lambda x: x.timestamp() if type(x.to_pydatetime()) == datetime.datetime else x
            for clm in df.columns:
                df[clm] = pd.to_datetime(df[clm], infer_datetime_format=True)
                df[clm] = df[clm][0].timestamp()
            #df = df.applymap(f_trans)
            #print(df)
            #for clm in df.columns:
            #    df[clm] = df[clm].astype(float, errors = 'raise')
            return df

        tmp_df = df.copy()
        # datetime to UNIX
        tmp_df[['max_temp_time','min_temp_time']] = trans_format(tmp_df[['max_temp_time','min_temp_time']])
        agg_cols = ['mean_temp', 'max_temp', 'max_temp_time', 'min_temp', 'min_temp_time', 'sum_rain', 'sun_time', 'mean_humid']
        gb_df = tmp_df.groupby(['date'])[agg_cols].mean()
        gb_df['area'] = 'Japan'
        gb_df['date'] = gb_df.index.tolist()
        # UNIX to datetime to string
        for clm in ['max_temp_time','min_temp_time']:
            gb_df[clm] = pd.to_datetime(gb_df[clm].astype(int), unit='s').dt.strftime('%Y/%m/%d %H:%M')
        df = pd.concat([df, gb_df], axis=0).reset_index(drop=True)

    df['timestamp'] = pd.to_datetime(df['date'], format='%Y%m%d').dt.strftime('%Y-%m-%d')
    return df

direct_flag = True
dir_base = get_path(direct_flag)

# import
df_train = pd.read_csv(dir_base + '\\input\\ori\\train_ori.csv', index_col=0)
df_test = pd.read_csv(dir_base + '\\input\\ori\\test_ori.csv', index_col=0)
df_weather = pd.read_csv(dir_base + '\\input\\ori\\weather_ori.csv', index_col=0)

# jpn to eng, city to area in weather
df_train = df_trans(df_train, 'train')
df_test = df_trans(df_test, 'test')
df_weather = df_trans(df_weather, 'weather')

# only kind in test
df_train = df_train[df_train['kind'].isin(df_test['kind'].unique())]
df_train = df_train.reset_index(drop=True)

print(df_train)
print(df_test)
print(df_weather)

my_makedirs(dir_base + '\\input\\add')
my_makedirs(dir_base + '\\input\\add\\file')
df_train.to_csv(dir_base + '\\input\\add\\file\\train.csv')
df_test.to_csv(dir_base + '\\input\\add\\file\\test.csv')
df_weather.to_csv(dir_base + '\\input\\add\\file\\weather.csv')

print('finish')