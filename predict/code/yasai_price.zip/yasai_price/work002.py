#coding: utf-8 
import os
from os import path
import errno
import configparser
import itertools
import json
import datetime
from datetime import datetime, timedelta

import pandas as pd
import numpy as np
from pkg.figure_save import figure_save_class

def my_makedirs(path):
    if not os.path.isdir(path):
        os.makedirs(path)


def get_path(direct_flag):
    if direct_flag:
        dir_base = path.dirname( path.abspath(__file__) )
    else:
        dir_base = os.getcwd()
    os.chdir(dir_base)
    print('dir_base = ', dir_base)
    return dir_base


def split_timestamp_variable(df, feat_mode='split'):
    def _check_timestamp(l):
        if '/' in l:
            type_ = '/'
        elif '-' in l:
            type_ = '-'
        else:
            type_ = 'error: timestamp column is wrong.'
            print(type_)
        return type_

    def _split_yyyymmdd(df, type_):
        #df_temp = df['timestamp'].dt.strftime('%Y' + type_ + '%m' + type_ + '%d').str.split(type_, expand=True)
        df_ = df.str.split(type_, expand=True)
        df_.columns = ['year', 'month', 'day']
        df_ = df_.astype(float)
        return df_

    df_ = df.copy()
    type_ = _check_timestamp(str(df_.at[0, 'timestamp']))
    df_temp = _split_yyyymmdd(df_['timestamp'], type_)
    if feat_mode=='split':
        df_ = df_temp.copy()
    elif feat_mode=='add':
        df_ = pd.concat([df_, df_temp], axis=1)
    return df_


def merge_df(df_weather, df_train):
    # df_train: ['amount','mode_price','area','kind','timestamp']
    df_weather = df_weather.loc[:, ['mean_temp','max_temp','min_temp','sum_rain','sun_time','mean_humid','area','timestamp']]
    kind_list = df_train['kind'].unique()
    for kind in kind_list:
        df_train_kind = df_train[df_train['kind'] == kind]
        df_train_kind = df_train_kind.drop('kind', axis=1)
        for c1, sdf in df_train_kind.groupby('area'):
            if c1 in df_weather['area'].tolist():
                print(kind + '_' + c1)
                df_weather_area = df_weather[df_weather['area'] == c1]
                df = pd.merge(sdf, df_weather_area, on=['area', 'timestamp'])
                filename = 'train'
                clmx = 'mean_temp'
                clmy = 'mode_price'
                figure_label = [clmx, clmy, df[clmx].min(), df[clmx].max(), 0, df[clmy].max()]
                fig_name = dir_base + '\\input\\add\\fig\\' + filename + '_scatter_' + clmx + '_' + clmy + '_' + kind + '_' + c1 + '.png'
                figure_save_class().scatter(figure_label, df[clmx], df[clmy], fig_name)
            else:
                print('skip ' + kind + '_' + c1)

def count_record(df, dir_base):
    TARGET = 'mode_price'
    start = '20210501'
    end = '20220430'
    df_part = df.query(start + ' <= date <= ' + end)
    df_pivot = pd.pivot_table(df_part, index='kind', columns='month', values=TARGET, aggfunc='count')
    df_pivot.to_csv(dir_base + '\\input\\add\\file\\pivot_' + start + '_' + end + '.csv')


def draw_trend(df, dir_base):
    def _get_dummy_df(df):
        max_days = (datetime(2022, 12, 31) - datetime(2005, 1, 1)).days
        dum_data = []
        clm_list = df.columns.tolist()
        print(clm_list)
        for i in range(max_days+1):
            date = datetime(2005, 1, 1) + timedelta(days=i)
            date = int(date.strftime('%Y%m%d'))
            dum_data.append([date, 0, 0])

        dum_df = pd.DataFrame(dum_data, columns = clm_list[:3])
        for clm in clm_list[3:]:
            if clm == 'kind' or clm.startswith('area'):
                dum_df[clm] = 'dummy'
            elif clm.endswith('prev'):
                dum_df[clm] = 0
            else:
                dum_df[clm] = 0
        dum_df['timestamp'] = pd.to_datetime(dum_df['date'], format="%Y%m%d").dt.strftime('%Y-%m-%d')
        dum_df[['year', 'month', 'day']] = split_timestamp_variable(dum_df, feat_mode='split')
        return dum_df

    dum_df = _get_dummy_df(df)
    vis_df = pd.concat([df, dum_df])
    vis_df = vis_df.query('20160601 <= date <= 20220430').reset_index(drop=True)
    vis_df = pd.pivot_table(vis_df, index='timestamp', columns='kind', values='mode_price').reset_index()
    vis_df['timestamp'] = pd.to_datetime(vis_df['timestamp'], format='%Y-%m-%d')
    #vis_df.fillna(0, inplace=True)
    
    for kind in df['kind'].unique():
        print('trend: ' + kind)
        sdf = vis_df.loc[:,['timestamp',kind]]
        figure_label = ['timestamp', 'mode_price', 0, sdf[kind].max()]
        fig_name = dir_base + '\\input\\add\\fig\\trend_mode_price_' + kind + '.png'
        figure_save_class().trend(figure_label, sdf['timestamp'], sdf[kind], fig_name)

def draw_scatter(df, dir_base):
    def draw_scatter_unit(df, dir_base, x, y):
        for c1, sdf in df.groupby('kind'):
            print('scatter: ' + x + ' - ' + y + ' in ' + c1)
            if x == 'month' or x == 'year' or x == 'day':
                sdf[x] = sdf[x].astype(int)

            x_min = sdf[x].min()
            x_max = sdf[x].max()
            y_max = sdf[y].max()
            figure_label = [x, y, x_min, x_max, 0, y_max]
            fig_name = dir_base + '\\input\\add\\fig\\scatter_' + x + '_' + y + '_' + c1 + '.png'
            if x == 'month':
                label = 'year'
                figure_label.extend(sdf[label].unique())
                figure_save_class().scatter_multi_label(figure_label, sdf[[x, label]], sdf[[y, label]], label, fig_name)
            else:
                fig_name = dir_base + '\\input\\add\\fig\\scatter_' + x + '_' + y + '_' + c1 + '.png'
                figure_save_class().scatter(figure_label, sdf[x], sdf[y], fig_name)

    df_scatter = df.query('20160601 <= date <= 20220430').reset_index(drop=True)
    prev_feats = [clm for clm in df_scatter.columns.tolist() if clm.endswith('prev')]
    scatter_x_list = ['month'] + prev_feats
    scatter_y_list = ['mode_price']
    for (scatter_x, scatter_y) in itertools.product(scatter_x_list, scatter_y_list):
        draw_scatter_unit(df_scatter, dir_base, scatter_x, scatter_y)

def cal_corr(df, dir_base):
    df_ = df.copy()
    prev_feats = [clm for clm in df_.columns.tolist() if clm.endswith('prev')]
    TARGET = 'mode_price'
    x_list = ['month'] + prev_feats
    df_ = df[['kind', TARGET] + x_list]
    
    for (i, kind) in enumerate(df_['kind'].unique()):
        print('corr: ' + kind)
        tmp_df = df_[df_['kind'] == kind].corr().loc[TARGET, :]
        #dprint(cor_df.query(f'0.5 <= {TARGET} < 1')[[TARGET]].sort_values(by=TARGET, ascending=False))
        if i > 0:
            cor_df = pd.concat([cor_df, tmp_df], axis=1)
        else:
            cor_df = tmp_df.copy()
    cor_df.columns = [idx + '_' + kind for idx, kind in zip(cor_df.columns.tolist(),df_['kind'].unique())]
    cor_df = cor_df.transpose().round(4)
    print(cor_df)
    cor_df.to_csv(dir_base + '\\input\\add\\file\\corr.csv')

direct_flag = True
dir_base = get_path(direct_flag)

# import
df_train_preprocessed = pd.read_csv(dir_base + '\\input\\add\\file\\train_preprocessed.csv', index_col=0)
df_test_preprocessed = pd.read_csv(dir_base + '\\input\\add\\file\\test_preprocessed.csv', index_col=0)

my_makedirs(dir_base + '\\input\\add\\fig')

# count record
#count_record(df_train_preprocessed, dir_base)
# trend
#draw_trend(df_train_preprocessed, dir_base)

# scatter
#draw_scatter(df_train_preprocessed, dir_base)

# corr 
cal_corr(df_train_preprocessed, dir_base)

print('finish')