#coding: utf-8 
import os
from os import path
import time

import pandas as pd
import numpy as np

from pkg import Model
from pkg.figure_save import figure_save_class

def my_makedirs(path):
    if not os.path.isdir(path):
        os.makedirs(path)

def get_path(direct_flag):
    if direct_flag:
        dir_base = path.dirname( path.abspath(__file__) )
    else:
        dir_base = os.getcwd()
    os.chdir(dir_base)
    print('dir_base = ', dir_base)
    return dir_base


def split_data_old(df, x_list, tra_period, test_period):
    def _list_check(list1, list2):
        return set(list1).issubset(list2)

    def _select_idx_dataframe(df, clm, txt):
        if _list_check(clm, np.arange(len(df.columns.tolist())).tolist()):
            df = pd.concat([df.iloc[:, 0], df.iloc[:, clm]], axis=1)
        else:
            df = 0
            print('input data does not contain ' + txt + '.')
        return df

    def _select_clm_dataframe(df, period, txt):
        if _list_check(period, df.index.tolist()):
            df_ = df.loc[period[0]:period[1], :]
        else:
            df_ = 0
            print('input data does not contain ' + txt + '.')
        return df_

    # x_select
    x_list = list(map(lambda x: x+1, x_list))
    df = _select_idx_dataframe(df, x_list, 'x_list')
    print('y = ', df.columns[0])
    print('x = ', df.columns[1:].tolist())

    # split
    print('training period: ', tra_period)
    print('predict period: ', test_period)
    df_tra = _select_clm_dataframe(df, tra_period, 'training period')
    df_test = _select_clm_dataframe(df, test_period, 'predict period')
    print('traning data')
    print(df_tra.shape)
    print(df_tra.head())
    print('validation data')
    print(df_test.shape)
    print(df_test.head())
    return df_tra, df_test

def split_data(df, x_list, drop_clm, drop_name):
    df = df[df[drop_clm] == drop_name]
    df = df.drop(drop_clm, axis=1)
    return df

def fit_predict(df_tra, df_pre, modeling_mode, date_val_start):
    def _metric(true_y, pred_y, metric_type='root_mean_squared_percentage_error'):
        if metric_type == 'root_mean_squared_percentage_error':
            return np.sqrt(np.mean(((pred_y - true_y) / true_y)**2))*100

    def _calc_model_metric(row):
        return np.sqrt(np.mean(((row['model_mode_price'] - row['mode_price']) / row['mode_price'])**2))*100


    def _cross_validation(df_tra, date_val_start, modeling_mode):
        # split to tra and val
        df_training = df_tra.query('date <= ' + date_val_start).drop('date', axis=1)
        df_validation = df_tra.query(date_val_start + ' <= date').drop('date', axis=1)
        X_tra = df_training.values[:, 1:]
        y_tra = df_training.values[:, 0]
        X_val = df_validation.values[:, 1:]
        y_val = df_validation.values[:, 0]

        if modeling_mode == 'RF':
            modeling_list = [100, 'None', 2]
        else:
            modeling_list = []

        # hyper search
        hyper_search_flag = True
        #hyper_search_flag = False

        if hyper_search_flag:
            # grid search, optuna
            search_mode = 'optuna'
            hypertuner = Model.HyperSearch(modeling_mode, modeling_list, search_mode)
            hypertuner.hyper_search(X_tra, y_tra)
            best_params = hypertuner.best_params
            model = Model.Model(modeling_mode, modeling_list, False, best_params=best_params)
        else:
            model = Model.Model(modeling_mode, modeling_list, False)
            best_params = {}

        # validation
        model.fit(X_tra, y_tra)
        y_est = model.predict(X_val)
        val_score = _metric(y_val, y_est, metric_type='root_mean_squared_percentage_error')
        print('validation score: ', val_score)
        return modeling_list, best_params, val_score

    # cross_validation and hyperparam
    (modeling_list, best_params, val_score) = _cross_validation(df_tra, date_val_start, modeling_mode)

    # final predict
    df_tra = df_tra.drop('date', axis=1)
    df_pre = df_pre.drop('date', axis=1)

    X_tra = df_tra.values[:, 1:]
    y_tra = df_tra.values[:, 0]
    X_pre = df_pre.values[:, 1:]
    y_act = df_pre.values[:, 0]

    model = Model.Model(modeling_mode, modeling_list, False, best_params=best_params)
    model.fit(X_tra, y_tra)
    y_pre = model.predict(X_pre)

    y_array = np.vstack([y_pre, y_act]).T
    df_y_pre = pd.DataFrame(y_array, 
                            index = df_pre.index, 
                            columns=[df_pre.columns[0]+'_pre', df_pre.columns[0]+'_act'])
    print(df_y_pre.head())
    return df_y_pre, val_score



# RF, LightGBM
modeling_mode = 'LightGBM'
# 1, 2, 3, 4
x_type = 4

direct_flag = True
dir_base = get_path(direct_flag)

df_train = pd.read_csv(dir_base + '\\input\\add\\file\\train_preprocessed.csv', index_col=0)
df_test = pd.read_csv(dir_base + '\\input\\add\\file\\test_preprocessed.csv', index_col=0)
df_test['mode_price'] = 0

date_val_start = '20220401'

time_feats = ['year','month','day']
area_feats = [clm for clm in df_train.columns.tolist() if clm.startswith('area_')]
prev_feats = [clm for clm in df_train.columns.tolist() if clm.endswith('prev')]
if x_type == 1:
    x_list = time_feats
elif x_type == 2:
    x_list = time_feats + area_feats
elif x_type == 3:
    x_list = time_feats + prev_feats
elif x_type == 4:
    x_list = time_feats + area_feats + prev_feats

clm_list = ['date','mode_price','kind'] + x_list
print(clm_list)
df_train = df_train[clm_list]
df_test = df_test[clm_list]

my_makedirs(dir_base + '\\output')
outpath = dir_base + '\\output\\rev' + str(x_type)
my_makedirs(outpath)
my_makedirs(outpath + '\\file')
my_makedirs(outpath + '\\fig')

score_list = []

start_time = time.time()
print ("calculation started.")
print('-----------------------------------')


for i, kind in enumerate(df_test['kind'].unique()):
    print(kind)
    
    df_tra = split_data(df_train, x_list, 'kind', kind)
    df_pre = split_data(df_test, x_list, 'kind', kind)

    # fit/predict
    (df_y_pre, val_score) = fit_predict(df_tra, df_pre, modeling_mode, date_val_start)

    # save output files
    #df_y_pre.to_csv(outpath + '\\file\\predict_' + kind + '.csv')
    #fig_name = outpath + '\\fig\\predict_' + kind + '.png'
    #figure_save_class().draw_trend_chart(df_y_pre, fig_name)

    if i == 0:
        df = df_y_pre.copy()
    else:
        df = pd.concat([df, df_y_pre], axis=0)
    score_list.append([kind, val_score])

# draw trend chart
fig_name = outpath + '\\fig\\predict_' + modeling_mode + '.png'
figure_save_class().draw_trend_chart(df, fig_name)

# cal_time
cal_time = time.time() - start_time
print('calculation time = %.3f min' % (cal_time/60))
score_df = pd.DataFrame(score_list, columns=['kind', 'score'])
score_df.loc['score mean'] = [np.nan, score_df.mean(numeric_only=True)['score']]
score_df.loc['time'] = [cal_time, cal_time/60]
score_df = score_df.round(4)
score_df.to_csv(outpath + '\\file\\score_' + modeling_mode + '.csv')

# submission file
df_submission = pd.read_csv(dir_base + '\\input\\ori\\sample_submission.csv', index_col=0)
df_submission['mode_price'] = df['mode_price_pre'].values
print(df_submission)
df_submission.to_csv(outpath + '\\file\\submission_' + modeling_mode + '.csv')

print('finish')