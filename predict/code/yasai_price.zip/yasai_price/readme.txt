# work000
must processing

# work001
preprocessing
- year/month/day
- area
- prev feature (price at each yasai)

# work002
figure
- scatter 
- trend
corr

# work003
predict
- modeling_mode
    - RF
    - lightGBM(hyperopt)

- x_type
    - 1: time_feat
    - 2: time_feat, area_feat
    - 3: time_feat, prev_feat(price at each yasai)
    - 4: time_feat, area_feat, prev_feat(price at each yasai)