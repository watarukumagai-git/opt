#coding: utf-8 
import warnings
import numpy as np

from sklearn.ensemble import RandomForestRegressor
from sklearn.cross_decomposition import PLSRegression
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import KFold
import lightgbm as lgb
import optuna
import optuna.integration.lightgbm as lgb_o

#ErrMsg
GeneralErrMsg1 = 'Modeling-mode does not work.'
PLSErrMsg1 = 'PLS Error: NumLV should be integer number within the range [1, number of variables].'
RFErrMsg1 = 'RF Error: NumTree should be integer number and larger than 1.'
RFErrMsg2 = 'RF Error: MaxDepth should be None or integer number and larger than 1.'
RFErrMsg3 = 'RF Error: MinSamplesSplit should be integer number and larger than 2.'

class HyperSearch:
    def __init__(self, modeling_mode, modeling_list, search_mode):
        self.modeling_mode = modeling_mode
        self.modeling_list = modeling_list
        self.search_mode = search_mode

    def hyper_search(self, X_tra, y_tra):
        if self.modeling_mode == 'RF':
            params = {
                     'n_estimators': [10, 50, 100, 1000],
                     'max_depth': range(3,7)
                     }
            model = Model.Model(self.modeling_mode, self.modeling_list, True)
            if self.search_mode == 'grid search':
                search_model = GridSearchCV(model.model, params, cv=5)
                tuner = search_model.fit(X_tra, y_tra)
            self.best_params = tuner.best_params_
            self.modeling_list[0] = self.best_params['n_estimators']
            self.modeling_list[1] = self.best_params['max_depth']
        elif self.modeling_mode == 'LightGBM':
            trainval = lgb.Dataset(X_tra, y_tra)
            params = {
                     'objective': 'regression',
                     'metric': 'rmse',
                     'random_seed': 0,
                     'verbosity': optuna.logging.set_verbosity(-1)
                     }
            if self.search_mode == 'optuna':
                warnings.resetwarnings()
                with warnings.catch_warnings():
                    warnings.simplefilter('ignore')
                    tuner = lgb_o.LightGBMTunerCV(params, trainval, show_progress_bar=False, callbacks=[lgb.early_stopping(100)], folds=KFold(n_splits=3))
                    tuner.run()
            self.best_params = tuner.best_params
        else:
            self.best_params = {}

class Model:
    def __init__(self, modeling_mode, modeling_list, hyper_flag, best_params={}):
        self.modeling_mode = modeling_mode
        self.modeling_list = modeling_list
        if modeling_mode == 'RF':
            # default: 100
            NumTree = int(modeling_list[0])
            # default: None
            if modeling_list[1] == 'None':
                MaxDepth = None
            else:
                MaxDepth = int(modeling_list[1])
            # default: 2
            MinSamplesSplit = int(modeling_list[2])
            if hyper_flag:
                self.model = RandomForestRegressor()
            else:
                self.model = RandomForestRegressor(n_estimators=NumTree, max_depth=MaxDepth, min_samples_split=MinSamplesSplit, n_jobs=-1, random_state=2525)
        elif modeling_mode == 'LightGBM':
            self.model = lgb.LGBMRegressor(**best_params)
        elif modeling_mode == 'PLS':
            NumLV = int(modeling_list[0])
            self.model = PLSRegression(n_components=NumLV)
        elif modeling_mode == 'MLR':
            self.model = LinearRegression()
        else:
            self.model = 0
            print(GeneralErrMsg1)

    def fit(self, X_tra, y_tra):
        if self.modeling_mode == 'PLS':
            if int(self.modeling_list[0]) > len(X_tra.shape[1]) or int(self.modeling_list[0]) < 1:
                print(PLSErrMsg1)
        elif self.modeling_mode == 'RF':
            if int(self.modeling_list[0]) < 1:
                print(RFErrMsg1)
            if self.modeling_list[1] != 'None' and int(self.modeling_list[1]) < 1:
                print(RFErrMsg2)
            if int(self.modeling_list[2]) < 2:
                print(RFErrMsg3)
        self.model.fit(X_tra, y_tra)

    def predict(self, X_val):
        if self.modeling_mode == 'PLS':
            pre = self.model.predict(X_val).reshape(len(X_val))
        elif self.modeling_mode == 'LightGBM':
            pre = self.model.predict(X_val, num_iteration=self.model.best_iteration_)
        else:
            pre = self.model.predict(X_val)
        return pre