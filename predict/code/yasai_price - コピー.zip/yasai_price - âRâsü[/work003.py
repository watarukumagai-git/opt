#coding: utf-8 
import os
from os import path
import errno
import configparser
import traceback
import json
import datetime

import pandas as pd
import numpy as np
from sklearn.model_selection import GridSearchCV

from pkg.Model import Model
from pkg.figure_save import figure_save_class

def my_makedirs(path):
    if not os.path.isdir(path):
        os.makedirs(path)

def read_config(param_file):
    def _read_period(ini_period):
        period = ini_period.split(', ')
        period = [period[0].split('[')[1], period[1].split(']')[0]]
        return period
    
    print('config file', param_file)
    if not os.path.exists(param_file):
        raise FileNotFoundError(errno.ENOENT, os.strerror(errno.ENOENT), param_file)

    config_ini = configparser.ConfigParser() 
    config_ini.read(param_file, encoding='utf-8')
    read_default = config_ini['DEFAULT']
    x_list = json.loads(read_default.get('XList'))
    tra_period = _read_period(read_default.get('TraPeriod'))
    pre_period = _read_period(read_default.get('PrePeriod'))
    modeling_mode = read_default.get('ModelingMode')

    if modeling_mode == 'RF':
        read_modeling = config_ini['RANDOMFOREST']
        modeling_list = [read_modeling.get('NumTree'), read_modeling.get('MaxDepth'), read_modeling.get('MinSamplesSplit')]
    elif modeling_mode == 'PLS':
        read_modeling = config_ini['PLS']
        modeling_list = [read_modeling.get('NumLV')]
    elif modeling_mode == 'MLR':
        modeling_list = []
    return x_list, modeling_mode, tra_period, pre_period, modeling_list


def get_path(direct_flag):
    if direct_flag:
        dir_base = path.dirname( path.abspath(__file__) )
    else:
        dir_base = os.getcwd()
    os.chdir(dir_base)
    print('dir_base = ', dir_base)
    return dir_base


def split_data_old(df, x_list, tra_period, test_period):
    def _list_check(list1, list2):
        return set(list1).issubset(list2)

    def _select_idx_dataframe(df, clm, txt):
        if _list_check(clm, np.arange(len(df.columns.tolist())).tolist()):
            df = pd.concat([df.iloc[:, 0], df.iloc[:, clm]], axis=1)
        else:
            df = 0
            print('input data does not contain ' + txt + '.')
        return df

    def _select_clm_dataframe(df, period, txt):
        if _list_check(period, df.index.tolist()):
            df_ = df.loc[period[0]:period[1], :]
        else:
            df_ = 0
            print('input data does not contain ' + txt + '.')
        return df_

    # x_select
    x_list = list(map(lambda x: x+1, x_list))
    df = _select_idx_dataframe(df, x_list, 'x_list')
    print('y = ', df.columns[0])
    print('x = ', df.columns[1:].tolist())

    # split
    print('training period: ', tra_period)
    print('predict period: ', test_period)
    df_tra = _select_clm_dataframe(df, tra_period, 'training period')
    df_test = _select_clm_dataframe(df, test_period, 'predict period')
    print('traning data')
    print(df_tra.shape)
    print(df_tra.head())
    print('validation data')
    print(df_test.shape)
    print(df_test.head())
    return df_tra, df_test

def split_data(df, x_list, drop_clm, drop_name):
    df = df[df[drop_clm] == drop_name]
    df = df.drop(drop_clm, axis=1)
    return df

def fit_predict(df_tra, df_val, modeling_mode, modeling_list):
    def _hyper_search(X_tra, y_tra, modeling_mode, modeling_list):
        if modeling_mode == 'RF':
            param_grid = {'n_estimators': [50, 100, 200, 500]}
        model = Model.Model(modeling_mode, modeling_list, True)
        grid_search = GridSearchCV(model.model, param_grid, cv=5)
        grid_search.fit(X_tra, y_tra)
        modeling_list[0] = grid_search.best_params_['n_estimators']
        return modeling_list

    from pkg import Model
    X_tra = df_tra.values[:, 1:]
    y_tra = df_tra.values[:, 0]
    X_val = df_val.values[:, 1:]
    y_val = df_val.values[:, 0]

    modeling_list = _hyper_search(X_tra, y_tra, modeling_mode, modeling_list)
    model = Model.Model(modeling_mode, modeling_list, False)
    model.fit(X_tra, y_tra)
    y_pre = model.predict(X_val)

    y_array = np.vstack([y_pre, y_val]).T
    df_y_pre = pd.DataFrame(y_array, 
                            index = df_val.index, 
                            columns=[df_val.columns[0]+'_pre', df_val.columns[0]+'_act'])
    print(df_y_pre.describe())
    print(df_y_pre.head())
    return df_y_pre



direct_flag = True
dir_base = get_path(direct_flag)

df_train = pd.read_csv(dir_base + '\\input\\add\\file\\train_preprocessed.csv', index_col=0)
df_test = pd.read_csv(dir_base + '\\input\\add\\file\\test_preprocessed.csv', index_col=0)
df_test['mode_price'] = 0

modeling_mode = 'RF'
modeling_list = [100, 'None', 2]

x_type = 3
time_feats = ['year','month','day']
area_feats = [clm for clm in df_train.columns.tolist() if clm.startswith('area_')]
prev_feats = [clm for clm in df_train.columns.tolist() if clm.endswith('prev')]
if x_type == 1:
    x_list = time_feats
elif x_type == 2:
    x_list = time_feats + area_feats
elif x_type == 3:
    x_list = time_feats + prev_feats
elif x_type == 4:
    x_list = time_feats + area_feats + prev_feats

clm_list = ['mode_price','kind'] + x_list
print(clm_list)
df_train = df_train[clm_list]
df_test = df_test[clm_list]

outpath = dir_base + '\\output\\rev' + str(x_type)
my_makedirs(outpath)
my_makedirs(outpath + '\\file')
my_makedirs(outpath + '\\fig')

for i, kind in enumerate(df_test['kind'].unique()):
    print(kind)
    
    df_tra = split_data(df_train, x_list, 'kind', kind)
    df_val = split_data(df_test, x_list, 'kind', kind)

    # fit/predict
    df_y_pre = fit_predict(df_tra, df_val, modeling_mode, modeling_list)

    # save output files
    df_y_pre.to_csv(outpath + '\\file\\predict_' + kind + '.csv')
    fig_name = outpath + '\\fig\\predict_' + kind + '.png'
    figure_save_class().draw_trend_chart(df_y_pre, fig_name)

    if i == 0:
        df = df_y_pre.copy()
    else:
        df = pd.concat([df, df_y_pre], axis=0)

# draw trend chart
fig_name = outpath + '\\fig\\predict.png'
figure_save_class().draw_trend_chart(df, fig_name)

df_submission = pd.read_csv(dir_base + '\\input\\ori\\sample_submission.csv', index_col=0)
df_submission['mode_price'] = df['mode_price_pre'].values
print(df_submission)
df_submission.to_csv(outpath + '\\file\\submission.csv')