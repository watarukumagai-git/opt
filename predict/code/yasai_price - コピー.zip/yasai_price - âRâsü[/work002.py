#coding: utf-8 
import os
from os import path
import errno
import configparser
import re
import json
import datetime
from datetime import datetime, timedelta

import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
from pkg.figure_save import figure_save_class

def my_makedirs(path):
    if not os.path.isdir(path):
        os.makedirs(path)

def read_config(param_file):
    def _read_period(ini_period):
        period = ini_period.split(', ')
        period = [period[0].split('[')[1], period[1].split(']')[0]]
        return period
    
    print('config file', param_file)
    if not os.path.exists(param_file):
        raise FileNotFoundError(errno.ENOENT, os.strerror(errno.ENOENT), param_file)

    config_ini = configparser.ConfigParser() 
    config_ini.read(param_file, encoding='utf-8')
    read_default = config_ini['DEFAULT']
    x_list = json.loads(read_default.get('XList'))
    tra_period = _read_period(read_default.get('TraPeriod'))
    pre_period = _read_period(read_default.get('PrePeriod'))
    modeling_mode = read_default.get('ModelingMode')

    if modeling_mode == 'RF':
        read_modeling = config_ini['RANDOMFOREST']
        modeling_list = [read_modeling.get('NumTree'), read_modeling.get('MaxDepth'), read_modeling.get('MinSamplesSplit')]
    elif modeling_mode == 'PLS':
        read_modeling = config_ini['PLS']
        modeling_list = [read_modeling.get('NumLV')]
    elif modeling_mode == 'MLR':
        modeling_list = []
    return x_list, modeling_mode, tra_period, pre_period, modeling_list


def get_path(direct_flag):
    if direct_flag:
        dir_base = path.dirname( path.abspath(__file__) )
    else:
        dir_base = os.getcwd()
    os.chdir(dir_base)
    print('dir_base = ', dir_base)
    return dir_base


def preprocessing(df, flag_list, encode_label_list, encode_onehot_list):
    def _add_timestamp_variable(df):
        def _check_timestamp(l):
            if '/' in l:
                type_ = '/'
            elif '-' in l:
                type_ = '-'
            else:
                type_ = 'error: timestamp column is wrong.'
                print(type_)
            return type_

        def _add_weekday(df, type_):
            #format_ = '%Y' + type_ + '%m' + type_ + '%d'
            #df['yyyy-mm-dd'] = pd.to_datetime(df['yyyy/mm/dd'], format=format_)
            #df['weekday'] = df['yyyy-mm-dd'].dt.strftime('%a')
            #df = df.drop(['yyyy-mm-dd'], axis=1)
            df['weekday'] = df['timestamp'].dt.strftime('%a')
            return df

        df_ = df.copy()
        type_ = _check_timestamp(str(df_['timestamp'][0]))
        #df_temp = df_['timestamp'].str.split(' ', expand=True)
        #df_temp.columns = ['yyyy/mm/dd', 'HH:MM']
        #type_ = _check_timestamp(df_temp['yyyy/mm/dd'].tolist()[0])
        df_temp = _add_weekday(df_, type_)
        df_['yyyy/mm/dd'] = df_['timestamp'].dt.strftime('%Y' + type_ + '%m' + type_ + '%d')
        df_temp2 = df_temp['yyyy/mm/dd'].str.split(type_, expand=True)
        df_temp2.columns = ['year', 'month', 'day']
        df_temp = df_temp.drop(['yyyy/mm/dd'], axis=1)
        df_ = pd.concat([df_temp2, df_temp['weekday']], axis=1)
        return df_
    
    def _encode_label(df, clm):
        def _encode_label_unit(df, clm):
            le = LabelEncoder()
            le = le.fit(df[clm])
            df[clm] = le.transform(df[clm])
            return df

        if len(clm) > 1:
            for i in clm:
                df = _encode_label_unit(df, i)
        else:
            df = _encode_label_unit(df, clm[0])
        return df

    def _encode_onehot(df, clm):
        df = pd.get_dummies(df, prefix=clm, prefix_sep='-')
        return df
    
    def _get_clm(encode_list, df, flag_list, clm_time=[]):
        encode_list = list(map(lambda x: x+1, encode_list))
        encode_list = df.iloc[:, encode_list].columns.tolist()
        if flag_list == True:
            if len(encode_list) == 0:
                clm = clm_time
            else:
                clm = encode_list + clm_time
        else:
            clm = encode_list
        return clm
    

    if flag_list[0] == True:
        df_time = _add_timestamp_variable(df)
        # ['year', 'month', 'day', 'weekday']
        clm_time = df_time.columns.to_list()
        df = pd.concat([df, df_time], axis=1)
    else:
        clm_time = []

    if flag_list[1] == True:
        if (flag_list[0] == False) and (len(encode_label_list) == 0):
            print('skip label-encoding')
        else:
            clm = _get_clm(encode_label_list, df, flag_list[0], clm_time)
            df = _encode_label(df, clm)

    if flag_list[2] == True:
        if (flag_list[0] == False) and (len(encode_onehot_list) == 0):
            print('skip onehot-encoding')
        else:
            clm = _get_clm(encode_onehot_list, df, flag_list[0], clm_time)
            df = _encode_onehot(df, clm)
    return df


def get_subs(clm_type):
    if clm_type == 'kind':
        subs = {'だいこん': 'Radish', 
                'かぶ': 'Turnip',
                'にんじん': 'Carrot',
                'ごぼう': 'Burdock', 
                'れんこん': 'Lotus_Root', 
                'キャベツ': 'Cabbage', 
                'レタス': 'Lettuce', 
                'はくさい': 'Chinese_Cabbage', 
                'こまつな': 'Komatsuna',
                'ほうれんそう': 'Spinach', 
                'ねぎ': 'Green_Onion', 
                'しゅんぎく': 'Crown_Daisy', 
                'ブロッコリー': 'Broccoli', 
                'きゅうり':'Cucumber', 
                'かぼちゃ':'Squash', 
                'なす':'Eggplant', 
                'トマト':'Tomato', 
                'ピーマン':'Green_Pepper',
                'じゃがいも':'Potato', 
                'さつまいも':'Sweet_Potato', 
                'さといも':'Taro', 
                'たまねぎ':'Onion', 
                'なましいたけ':'Shiitake', 
                'セルリー':'Celery', 
                'さやえんどう':'Field_Peas', 
                'なのはな':'Rape_Blossom',
                'たけのこ':'Bamboo_Shoot', 
                'ふき': 'Fuki', 
                'うど': 'Udo', 
                'そらまめ': 'Broad_Bean', 
                'アスパラガス': 'Asparagus', 
                'ピース': 'Peas', 
                'とうもろこし': 'Corn', 
                'いんげん': 'Kidney_Bean', 
                'えだまめ': 'Edamame',
                'うめ': 'Ume', 
                'まつたけ': 'Pine_Mushroom', 
                'オクラ': 'Okra', 
                'レイシにがうり': 'Bitter_Melon', 
                'みずな': 'Mizuna', 
                'ミニトマト':'Mini_Tomato', 
                'にら': 'Leek', 
                'えのきだけ': 'Enoki_Mushroom', 
                'しめじ': 'Shimeji_Mushroom'}
    elif clm_type == 'city':
        subs = {'青森':'Aomori', 
                '盛岡':'Morioka',
                '秋田':'Akita',
                '仙台':'Sendai', 
                '山形':'Yamagata', 
                '福島':'Fukushima',
                '水戸':'Mito',
                '宇都宮':'Utsunomiya',
                '前橋':'Maebashi', 
                '熊谷':'Kumagaya',
                '甲府':'Koufu', 
                '横浜':'Yokohama', 
                '千葉':'Chiba',
                '浜松':'Hamamatsu', 
                '長野':'Nagano', 
                '新潟':'Niigata', 
                '名古屋':'Nagoya', 
                '高松':'Takamatsu', 
                '徳島':'Tokushima', 
                '高知': 'Kouchi',
                '松山': 'Matsuyama',
                '那覇': 'Naha',
                '鹿児島': 'Kagoshima',
                '宮崎': 'Miyazaki',
                '長崎': 'Nagasaki',
                '熊本': 'Kumamoto',
                '福岡': 'Fukuoka',
                '佐賀':'Saga',
                '和歌山': 'Wakayama',
                '神戸': 'Koube',
                '帯広': 'Obihiro',
                '東京':'Tokyo'}
    elif clm_type == 'area':
        subs = {'青森':'Aomori', 
                '岩手':'Morioka',
                '秋田':'Akita',
                '宮城':'Miyagi', 
                '山形':'Yamagata', 
                '福島':'Fukushima',
                '茨城':'Ibaraki',
                '栃木':'Tochigi',
                '群馬':'Gumma', 
                '埼玉':'Saitama',
                '山梨':'Yamanashi', 
                '神奈川':'Kanagawa', 
                '千葉':'Chiba',
                '静岡':'Shizuoka', 
                '長野':'Nagano', 
                '新潟':'Niigata', 
                '愛知':'Aichi', 
                '香川':'Kagawa', 
                '徳島':'Tokushima', 
                '高知': 'Kouchi',
                '愛媛': 'Ehime',
                '沖縄': 'Okinawa',
                '鹿児島': 'Kagoshima',
                '宮崎': 'Miyazaki',
                '長崎': 'Nagasaki',
                '熊本': 'Kumamoto',
                '福岡': 'Fukuoka',
                '佐賀':'Saga',
                '和歌山': 'Wakayama',
                '兵庫': 'Hyogo',
                '北海道': 'Hokkaido',
                '東京':'Tokyo',
                '各地':'Each',
                '中国':'China',
                'アメリカ':'USA',
                'カナダ':'Canada',
                'ニュージーランド':'NewZealand',
                'メキシコ':'Mexico'}
    return subs

def jpn_trans_eng(jpn_ls, clm_type):
    eng_ls = jpn_ls.copy()
    if clm_type == 'area':
        for (jpn, eng) in get_subs(clm_type).items():
            eng_ls = [jpn_item.replace(jpn, eng) for jpn_item in eng_ls]
    else:
        for (jpn, eng) in get_subs(clm_type).items():
            eng_ls = [jpn_item.replace(jpn, eng) if jpn_item.startswith(jpn) else jpn_item for jpn_item in eng_ls]
    return eng_ls

def df_trans(df, dir_base, filename):
    if filename == 'train' or filename == 'test':
        df['kind'] = df.index.tolist()
        df['kind'] = jpn_trans_eng(df['kind'], 'kind')
        df['area'] = jpn_trans_eng(df['area'], 'area')
    elif filename == 'weather':
        df['date'] = df.index.tolist()
        df['area'] = jpn_trans_eng(df['area'], 'city')
        
    df = df.reset_index(drop=True)
    df['timestamp'] = pd.to_datetime(df['date'], format="%Y%m%d")
    df.to_csv(dir_base + '\\input\\add\\file\\' + filename + '.csv')
    return df

def merge_df(df_weather, df_train):
    # df_train: ['amount','mode_price','area','kind','timestamp']
    df_weather = df_weather.loc[:, ['mean_temp','max_temp','min_temp','sum_rain','sun_time','mean_humid','area','timestamp']]
    kind_list = df_train['kind'].unique()
    for kind in kind_list:
        df_train_kind = df_train[df_train['kind'] == kind]
        df_train_kind = df_train_kind.drop('kind', axis=1)
        for c1, sdf in df_train_kind.groupby('area'):
            if c1 in df_weather['area'].tolist():
                print(kind + '_' + c1)
                df_weather_area = df_weather[df_weather['area'] == c1]
                df = pd.merge(sdf, df_weather_area, on=['area', 'timestamp'])
                filename = 'train'
                clmx = 'mean_temp'
                clmy = 'mode_price'
                figure_label = [clmx, clmy, df[clmx].min(), df[clmx].max(), 0, df[clmy].max()]
                fig_name = dir_base + '\\input\\add\\fig\\' + filename + '_scatter_' + clmx + '_' + clmy + '_' + kind + '_' + c1 + '.png'
                figure_save_class().scatter(figure_label, df[clmx], df[clmy], fig_name)
            else:
                print('skip ' + kind + '_' + c1)

def count_record(df, dir_base):
    TARGET = 'mode_price'
    start = '20210501'
    end = '20220430'
    df_part = df.query(start + ' <= date <= ' + end)
    df_pivot = pd.pivot_table(df_part, index='kind', columns='month', values=TARGET, aggfunc='count')
    df_pivot.to_csv(dir_base + '\\input\\add\\file\\pivot_' + start + '_' + end + '.csv')


def draw_trend(df, dir_base):
    def _add_split_yyyymmdd(df, type_):
        df['yyyy/mm/dd'] = df['timestamp'].dt.strftime('%Y' + type_ + '%m' + type_ + '%d')
        df_temp = df['yyyy/mm/dd'].str.split(type_, expand=True)
        df_temp.columns = ['year', 'month', 'day']
        df_temp = df_temp.astype(float)
        df = df.drop(['yyyy/mm/dd'], axis=1)
        df = pd.concat([df, df_temp], axis=1)
        return df

    def _get_dummy_df(df):
        max_days = (datetime(2022, 12, 31) - datetime(2005, 1, 1)).days
        dum_data = []
        for i in range(max_days+1):
            date = datetime(2005, 1, 1) + timedelta(days=i)
            date = int(date.strftime('%Y%m%d'))
            dum_data.append([date, 0, 0, 'dummy', 'dummy'])

        dum_df = pd.DataFrame(dum_data)
        dum_df.columns = df.columns.tolist()[:5]
        dum_df['timestamp'] = pd.to_datetime(dum_df['date'], format="%Y%m%d")
        dum_df = _add_split_yyyymmdd(dum_df, '-')
        dum_df.columns = df.columns
        return dum_df

    dum_df = _get_dummy_df(df)
    vis_df = pd.concat([df, dum_df])
    vis_df = vis_df.query('20160601 <= date <= 20220430').reset_index(drop=True)
    vis_df = pd.pivot_table(vis_df, index='timestamp', columns='kind', values='mode_price').reset_index()
    #vis_df.fillna(0, inplace=True)
    print(vis_df)
    
    for kind in df['kind'].unique():
        print('trend: ' + kind)
        sdf = vis_df.loc[:,['timestamp',kind]]
        figure_label = ['timestamp', 'mode_price', 0, sdf[kind].max()]
        fig_name = dir_base + '\\input\\add\\fig\\trend_mode_price_' + kind + '.png'
        figure_save_class().trend(figure_label, sdf['timestamp'], sdf[kind], fig_name)

def draw_scatter(df, dir_base, x, y):
    x_min = df[x].min()
    x_max = df[x].max()
    for c1, sdf in df.groupby('kind'):
        print('scatter: ' + x + ' - ' + y + ' in ' + c1)
        if x == 'month' or x == 'year' or x == 'day':
            sdf[x] = sdf[x].astype(int)
        if x == 'month':
            label = 'year'
            figure_label = [x, y, x_min, x_max, 0, sdf[y].max()]
            #figure_label.extend([int(i) for i in sdf[label].unique()])
            figure_label.extend(sdf[label].unique())
            fig_name = dir_base + '\\input\\add\\fig\\scatter_' + x + '_' + y + '_' + c1 + '.png'
            figure_save_class().scatter_multi_label(figure_label, sdf[[x, label]], sdf[[y, label]], label, fig_name)
        else:
            figure_label = [x, y, x_min, x_max, 0, sdf[y].max()]
            fig_name = dir_base + '\\input\\add\\fig\\scatter_' + x + '_' + y + '_' + c1 + '.png'
            figure_save_class().scatter(figure_label, sdf[x], sdf[y], fig_name)

direct_flag = True
dir_base = get_path(direct_flag)

# import
df_train_preprocessed = pd.read_csv(dir_base + '\\input\\add\\file\\train_preprocessed.csv', index_col=0)
df_test_preprocessed = pd.read_csv(dir_base + '\\input\\add\\file\\test_preprocessed.csv', index_col=0)

# count record
count_record(df_train_preprocessed, dir_base)
# trend
draw_trend(df_train_preprocessed, dir_base)
# scatter
scatter_x = 'month'
scatter_y = 'mode_price'
draw_scatter(df_train_preprocessed.query('20160601 <= date <= 20220430').reset_index(drop=True), dir_base, scatter_x, scatter_y)

print('finish')