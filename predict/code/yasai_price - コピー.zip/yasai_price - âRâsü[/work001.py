#coding: utf-8 
import os
from os import path
import errno
import configparser
import itertools
import json
import datetime
from re import A

import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
from pkg.figure_save import figure_save_class

def my_makedirs(path):
    if not os.path.isdir(path):
        os.makedirs(path)

def read_config(param_file):
    def _read_period(ini_period):
        period = ini_period.split(', ')
        period = [period[0].split('[')[1], period[1].split(']')[0]]
        return period
    
    print('config file', param_file)
    if not os.path.exists(param_file):
        raise FileNotFoundError(errno.ENOENT, os.strerror(errno.ENOENT), param_file)

    config_ini = configparser.ConfigParser() 
    config_ini.read(param_file, encoding='utf-8')
    read_default = config_ini['DEFAULT']
    x_list = json.loads(read_default.get('XList'))
    tra_period = _read_period(read_default.get('TraPeriod'))
    pre_period = _read_period(read_default.get('PrePeriod'))
    modeling_mode = read_default.get('ModelingMode')

    if modeling_mode == 'RF':
        read_modeling = config_ini['RANDOMFOREST']
        modeling_list = [read_modeling.get('NumTree'), read_modeling.get('MaxDepth'), read_modeling.get('MinSamplesSplit')]
    elif modeling_mode == 'PLS':
        read_modeling = config_ini['PLS']
        modeling_list = [read_modeling.get('NumLV')]
    elif modeling_mode == 'MLR':
        modeling_list = []
    return x_list, modeling_mode, tra_period, pre_period, modeling_list


def get_path(direct_flag):
    if direct_flag:
        dir_base = path.dirname( path.abspath(__file__) )
    else:
        dir_base = os.getcwd()
    os.chdir(dir_base)
    print('dir_base = ', dir_base)
    return dir_base


def preprocessing(df, flag_list, encode_label_list, encode_onehot_list):
    def _add_timestamp_variable(df):
        def _check_timestamp(l):
            if '/' in l:
                type_ = '/'
            elif '-' in l:
                type_ = '-'
            else:
                type_ = 'error: timestamp column is wrong.'
                print(type_)
            return type_

        def _add_weekday(df, type_):
            #format_ = '%Y' + type_ + '%m' + type_ + '%d'
            #df['yyyy-mm-dd'] = pd.to_datetime(df['yyyy/mm/dd'], format=format_)
            #df['weekday'] = df['yyyy-mm-dd'].dt.strftime('%a')
            #df = df.drop(['yyyy-mm-dd'], axis=1)
            df['weekday'] = df['timestamp'].dt.strftime('%a')
            return df

        df_ = df.copy()
        type_ = _check_timestamp(str(df_['timestamp'][0]))
        #df_temp = df_['timestamp'].str.split(' ', expand=True)
        #df_temp.columns = ['yyyy/mm/dd', 'HH:MM']
        #type_ = _check_timestamp(df_temp['yyyy/mm/dd'].tolist()[0])
        df_temp = _add_weekday(df_, type_)
        df_['yyyy/mm/dd'] = df_['timestamp'].dt.strftime('%Y' + type_ + '%m' + type_ + '%d')
        df_temp2 = df_temp['yyyy/mm/dd'].str.split(type_, expand=True)
        df_temp2.columns = ['year', 'month', 'day']
        df_temp = df_temp.drop(['yyyy/mm/dd'], axis=1)
        df_ = pd.concat([df_temp2, df_temp['weekday']], axis=1)
        return df_
    
    def _encode_label(df, clm):
        def _encode_label_unit(df, clm):
            le = LabelEncoder()
            le = le.fit(df[clm])
            df[clm] = le.transform(df[clm])
            return df

        if len(clm) > 1:
            for i in clm:
                df = _encode_label_unit(df, i)
        else:
            df = _encode_label_unit(df, clm[0])
        return df

    def _encode_onehot(df, clm):
        df = pd.get_dummies(df, prefix=clm, prefix_sep='-')
        return df
    
    def _get_clm(encode_list, df, flag_list, clm_time=[]):
        encode_list = list(map(lambda x: x+1, encode_list))
        encode_list = df.iloc[:, encode_list].columns.tolist()
        if flag_list == True:
            if len(encode_list) == 0:
                clm = clm_time
            else:
                clm = encode_list + clm_time
        else:
            clm = encode_list
        return clm
    

    if flag_list[0] == True:
        df_time = _add_timestamp_variable(df)
        # ['year', 'month', 'day', 'weekday']
        clm_time = df_time.columns.to_list()
        df = pd.concat([df, df_time], axis=1)
    else:
        clm_time = []

    if flag_list[1] == True:
        if (flag_list[0] == False) and (len(encode_label_list) == 0):
            print('skip label-encoding')
        else:
            clm = _get_clm(encode_label_list, df, flag_list[0], clm_time)
            df = _encode_label(df, clm)

    if flag_list[2] == True:
        if (flag_list[0] == False) and (len(encode_onehot_list) == 0):
            print('skip onehot-encoding')
        else:
            clm = _get_clm(encode_onehot_list, df, flag_list[0], clm_time)
            df = _encode_onehot(df, clm)
    return df


def get_subs(clm_type):
    if clm_type == 'kind':
        subs = {
                'だいこん': 'Radish', 
                'かぶ': 'Turnip',
                'にんじん': 'Carrot',
                'ごぼう': 'Burdock', 
                'れんこん': 'Lotus_Root', 
                'キャベツ': 'Cabbage', 
                'レタス': 'Lettuce', 
                'はくさい': 'Chinese_Cabbage', 
                'こまつな': 'Komatsuna',
                'ほうれんそう': 'Spinach', 
                'ねぎ': 'Green_Onion', 
                'しゅんぎく': 'Crown_Daisy', 
                'ブロッコリー': 'Broccoli', 
                'きゅうり':'Cucumber', 
                'かぼちゃ':'Squash', 
                'なす':'Eggplant', 
                'トマト':'Tomato', 
                'ピーマン':'Green_Pepper',
                'じゃがいも':'Potato', 
                'さつまいも':'Sweet_Potato', 
                'さといも':'Taro', 
                'たまねぎ':'Onion', 
                'なましいたけ':'Shiitake', 
                'セルリー':'Celery', 
                'さやえんどう':'Field_Peas', 
                'なのはな':'Rape_Blossom',
                'たけのこ':'Bamboo_Shoot', 
                'ふき': 'Fuki', 
                'うど': 'Udo', 
                'そらまめ': 'Broad_Bean', 
                'アスパラガス': 'Asparagus', 
                'ピース': 'Peas', 
                'とうもろこし': 'Corn', 
                'いんげん': 'Kidney_Bean', 
                'えだまめ': 'Edamame',
                'うめ': 'Ume', 
                'まつたけ': 'Pine_Mushroom', 
                'オクラ': 'Okra', 
                'レイシにがうり': 'Bitter_Melon', 
                'みずな': 'Mizuna', 
                'ミニトマト':'Mini_Tomato', 
                'にら': 'Leek', 
                'えのきだけ': 'Enoki_Mushroom', 
                'しめじ': 'Shimeji_Mushroom'
                }
    elif clm_type == 'city':
        subs = {
                '青森':'Aomori', 
                '盛岡':'Morioka',
                '秋田':'Akita',
                '仙台':'Sendai', 
                '山形':'Yamagata', 
                '福島':'Fukushima',
                '水戸':'Mito',
                '宇都宮':'Utsunomiya',
                '前橋':'Maebashi', 
                '熊谷':'Kumagaya',
                '甲府':'Kofu', 
                '横浜':'Yokohama', 
                '千葉':'Chiba',
                '浜松':'Hamamatsu', 
                '長野':'Nagano', 
                '新潟':'Niigata', 
                '名古屋':'Nagoya', 
                '高松':'Takamatsu', 
                '徳島':'Tokushima', 
                '高知': 'Kochi',
                '松山': 'Matsuyama',
                '那覇': 'Naha',
                '鹿児島': 'Kagoshima',
                '宮崎': 'Miyazaki',
                '長崎': 'Nagasaki',
                '熊本': 'Kumamoto',
                '福岡': 'Fukuoka',
                '佐賀':'Saga',
                '和歌山': 'Wakayama',
                '神戸': 'Kobe',
                '帯広': 'Obihiro',
                '東京': 'Tokyo'
                }
    elif clm_type == 'area':
        subs = {
                '青森':'Aomori', 
                '岩手':'Morioka',
                '秋田':'Akita',
                '宮城':'Miyagi', 
                '山形':'Yamagata', 
                '福島':'Fukushima',
                '茨城':'Ibaraki',
                '栃木':'Tochigi',
                '群馬':'Gunma', 
                '埼玉':'Saitama',
                '山梨':'Yamanashi', 
                '神奈川':'Kanagawa', 
                '千葉':'Chiba',
                '静岡':'Shizuoka', 
                '長野':'Nagano', 
                '新潟':'Niigata', 
                '愛知':'Aichi', 
                '香川':'Kagawa', 
                '徳島':'Tokushima', 
                '高知': 'Kochi',
                '愛媛': 'Ehime',
                '沖縄': 'Okinawa',
                '鹿児島': 'Kagoshima',
                '宮崎': 'Miyazaki',
                '長崎': 'Nagasaki',
                '熊本': 'Kumamoto',
                '福岡': 'Fukuoka',
                '佐賀':'Saga',
                '和歌山': 'Wakayama',
                '兵庫': 'Hyogo',
                '北海道': 'Hokkaido',
                '東京':'Tokyo',
                '各地':'Japan',
                '中国':'China',
                'アメリカ':'USA',
                'カナダ':'Canada',
                'ニュージーランド':'NewZealand',
                'メキシコ':'Mexico',
                'トンガ':'Tonga'
                }
    elif clm_type == 'area_mapping':
        subs = {
                'Morioka':'Iwate',
                'Sendai':'Miyagi',
                'Hamamatsu':'Shizuoka',
                'Naha':'Okinawa',
                'Yokohama':'Kanagawa',
                'Nagoya':'Aichi',
                'Mito':'Ibaraki',
                'Obihiro':'Hokkaido',
                'Kobe':'Hyogo',
                'Takamatsu':'Kagawa',
                'Kumagaya':'Saitama',
                'Kofu':'Yamanashi',
                'Utsunomiya':'Tochigi',
                'Maebashi':'Gunma',
                'Matsuyama':'Ehime'
                }
    return subs

def clm_mapping(from_ls, clm_type):
    to_ls = from_ls.copy()
    if clm_type == 'area':
        for (jpn, eng) in get_subs(clm_type).items():
            to_ls = [jpn_item.replace(jpn, eng) for jpn_item in to_ls]
    elif clm_type == 'kind' or clm_type == 'city':
        for (jpn, eng) in get_subs(clm_type).items():
            to_ls = [jpn_item.replace(jpn, eng) if jpn_item.startswith(jpn) else jpn_item for jpn_item in to_ls]
    elif clm_type == 'area_mapping':
        for (city, area) in get_subs(clm_type).items():
            to_ls = [city_item.replace(city, area) for city_item in to_ls]
    return to_ls

def add_timestamp_variable(df):
    def _check_timestamp(l):
        if '/' in l:
            type_ = '/'
        elif '-' in l:
            type_ = '-'
        else:
            type_ = 'error: timestamp column is wrong.'
            print(type_)
        return type_

    def _add_split_yyyymmdd(df, type_):
        df['yyyy/mm/dd'] = df['timestamp'].dt.strftime('%Y' + type_ + '%m' + type_ + '%d')
        df_temp = df['yyyy/mm/dd'].str.split(type_, expand=True)
        df_temp.columns = ['year', 'month', 'day']
        df_temp = df_temp.astype(float)
        df = df.drop(['yyyy/mm/dd'], axis=1)
        df = pd.concat([df, df_temp], axis=1)
        return df

    df_ = df.copy()
    df_['timestamp'] = pd.to_datetime(df_['date'], format="%Y%m%d")
    type_ = _check_timestamp(str(df_['timestamp'][0]))
    df_ = _add_split_yyyymmdd(df_, type_)
    return df_

def df_trans(df, filename):
    if filename == 'train' or filename == 'test':
        df['kind'] = df.index.tolist()
        df['kind'] = clm_mapping(df['kind'], 'kind')
        df['area'] = clm_mapping(df['area'], 'area')
    elif filename == 'weather':
        df['date'] = df.index.tolist()
        df['area'] = clm_mapping(df['area'], 'city')
        # city to area in weather
        df['area'] = clm_mapping(df['area'], 'area_mapping')
    
    df = df.reset_index(drop=True)

    if filename == 'weather':
        def trans_format(df):
            f_trans = lambda x: x.timestamp() if type(x.to_pydatetime()) == datetime.datetime else x
            for clm in df.columns:
                df[clm] = pd.to_datetime(df[clm], infer_datetime_format=True)
                df[clm] = df[clm][0].timestamp()
            #df = df.applymap(f_trans)
            #print(df)
            #for clm in df.columns:
            #    df[clm] = df[clm].astype(float, errors = 'raise')
            return df

        tmp_df = df.copy()
        # datetime to UNIX
        tmp_df[['max_temp_time','min_temp_time']] = trans_format(tmp_df[['max_temp_time','min_temp_time']])
        agg_cols = ['mean_temp', 'max_temp', 'max_temp_time', 'min_temp', 'min_temp_time', 'sum_rain', 'sun_time', 'mean_humid']
        gb_df = tmp_df.groupby(['date'])[agg_cols].mean()
        gb_df['area'] = 'Japan'
        gb_df['date'] = gb_df.index.tolist()
        # UNIX to datetime to string
        for clm in ['max_temp_time','min_temp_time']:
            gb_df[clm] = pd.to_datetime(gb_df[clm].astype(int), unit='s').dt.strftime('%Y/%m/%d %H:%M')
        df = pd.concat([df, gb_df], axis=0)

    df = add_timestamp_variable(df)
    return df

def df_each_save(df, dir_base, filename):
    for c1, sdf in df.groupby('kind'):
        print(filename + '_' + c1)
        sdf.to_csv(dir_base + '\\input\\add\\file\\' + filename + '_' + c1 + '.csv')

def add_diff_feat(df, targets, nshift, dir_base):
    df_ = df.copy()
    prev_clm = [f'{target}_{i}prev' for (target, i) in itertools.product(targets, nshift)]
    clm_list = list(set(prev_clm) - set(targets))
    df_[clm_list] = np.nan
    for kind in df['kind'].unique():
        print(kind)
        df_target = df_[df_['kind'] == kind]
        df_target = df_target.drop('kind', axis=1)
        df_target = df_target[targets]
        for (target, i) in itertools.product(targets, nshift):
            df_target[f'{target}_{i}prev'] = df_target[target].shift(i)
        df_target = df_target.drop(targets, axis=1)
        print(df_target)
        print(df_.loc[df_['kind'] == kind])
        df_.loc[df_['kind'] == kind].loc[:, targets] = df_target
        df_.to_csv(dir_base + '\\input\\add\\file\\df.csv')
        print(df_)
        a
    # drop feat_prev = NaN
    df_.to_csv(dir_base + '\\input\\add\\file\\df.csv')
    df_ = df_.dropna(subset=clm_list, how='any').reset_index(drop=True)
    return df

def add_diff_feat_weather(all_df, wea_df, nshift):
    mer_wea_df = wea_df.copy()
    mer_wea_df.columns = [f'{i}_{nshift}prev' if i not in ['year','month','day','area'] else i for i in mer_wea_df.columns]
    mer_wea_df = mer_wea_df.rename(columns={'year':'merge_year','month':'merge_month','day':'merge_day'})

    data = []

    for year, month, day in zip(all_df['year'].values, all_df['month'].values, all_df['day'].values):
        pre_day = day
        pre_month = month
        month -= nshift
        if month <= 0:
            month += 12
            year -=1
        if int(pre_month) in [1, 3, 5, 7, 8, 10, 12] and int(pre_day) == 1:
            day = 30
        data.append([year, month, day])

    tmp_df = pd.DataFrame(data, columns=['merge_year','merge_month','merge_day'])
    print(tmp_df)

    mer_df = pd.concat([all_df, tmp_df],axis=1)

    mer_df = pd.merge(mer_df, mer_wea_df, on=['merge_year','merge_month','merge_day','area'], how='left')
    mer_df.drop(['merge_year', 'merge_month', 'merge_day'], axis=1, inplace=True)

    return mer_df


def processing_area(df, dir_base):
    def _flatten_list(l):
        for el in l:
            if isinstance(el, list):
                yield from _flatten_list(el)
            else:
                yield el
    def _get_area_list(df):
        area_list = []
        for i in range(0, len(df.columns)):
            area_list.append(df.iloc[:, i].unique().tolist())
        area_list = list(set(list(_flatten_list(area_list))))
        area_list.remove(None)
        print(area_list)
        return area_list

    df_ = df.copy()
    df_split = df_['area'].str.split('_', expand=True)
    df_split.columns = ['area_1', 'area_2', 'area_3']
    area_list = _get_area_list(df_split)
    for i, clm in enumerate(df_split.columns):
        sdf_split = pd.get_dummies(df_split[clm])
        nonexist_list = list(set(area_list) - set(sdf_split.columns.tolist()))
        if len(nonexist_list) > 0:
            sdf_split[nonexist_list] = 0
        if i > 0:
            sdf_split = sdf_split + pre
        pre = sdf_split.copy()
    df_split = sdf_split.copy()
    df_split.columns = ['area_' + i for i in df_split.columns.tolist()]
    df_ = pd.concat([df_, df_split], axis=1)
    return df_

direct_flag = True
dir_base = get_path(direct_flag)

# import
df_train = pd.read_csv(dir_base + '\\input\\add\\file\\train.csv', index_col=0)
df_test = pd.read_csv(dir_base + '\\input\\add\\file\\test.csv', index_col=0)
df_weather = pd.read_csv(dir_base + '\\input\\add\\file\\weather.csv', index_col=0)

date_test_start = '20220501'

# area split and onehot-encoding
all_df = pd.concat([df_train, df_test], axis=0).reset_index(drop=True)
all_df_preprocessed = processing_area(all_df, dir_base)

# add diff feature y
targets = ['mode_price']
n_shifts = [1,2,3,6,9,12]
# nshift month -> nshift day
n_shifts = [int(i*20) for i in n_shifts]
all_df_preprocessed = add_diff_feat(all_df_preprocessed, targets, n_shifts, dir_base)

df_train_preprocessed = all_df_preprocessed.query('date <= ' + date_test_start)
df_test_preprocessed = all_df_preprocessed.query(date_test_start + ' <= date')
#df_train_preprocessed = df_train.copy()
#df_test_preprocessed = df_test.copy()

print(df_train_preprocessed)
print(df_test_preprocessed)

df_train_preprocessed.to_csv(dir_base + '\\input\\add\\file\\train_preprocessed.csv')
df_test_preprocessed.to_csv(dir_base + '\\input\\add\\file\\test_preprocessed.csv')

print('finish')