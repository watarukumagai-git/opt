#coding: utf-8 
import os
from os import path
import errno
import configparser
import re
import json
import datetime

import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
from pkg.figure_save import figure_save_class

def my_makedirs(path):
    if not os.path.isdir(path):
        os.makedirs(path)

def read_config(param_file):
    def _read_period(ini_period):
        period = ini_period.split(', ')
        period = [period[0].split('[')[1], period[1].split(']')[0]]
        return period
    
    print('config file', param_file)
    if not os.path.exists(param_file):
        raise FileNotFoundError(errno.ENOENT, os.strerror(errno.ENOENT), param_file)

    config_ini = configparser.ConfigParser() 
    config_ini.read(param_file, encoding='utf-8')
    read_default = config_ini['DEFAULT']
    x_list = json.loads(read_default.get('XList'))
    tra_period = _read_period(read_default.get('TraPeriod'))
    pre_period = _read_period(read_default.get('PrePeriod'))
    modeling_mode = read_default.get('ModelingMode')

    if modeling_mode == 'RF':
        read_modeling = config_ini['RANDOMFOREST']
        modeling_list = [read_modeling.get('NumTree'), read_modeling.get('MaxDepth'), read_modeling.get('MinSamplesSplit')]
    elif modeling_mode == 'PLS':
        read_modeling = config_ini['PLS']
        modeling_list = [read_modeling.get('NumLV')]
    elif modeling_mode == 'MLR':
        modeling_list = []
    return x_list, modeling_mode, tra_period, pre_period, modeling_list


def get_path(direct_flag):
    if direct_flag:
        dir_base = path.dirname( path.abspath(__file__) )
    else:
        dir_base = os.getcwd()
    os.chdir(dir_base)
    print('dir_base = ', dir_base)
    return dir_base


def preprocessing(df, flag_list, encode_label_list, encode_onehot_list):
    def _add_timestamp_variable(df):
        def _check_timestamp(l):
            if '/' in l:
                type_ = '/'
            elif '-' in l:
                type_ = '-'
            else:
                type_ = 'error: timestamp column is wrong.'
                print(type_)
            return type_

        def _add_weekday(df, type_):
            #format_ = '%Y' + type_ + '%m' + type_ + '%d'
            #df['yyyy-mm-dd'] = pd.to_datetime(df['yyyy/mm/dd'], format=format_)
            #df['weekday'] = df['yyyy-mm-dd'].dt.strftime('%a')
            #df = df.drop(['yyyy-mm-dd'], axis=1)
            df['weekday'] = df['timestamp'].dt.strftime('%a')
            return df

        df_ = df.copy()
        type_ = _check_timestamp(str(df_['timestamp'][0]))
        #df_temp = df_['timestamp'].str.split(' ', expand=True)
        #df_temp.columns = ['yyyy/mm/dd', 'HH:MM']
        #type_ = _check_timestamp(df_temp['yyyy/mm/dd'].tolist()[0])
        df_temp = _add_weekday(df_, type_)
        df_['yyyy/mm/dd'] = df_['timestamp'].dt.strftime('%Y' + type_ + '%m' + type_ + '%d')
        df_temp2 = df_temp['yyyy/mm/dd'].str.split(type_, expand=True)
        df_temp2.columns = ['year', 'month', 'day']
        df_temp = df_temp.drop(['yyyy/mm/dd'], axis=1)
        df_ = pd.concat([df_temp2, df_temp['weekday']], axis=1)
        return df_
    
    def _encode_label(df, clm):
        def _encode_label_unit(df, clm):
            le = LabelEncoder()
            le = le.fit(df[clm])
            df[clm] = le.transform(df[clm])
            return df

        if len(clm) > 1:
            for i in clm:
                df = _encode_label_unit(df, i)
        else:
            df = _encode_label_unit(df, clm[0])
        return df

    def _encode_onehot(df, clm):
        df = pd.get_dummies(df, prefix=clm, prefix_sep='-')
        return df
    
    def _get_clm(encode_list, df, flag_list, clm_time=[]):
        encode_list = list(map(lambda x: x+1, encode_list))
        encode_list = df.iloc[:, encode_list].columns.tolist()
        if flag_list == True:
            if len(encode_list) == 0:
                clm = clm_time
            else:
                clm = encode_list + clm_time
        else:
            clm = encode_list
        return clm
    

    if flag_list[0] == True:
        df_time = _add_timestamp_variable(df)
        #clm_time = df_time.columns.to_list()
        clm_time = ['weekday']
        df = pd.concat([df, df_time], axis=1)
    else:
        clm_time = []

    if flag_list[1] == True:
        if (flag_list[0] == False) and (len(encode_label_list) == 0):
            print('skip label-encoding')
        else:
            clm = _get_clm(encode_label_list, df, flag_list[0], clm_time)
            df = _encode_label(df, clm)

    if flag_list[2] == True:
        if (flag_list[0] == False) and (len(encode_onehot_list) == 0):
            print('skip onehot-encoding')
        else:
            clm = _get_clm(encode_onehot_list, df, flag_list[0], clm_time)
            df = _encode_onehot(df, clm)
    return df


def get_subs(clm_type):
    if clm_type == 'kind':
        subs = {'だいこん': 'Radish', 
                'かぶ': 'Turnip',
                'にんじん': 'Carrot',
                'ごぼう': 'Burdock', 
                'れんこん': 'Lotus_Root', 
                'キャベツ': 'Cabbage', 
                'レタス': 'Lettuce', 
                'はくさい': 'Chinese_Cabbage', 
                'こまつな': 'Komatsuna',
                'ほうれんそう': 'Spinach', 
                'ねぎ': 'Green_Onion', 
                'しゅんぎく': 'Crown_Daisy', 
                'ブロッコリー': 'Broccoli', 
                'きゅうり':'Cucumber', 
                'かぼちゃ':'Squash', 
                'なす':'Eggplant', 
                'トマト':'Tomato', 
                'ピーマン':'Green_Pepper',
                'じゃがいも':'Potato', 
                'さつまいも':'Sweet_Potato', 
                'さといも':'Taro', 
                'たまねぎ':'Onion', 
                'なましいたけ':'Shiitake', 
                'セルリー':'Celery', 
                'さやえんどう':'Field_Peas', 
                'なのはな':'Rape_Blossom',
                'たけのこ':'Bamboo_Shoot', 
                'ふき': 'Fuki', 
                'うど': 'Udo', 
                'そらまめ': 'Broad_Bean', 
                'アスパラガス': 'Asparagus', 
                'ピース': 'Peas', 
                'とうもろこし': 'Corn', 
                'いんげん': 'Kidney_Bean', 
                'えだまめ': 'Edamame',
                'うめ': 'Ume', 
                'まつたけ': 'Pine_Mushroom', 
                'オクラ': 'Okra', 
                'レイシにがうり': 'Bitter_Melon', 
                'みずな': 'Mizuna', 
                'ミニトマト':'Mini_Tomato', 
                'にら': 'Leek', 
                'えのきだけ': 'Enoki_Mushroom', 
                'しめじ': 'Shimeji_Mushroom'}
    return subs

def jpn_trans_eng(jpn_ls, clm_type):
    eng_ls = jpn_ls.copy()
    for (jpn, eng) in get_subs(clm_type).items():
        eng_ls = [jpn_item.replace(jpn, eng) if jpn_item.startswith(jpn) else jpn_item for jpn_item in eng_ls]
    return eng_ls

def df_trans(df, dir_base, filename):
    df['kind'] = df.index.tolist()
    df['kind'] = jpn_trans_eng(df['kind'], 'kind')

    df = df.reset_index(drop=True)
    df['timestamp'] = pd.to_datetime(df['date'], format="%Y%m%d")
    df.to_csv(dir_base + '\\input\\add\\file\\' + filename + '.csv')
    return df

def df_each_save(df, dir_base, filename):
    for c1, sdf in df.groupby('kind'):
        print(c1)
        sdf.to_csv(dir_base + '\\input\\add\\file\\' + filename + '_' + c1 + '.csv')
        if filename == 'train':
            figure_label = ['timestamp', 'mode_price', 0, sdf['mode_price'].max()]
            fig_name = dir_base + '\\input\\add\\fig\\' + filename + '_mode_price_' + c1 + '.png'
            figure_save_class().trend(figure_label, sdf['timestamp'], sdf['mode_price'], fig_name)

            sdf['month'] = sdf['month'].astype(int)
            figure_label = ['month', 'mode_price', 1, 12, 0, sdf['mode_price'].max()]
            fig_name = dir_base + '\\input\\add\\fig\\' + filename + '_scatter_month_mode_price_' + c1 + '.png'
            figure_save_class().scatter(figure_label, sdf['month'], sdf['mode_price'], fig_name)


direct_flag = True
dir_base = get_path(direct_flag)

df_train = pd.read_csv(dir_base + '\\input\\ori\\train_ori.csv', index_col=0)
df_test = pd.read_csv(dir_base + '\\input\\ori\\test_ori.csv', index_col=0)
df_weather = pd.read_csv(dir_base + '\\input\\ori\\weather_ori.csv', index_col=0)

df_train = df_trans(df_train, dir_base, 'train')
df_train = preprocessing(df_train, [1,1,0], [], [])
print(df_train)
df_each_save(df_train, dir_base, 'train')

df_test = df_trans(df_test, dir_base, 'test')
df_test = preprocessing(df_test, [1,1,0], [], [])
print(df_test)
df_each_save(df_test, dir_base, 'test')

print('finish')
