# -*- coding: utf-8 -*-
import time
import os
from os import path
import numpy as np
import pandas as pd
from sklearn.metrics import r2_score
from sklearn.preprocessing import MinMaxScaler
from sklearn.datasets import fetch_california_housing

from pkg.Model import Model, HyperSearch
from pkg.figure_save import figure_save_class

def make_dir(DIR):
    if not os.path.exists(DIR):
        # ディレクトリが存在しない場合、ディレクトリを作成する
        os.makedirs(DIR)

def load_data():
    # data generation
    california_housing_data = fetch_california_housing()
    # 目的変数
    X = pd.DataFrame(california_housing_data.data, columns=california_housing_data.feature_names)
    # 説明変数
    y = pd.DataFrame(california_housing_data.target, columns=['HousingPrices'])
    # データを結合
    df = pd.concat([y, X], axis=1)
    return df


def X_y_split(data):  
    # data should be pd.DataFrame()
    docY = data.iloc[:, 0]
    docX = data.iloc[:, 1:]
    return docX, docY


def train_test_split(df, test_rate):  
    # This just splits data to training and testing parts
    train_rate = 1 - test_rate
    ntrn = int(len(df) * train_rate)
    train, test = df.iloc[0:ntrn], df.iloc[ntrn:]
    return train, test

def get_RMSE_MAPE(df_est, df_pre):
    a = np.zeros((2, 4))
    df_MAPE_RMSE = pd.DataFrame(a, index=["est", "pre"], columns=["MAPE", "RMSE", "RMSE rate","R-squared"])

    # evaluation
    for i, df_ in enumerate([df_est, df_pre]):
        if i == 0:
            name = "est"
            name_ = "estimate"
        else:
            name = "pre"
            name_ = "predict"
        df_.loc[:,"abs_error"] = df_.loc[:,"actual"] - df_.loc[:,name_]
        df_.loc[:,"abs_error"] = df_.loc[:,"abs_error"].abs()
        if 0 in df_.loc[:,"actual"]: 
            df_.loc[:,"rel_error"] = df_.loc[:,"abs_error"] / (df_.loc[:,"actual"].max() - df_.loc[:,"actual"].min())
        else:
            df_.loc[:,"rel_error"] = (df_.loc[:,"abs_error"] / df_.loc[:,"actual"]).abs()

        df_MAPE_RMSE.at[name,"MAPE"] = df_.loc[:, "rel_error"].mean()
        df_MAPE_RMSE.at[name,"RMSE"] =  (df_.loc[:, "abs_error"]**2).mean()**(0.5)
        df_MAPE_RMSE.at[name,"RMSE rate"] =  (df_MAPE_RMSE.at[name,"RMSE"])/df_.loc[:,"actual"].mean()
        df_MAPE_RMSE.at[name,"R-squared"] = r2_score(df_.loc[:, 'actual'].values, df_.loc[:, name_].values)

    print (df_MAPE_RMSE)
    return df_est, df_pre, df_MAPE_RMSE

def main():
    # 'MLR', 'LinearTree', 'RF', 'LightGBM'
    modeling_mode = 'LightGBM'
    hyper_flag = False
    # 'grid search', 'optuna'
    search_mode = 'grid search'

    df = load_data()

    if modeling_mode == 'RF':
        # [NumTree=100, MaxDepth='None', MinSamplesSplit=2]
        init_params = {'n_estimators': 100, 
                       'max_depth': None, 
                       'min_samples_split': 2,
                       }
    elif modeling_mode == 'LinearTree':
        # [MaxBins=25, MaxDepth=5, MinSamplesSplit=6]
        init_params = {'max_bins': 25, 
                       'max_depth': 4, 
                       'min_samples_split': 6,
                       }
    elif modeling_mode == 'LightGBM':
        # [n_estimators=100, MaxDepth=-1, MinChildSamples=20]
        init_params = {'n_estimators': 100, 
                       'max_depth': -1, 
                       'min_child_samples': 20,
                       }
    else:
        init_params = []


    ## This just splits data to training and testing parts
    test_rate = 0.2
    train, test = train_test_split(df, test_rate)
    print(train.shape)
    print(test.shape)
 
    # dataset generation
    X_train, y_train = X_y_split(train)
    X_test, y_test = X_y_split(test)
    print("X_train: ", X_train.shape)
    print("y_train: ", y_train.shape)
    print("X_test: ", X_test.shape)
    print("y_test: ", y_test.shape)

    time_start = time.perf_counter()
    # training
    if hyper_flag:
        hypertuner = HyperSearch(modeling_mode, init_params, search_mode)
        hypertuner.hyper_search(X_train, y_train)
        best_params = hypertuner.best_params
    else:
        best_params = init_params
    print(best_params)
    model = Model(modeling_mode, best_params, False)
    model.fit(X_train, y_train)
    time_end = time.perf_counter()
    training_time = time_end - time_start
    print("training time = {:.2f} sec".format(training_time))

    # estimate / predict
    estimated = model.predict(X_train)
    df_est = model.make_df(estimated, y_train, 'estimate')
    time_start = time.perf_counter()
    predicted = model.predict(X_test)
    time_end = time.perf_counter()
    df_pre = model.make_df(predicted, y_test, 'predict')
    df_est, df_pre, df_MAPE_RMSE = get_RMSE_MAPE(df_est, df_pre)
    prediction_time = time_end - time_start
    print("prediction time = {:.2f} sec".format(prediction_time))


    # get path
    work_path = path.dirname( path.abspath(__file__) )
    os.chdir(work_path)
    dir_base = work_path + '\\output\\'
    make_dir(dir_base)
    fig_base = work_path + '\\output\\fig\\'
    file_base = work_path + '\\output\\file\\'
    make_dir(fig_base)
    make_dir(file_base)

    # result save
    df_time = pd.DataFrame(np.array([training_time, prediction_time]), index=['train', 'predict'])
    df_hyperparam = pd.DataFrame(best_params, index=['train', 'predict'])
    df_time.to_csv(file_base + "calculation_time_" + modeling_mode + ".csv")
    df_est.to_csv(file_base + "estimate_" + modeling_mode + ".csv")
    df_pre.to_csv(file_base + "predict_" + modeling_mode + ".csv")
    df_MAPE_RMSE.to_csv(file_base + "result_" + modeling_mode + ".csv")
    print ("file saving finished.")


    # figure save
    figure_label = ["sample", "y", "actual", "predict"]
    fig_file_name = fig_base + 'predict_' + modeling_mode + '.png'
    figure_save_class().trend1(figure_label, df_pre.loc[:,"actual"].values, df_pre.loc[:,"predict"].values, fig_file_name)

    figure_label = ["sample", "y", "actual", "predict"]
    fig_file_name = fig_base + 'estimate_' + modeling_mode + '.png'
    figure_save_class().trend1(figure_label, df_est.loc[:,"actual"].values, df_est.loc[:,"estimate"].values, fig_file_name)

    figure_label = ["y_actual", "y_estimate", [0, 100], [0, 20]]
    fig_file_name = fig_base + 'estimate_scatter_' + modeling_mode + '.png'
    figure_save_class().scatter(figure_label, df_est.loc[:,"actual"].values, df_est.loc[:,"estimate"].values, fig_file_name)

    figure_label = ["y_actual", "y_predict", [0, 100], [0, 20]]
    fig_file_name = fig_base + 'predict_scatter_' + modeling_mode + '.png'
    figure_save_class().scatter(figure_label, df_pre.loc[:,"actual"].values, df_pre.loc[:,"predict"].values, fig_file_name)

    for i in range(X_train.shape[1]):
        figure_label = ["x_" + str(i), "y", "actual", "estimate", [0, 100], [0, 20]]
        fig_file_name = fig_base + 'estimate_' + str(i) + '_scatter_' + modeling_mode + '.png'
        figure_save_class().scatter2(figure_label, X_train.iloc[:,i].values, df_est.loc[:,"actual"].values, df_est.loc[:,"estimate"].values, fig_file_name)

    for i in range(X_test.shape[1]):
        figure_label = ["x_" + str(i), "y", "actual", "predict", [0, 100], [0, 20]]
        fig_file_name = fig_base + 'predict_' + str(i) + '_scatter_' + modeling_mode + '.png'
        figure_save_class().scatter2(figure_label, X_test.iloc[:,i].values, df_pre.loc[:,"actual"].values, df_pre.loc[:,"predict"].values, fig_file_name)

    print ("figure saving finished.")


    
if __name__ == "__main__":
    main()
