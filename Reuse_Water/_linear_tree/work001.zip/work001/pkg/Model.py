#coding: utf-8 
import warnings
import numpy as np
import pandas as pd

from sklearn.ensemble import RandomForestRegressor
from sklearn.cross_decomposition import PLSRegression
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import KFold
from lineartree import LinearTreeRegressor
import lightgbm as lgb
import optuna
import optuna.integration.lightgbm as lgb_o

#ErrMsg
GeneralErrMsg1 = 'Modeling-mode does not work.'
RFErrMsg1 = 'RF Error: NumTree should be integer number and larger than 1.'
RFErrMsg2 = 'RF Error: MaxDepth should be None or integer number and larger than 1.'
RFErrMsg3 = 'RF Error: MinSamplesSplit should be integer number and larger than 2.'

class HyperSearch:
    def __init__(self, modeling_mode, init_params, search_mode):
        self.modeling_mode = modeling_mode
        self.init_params = init_params
        self.search_mode = search_mode

    def hyper_search(self, X_tra, y_tra):
        if self.modeling_mode == 'RF':
            param_grid = {
                     'n_estimators': [10, 50, 100],
                     'max_depth': range(3,7),
                     'min_samples_split': range(2,3),
                     }
        elif self.modeling_mode == 'LightGBM':
            trainval = lgb.Dataset(X_tra, y_tra)
            param_grid = {
                        'estimators': [10, 50, 100],
                        'max_depth': range(2, 6), 
                        'reg_alpha': [0.0001, 0.003, 0.1],
                        'reg_lambda': [0.0001, 0.1],
                        'num_leaves': [2, 3, 4, 6],
                        'min_child_samples': [0, 2, 5, 10]
                        }
            params = {
                     'objective': 'regression',
                     'metric': 'rmse',
                     'random_seed': 0,
                     'verbosity': optuna.logging.set_verbosity(-1)
                     }
        model = Model(self.modeling_mode, self.init_params, True)

        if self.search_mode == 'optuna':
            warnings.resetwarnings()
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                tuner = lgb_o.LightGBMTunerCV(params, trainval, show_progress_bar=False, callbacks=[lgb.early_stopping(100)], folds=KFold(n_splits=3))
                tuner.run()
            self.best_params = tuner.best_params
        elif self.search_mode == 'grid search':
            search_model = GridSearchCV(model.model, param_grid=param_grid, cv=5)
            tuner = search_model.fit(X_tra, y_tra)
            self.best_params = tuner.best_params_
        else:
            self.best_params = {}

class Model:
    def __init__(self, modeling_mode, hyperparams, hyper_flag, sub_type='MLR'):
        self.modeling_mode = modeling_mode
        self.hyperparams = hyperparams
        if modeling_mode == 'RF':
            if hyper_flag:
                self.model = RandomForestRegressor()
            else:
                self.model = RandomForestRegressor(**hyperparams, random_state=2525)
        elif modeling_mode == 'LightGBM':
            if hyper_flag:
                self.model = lgb.LGBMRegressor()
            else:
                self.model = lgb.LGBMRegressor(**hyperparams)
        elif modeling_mode == 'MLR':
            self.model = LinearRegression()
        elif modeling_mode == 'LinearTree':
            sub_type = 'MLR'
            if sub_type == 'MLR':
                self.model = LinearTreeRegressor(base_estimator=LinearRegression(), **hyperparams)
        else:
            self.model = 0
            print(GeneralErrMsg1)

    def fit(self, X_tra, y_tra):
        if self.modeling_mode == 'RF':
            if self.hyperparams['n_estimators'] < 1:
                print(RFErrMsg1)
            if self.hyperparams['max_depth'] != None and self.hyperparams['max_depth'] < 1:
                print(RFErrMsg2)
            if self.hyperparams['min_samples_split'] < 2:
                print(RFErrMsg3)
        self.model.fit(X_tra, y_tra)
        (self.y_max, self.y_min) = (y_tra.max(), y_tra.min())

    def predict(self, X_val):
        if self.modeling_mode == 'LightGBM':
            pre = self.model.predict(X_val, num_iteration=self.model.best_iteration_)
        else:
            pre = self.model.predict(X_val)
        # modification function
        pre = np.clip(pre, self.y_min, self.y_max)
        return pre

    def make_df(self, calc, df_, name):
        df_calc = pd.DataFrame(calc, index=df_.index, columns=[name])
        df_ = pd.concat([df_calc, df_], axis=1)
        df_.columns = [name, "actual"]
        print(df_)
        return df_
