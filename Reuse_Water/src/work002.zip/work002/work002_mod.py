# -*- coding: utf-8 -*-
"""
Created on Wed Oct 28 16:11:28 2020

@author: abranch
"""

import pandas as pd
import os
import glob
import numpy as np
from matplotlib import pyplot as plt
import matplotlib.dates as mdates
import datetime as dt

Absolute_Zero = 273.15
At_Normal_Temperature = 25

def import_df1(work_path, extension):
    os.chdir(work_path)
    all_filenames = [i for i in glob.glob('*.{}'.format(extension))]
    df = pd.concat([pd.read_csv(f, parse_dates=True, index_col='t_stamp') for f in all_filenames ])
    return df

def import_df2(work_path):
    file_name = work_path + '\\RO Permeate Pressures.csv'
    df = pd.read_csv(file_name, parse_dates=True, index_col='t_stamp')
    return df

def preprocess_df(df):
    new_df = df.copy()
    new_df = new_df.replace(0, np.nan).drop_duplicates().groupby('t_stamp').mean()
    new_df.reset_index()
    return new_df



def id_to_name_df(df):
    tag_dict = {'FIT_41074': 'Flow_perm_S1',
                'FIT_41274': 'Flow_perm_S2',
                'FIT_41374': 'Flow_perm_S3',
                'FIT_41974': 'Flow_conc_S3',
                'PT_41095': 'P_feed_S1',
                'PT_41245': 'P_feed_S2',
                'PT_41345': 'P_conc_S2',
                'PT_41347': 'P_feed_S3',
                'PT_41945': 'P_conc_S3',
                'S1PP': 'P_perm_S1',
                'S2PP': 'P_perm_S2',
                'S3PP': 'P_perm_S3',
                'AIT_40006': 'EC_feed_S1',
                'AIT_41092': 'EC_perm_S1',
                'AIT_41292': 'EC_perm_S2',
                'TIT_40005': 'T_F'}
    # Volume Flow Rate (Flux): Q [gpm] (m^3/s)
    # FIT_41074: Permeate Flow Stage1: Q_perm1
    # FIT_41274: Permeate Flow Stage2: Q_perm2
    # FIT_41374: Permeate Flow Stage3: Q_perm3
    # FIT_41974: Concetrate Flow Stage3: Q_conc3
    # Pressure: P [psi] (N/m^2)
    # PT_41095: Feed Pressure Stage1: P_feed1
    # PT_41245: Feed Pressure Stage2: P_feed2
    # PT_41345: Concetrate Pressure Stage2: P_conc2
    # PT_41347: Feed Pressure Stage3: P_feed3
    # PT_41945: Concetrate Pressure Stage3: P_conc3
    # S1PP: Permeate Pressure Stage1: P_perm1
    # S2PP: Permeate Pressure Stage2: P_perm2
    # S3PP: Permeate Pressure Stage3: P_perm3
    # Conducticity (EC) : C [muS/cm] (S/m)
    # AIT_40006: Feed EC Stage1: EC_feed1
    # AIT_41092: Permeate EC Stage1: EC_perm1
    # AIT_41292: Permeate EC Stage2: EC_perm2
    # TIT_40005: Feed Temperature Stage 1
    clm_list = df.columns.tolist()
    for id, name in tag_dict.items():
        clm_list = [name if clm == id else clm for clm in clm_list]
    df.columns = clm_list
    return df


def calc(df):
    def F_to_C_temp(F):
        return (F - 32)*5/9

    def C_to_K_temp(C):
        return C + Absolute_Zero

    def compensate_temp(temp_C, coef, type_K):
        # only deg C
        if type_K == 1:
            temp_K = C_to_K_temp(temp_C)
            # exp(1/T)
            temp_comp = np.exp(coef/temp_K)
        else:
            # exp(T-25)
            temp_comp = np.exp(coef*(temp_C-At_Normal_Temperature))
        return temp_comp


    dfc = df.copy()

    # filtering for system operation
    # Q_perm3 > 2 and Q_perm2 > 6
    dfc = dfc[(dfc['Flow_perm_S3'] > 2.0) & (dfc['Flow_perm_S2'] > 6.0)]

    # degF to degC
    dfc['T'] = dfc['T_F'].map(F_to_C_temp)

    # temperature higher than normal
    dfc['Temp_High'] = False
    dfc['Temp_High'].loc[dfc['T'] > At_Normal_Temperature] = True

    TA1 = 0.0107
    TA2 = 0.0072
    TB1 = 0.0331
    TB2 = 0.0289
    TC = 1965
    ECOS = 0.006


    # TCF: temperature correction factor
    dfc['T_TCF'] = dfc['T'].map(compensate_temp,args=(TA1,0))
    dfc['SP_TCF'] = dfc['T'].map(compensate_temp,args=(TB1,0))
    dfc['T_TCF'].loc[dfc['Temp_High'] == True] = dfc['T'].map(compensate_temp,args=(TA2,0))
    dfc['SP_TCF'].loc[dfc['Temp_High'] == True]= dfc['T'].map(compensate_temp,args=(TB2,0))

    # Flow_TCF = T_TCF * exp(1965/NormTemp)/exp(1965/T))
    dfc['Flow_TCF'] = (compensate_temp(At_Normal_Temperature,TC,1)/dfc['T'].map(compensate_temp,args=(TC,1)))*dfc['T_TCF']

    # Feed Flow Stage1: Q_in1
    # Feed Flow Stage2: Q_in2
    # Feed Flow Stage3: Q_in3
    dfc['Flow_feed_S1'] = dfc['Flow_perm_S1'] + dfc['Flow_perm_S2'] + dfc['Flow_perm_S3'] + dfc['Flow_conc_S3']
    dfc['Flow_feed_S2'] = dfc['Flow_feed_S1'] - dfc['Flow_perm_S1']
    dfc['Flow_feed_S3'] = dfc['Flow_feed_S2'] - dfc['Flow_perm_S2']

    # Module Differential Pressure [psi] (N/m^2)
    dfc['DP_S1'] = dfc['P_feed_S1']-dfc['P_feed_S2']
    dfc['DP_S2'] = dfc['P_feed_S2']-dfc['P_conc_S2']
    dfc['DP_S3'] = dfc['P_feed_S3']-dfc['P_conc_S3']

    # mode: number of operating stages
    dfc['Mode'] = 3
    # Q_perm1 < 1 => 2 stages
    dfc['Mode'].loc[dfc['Flow_perm_S1'] < 1.0] = 2

    stage_list = ['S1', 'S2', 'S3']
    for i, stage in enumerate(stage_list):
        # Membrane Areas
        if stage == 'S1':
            coef_area = 4
        elif stage == 'S2':
            coef_area = 2
        elif stage == 'S3':
            coef_area = 1

        dfc['Area_' + stage] = 6*coef_area*87
        if stage == 'S2' or stage == 'S3':
            dfc['Area_' + stage].loc[dfc['Mode'] == 2] = 7*coef_area*87

        # Flow Velocity (Flux Density): V_perm (m/s)
        # V_perm = Q_perm / Area
        dfc['V_perm_' + stage] = dfc['Flow_perm_' + stage]*60*24/dfc['Area_' + stage]
        if stage == 'S1':
            dfc['V_perm_' + stage].loc[dfc['Mode'] == 2] = np.NaN

        # Flow Recovery Rate [%]
        # Rec = Q_perm / Q_feed
        dfc['Rec_' + stage] = dfc['Flow_perm_' + stage]/dfc['Flow_feed_' + stage]
        if stage == 'S1':
            dfc['Rec_' + stage].loc[dfc['Mode'] == 2] = np.NaN

        # Mass Flow Rate: m [g/m^3]
        # EC[S/m] => [mol/m^3] => C[g/m^3] = [g/mol] * EC[mol/m^3]
        # m = C[g/m^3] * Q[m^3/s] 
        if stage == 'S1' or 'S2':
            dfc['m_feed_' + stage] = dfc['EC_feed_' + stage]*dfc['Flow_feed_' + stage]
            dfc['m_perm_' + stage] = dfc['EC_perm_' + stage]*dfc['Flow_perm_' + stage]
        else:
            dfc['m_feed_' + stage] = dfc['m_feed_' + stage_list[i-1]] - dfc['m_perm_' + stage_list[i-1]]
        
        # Feed Conductivity: EC_feed (S/m)
        # EC_feed = m_feed/Q_feed
        if stage == 'S2' or 'S3':
            dfc['EC_feed_' + stage] = dfc['m_feed_' + stage]/dfc['Flow_feed_' + stage]
        if stage == 'S2':
            dfc['EC_feed_' + stage].loc[dfc['Mode'] == 2] = dfc['EC_feed_' + stage_list[i-1]]

        # Osmotic Pressure [psi]
        dfc['OsP_' + stage] = ECOS*dfc['EC_feed_' + stage]*np.log(1/(1-dfc['Rec_' + stage]))/dfc['Rec_' + stage]
        if stage == 'S1':
            dfc['OsP_' + stage].loc[dfc['Mode'] == 2] = np.NaN

        # NDP [psi]
        dfc['NDP_' + stage] = dfc['P_feed_' + stage]-dfc['OsP_' + stage]-dfc['DP_' + stage]/2-dfc['P_perm_' + stage]
        if stage == 'S1':
            dfc['NDP_' + stage].loc[dfc['Mode'] == 2] = np.NaN

        # Specific Flux
        # Flux_specific = V_perm/(F_TCF*DP)
        dfc['Flux_Spec_' + stage] = dfc['V_perm_' + stage]/(dfc['Flow_TCF']*dfc['NDP_' + stage])
        if stage == 'S1':
            dfc['Flux_Spec_' + stage].loc[dfc['Mode'] == 2] = np.NaN

    dfc['Flow'] = dfc['Flow_feed_S1']
    dfc['Reject'] = dfc['Flow_conc_S3']
    dfc['opmin'] = 1
    return dfc


def main():
    dir_base = 'C:\\Users\\abranch\\OneDrive - Carollo Engineers\\Desktop\\LVMWD data\\RO'
    #dir_base = path.dirname( path.abspath(__file__) )

    #Import all spreadsheets in folder
    work_path = dir_base + '\\CSV\\'
    extension = 'csv'
    df1 = import_df1(work_path, extension)
    df1 = preprocess_df(df1)
    work_path = dir_base + '\\Permeate Pressures'
    df2 = import_df2(work_path)

    #Make a new frame for data each minute
    df_min1 = df1.resample('min').mean()
    df_min2 = df2.resample('min').mean().fillna(method='ffill')
    df_min = df_min1.join(df_min2, how='outer')

    #set date range
    #Update these to get file labels
    L = 'July 2020'
    R = 'End June 2022'
    left = dt.date(2020, 7, 1)
    right = dt.date(2022, 7, 1)

    dfc = id_to_name_df(df_min)
    dfc = calc(dfc)

    ROpro = dfc[['Flow','Reject','opmin']]
    ROprod = ROpro.resample("d").sum()
    ROprod = ROprod[left:right]
    ROprod.to_csv(dir_base + '\\RO Production "f"{L}_to_{R}.csv')

    dfc_op_15 = dfc.resample('15min').mean()
    dfc_op_15 = dfc_op_15[left:right]
    dfc_op_15.to_csv(dir_base + '\\RO 15 min Av "f"{L}_to_{R}.csv')

    dfc_op_Daily = dfc.resample('d').mean()
    dfc_op_Daily = dfc_op_Daily[left:right]
    dfc_op_Daily.to_csv(dir_base + '\\RO Data K Daily Av "f"{L}_to_{R}.csv')

    ROkN = dfc_op_Daily[['TIT_40005','AIT_40006','AIT_41892','AIT_41092','AIT_41292 ','FIT_41074 ','FIT_41274 ','PT_41095 ','PT_41245 ','S1PP','PT_41345 ','S2PP','AIT_41392 ','FIT_41374 ','PT_41347 ','PT_41945 ','S3PP','FIT_41974 ','Flux_Spec_S1','Flux_Spec_S2','Flux_Spec_S3']].copy()
    ROkN.to_csv(dir_base + '\\RO Data Normalized Daily Av "f"{L}_to_{R}.csv')


if __name__ == "__main__":
    main()
