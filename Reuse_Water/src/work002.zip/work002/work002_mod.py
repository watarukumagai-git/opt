# -*- coding: utf-8 -*-
"""
Created on Wed Oct 28 16:11:28 2020

@author: abranch
"""

import pandas as pd
import os
import glob
import numpy as np
from matplotlib import pyplot as plt
import matplotlib.dates as mdates
import datetime as dt

Absolute_Zero = 273.15
At_Normal_Temperature = 25

def import_df1(work_path, extension):
    os.chdir(work_path)
    all_filenames = [i for i in glob.glob('*.{}'.format(extension))]
    df = pd.concat([pd.read_csv(f, parse_dates=True, index_col='t_stamp') for f in all_filenames ])
    return df

def import_df2(work_path):
    file_name = work_path + '\\RO Permeate Pressures.csv'
    df = pd.read_csv(file_name, parse_dates=True, index_col='t_stamp')
    return df

def preprocess_df(df):
    # clean
    df = df.replace(0, np.nan)
    df = df.drop_duplicates() 
    df = df.groupby("t_stamp").mean()
    df.reset_index()
    #Make a new frame for data each minute
    new_df =  df.resample("min").mean()
    return new_df


def compensate_temp(temp, coef, type_K):
    # only deg C
    if type_K == 1:
        temp_comp = np.exp(coef/(temp+Absolute_Zero))
    else:
        temp_comp = np.exp(coef*(temp-At_Normal_Temperature))
    return temp_comp


def calc(dfc):
    TA1 = 0.0107
    TA2 = 0.0072
    TB1 = 0.0331
    TB2 = 0.0289
    ECOS = 0.006

    dfc['TempH'] = False
    dfc['TempH'].loc[dfc['T'] > 25] = True

    # TCF: temperature correction factor
    dfc['TorayF'] = dfc['T'].map(compensate_temp,args=(TA1,0))
    dfc['TCFSP'] = dfc['T'].map(compensate_temp,args=(TB1,0))
    dfc['TorayF'].loc[dfc['T'] > 25] = dfc['T'].map(compensate_temp,args=(TA2,0))
    dfc['TCFSP'].loc[dfc['T'] > 25]= dfc['T'].map(compensate_temp,args=(TB2,0))
    # np.exp(1965/NormTemp) / np.exp(1965/T)) * T
    TC = 1965
    dfc['TCFFlow'] = (compensate_temp(At_Normal_Temperature,TC,1)/dfc['T'].map(compensate_temp,args=(TC,1)))*dfc['TorayF']


    #membrane areas
    dfc['Mode'] = "3 stage"
    dfc['S1MA'] = 6*4*87
    dfc['S2MA'] = 6*2*87
    dfc['S3MA'] = 6*1*87

    #S1 recovery calculation
    dfc['YS1'] = dfc['FIT_41074']/(dfc['FIT_41074'] + dfc['FIT_41274']+dfc['FIT_41374']+dfc['FIT_41974'])

    #feed conductivities
    dfc['S2FEC'] = (dfc['AIT_40006']*(dfc['FIT_41074'] + dfc['FIT_41274'] + dfc['FIT_41374'] + dfc['FIT_41974']) - (dfc['FIT_41074']*dfc['AIT_41092']))/(dfc['FIT_41274'] + dfc['FIT_41374'] + dfc['FIT_41974'])

    # osmotic pressure 
    dfc['S1OsP'] = ECOS*dfc['AIT_40006']*(np.log(1/(1-dfc['YS1'])))/dfc['YS1']
    dfc['S1NDP'] = dfc['PT_41095/Val']-dfc['S1OsP']-((dfc['PT_41095/Val']-dfc['PT_41245/Val'])/2)-dfc['S1PP']
    dfc['S1J'] = dfc['LasVirgenes/UF/FIT_41074/Val']*60*24/dfc['S1MA']
    dfc['S1K'] = dfc['S1J']/dfc['TCFFlow']/dfc['S1NDP']

    dfc['Mode'].loc[dfc['LasVirgenes/UF/FIT_41074/Val'] < 1.0] = "2 stage"
    dfc['S2MA'].loc[dfc['LasVirgenes/UF/FIT_41074/Val'] < 1.0] = 7*2*87
    dfc['S3MA'].loc[dfc['LasVirgenes/UF/FIT_41074/Val'] < 1.0] = 7*1*87
    dfc['YS1'].loc[dfc['LasVirgenes/UF/FIT_41074/Val'] < 1.0] = np.NaN
    dfc['S2FEC'].loc[dfc['LasVirgenes/UF/FIT_41074/Val'] < 1.0] = dfc['LasVirgenes/UF/AIT_40006/Val']
    dfc['S1OsP'].loc[dfc['LasVirgenes/UF/FIT_41074/Val'] < 1.0] = np.NaN
    dfc['S1NDP'].loc[dfc['LasVirgenes/UF/FIT_41074/Val'] < 1.0] = np.NaN
    dfc['S1J'].loc[dfc['LasVirgenes/UF/FIT_41074/Val'] < 1.0] = np.NaN
    dfc['S1K'].loc[dfc['LasVirgenes/UF/FIT_41074/Val'] < 1.0] = np.NaN

    #flux (J) calculation
    dfc['S2J'] = dfc['LasVirgenes/UF/FIT_41274/Val']*60*24/dfc['S2MA']    
    dfc['S3J'] = dfc['LasVirgenes/UF/FIT_41374/Val']*60*24/dfc['S3MA']

    #S2 and S3 recovery calculation
    dfc['YS2'] = dfc['LasVirgenes/UF/FIT_41274/Val']/(dfc['LasVirgenes/UF/FIT_41274/Val']+dfc['LasVirgenes/UF/FIT_41374/Val']+dfc['LasVirgenes/UF/FIT_41974/Val'])
    dfc['YS3'] = dfc['LasVirgenes/UF/FIT_41374/Val']/(dfc['LasVirgenes/UF/FIT_41374/Val']+dfc['LasVirgenes/UF/FIT_41974/Val'])

    #S3 Feed conductivity
    dfc['S3FEC'] = (dfc['S2FEC']*(dfc['LasVirgenes/UF/FIT_41274/Val'] + dfc['LasVirgenes/UF/FIT_41374/Val'] + dfc['LasVirgenes/UF/FIT_41974/Val']) - (dfc['LasVirgenes/UF/FIT_41274/Val']*dfc['LasVirgenes/UF/AIT_41292/Val']))/(dfc['LasVirgenes/UF/FIT_41374/Val'] + dfc['LasVirgenes/UF/FIT_41974/Val'])

    #S2 and S3 Osmotic Pressure
    dfc['S2OsP'] = ECOS*dfc['S2FEC']*(np.log(1/(1-dfc['YS2'])))/dfc['YS2']
    dfc['S3OsP'] = ECOS*dfc['S3FEC']*(np.log(1/(1-dfc['YS3'])))/dfc['YS3']

    #S2 and S3 NDP
    dfc['S2NDP'] = dfc['LasVirgenes/UF/PT_41245/Val']-dfc['S2OsP']-((dfc['LasVirgenes/UF/PT_41245/Val']-dfc['LasVirgenes/UF/PT_41345/Val'])/2)-dfc['S2PP']
    dfc['S3NDP'] = dfc['LasVirgenes/UF/PT_41347/Val']-dfc['S3OsP']-((dfc['LasVirgenes/UF/PT_41347/Val']-dfc['LasVirgenes/UF/PT_41945/Val'])/2)-dfc['S3PP']

    #Specific Flux
    dfc['S2K'] = dfc['S2J']/dfc['TCFFlow']/dfc['S2NDP']
    dfc['S3K'] = dfc['S3J']/dfc['TCFFlow']/dfc['S3NDP']
    return dfc


def main():
    dir_base = 'C:\\Users\\abranch\\OneDrive - Carollo Engineers\\Desktop\\LVMWD data\\RO'
    #dir_base = path.dirname( path.abspath(__file__) )

    #Import all spreadsheets in folder
    work_path = dir_base + '\\CSV\\'
    extension = 'csv'
    df = import_df1(work_path, extension)
    df_min1 = preprocess_df(df)

    #Permeate Pressures (psi) - compile logsheet data
    work_path = dir_base + '\\Permeate Pressures'
    df2 = import_df2(work_path)
    df_min2 = df2.resample("min").mean().fillna(method='ffill')

    df_min = df_min1.join(df_min2, how="outer")

    #set date range
    #Update these to get file labels
    L = 'July 2020'
    R = 'End June 2022'
    left = dt.date(2020, 7, 1)
    right = dt.date(2022, 7, 1)

    #Temperature correction factors
    # degF to degC
    df_min['T'] = (df_min['LasVirgenes/UF/TIT_40005/Val'] - 32)*5/9

    #filtering for system operation
    dfc = df_min[df_min['LasVirgenes/UF/FIT_41374/Val'] > 2.0]
    dfc = dfc[dfc['LasVirgenes/UF/FIT_41274/Val'] > 6.0]
    dfc = calc(dfc)

    #5 and 15 minute rolling averages    
    #dfc_op_5 = dfc.rolling(5, min_periods=1).mean()
    #dfc_op_15 = dfc.rolling(15, min_periods=1).mean()


    dfc['Flow'] = dfc['LasVirgenes/UF/FIT_41074/Val'] + dfc['LasVirgenes/UF/FIT_41274/Val'] + dfc['LasVirgenes/UF/FIT_41374/Val'] + dfc['LasVirgenes/UF/FIT_41974/Val']
    dfc['Reject'] = dfc['LasVirgenes/UF/FIT_41974/Val']
    dfc['opmin'] = 1
    ROpro = dfc[['Flow','Reject','opmin']]
    ROprod = ROpro.resample("d").sum()
    ROprod = ROprod[left:right]
    ROprod.to_csv(dir_base + '\\RO Production July 2020 to end June 22.csv')


    dfc_op_15 = dfc.resample("15min").mean()
    dfc_op_15 = dfc_op_15[left:right]
    dfc_op_15.to_csv(dir_base + '\\/RO 15 min Av "f"{L}_to_{R}.csv')

    dfc_op_Daily = dfc.resample("d").mean()
    dfc_op_Daily = dfc_op_Daily[left:right]
    dfc_op_Daily.to_csv(dir_base + '\\RO Data K Daily Av "f"{L}_to_{R}.csv')

    ROkN = dfc_op_Daily[['LasVirgenes/UF/TIT_40005/Val','LasVirgenes/UF/AIT_40006/Val','LasVirgenes/UF/AIT_41892/Val','LasVirgenes/UF/AIT_41092/Val','LasVirgenes/UF/AIT_41292/Val','LasVirgenes/UF/FIT_41074/Val','LasVirgenes/UF/FIT_41274/Val','LasVirgenes/UF/PT_41095/Val','LasVirgenes/UF/PT_41245/Val','S1PP','LasVirgenes/UF/PT_41345/Val','S2PP','LasVirgenes/UF/AIT_41392/Val','LasVirgenes/UF/FIT_41374/Val','LasVirgenes/UF/PT_41347/Val','LasVirgenes/UF/PT_41945/Val','S3PP','LasVirgenes/UF/FIT_41974/Val','S1K','S2K','S3K']].copy()
    ROkN.to_csv(dir_base + '\\/RO Data Normalized Daily Av "f"{L}_to_{R}.csv')


if __name__ == "__main__":
    main()
