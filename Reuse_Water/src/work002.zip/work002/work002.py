# -*- coding: utf-8 -*-
"""
Created on Wed Oct 28 16:11:28 2020

@author: abranch
"""

import pandas as pd
import os
import glob
import numpy as np
from matplotlib import pyplot as plt
import matplotlib.dates as mdates
import datetime as dt


#Import all spreadsheets in folder

os.chdir("C:/Users/abranch/OneDrive - Carollo Engineers/Desktop/LVMWD data/RO/CSV/")

extension = 'csv'
all_filenames = [i for i in glob.glob('*.{}'.format(extension))]

df = pd.concat([pd.read_csv(f, parse_dates=True, index_col='t_stamp') for f in all_filenames ])

#Clean inports
df = df.replace(0, np.nan)
df = df.drop_duplicates() 
df = df.groupby("t_stamp").mean()
df.reset_index()

#Make a new frame for data each minute
df_mi =  df.resample("min").mean()

#Permeate Pressures (psi) - compile logsheet data
dp = pd.read_csv("C:/Users/abranch/OneDrive - Carollo Engineers/Desktop/LVMWD data/RO/Permeate Pressures/RO Permeate Pressures.csv", parse_dates=True, index_col='t_stamp')
dp_min = dp.resample("min").mean()
dp_min2 = dp_min.fillna(method='ffill')
df_min = df_mi.join(dp_min2, how="outer")

#Temperature correction factors
df_min['T'] = (df_min['LasVirgenes/UF/TIT_40005/Val'] - 32)*5/9

#set date range
#Update these to get file labels
L = 'July 2020'
R = 'End June 2022'
left = dt.date(2020, 7, 1)
right = dt.date(2022, 7, 1)

#filtering for system operation
dfc = df_min[df_min['LasVirgenes/UF/FIT_41374/Val'] > 2.0]
dfc = dfc[dfc['LasVirgenes/UF/FIT_41274/Val'] > 6.0]

#if(dfc['T'] <= 25.01): 
#    dfc['TempH'] = False
#else:
#    dfc['TempH'] = True

dfc['TempH'] = False
dfc['TempH'].loc[dfc['T'] > 25] = True

#Permeate Pressures (psi) - used average of gauge
#dfc['S1PP'] = 37
#dfc['S2PP'] = 14
#dfc['S3PP'] = 10

TA1 = 0.0107
TA2 = 0.0072
TB1 = 0.0331
TB2 = 0.0289
ECOS = 0.006

dfc['TorayF'] = np.exp(TA1*(dfc['T']-25))
dfc['TCFSP'] = np.exp(TB1*(dfc['T']-25))
dfc['TorayF'].loc[dfc['T'] > 25] = np.exp(TA2*(dfc['T']-25))
dfc['TCFSP'].loc[dfc['T'] > 25] = np.exp(TB2*(dfc['T']-25))   

dfc['TCFFlow'] = np.exp(1965/(298.15))/np.exp(1965/(dfc['T']+273.15))*dfc['TorayF']

#membrane areas, feed conductivities, osmotic pressure and S1 recovery calculation
dfc['S1MA'] = 6*4*87

dfc['Mode'] = "3 stage"
dfc['S2MA'] = 6*2*87
dfc['S3MA'] = 6*1*87
dfc['YS1'] = dfc['LasVirgenes/UF/FIT_41074/Val']/(dfc['LasVirgenes/UF/FIT_41074/Val'] + dfc['LasVirgenes/UF/FIT_41274/Val']+dfc['LasVirgenes/UF/FIT_41374/Val']+dfc['LasVirgenes/UF/FIT_41974/Val'])
dfc['S2FEC'] = (dfc['LasVirgenes/UF/AIT_40006/Val']*(dfc['LasVirgenes/UF/FIT_41074/Val'] + dfc['LasVirgenes/UF/FIT_41274/Val'] + dfc['LasVirgenes/UF/FIT_41374/Val'] + dfc['LasVirgenes/UF/FIT_41974/Val']) - (dfc['LasVirgenes/UF/FIT_41074/Val']*dfc['LasVirgenes/UF/AIT_41092/Val']))/(dfc['LasVirgenes/UF/FIT_41274/Val'] + dfc['LasVirgenes/UF/FIT_41374/Val'] + dfc['LasVirgenes/UF/FIT_41974/Val'])
dfc['S1OsP'] = ECOS*dfc['LasVirgenes/UF/AIT_40006/Val']*(np.log(1/(1-dfc['YS1'])))/dfc['YS1']
dfc['S1NDP'] = dfc['LasVirgenes/UF/PT_41095/Val']-dfc['S1OsP']-((dfc['LasVirgenes/UF/PT_41095/Val']-dfc['LasVirgenes/UF/PT_41245/Val'])/2)-dfc['S1PP']
dfc['S1J'] = dfc['LasVirgenes/UF/FIT_41074/Val']*60*24/dfc['S1MA']
dfc['S1K'] = dfc['S1J']/dfc['TCFFlow']/dfc['S1NDP']

dfc['Mode'].loc[dfc['LasVirgenes/UF/FIT_41074/Val'] < 1.0] = "2 stage"
dfc['S2MA'].loc[dfc['LasVirgenes/UF/FIT_41074/Val'] < 1.0] = 7*2*87
dfc['S3MA'].loc[dfc['LasVirgenes/UF/FIT_41074/Val'] < 1.0] = 7*1*87
dfc['YS1'].loc[dfc['LasVirgenes/UF/FIT_41074/Val'] < 1.0] = np.NaN
dfc['S2FEC'].loc[dfc['LasVirgenes/UF/FIT_41074/Val'] < 1.0] = dfc['LasVirgenes/UF/AIT_40006/Val']
dfc['S1OsP'].loc[dfc['LasVirgenes/UF/FIT_41074/Val'] < 1.0] = np.NaN
dfc['S1NDP'].loc[dfc['LasVirgenes/UF/FIT_41074/Val'] < 1.0] = np.NaN
dfc['S1J'].loc[dfc['LasVirgenes/UF/FIT_41074/Val'] < 1.0] = np.NaN
dfc['S1K'].loc[dfc['LasVirgenes/UF/FIT_41074/Val'] < 1.0] = np.NaN

#flux (J) calculation
dfc['S2J'] = dfc['LasVirgenes/UF/FIT_41274/Val']*60*24/dfc['S2MA']    
dfc['S3J'] = dfc['LasVirgenes/UF/FIT_41374/Val']*60*24/dfc['S3MA']

#S2 and S3 recovery calculation
dfc['YS2'] = dfc['LasVirgenes/UF/FIT_41274/Val']/(dfc['LasVirgenes/UF/FIT_41274/Val']+dfc['LasVirgenes/UF/FIT_41374/Val']+dfc['LasVirgenes/UF/FIT_41974/Val'])
dfc['YS3'] = dfc['LasVirgenes/UF/FIT_41374/Val']/(dfc['LasVirgenes/UF/FIT_41374/Val']+dfc['LasVirgenes/UF/FIT_41974/Val'])

#S3 Feed conductivity
dfc['S3FEC'] = (dfc['S2FEC']*(dfc['LasVirgenes/UF/FIT_41274/Val'] + dfc['LasVirgenes/UF/FIT_41374/Val'] + dfc['LasVirgenes/UF/FIT_41974/Val']) - (dfc['LasVirgenes/UF/FIT_41274/Val']*dfc['LasVirgenes/UF/AIT_41292/Val']))/(dfc['LasVirgenes/UF/FIT_41374/Val'] + dfc['LasVirgenes/UF/FIT_41974/Val'])

#S2 and S3 Osmotic Pressure
dfc['S2OsP'] = ECOS*dfc['S2FEC']*(np.log(1/(1-dfc['YS2'])))/dfc['YS2']
dfc['S3OsP'] = ECOS*dfc['S3FEC']*(np.log(1/(1-dfc['YS3'])))/dfc['YS3']

#S2 and S3 NDP
dfc['S2NDP'] = dfc['LasVirgenes/UF/PT_41245/Val']-dfc['S2OsP']-((dfc['LasVirgenes/UF/PT_41245/Val']-dfc['LasVirgenes/UF/PT_41345/Val'])/2)-dfc['S2PP']
dfc['S3NDP'] = dfc['LasVirgenes/UF/PT_41347/Val']-dfc['S3OsP']-((dfc['LasVirgenes/UF/PT_41347/Val']-dfc['LasVirgenes/UF/PT_41945/Val'])/2)-dfc['S3PP']

#Specific Flux
dfc['S2K'] = dfc['S2J']/dfc['TCFFlow']/dfc['S2NDP']
dfc['S3K'] = dfc['S3J']/dfc['TCFFlow']/dfc['S3NDP']

#5 and 15 minute rolling averages    
dfc_op_5 = dfc.rolling(5, min_periods=1).mean()

dfc_op_15 = dfc.rolling(15, min_periods=1).mean()

dfc['Flow'] = dfc['LasVirgenes/UF/FIT_41074/Val'] + dfc['LasVirgenes/UF/FIT_41274/Val'] + dfc['LasVirgenes/UF/FIT_41374/Val'] + dfc['LasVirgenes/UF/FIT_41974/Val']
dfc['Reject'] = dfc['LasVirgenes/UF/FIT_41974/Val']
dfc['opmin'] = 1

ROpro = dfc[['Flow','Reject','opmin']]
ROprod = ROpro.resample("d").sum()

plt.rcParams.update({'font.size': 18})

#figureTMP = dfc_op_15['S2J'].plot(style='b.', label='flux',figsize=(18,9))
#dfc_op_15['LasVirgenes/UF/FIT_41274/Val'].plot(style='r.', label='flow')
#dfc_op_15['S2K'].plot(style='k.', label='SF ', secondary_y=True)
#dfc_op_15['T'].plot(style='g.', label='Temp ')
#plt.legend(loc=3)
#plt.yticks(np.arange(0, 12.02, 1.0))
#plt.ylim(0,12)
#plt.ylabel('UVT or Power (%)')
#plt.grid()
#plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%b')) 
#plt.gca().xaxis.set_major_locator(mdates.MonthLocator(interval=1)) 
#plt.gca().xaxis.set_tick_params(rotation = 0)  
#plt.gca().set_xbound(left, right)
#plt.rcParams.update({'font.size': 18})
#plt.xlabel(" ")
#plt.title(" ")
#plt.tight_layout()

#plt.savefig('/Users/abranch/OneDrive - Carollo Engineers/Desktop/LVMWD data/UV/Images/Power and UVT July to March.jpg',dpi=300)
#plt.show(figureTMP)

#figureFlux = dfc_op_15['LasVirgenes/UF/AI_UV_DOSE/Val'].plot(style='b.', label='UV PSS Dose',figsize=(18,9))
#dfc_op_5['LasVirgenes/UF/UF_03_TCFlux/Val'].plot(style='b', label='Flux Temperature Corrected')
#dfc_op_5['LasVirgenes/UF/UF_02_Permeability/Val'].plot(style='r', label='TMP ', grid=True)
#plt.legend(loc=3)
#plt.yticks(np.arange(0, 50.02, 5.0))
#plt.ylim(0,50)
#plt.ylabel('UV Dose (mJ/cm2)')
#plt.grid()
#plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%b')) 
#plt.gca().xaxis.set_major_locator(mdates.MonthLocator(interval=1)) 
#plt.gca().xaxis.set_tick_params(rotation = 0)  
#plt.gca().set_xbound(left, right)
#plt.rcParams.update({'font.size': 18})
#plt.xlabel(" ")
#plt.title(" ")
#plt.tight_layout()

#plt.savefig('/Users/abranch/OneDrive - Carollo Engineers/Desktop/LVMWD data/UV/Images/UV Dose July to March',dpi=300)
#plt.show(figureFlux)

#figureK = dfc_op_15['LasVirgenes/UF/AI_UV_INT/Val'].plot(style='b.', label='UV Intensity',figsize=(18,9))
#dfc_op_5['UVI/Q'].plot(style='r.', label='UVI/Q')
#dfc_op_5['LasVirgenes/UF/UF_02_Permeability/Val'].plot(style='r', label='TMP ', grid=True)
#plt.legend(loc=3)
#plt.yticks(np.arange(0, 12.02, 1.0))
#plt.ylim(0,12)
#plt.ylabel('UVI (mW/cm2) or UVI/Q (mW/cm2/gpm)')
#plt.grid()
#plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%b')) 
#plt.gca().xaxis.set_major_locator(mdates.MonthLocator(interval=1)) 
#plt.gca().xaxis.set_tick_params(rotation = 0)  
#plt.gca().set_xbound(left, right)
#plt.rcParams.update({'font.size': 18})
#plt.xlabel(" ")
#plt.title(" ")
#plt.tight_layout()

#plt.savefig('/Users/abranch/OneDrive - Carollo Engineers/Desktop/LVMWD data/UV/Images/UVI and UVIQ July to March',dpi=300)
#plt.show(figureK)

#dfc_op_1 = dfc.resample("min").mean()
#dfc_op_1.to_csv("C:/Users/abranch/OneDrive - Carollo Engineers/Desktop/LVMWD data/RO/RO Data 1 min Av July 2020 to June 14th 2021.csv")

#df_mi.to_csv("C:/Users/abranch/OneDrive - Carollo Engineers/Desktop/LVMWD data/RO/RO Data unfiltered July 2020 to July 26 2021.csv")

#dfc.to_csv("C:/Users/abranch/OneDrive - Carollo Engineers/Desktop/LVMWD data/RO/RO Data operating July 2020 to end July 26.csv")
ROprod = ROprod[left:right]
ROprod.to_csv("C:/Users/abranch/OneDrive - Carollo Engineers/Desktop/LVMWD data/RO/RO Production July 2020 to end June 22.csv")

#dfc_op_5 = dfc_op_5.resample("5min").mean()
#dfc_op_5.to_csv("C:/Users/abranch/OneDrive - Carollo Engineers/Desktop/LVMWD data/RO/RO Data K 5 min Av July 2020 to end July 26.csv")

dfc_op_15 = dfc.resample("15min").mean()
dfc_op_15 = dfc_op_15[left:right]
#dfc_op_15.to_csv("C:/Users/abranch/OneDrive - Carollo Engineers/Desktop/LVMWD data/RO/RO Data K 15 min Av July 2020 to end July 26.csv")


dfc_op_Daily = dfc.resample("d").mean()
dfc_op_Daily = dfc_op_Daily[left:right]
#ROkN = dfc_op_Daily[['Flow','Reject','opmin']]
dfc_op_Daily.to_csv("C:/Users/abranch/OneDrive - Carollo Engineers/Desktop/LVMWD data/RO/RO Data K Daily Av "f"{L}_to_{R}.csv")
ROkN = dfc_op_Daily[['LasVirgenes/UF/TIT_40005/Val','LasVirgenes/UF/AIT_40006/Val','LasVirgenes/UF/AIT_41892/Val','LasVirgenes/UF/AIT_41092/Val','LasVirgenes/UF/AIT_41292/Val','LasVirgenes/UF/FIT_41074/Val','LasVirgenes/UF/FIT_41274/Val','LasVirgenes/UF/PT_41095/Val','LasVirgenes/UF/PT_41245/Val','S1PP','LasVirgenes/UF/PT_41345/Val','S2PP','LasVirgenes/UF/AIT_41392/Val','LasVirgenes/UF/FIT_41374/Val','LasVirgenes/UF/PT_41347/Val','LasVirgenes/UF/PT_41945/Val','S3PP','LasVirgenes/UF/FIT_41974/Val','S1K','S2K','S3K']].copy()
ROkN.to_csv("C:/Users/abranch/OneDrive - Carollo Engineers/Desktop/LVMWD data/RO/RO Data Normalized Daily Av "f"{L}_to_{R}.csv")
dfc_op_15 .to_csv("C:/Users/abranch/OneDrive - Carollo Engineers/Desktop/LVMWD data/RO/RO 15 min Av "f"{L}_to_{R}.csv")

#dfc15av = dfc.resample("15min").mean()

#dfc15av.to_csv("C:/Users/abranch/OneDrive - Carollo Engineers/Desktop/LVMWD data/RO/LVMWD RO 15 min av Mar 1 to 21  2022.csv")

#print(dfc['TCFFlow'])

exit()