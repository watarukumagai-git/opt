work007
- description
 plant optimization (LVMWD)

- prediction model
 stub

- algorithm
 SHADE

- variable: 3

- condition
 start 20220601 97step
