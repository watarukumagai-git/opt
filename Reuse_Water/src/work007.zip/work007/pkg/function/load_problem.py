#coding: utf-8
import numpy as np
import random as rnd
import math

class LoadProblemClass:
    def __init__(self, problem_type_, flag_pattern_):
        self.problem_type = problem_type_
        self.flag_pattern = flag_pattern_
        self.g_num = 0
        self.deadtime = 0


    def load_problem(self, param_df):
        Time_start = 1
        #self.delta_t = 96
        self.delta_t = 48
        self.Time = self.delta_t-1 + Time_start

        (no_cost, self.no_feat_fac, self.no_feat_demand, self.no_feat_storage) = self.get_problem_parameter()
        
        # bigdim: 5 * (8 + 1) = 45
        self.bigN = self.num_feat_total * self.delta_t
        print('delta_t =', self.delta_t)

        # upper/lower/pattern
        min_clm = [i + '_Min' for i in self.ID_list]
        max_clm = [i + '_Max' for i in self.ID_list]
        pattern_clm = [i + '_Pattern' for i in self.ID_list]
        demand_clm = [i + '_Demand' for i in self.ID_list]
        seedflag_clm = [i + '_SeedFlag' for i in self.ID_list]
        if self.delta_t == 1:
            min_df = param_df.loc[Time_start, min_clm]
            max_df = param_df.loc[Time_start, max_clm]
            self.pattern = param_df.loc[Time_start, pattern_clm].values
            self.seedflag = param_df.loc[Time_start, seedflag_clm].values
        else:
            min_df = param_df.loc[Time_start:self.Time, min_clm]
            max_df = param_df.loc[Time_start:self.Time, max_clm]
            self.pattern = param_df.loc[Time_start:self.Time, pattern_clm].values
            self.seedflag = param_df.loc[Time_start:self.Time, seedflag_clm].values

        # index_array: (num_free, 2), [row_index, column_index] (num_feat, delta_t)
        index_array = list(zip(*np.where(self.seedflag.T==0)))
        self.N = len(index_array)

        # [x1[0],x1[1],x1[2],x2[0],x2[1],x2[1],....]
        self.pattern = self.pattern.T.reshape(self.bigN)
        self.seedflag = self.seedflag.T.reshape(self.bigN)

        # [min, max]
        self.bigx_ul = np.ones((self.bigN, 2))
        self.bigx_ul[:,0] = min_df.values.T.reshape(self.bigN)
        self.bigx_ul[:,1] = max_df.values.T.reshape(self.bigN)
        if np.any(self.seedflag==1):
            idx = np.where(self.seedflag == 0)
            self.x_ul = self.bigx_ul[idx,:][0]
        else:
            self.x_ul = self.bigx_ul

        # cost: (num_feat_total, Time)
        # ['ID000', 'ID001', 'ID002', 'ID100', 'ID200']
        c = np.zeros((self.num_feat_total, self.delta_t))
        c[1,:] = 10

        # demand: (num_demand, Time)
        demand = np.zeros((self.num_demand, self.delta_t))
        if self.delta_t == 1:
            for i in range(0, self.num_demand):
                for j in self.no_feat_demand[i]:
                    demand[i, :] = param_df.loc[Time_start-1, demand_clm[j]]
        else:
            for i in range(0, self.num_demand):
                for j in self.no_feat_demand[i]:
                    demand[i, :] = param_df.loc[Time_start-1:self.Time-1, demand_clm[j]].values.T

        return c, demand


    def get_problem_parameter(self):
        # x0: ID000
        # x1: ID001
        # x2: ID002
        # x3: ID100
        # x4: ID200
        if self.problem_type <= 6:
            self.num_feat_total = 5
            self.ID_list = ['ID000', 'ID001', 'ID002', 'ID100', 'ID200']
            self.ID = dict(zip(self.ID_list, range(self.num_feat_total)))
            no_cost = ['ID000']
            no_feat_fac = [['ID000', 'ID001', 'ID100'],
                           ['ID000', 'ID002', 'ID200']]
            no_feat_demand = []
            no_feat_storage = []
            self.deadtime = [0, 0, 0, 0, 0]
            self.no_diff = ['ID000']
        else:
            self.num_feat_total = 1
            no_cost = []
            no_feat_fac = []
            no_feat_demand = []
            no_feat_storage = []
            self.ID_list = []
            self.deadtime = []

        # num_feature at facility
        self.num_fac = len(no_feat_fac)
        # num_feature at demand
        self.num_demand = len(no_feat_demand)
        # num_feature at storage
        self.num_storage = len(no_feat_storage)

        return no_cost, no_feat_fac, no_feat_demand, no_feat_storage