work005
30min edit data => AR modeling