# -*- coding: utf-8 -*-
import os
from os import path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from pkg.helper import helper_class
from pkg.get_param import get_param_class
from pkg.figure_save import figure_save_class

def make_save_dir(work_path):
    # makedirs
    helper_class().my_makedirs(work_path)
    helper_class().my_makedirs(work_path + '\\fig')
    helper_class().my_makedirs(work_path + '\\file')

def index_to_datetime(df, ts_clm):
    df[ts_clm] = pd.to_datetime(df.index)
    df.set_index(ts_clm, inplace=True)
    return df

def split_df(df):
    df_unit = df.loc[['unit', 'description'], :]
    print(df_unit)
    df = df.drop(['unit', 'description'])
    df = index_to_datetime(df, 'timestamp').astype(float)
    return df, df_unit

def split_df_est_val(df_y, flag):
    if flag == 1:
        tra_str = '2021-07-01 00:30:00'
        tra_end = '2021-10-01 00:00:00'
        val_str = '2021-10-01 00:30:00'
        val_end = '2022-01-01 00:00:00'
        val1_end = '2021-11-16 00:00:00'
        val2_str = '2021-11-16 00:30:00'
    elif flag == 2:
        tra_str = '2021-10-01 00:30:00'
        tra_end = '2022-01-10 00:00:00'
        val_str = '2022-01-10 00:30:00'
        val_end = '2022-04-01 00:00:00'
        val1_end = '2022-02-17 00:00:00'
        val2_str = '2022-02-17 00:30:00'
    elif flag == 3:
        tra_str = '2022-04-01 00:30:00'
        tra_end = '2022-07-01 00:00:00'
        val_str = '2022-07-01 00:30:00'
        val_end = '2022-10-01 00:00:00'
        val1_end = '2022-08-17 00:00:00'
        val2_str = '2022-08-17 00:30:00'

    val1_str = val_str
    val2_end = val_end
    period = [tra_str, tra_end, val_str, val_end]
    sp_period = [val1_str, val1_end, val2_str, val2_end]
    tra_df = df_y.loc[tra_str:tra_end]
    val_df = df_y.loc[val_str:val_end]
    return tra_df, val_df, period, sp_period


class Error_df:
    def res(self, act_df, pre_df):
        return act_df - pre_df
    def mape(self, act_df, pre_df):
        return np.mean(np.abs(self.res(act_df, pre_df)/act_df))
    def rmse(self, act_df, pre_df):
        return np.sqrt(np.mean(self.res(act_df, pre_df)**2))



def metric_df(error, period, act_pre_df, tag, label=['est', 'pre']):
    (tra_str, tra_end, val_str, val_end) = period
    if label[0] == 'est':
        est_mape = error.mape(act_pre_df.loc[tra_str:tra_end, tag], act_pre_df.loc[tra_str:tra_end, label[0]])
        est_rmse = error.rmse(act_pre_df.loc[tra_str:tra_end, tag], act_pre_df.loc[tra_str:tra_end, label[0]])
        pre_mape = error.mape(act_pre_df.loc[val_str:val_end, tag], act_pre_df.loc[val_str:val_end, label[1]])
        pre_rmse = error.rmse(act_pre_df.loc[val_str:val_end, tag], act_pre_df.loc[val_str:val_end, label[1]])
    else:
        est_mape = error.mape(act_pre_df.loc[tra_str:tra_end, tag], act_pre_df.loc[tra_str:tra_end, 'pre'])
        est_rmse = error.rmse(act_pre_df.loc[tra_str:tra_end, tag], act_pre_df.loc[tra_str:tra_end, 'pre'])
        pre_mape = error.mape(act_pre_df.loc[val_str:val_end, tag], act_pre_df.loc[val_str:val_end, 'pre'])
        pre_rmse = error.rmse(act_pre_df.loc[val_str:val_end, tag], act_pre_df.loc[val_str:val_end, 'pre'])
    df_metric = pd.DataFrame(np.zeros((2, 2)), index=[label[0], label[1]], columns=['mape', 'rmse'])
    df_metric.at[label[0], 'mape'] = est_mape
    df_metric.at[label[0], 'rmse'] = est_rmse
    df_metric.at[label[1], 'mape'] = pre_mape
    df_metric.at[label[1], 'rmse'] = pre_rmse
    return df_metric

def save_file(save_path, period, str):
    f = open(save_path + '\\set_param.ini', 'w')
    for i in range(len(str)):
        f.write(str[i] + ': ' + period[i] + '\n')
    f.close()


class tag_chart:
    def __init__(self, df, df_unit, tag_list):
        self.xmin = 0
        self.xmax = 1
        self.ymin = 0
        self.ymax = 1
        self.minmax_status = 'min'
        self.df_unit = df_unit
        self.tag_list = tag_list

    def tag_scatter(self, df, fig_name_list):
        for i, tag in enumerate(self.tag_list):
            x = df.loc[:, tag + '_t-1'].values
            y = df.loc[:, tag].values
            self.xmax = y.max()
            self.ymax = y.max()
            title = self.df_unit.loc['description', tag] + ' [' + self.df_unit.loc['unit',tag] + ']'
            figure_label = ['t-1', 't', [self.xmin, self.xmax, self.ymin, self.ymax], title]
            figure_save_class().draw_scatter(fig_name_list[i], figure_label, x, y, self.minmax_status)


def main():
    dir_base = path.dirname( path.abspath(__file__) )

    # read file
    root_path = dir_base + '\\input'
    df_master = pd.read_csv(root_path + '\\master_30min_preprocessed_edit.csv', index_col=0)

    flag = 1
    modeling_mode = 'prophet'
    save_path = dir_base + '\\output_' + str(flag)

    # select tag and pre-processing
    low_up_dict = {'AIT_40006': [250, 2000],
                   'AIT_41092': [7, 40], 
                   'AIT_41292': [5, 45], 
                   'AIT_41392': [10, 50], 
                   'AIT_41892': [5, 48]}
    status_id = 'RO_Status'

    (df_master, df_unit) = split_df(df_master)
   
    # y
    tag_id_list = list(low_up_dict.keys())
    df_y = df_master.loc[:, tag_id_list]
    print(df_y.shape)
    print(df_y.head(2))
    print(df_y.tail(2))


    df_feed = pd.read_csv(save_path + '\\file\\RO Feed Conductivity_' + modeling_mode + '_value.csv', index_col=0, parse_dates=True)
    feed_tag = 'AIT_40006'
    for tag in tag_id_list:
        if tag == feed_tag:
            continue
        print(tag)
        df = pd.read_csv(save_path + '\\file\\' + df_unit.loc['description', tag] + '_' + modeling_mode + '_value.csv', index_col=0, parse_dates=True)
        clm = [tag, 'est', 'pre']
        for i, t in enumerate(clm):
            df_ = (df_feed[feed_tag] - df[t]) / df_feed[feed_tag]
            if i == 0:
                removal_rate_df = df_
            else:
                removal_rate_df = pd.concat([removal_rate_df, df_], axis=1)
        removal_rate_df = removal_rate_df * 100
        removal_rate_df.columns = clm
        removal_rate_df.to_csv(save_path + '\\file\\' + df_unit.loc['description', tag] + '_removal rate_' + modeling_mode + '.csv')


        legend_name = ['actual', 'estimate', 'predict']
        minmax = [removal_rate_df.index[0], removal_rate_df.index[-1], 95, 100]
        ylabel = df_unit.loc['description', tag] + ' removal rate [%]'
        figure_label = ['DATE', ylabel, legend_name, minmax]
        fig_file_name = save_path + '\\fig\\' + df_unit.loc['description', tag] + '_removal rate_' + modeling_mode + '.png'
        figure_save_class().draw_multi_trend(fig_file_name, figure_label, removal_rate_df.index.tolist(), removal_rate_df.values, minmax_status='minmax', lang = 'eng')

    print('finish')

if __name__ == "__main__":
    main()
