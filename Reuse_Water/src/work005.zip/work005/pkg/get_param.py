#coding: utf-8 
import re
import os
from os import path
import errno

class get_param_class:
    def get_param(self, param_file):
        if not os.path.exists(param_file):
            raise FileNotFoundError(errno.ENOENT, os.strerror(errno.ENOENT), param_file)
        with open(param_file, 'r') as f:
            for line in f:
                line = re.sub(r'\s|\n', '', line)
                if len(line) == 0 or line[0] == '#':
                    continue
                line = line.split("=")
                
                if line[0] == 'offset_status':
                    offset_status = line[1]
                else:
                    raise 'invalid keyword: ' + line[0]

        print('offset_status = ', offset_status)
        return offset_status