# -*- coding: utf-8 -*-
import os
from os import path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.tsa as sm
from statsmodels.tsa.ar_model import AutoReg

from pkg.helper import helper_class
from pkg.get_param import get_param_class
from pkg.figure_save import figure_save_class

def make_save_dir(work_path):
    # makedirs
    helper_class().my_makedirs(work_path)
    helper_class().my_makedirs(work_path + '\\fig')
    helper_class().my_makedirs(work_path + '\\file')

def index_to_datetime(df, ts_clm):
    df[ts_clm] = pd.to_datetime(df.index)
    df.set_index(ts_clm, inplace=True)
    return df

def split_df(df):
    df_unit = df.loc[['unit', 'description'], :]
    print(df_unit)
    df = df.drop(['unit', 'description'])
    df = index_to_datetime(df, 'timestamp')
    df = df.astype(float)
    return df, df_unit

def shift_df(df, low_up_dict):
    df_ = df.copy()
    for key, values in low_up_dict.items():
        df_[key + '_t-1'] = df_[key].shift(freq='30min')
    return df_

def calc_corr_df(df, id_list):
    df_ = df.copy()
    id_list += [id + '_t-1' for id in id_list]
    print(id_list)
    df_corr = df_.loc[:, id_list].corr()
    return df_corr

def self_correlation(df, df_des, save_path, nlags):
    for i, tag in enumerate(df.columns):
        df_acf = sm.api.stattools.acf(df[tag], nlags=nlags)
        fig = plt.figure(figsize=(12,8))
        fig = sm.graphics.tsa.plot_acf(df[tag], lags=nlags)
        plt.savefig(save_path + '\\' + df_des[tag] + '_selfcorrelation_30min.png', bbox_inches="tight")
    return df_acf

def decompose(df, df_des, save_path):
    for i, tag in enumerate(df.columns):
        res = sm.api.seasonal_decompose(df[tag].values, period=48)
        fig = res.plot()
        plt.savefig(save_path + '\\' + df_des[tag] + '_decompose_30min.png', bbox_inches="tight")

class AR:
    def __init__(self, lags):
        self.lags = 2
    def AR_fit(self, tra_array):
        ar_model = AutoReg(tra_array, lags=self.lags)
        self.ar_res = ar_model.fit()

    def AR_predict(self, val_period):
        ar_pre = self.ar_res.predict(val_period[0], val_period[1])
        return ar_pre

class tag_chart:
    def __init__(self, df, df_unit, tag_list):
        self.xmin = 0
        self.xmax = 1
        self.ymin = 0
        self.ymax = 1
        self.minmax_status = 'min'
        self.df_unit = df_unit
        self.tag_list = tag_list

    def tag_scatter(self, df, fig_name_list):
        for i, tag in enumerate(self.tag_list):
            x = df.loc[:, tag + '_t-1'].values
            y = df.loc[:, tag].values
            self.xmax = y.max()
            self.ymax = y.max()
            title = self.df_unit.loc['description', tag] + ' [' + self.df_unit.loc['unit',tag] + ']'
            figure_label = ['t-1', 't', [self.xmin, self.xmax, self.ymin, self.ymax], title]
            figure_save_class().draw_scatter(fig_name_list[i], figure_label, x, y, self.minmax_status)


def main():
    dir_base = path.dirname( path.abspath(__file__) )

    # read file
    root_path = dir_base + '\\input'
    df_master = pd.read_csv(root_path + '\\master_30min_preprocessed_edit.csv', index_col=0)

    save_path = dir_base + '\\output'
    make_save_dir(save_path)

    # select tag and pre-processing
    low_up_dict = {'AIT_40006': [250, 2000],
                   'AIT_41092': [7, 40], 
                   'AIT_41292': [5, 45], 
                   'AIT_41392': [10, 50], 
                   'AIT_41892': [5, 48]}
    status_id = 'RO_Status'

    (df_master, df_unit) = split_df(df_master)
   
    # y
    tag_id_list = list(low_up_dict.keys())
    df_y = df_master.loc[:, tag_id_list]
    print(df_y.shape)
    print(df_y.head(2))
    print(df_y.tail(2))

    # self_correlation
    #df_acf = self_correlation(df_y, df_unit.loc['description', :], save_path + '\\fig', 48)
    #decompose(df_y, df_unit.loc['description', :], save_path + '\\fig')

    # AR model
    tra_str = '2021-07-01 00:00:00'
    tra_end = '2022-09-01 00:00:00'
    val_str = '2022-09-01 00:30:00'
    val_end = '2022-10-01 00:00:00'
    #period = [tra_str, tra_end, val_str, val_end]
    tra_df = df_y.loc[tra_str:tra_end]
    val_df = df_y.loc[val_str:val_end]
    const_AR = AR(2)
    for i, tag in enumerate(df_y.columns):
        tra_period = [tra_df.index.get_loc(tra_str), tra_df.index.get_loc(tra_end)]
        val_period = [val_df.index.get_loc(val_str), val_df.index.get_loc(val_end)]
        const_AR.AR_fit(tra_df[tag].values)
        est = const_AR.AR_predict(tra_period)
        pre = const_AR.AR_predict(val_period)
        act_est_df = pd.concat([tra_df[tag], pd.DataFrame(est, index=tra_df.index)], axis=1)
        act_est_df.to_csv(save_path + '\\file\\' + df_unit.loc['description', tag] + '_est.csv')
        act_pre_df = pd.concat([val_df[tag], pd.DataFrame(pre, index=val_df.index)], axis=1)
        act_pre_df.to_csv(save_path + '\\file\\' + df_unit.loc['description', tag] + '_pre.csv')

    print('finish')

if __name__ == "__main__":
    main()
