# -*- coding: utf-8 -*-
import os
from os import path

import numpy as np
import pandas as pd
from sktime.forecasting.arima import ARIMA, AutoARIMA
from sktime.forecasting.fbprophet import Prophet
import matplotlib.pyplot as plt

from pkg.helper import helper_class
from pkg.get_param import get_param_class
from pkg.figure_save import figure_save_class

def make_save_dir(work_path):
    # makedirs
    helper_class().my_makedirs(work_path)
    helper_class().my_makedirs(work_path + '\\fig')
    helper_class().my_makedirs(work_path + '\\file')

def index_to_datetime(df, ts_clm):
    df[ts_clm] = pd.to_datetime(df.index)
    df.set_index(ts_clm, inplace=True)
    return df

def split_df(df):
    df_unit = df.loc[['unit', 'description'], :]
    print(df_unit)
    df = df.drop(['unit', 'description'])
    df = index_to_datetime(df, 'timestamp')
    df = df.astype(float)
    return df, df_unit

class Error_df:
    def res(self, act_df, pre_df):
        return act_df - pre_df
    def mape(self, act_df, pre_df):
        return np.mean(np.abs(self.res(act_df, pre_df)/act_df))
    def rmse(self, act_df, pre_df):
        return np.sqrt(np.mean(self.res(act_df, pre_df)**2))


class MODEL_:
    def __init__(self, modeling_mode, n=1, auto_mode='manual'):
        self.modeling_mode = modeling_mode
        if modeling_mode == 'ARIMA':
            if auto_mode == 'manual':
                self.model = ARIMA(
                    order=(1, 1, 0),
                    seasonal_order=(0, 1, 0, 12),
                    suppress_warnings=True)
            elif auto_mode == 'auto':
                self.model = AutoARIMA(
                    max_d=3,
                    start_p=5,
                    max_p=10, 
                    start_q=5,
                    max_q=10, 
                    max_order = 15,
                    suppress_warnings=True)
        elif modeling_mode == 'prophet':
            self.model = Prophet(
                seasonality_mode='multiplicative',
                yearly_seasonality=False, 
                weekly_seasonality=True, 
                daily_seasonality=True,
                n_changepoints = 35)

    def fit(self, tra_df):
        if self.modeling_mode == 'ARIMA':
            self.model.fit(tra_df.values)
        elif self.modeling_mode == 'prophet':
            self.model.fit(tra_df)

    def pre(self, val_df):
        if self.modeling_mode == 'ARIMA':
            fh = np.arange(1, len(val_df) + 1)
        elif self.modeling_mode == 'prophet':
            fh = val_df.index
        pre = self.model.predict(fh)
        return pre

def metric_df(error, period, act_pre_df, tag, label=['est', 'pre']):
    (tra_str, tra_end, val_str, val_end) = period
    if label[0] == 'est':
        est_mape = error.mape(act_pre_df.loc[tra_str:tra_end, tag], act_pre_df.loc[tra_str:tra_end, label[0]])
        est_rmse = error.rmse(act_pre_df.loc[tra_str:tra_end, tag], act_pre_df.loc[tra_str:tra_end, label[0]])
        pre_mape = error.mape(act_pre_df.loc[val_str:val_end, tag], act_pre_df.loc[val_str:val_end, label[1]])
        pre_rmse = error.rmse(act_pre_df.loc[val_str:val_end, tag], act_pre_df.loc[val_str:val_end, label[1]])
    else:
        est_mape = error.mape(act_pre_df.loc[tra_str:tra_end, tag], act_pre_df.loc[tra_str:tra_end, 'pre'])
        est_rmse = error.rmse(act_pre_df.loc[tra_str:tra_end, tag], act_pre_df.loc[tra_str:tra_end, 'pre'])
        pre_mape = error.mape(act_pre_df.loc[val_str:val_end, tag], act_pre_df.loc[val_str:val_end, 'pre'])
        pre_rmse = error.rmse(act_pre_df.loc[val_str:val_end, tag], act_pre_df.loc[val_str:val_end, 'pre'])
    df_metric = pd.DataFrame(np.zeros((2, 2)), index=[label[0], label[1]], columns=['mape', 'rmse'])
    df_metric.at[label[0], 'mape'] = est_mape
    df_metric.at[label[0], 'rmse'] = est_rmse
    df_metric.at[label[1], 'mape'] = pre_mape
    df_metric.at[label[1], 'rmse'] = pre_rmse
    return df_metric


class tag_chart:
    def __init__(self, df, df_unit, tag_list):
        self.xmin = 0
        self.xmax = 1
        self.ymin = 0
        self.ymax = 1
        self.minmax_status = 'min'
        self.df_unit = df_unit
        self.tag_list = tag_list

    def tag_scatter(self, df, fig_name_list):
        for i, tag in enumerate(self.tag_list):
            x = df.loc[:, tag + '_t-1'].values
            y = df.loc[:, tag].values
            self.xmax = y.max()
            self.ymax = y.max()
            title = self.df_unit.loc['description', tag] + ' [' + self.df_unit.loc['unit',tag] + ']'
            figure_label = ['t-1', 't', [self.xmin, self.xmax, self.ymin, self.ymax], title]
            figure_save_class().draw_scatter(fig_name_list[i], figure_label, x, y, self.minmax_status)


def main():
    dir_base = path.dirname( path.abspath(__file__) )

    # read file
    root_path = dir_base + '\\input'
    df_master = pd.read_csv(root_path + '\\master_30min_preprocessed_edit.csv', index_col=0)

    save_path = dir_base + '\\output'
    make_save_dir(save_path)

    # select tag and pre-processing
    low_up_dict = {'AIT_40006': [250, 2000],
                   'AIT_41092': [7, 40], 
                   'AIT_41292': [5, 45], 
                   'AIT_41392': [10, 50], 
                   'AIT_41892': [5, 48]}
    status_id = 'RO_Status'

    (df_master, df_unit) = split_df(df_master)
   
    # y
    tag_id_list = list(low_up_dict.keys())
    df_y = df_master.loc[:, tag_id_list]
    print(df_y.shape)
    print(df_y.head(2))
    print(df_y.tail(2))

    tra_str = '2022-04-01 00:00:00'
    tra_end = '2022-07-01 00:00:00'
    val_str = '2022-07-01 00:30:00'
    val_end = '2022-10-01 00:00:00'
    val1_str = val_str
    val1_end = '2022-08-16 00:00:00'
    val2_str = '2022-08-16 00:30:00'
    val2_end = val_end
    period = [tra_str, tra_end, val_str, val_end]
    sp_period = [val1_str, val1_end, val2_str, val2_end]
    tra_df = df_y.loc[tra_str:tra_end]
    val_df = df_y.loc[val_str:val_end]

    # ARIMA/Prophet
    # manual/auto
    modeling_mode = 'prophet'
    const = MODEL_(modeling_mode, n=2, auto_mode='manual')
    error = Error_df()

    for tag in tag_id_list:
        print(tag)
        const.fit(tra_df[tag])
        # estimate/predict
        for mode in ['est', 'pre']:
            if mode == 'est':
                df = tra_df.copy()
            else: 
                df = val_df.copy()
            pre = const.pre(df[tag])
            pre_df = pd.DataFrame(pre, index=df.index, columns=[mode])
            if mode == 'est':
                act_pre_df = pd.concat([df_y[tag], pre_df], axis=1)
            else:
                act_pre_df = pd.concat([act_pre_df, pre_df], axis=1)
        act_pre_df.to_csv(save_path + '\\file\\' + df_unit.loc['description', tag] + '_' + modeling_mode + '_value.csv')
        legend_name = ['actual', 'estimate', 'predict']
        minmax = [df.index[0], df.index[-1], 0, low_up_dict[tag][1]]
        figure_label = ['time', df_unit.loc['description', tag], legend_name, minmax]
        fig_file_name = save_path + '\\fig\\' + df_unit.loc['description', tag] + '_' + modeling_mode + '.png'
        figure_save_class().draw_multi_trend(fig_file_name, figure_label, act_pre_df.index.tolist(), act_pre_df.values, minmax_status='min')

        df_metric = metric_df(error, period, act_pre_df, tag, label=['est', 'pre'])
        df_metric.to_csv(save_path + '\\file\\' + df_unit.loc['description', tag] + '_' + modeling_mode + '_metric.csv')
        df_metric_spe = metric_df(error, sp_period, act_pre_df, tag, label=['pre_first', 'pre_latter'])
        df_metric_spe.to_csv(save_path + '\\file\\' + df_unit.loc['description', tag] + '_' + modeling_mode + '_metric_pre.csv')

    print('finish')

if __name__ == "__main__":
    main()
