#coding: utf-8
import numpy as np
from sklearn import linear_model

def model2():
    #r1 = np.random.rand(100, 2)
    #r2 = np.random.rand(100)
    #X = r1.copy()
    #Y = 2 * X[:, 0] - X[:, 1] + r2.copy()
    #model2 = linear_model.LinearRegression()
    #model2.fit(X, Y)
    # Y = 0.0000001 * ID000 + 0.00759418 * ID002 + 0.024452
    model2 = linear_model.LinearRegression()
    model2.coef_ = np.array([0.0000001, 0.00759418])
    model2.intercept_ = 0.024452
    return model2