import numpy as np

class fouling:
    def __init__(self, est_rho_model, est_cl_model, loaded_scaler):
        self.est_rho_model = est_rho_model
        self.est_cl_model = est_cl_model
        self.loaded_scaler = loaded_scaler

    def cal_fouling(self, S1_Feed_Pre, S1_Perm_Flow, S2_Perm_Flow, S3_Perm_Flow, S3_Conc_Pre, S3_Conc_Flow):
        """
        calulation initial fouling.

        Parameters
        ----------
        S1_Feed_Pre : double (Time,)
            RO Stage 1 Feed Pressure (ave_data[:,0])
        S1_Perm_Flow : double (Time,)
            RO Stage 1 Permeate Flow (ave_data[:,2])
        S2_Perm_Flow : double (Time,)
            RO Stage 2 Permeate Flow (ave_data[:,3])
        S3_Perm_Flow : double (Time,)
            RO Stage 3 Permeate Flow (ave_data[:,4])
        S3_Conc_Pre : double (Time,)
            RO Stage 3 Concentrate Pressure (ave_data[:,1])
        S3_Conc_Flow : double (Time,)
            RO Stage 3 Concentrate Flow (ave_data[:,5])

        Returns
        -------
        fouling_scale : double (Time,)
            calculated initial fouling value in [0,1]
        """
        def trans_gmp(x):
            return x*3.785/60
        
        pa = (S1_Feed_Pre - 44 - 18 - 14 - S3_Conc_Pre) * 6895
        v2 = (((S1_Perm_Flow + S2_Perm_Flow + S3_Perm_Flow + trans_gmp(S3_Conc_Flow)))**2
               - (trans_gmp(S1_Perm_Flow))**2 - (trans_gmp(S2_Perm_Flow))**2 
               - (trans_gmp(S3_Perm_Flow))**2 - (trans_gmp(S3_Conc_Flow))**2)/2
        fouling = pa + v2/self.est_rho_model.coef_
        fouling_scale = self.loaded_scaler.transform(fouling.reshape(-1,1))[0]
        if len(fouling_scale) == 1:
            fouling_scale = fouling_scale[0]
        return fouling_scale


    def cal_delta_fouling(self, Total_Chlorine):
        """
        calulation delta fouling.

        Parameters
        ----------
        Total_Chlorine : double (Time,)
            UF Filtrate Total Chlorine (ave_data[:,6])

        Returns
        -------
        delta_fouling : double (Time,)
            time evolution of fouling from initial value
        """

        return Total_Chlorine * self.est_cl_model.coef_ + self.est_cl_model.intercept_ 
    
    def predict(self, x):
        """
        prediction fouling.

        Parameters
        ----------
        x : double (7, Time)
            0: RO Stage 1 Feed Pressure
            1: UF Filtrate Total Chlorine
            2: RO Stage 1 Permeate Flow
            3: RO Stage 2 Permeate Flow
            4: RO Stage 3 Permeate Flow
            5: RO Stage 3 Concentrate Pressure
            6: RO Stage 3 Concentrate Flow

        Returns
        -------
        fouling predicted value : double (Time,)
        """
        # if 30min is delta_t = 48.0 / 1day
        delta_t = 48.0
        timestep = x.shape[1]
        y = np.zeros(timestep)
        y[0] = self.cal_fouling(x[0, 0], x[2, 0], x[3, 0], x[4, 0], x[5, 0], x[6, 0])
        for t in range(0, timestep-1):
            y[t+1] = y[t] + self.cal_delta_fouling(x[1, t]) / delta_t
        return y