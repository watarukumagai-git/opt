#coding: utf-8
import numpy as np
import pickle

from .fouling_submodel import fouling
from .model1 import model1
from .model2 import model2

class Model_class:
    def __init__(self):
        self.FOULING = self.import_fouling
        self.model1 = model1
        self.model2 = model2

    def import_fouling(self):
        base_folder_path = 'sub_model_fouling'
        rho_model_filename = base_folder_path + '\\est_rho_model.sav'
        cl_model_filename = base_folder_path + '\\est_cl_model.sav'
        scaler_filename = base_folder_path + '\\fouling_scaler.sav'
        est_rho_model = pickle.load(open(rho_model_filename, 'rb'))
        est_cl_model = pickle.load(open(cl_model_filename, 'rb'))
        loaded_scaler = pickle.load(open(scaler_filename, 'rb'))
        FOULING = fouling(est_rho_model, est_cl_model, loaded_scaler)
        return FOULING
