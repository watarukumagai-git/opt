#coding: utf-8
from os import path
import pickle

from .fouling_submodel import fouling
from .model1 import EC_model
from .model2 import TOC_model

class Model_class:
    def __init__(self, base_path):
        self.model1 = EC_model()
        self.model2 = TOC_model()
        base_folder_path = base_path + '\\sub_model_fouling'
        (est_rho_model, est_cl_model, loaded_scaler) = self.import_fouling(base_folder_path)
        self.FOULING = fouling(est_rho_model, est_cl_model, loaded_scaler)

    def import_fouling(self, base_folder_path):
        rho_model_filename = base_folder_path + '\\est_rho_model.sav'
        cl_model_filename = base_folder_path + '\\est_cl_model.sav'
        scaler_filename = base_folder_path + '\\fouling_scaler.sav'
        est_rho_model = pickle.load(open(rho_model_filename, 'rb'))
        est_cl_model = pickle.load(open(cl_model_filename, 'rb'))
        loaded_scaler = pickle.load(open(scaler_filename, 'rb'))
        return est_rho_model, est_cl_model, loaded_scaler
