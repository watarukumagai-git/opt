#coding: utf-8
import numpy as np
from sklearn import linear_model

def model1():
    # Y = 0.0000001 * ID000 + 0.0049530 * ID001 + 18.4720
    model1 = linear_model.LinearRegression()
    model1.coef_ = np.array([0.0000001, 0.0049530])
    model1.intercept_ = 18.4720
    return model1