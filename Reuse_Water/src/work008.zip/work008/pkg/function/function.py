#coding: utf-8
import numpy as np
import pandas as pd
from .model.import_model import Model_class


class Function:
    def __init__(self, load_pro, alg_type, cost, eval_type):
        self.load_pro = load_pro
        self.problem_type = load_pro.problem_type
        self.N = load_pro.N
        self.eval_type = eval_type
        self.alg_type = alg_type
        self.g_num = 0
        self.cost = cost
        self.epsilon_fac = [1,1]
        if self.problem_type == 1:
            diff_min = [-1]
            diff_max = [1]
        self.diff_minmax = [[i, j] for i, j in zip(diff_min, diff_max)]
        self.Model = Model_class()

        self.id_alldict = self.load_pro.alltagdict
        self.id_alltagid = list(self.id_alldict['Description'].keys())
        self.id_allseedmode = list(self.id_alldict['SeedMode'].values())
        self.init_big_x_2D = self.get_init_big_x_2D()


    def get_init_big_x_2D(self):
        x_2D = np.zeros((len(self.id_alltagid), self.load_pro.delta_t))
        j = 0
        h = 0
        for clm, tagid in enumerate(self.id_alltagid):
            if self.id_allseedmode[clm] == '1':
                x_2D[clm, :] = self.load_pro.pattern_fixed[j, :].copy()
                j = j + 1
            elif self.id_allseedmode[clm] == '2':
                x_2D[clm, :] = self.load_pro.pattern_inter[h, :].copy()
                h = h + 1
        return x_2D
    
    def convert_x_to_schedule(self, x_):
        # x: (N, 1)
        # schedule: (num_feat_total, delta_t)
        if np.any(self.load_pro.seedflag!=0):
            schedule = np.where(self.load_pro.seedflag, self.load_pro.pattern, -999)
            schedule[schedule == -999] = x_
        else:
            schedule = x_.copy()
        schedule = schedule.reshape(self.load_pro.num_feat_total, self.load_pro.delta_t)
        return schedule

    def convert_schedule_to_x(self, schedule):
        # schedule: (num_feat_total, delta_t)
        # x: (N, 1)
        x_ = schedule.reshape(self.N)
        if np.any(self.load_pro.seedflag!=0):
            x_ = np.delete(x_, np.where(self.load_pro.seedflag!=0))
        return x_

    def basis_func(self, func_type, x, c):
        # x: (N,)
        # c: (N,) or (N+1,)
        # func_type 1: linear
        if func_type == 1:
            if x.ndim >= 1:
                if len(c) == len(x):
                    f =  np.sum(c*x)
                else:
                    f =  np.sum(c[:-1]*x) + c[-1]
            else:
                f = c*x
        return f

    def object_function(self, x__):
        def _penalty(x_2D, pcoef):
            pattern_2D = self.load_pro.pattern.reshape(self.load_pro.num_feat_total, self.load_pro.delta_t)
            target = np.where(np.arange(self.load_pro.delta_t) <= self.load_pro.deadtime[0]+1, pattern_2D[0, :], self.demand[0, :])
            #target = np.array([pattern_2D[0, t] if t <= self.load_pro.deadtime[0]+1 else self.demand[0, t] for t in range(0, self.load_pro.delta_t) ])
            pepsilon = [0.01]
            g = self.get_vio_demand(x_2D[0,:], np.ones(self.load_pro.delta_t), pepsilon, target)
            g = np.where(g<0, 0, g)
            return pcoef * g.sum()

        # input
        # x__: (N_, )
        # output
        # f: float
        c = self.cost.reshape(self.load_pro.bigN)
        x_2D = self.convert_x_to_schedule(x__)
        f1 = self.basis_func(1, x_2D.reshape(self.load_pro.bigN), c)

        # ID100 penalty for target
        pcoef = pow(10, -1)
        #f2 = _penalty(x_2D, pcoef)
        #f = f1 + f2
        f = f1
        return f

    def get_oneside_vio(self, g_equal, lower, upper):
        return np.where((lower + upper)/2>=g_equal, lower - g_equal, g_equal - upper)

    def relax_const(self, x, coef, lower, upper):
        """
        relax for constarint functions.

        Parameters
        ----------
        eval_const : object
            constraint function
        x : double (num_feat, Time)
            solution
        coef : double (num_feat+1,)
            coefficient and bias for x
        lower : double (Time,)
            lower for x
        upper : double (Time,)
            upper for x

        Returns
        -------
        g_inequal : double (Time,)
            inequality constarints relaxed by lower/upper
        """
        # g_equal: (Time,)
        if x.ndim > 1:
            if len(coef) == x.shape[0]:
                g_equal = np.dot(coef, x)
            elif len(coef) == x.shape[0]+1:
                g_equal = np.dot(coef[:-1], x) + coef[-1]
        else:
            if len(coef) == len(x):
                g_equal = coef*x
            elif len(coef) == len(x) + 1:
                g_equal = coef[:-1]*x + coef[-1]
        g_inequal = self.get_oneside_vio(g_equal, lower, upper)
        return g_inequal

    def get_vio_minmax(self, x__, min__, max__):
        # x__ : (N,)
        # min__ : (N,) self.load_pro.x_ul[:,0]
        # max__ : (N,) self.load_pro.x_ul[:,1]
        return self.get_oneside_vio(x__, min__, max__)

    def get_vio_fac(self, x_2D, coef, epsilon):
        # x_2D: (num_feat, Time)
        # coef: (num_feat+1,)
        lower = -epsilon*np.ones(x_2D.shape[1])
        upper = epsilon*np.ones(x_2D.shape[1])
        # g_inequal : (Time,)
        g_inequal = self.relax_const(x_2D, coef, lower, upper)
        return g_inequal

    def get_vio_demand(self, x_2D, coef, epsilon, demand):
        # x_2D: (num_feat, Time)
        # coef: (num_feat,)
        # demand: (Time,)
        lower = demand - epsilon[0]
        upper = demand + epsilon[0]
        #lower = np.array([demand[t] - epsilon[0] for t in range(0,self.load_pro.delta_t)])
        #upper = np.array([demand[t] + epsilon[0] for t in range(0,self.load_pro.delta_t)])
        # g_inequal : (Time,)
        g_inequal = self.relax_const(x_2D, coef, lower, upper)
        return g_inequal

    def get_vio_diff(self, x_diff, diff_minmax):
        # x_diff: (Time-1,)
        # diff_minmax: [diff_min, diff_max]
        lower = diff_minmax[0]*np.ones(len(x_diff))
        upper = diff_minmax[1]*np.ones(len(x_diff))
        # g_inequal : (Time-1,)
        g_inequal = self.get_oneside_vio(x_diff, lower, upper)
        return g_inequal

    def constraint_function(self, x__):
        def _flatten_list(l):
            for el in l:
                if isinstance(el, list):
                    yield from _flatten_list(el)
                else:
                    yield el        

        def _get_const_facility(x_2D, epsilon_fac, diff_flag=[0]*self.load_pro.num_fac):
            # facility coef: array-(num_fac, each_coef)
            # g_fac : (Time*num_fac,)
            if any(i == 0 for i in diff_flag):
                for (j, idx_x) in enumerate(self.load_pro.no_feat_fac):
                    idx_x = self.load_pro.ID[idx_x]
                    X = x_2D[idx_x, :]
                    if diff_flag[j] == 1:
                        # x[t+1] - x[t], t=1,...,Time-1
                        X = np.diff(X, axis=1, n=1) + 50
                    unit_fac = self.get_vio_fac(X, self.fac_coef[j], epsilon_fac[j])
                    if j == 0:
                        g_fac = unit_fac
                    else:
                        g_fac = np.concatenate([g_fac, unit_fac])
            elif all(i == 1 for i in diff_flag):
                for (j, idx_x) in enumerate(self.load_pro.no_feat_fac):
                    idx_x = self.load_pro.ID[idx_x]
                    # x[t+1] - x[t], t=1,...,Time-1
                    X = np.diff(x_2D[idx_x, :], axis=1, n=1) + 50
                    unit_fac = self.get_vio_fac(X, self.fac_coef[j], epsilon_fac[j])
                    if j == 0:
                        g_fac = unit_fac
                    else:
                        g_fac = np.concatenate([g_fac, unit_fac])
            return g_fac

        def _get_const_demand(x_2D, epsilon_demand, coef_demand):
            # demand: (num_demand, Time)
            # g_demand : (Time*num_demand,)
            g_demand = []
            for j in range(0, self.load_pro.num_demand):
                idx_x = self.load_pro.no_feat_demand[j]
                g_demand.append(self.get_vio_demand(x_2D[idx_x, :], coef_demand[j, :], epsilon_demand, self.demand[j, :]))
            return np.array(g_demand[0])

        def _get_const_diff(x_2D, epsilon_diff):
            for (j, idx) in enumerate(self.load_pro.no_diff):
                idx = self.load_pro.ID[idx]
                x_diff = np.diff(x_2D[idx, :], n=1)
                unit_diff = self.get_vio_diff(x_diff, epsilon_diff[idx])
                if j == 0:
                    g_diff = unit_diff
                else:
                    g_diff = np.concatenate([g_diff, unit_diff])
            return g_diff
        
        def _get_dict_vallist(d_, l_):
            return [d_[d] for d in l_]
        
        def _prediction(id_dict, x_2D, x_l, y_l):
            idx = _get_dict_vallist(list(id_dict), x_l)
            # id1000, id1001, id1002
            if y_l == 'ID1002':
                if y_l == 'ID1000':
                    model = self.Model.model1
                elif y_l == 'ID1001':
                    model = self.Model.model2
                y = model.predict(x_2D[idx, :].reshape(1,2))
            else:
                fouling = self.Model.FOULING.cal_fouling()
                cal_delta = self.Model.FOULING.cal_delta_fouling()
            return y
        
        def _get_minmax_inter(id_dict, x_2D):
            idx = _get_dict_vallist(list(id_dict['Description'].keys()), self.load_pro.inter_taglist)
            x__ = x_2D[idx, :]
            gminmax = self.get_vio_minmax(x__, self.load_pro.x_ul_inter[:,0], self.load_pro.x_ul_inter[:,1])
            return gminmax
        
        def _get_limit_inter(input, output, lower, upper):
            g_equal_rate = 100 * (input - output) / input
            return self.get_oneside_vio(g_equal_rate, lower, upper)


        def _get_big_x_2D(x_2D):
            big_x_2D = self.init_big_x_2D.copy()
            i = 0
            for clm, tagid in enumerate(self.id_alltagid):
                if self.id_allseedmode[clm] == '0':
                    big_x_2D[clm, :] = x_2D[i, :].copy()
                    i = i + 1
            return big_x_2D

        if self.problem_type <= 6:

            # (num_feat_total, delta_t)
            x_2D = self.convert_x_to_schedule(x__)
            big_x_2D = _get_big_x_2D(x_2D)

            id_num = self.load_pro.no_feat_fac
            id_dict = self.load_pro.tagdict


            # prediction
            #x = np.zeros((1, 2))
            #x[0,0] = 5.0
            #x[0,1] = 2.5

            # facility_violation
            g_fac = []

            # ID1000 prediction
            x_l = ['ID000','ID001']
            y_l = 'ID1000'
            ID1000 = _prediction(self.id_alltagid, big_x_2D, x_l, y_l)
            # ID1001 prediction
            x_l = ['ID000','ID002']
            y_l = 'ID1001'
            ID1001 = _prediction(self.id_alltagid, big_x_2D, x_l, y_l)
            # fouling model
            #l = [S1_Feed_Pre, S3_Conc_Pre, S1_Perm_Flow, S2_Perm_Flow, S3_Perm_Flow, S3_Conc_Flow, UF_Filtrate_Total_Chlorine]
            x_l = ['ID003','ID004','ID100','ID200','ID300','ID301','ID302']
            y_l = 'ID1002'
            ID1002 = _prediction(self.id_alltagid, big_x_2D, x_l, y_l)


            # min-max_violation
            g_minmax = _get_minmax_inter(self.id_alldict, x_2D)

            # prediction rate
            g_rate =[]
            lower = 50
            upper = 100
            g_in1 = _get_limit_inter(x_2D[id_dict['ID001'], 0], ID1000, lower, upper)
            g_in2 = _get_limit_inter(x_2D[id_dict['ID002'], 0], ID1001, lower, upper)
            g_rate.append(g_in1)
            g_rate.append(g_in2)

            # diff_violation
            g_diff = _get_const_diff(x_2D, self.diff_minmax)

            g = np.ravel(np.concatenate([g_fac, g_minmax, g_rate, g_diff]))
        else:
            g = [0]
        return g