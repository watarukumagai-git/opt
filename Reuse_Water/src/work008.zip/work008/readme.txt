work008
- description
 plant optimization (LVMWD)

- prediction model
 stub, fouling

- algorithm
 SHADE

- variable: 3

- SeedMode
 0: Opt. Variable
 1: Fixed Parameter
 2: Intermediate Variable

- condition
 start 20220601 0:00 - 20220603 0:00 97step
