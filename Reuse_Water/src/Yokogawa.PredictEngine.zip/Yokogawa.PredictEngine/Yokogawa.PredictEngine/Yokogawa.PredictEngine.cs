﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using MathNet.Numerics.LinearAlgebra.Double;
using MathNet.Numerics.LinearAlgebra;
using MathNet.Numerics.Statistics;
using MathNet.Numerics.Distributions;
using System.IO;

namespace Yokogawa.PredictEngine
{
    class Error//エラーコード//
    {
        //Input Error Code in Fit//
        internal const int FitDataSizeError1 = 100;
        internal const int FitDataSizeError2 = 101;
        internal const int FitDataNaNError1 = 102;
        internal const int PLSHpyperparameterError = 103;
        internal const int PLSHpyperparameterNaNError = 104;
        internal const int RFDataSizeError = 105;
        internal const int RFHpyperparameterError1 = 106;
        internal const int RFHpyperparameterNaNError1 = 107;
        internal const int RFHpyperparameterError2 = 108;
        internal const int RFHpyperparameterNaNError2 = 109;
        internal const int RFHpyperparameterError3 = 110;
        internal const int FitDataSizeError3 = 111;
        internal const int FitDataSizeError4 = 112;
        internal const int FitDataNaNError2 = 700;
        internal const int RFResampleNegativeError = 120;
        internal const int RFResampleSizeError = 121;
        internal const int RFSelectedFeatureZeroError = 122;
        internal const int RFSelectedFeatureSizeError = 123;

        //Input Error Code in Predict//
        internal const int PredDataSizeError1 = 200;
        internal const int PredDataNaNError1 = 201;
        internal const int PredDataSizeError2 = 202;
        internal const int PredDataNaNError2 = 300;

        //Input Error Code in ModPredict//
        internal const int modParaSizeError = 400;
        internal const int modParaError1 = 401;
        internal const int modParaError2 = 402;
        internal const int modParaError3 = 403;
        internal const int modParaNaNError = 404;
        internal const int modDataError1 = 405;
        internal const int modDataError2 = 406;
        internal const int modDataError3 = 407;
        internal const int modDataError4 = 408;
        internal const int modDataError5 = 409;
        internal const int modDataError6 = 410;
        internal const int modDataError7 = 411;
        internal const int modPredictError = 500;

        internal const int BadSerializedData = 600;

        //Output Error Code in Filtering//
        internal const int filteringDataSizeError1 = 800;
        internal const int filteringDataSizeError2 = 801;
        internal const int filteringDataNaNError = 802;
        internal const int filteringDataAndParameterSizeError = 803;
        internal const int filteringParameterSizeError = 804;
        internal const int filteringTargetError = 805;
        internal const int filteringMinMaxBoundError = 806;
        internal const int filteringOutlierRateError = 807;
        internal const int filteringMDCalculationError = 808;
        internal const int filteringChiSquaredCalculationError = 809;
    }

    //-------------------------------------------フィルタリング機能
    public interface IFilteringHyperParameter
    {
    }

    public class MinMaxHyperParameter : IFilteringHyperParameter
{
    internal bool[] FilteringTarget;
    internal double[] MinBounds;
    internal double[] MaxBounds;


public MinMaxHyperParameter(bool[] FilteringTarget, double[] MinBounds, double[] MaxBounds)
{
        this.FilteringTarget = FilteringTarget;
        this.MinBounds = MinBounds;
        this.MaxBounds = MaxBounds;
}
}

    public class MaharanobisHyperParameter : IFilteringHyperParameter
{
    internal bool[] FilteringTarget;
    internal double OutlierRate;

    public MaharanobisHyperParameter(bool[] FilteringTarget, double OutlierRate)
    {
        this.FilteringTarget = FilteringTarget;
        this.OutlierRate = OutlierRate;
    }
}

    public interface IFilter
    {
        int Filtering(double[][] xtra, double[] ytra, out double[][] xtraFiltered, out double[] ytraFiltered, out bool[] actFilter);
    }

    public class MinMaxFilter : IFilter
    {
        bool[] FilteringTarget;
        double[] MinBounds;
        double[] MaxBounds;

        public MinMaxFilter(MinMaxHyperParameter fhp)
        {
            FilteringTarget = fhp.FilteringTarget;
            MinBounds = fhp.MinBounds;
            MaxBounds = fhp.MaxBounds;
        }

        public int Filtering(double[][] xtra, double[] ytra, out double[][] xtraFiltered, out double[] ytraFiltered, out bool[] actFilter)
        {
            xtraFiltered = null;
            ytraFiltered = null;
            actFilter = null;

            // xtra, ytra の配列の要素数の取得
            int xtraNumRow = xtra.Length;
            int xtraNumCol = xtra[0].Length;
            int ytraNumRow = ytra.Length;
            int ytraNumCol = 1;

            //Input Error Check//
            //800: 説明変数のデータ数と目的変数のデータ数は一致する必要がある//
            // xtra, ytra の行数のチェック
            if (xtraNumRow != ytraNumRow)
            {
                return Error.filteringDataSizeError1;
            }
            //801: 説明変数のデータ数と目的変数のデータ数は2以上である必要がある//
            if (xtraNumRow < 2 || ytraNumRow < 2)
            {
                return Error.filteringDataSizeError2;
            }
            //802: 説明変数あるいは目的変数にNaNが含まれている//
            int errorFlag1;
            int errorFlag2;
            helper.CheckDouble2D(xtra, out errorFlag1);
            helper.Check1D(ytra, out errorFlag2);
            if (errorFlag1 == 1 || errorFlag2 == 1)
            {
                return Error.filteringDataNaNError;
            }
            //803: 説明変数＋目的変数の数とフィルタリング対象・対象外の変数の数は一致する必要がある//
            // xtra + ytra の列数 と FilteringTarget の行数のチェック
            if (xtraNumCol+ ytraNumCol != FilteringTarget.Length)
            {
                return Error.filteringDataAndParameterSizeError;
            }
            //804: フィルタリング対象・対象外の変数の数と最大値の数と最小値の数は一致する必要がある//
            // FilteringTarget, MinBounds, MaxBounds の行数のチェック
            if (FilteringTarget.Length != MinBounds.Length)
            {
                return Error.filteringParameterSizeError;
            }
            if (FilteringTarget.Length != MaxBounds.Length)
            {
                return Error.filteringParameterSizeError;
            }
            if (MinBounds.Length != MaxBounds.Length)
            {
                return Error.filteringParameterSizeError;
            }
            //805: 全変数がフィルタリング対象外になってる//
            bool onFiltering = false;
            for (int i = 0; i < FilteringTarget.Length; i++)
            {
                if (FilteringTarget[i] == true)
                {
                    onFiltering = true;

                    break;
                }
            }
            if (onFiltering == false)
            {
                return Error.filteringTargetError;
            }
            //806: 最大値と最小値の大小関係が正しくない//
            // MinBounds, MaxBounds の大小関係のチェック
            for (int i = 0; i < MinBounds.Length; i++)
            {
                if (MinBounds[i] > MaxBounds[i])
                {
                    return Error.filteringMinMaxBoundError;
                }
            }

            // 最大最小値フィルタリング機能
            actFilter = new bool[xtraNumRow];
            for (int i = 0; i < xtraNumRow; i++)
            {
                bool outlier = false;
                for (int j = 0; j < xtraNumCol; j++)
                {
                    if (FilteringTarget[j] == true)
                    {
                        // xtra 最小最大値範囲外の判定
                        if (xtra[i][j] < MinBounds[j] || xtra[i][j] > MaxBounds[j])
                        {
                            outlier = true;

                            break;
                        }
                    }
                }

                if (outlier == false)
                {
                    if (FilteringTarget[xtraNumCol + ytraNumCol - 1] == true)
                    {
                        // ytra 最小最大値範囲外の判定
                        if (ytra[i] < MinBounds[xtraNumCol + ytraNumCol - 1] || ytra[i] > MaxBounds[xtraNumCol + ytraNumCol - 1])
                        {
                            outlier = true;
                        }
                    }
                }

                // 範囲外の場合、外れ値とする
                if (outlier == true)
                {
                    actFilter[i] = true;
                }
            }

            // 外れ値ではないデータのカウント
            int numNotOutlier = 0;
            for (int i = 0; i < xtraNumRow; i++)
            {
                if (actFilter[i] == false)
                {
                    numNotOutlier++;
                }
            }

            // フィルタリング済データの出力
            xtraFiltered = new double[numNotOutlier][];
            for (int i = 0; i < xtraFiltered.Length; i++)
            {
                xtraFiltered[i] = new double[xtraNumCol];
            }
            ytraFiltered = new double[numNotOutlier];

            int counter = 0;
            for (int i = 0; i < xtraNumRow; i++)
            {
                if (actFilter[i] == false)
                {
                    for (int j = 0; j < xtraNumCol; j++)
                    {
                        xtraFiltered[counter][j] = xtra[i][j];
                    }
                    ytraFiltered[counter] = ytra[i];

                    counter++;
                }
            }

            return 0;
        }
    }

    public class MaharanobisFilter : IFilter
    {
        bool[] FilteringTarget;
        double OutlierRate;

        public MaharanobisFilter(MaharanobisHyperParameter fhp)
        {
            FilteringTarget = fhp.FilteringTarget;
            OutlierRate = fhp.OutlierRate;
        }

        public int Filtering(double[][] xtra, double[] ytra, out double[][] xtraFiltered, out double[] ytraFiltered, out bool[] actFilter)
        {
            xtraFiltered = null;
            ytraFiltered = null;
            actFilter = null;

            // xtra, ytra の配列の要素数の取得
            int xtraNumRow = xtra.Length;
            int xtraNumCol = xtra[0].Length;
            int ytraNumRow = ytra.Length;
            int ytraNumCol = 1;

            //Input Error Check//
            //800: 説明変数のデータ数と目的変数のデータ数は一致する必要がある//
            // xtra, ytra の行数のチェック
            if (xtraNumRow != ytraNumRow)
            {
                return Error.filteringDataSizeError1;
            }
            //801: 説明変数のデータ数と目的変数のデータ数は2以上である必要がある//
            if (xtraNumRow < 2 || ytraNumRow < 2)
            {
                return Error.filteringDataSizeError2;
            }
            //802: 説明変数あるいは目的変数にNaNが含まれている//
            int errorFlag1;
            int errorFlag2;
            helper.CheckDouble2D(xtra, out errorFlag1);
            helper.Check1D(ytra, out errorFlag2);
            if (errorFlag1 == 1 || errorFlag2 == 1)
            {
                return Error.filteringDataNaNError;
            }
            //803: 説明変数＋目的変数の数とフィルタリング対象・対象外の変数の数は一致する必要がある//
            // xtra + ytra の列数 と FilteringTarget の行数のチェック
            if (xtraNumCol + ytraNumCol != FilteringTarget.Length)
            {
                return Error.filteringDataAndParameterSizeError;
            }
            //805: 全変数がフィルタリング対象外になってる//
            bool onFiltering = false;
            for (int i = 0; i < FilteringTarget.Length; i++)
            {
                if (FilteringTarget[i] == true)
                {
                    onFiltering = true;

                    break;
                }
            }
            if (onFiltering == false)
            {
                return Error.filteringTargetError;
            }
            //807: OutlierRateは0以上1以下の値である必要がある//
            // OutlierRate のチェック
            if (OutlierRate < 0.0 || OutlierRate > 1.0)
            {
                return Error.filteringOutlierRateError;
            }

            int status;
            double[,] array_data;
            double[] array_output;
            double FreedomDegree;
            double Threshold;
            List<double> MahalanobisDistances = new List<double>();

            // 計算対象データ（行列形式）の取得
            status = makeMartix(xtra, ytra, FilteringTarget, out array_data);
            if (status != 0)
            {
                return status;
            }

            // マハラノビス距離を計算するメソッド（Math.NET Numerics ライブラリ利用）
            status = MathNetNumericsMD(array_data, out array_output);
            if (status != 0)
            {
                return status;
            }
            MahalanobisDistances = array_output.ToList();

            // カイ二乗分布を用いた閾値を計算するメソッド（Math.NET Numerics ライブラリ利用）
            FreedomDegree = array_data.GetLength(1);
            status = MathNetNumericsThreshold(OutlierRate, FreedomDegree, out Threshold);
            if (status != 0)
            {
                return status;
            }

            // 外れ値の判定
            actFilter = new bool[xtraNumRow];
            for (int i = 0; i < xtraNumRow; i++)
            {
                if (MahalanobisDistances[i] <= Threshold)  // 正常値
                {
                    actFilter[i] = false;
                }
                else    // 外れ値
                {
                    actFilter[i] = true;
                }
            }

            // 外れ値ではないデータのカウント
            int numNotOutlier = 0;
            for (int i = 0; i < xtraNumRow; i++)
            {
                if (actFilter[i] == false)
                {
                    numNotOutlier++;
                }
            }

            // フィルタリング済データの出力
            xtraFiltered = new double[numNotOutlier][];
            for (int i = 0; i < xtraFiltered.Length; i++)
            {
                xtraFiltered[i] = new double[xtraNumCol];
            }
            ytraFiltered = new double[numNotOutlier];

            int counter = 0;
            for (int i = 0; i < xtraNumRow; i++)
            {
                if (actFilter[i] == false)
                {
                    for (int j = 0; j < xtraNumCol; j++)
                    {
                        xtraFiltered[counter][j] = xtra[i][j];
                    }
                    ytraFiltered[counter] = ytra[i];

                    counter++;
                }
            }

            return 0;
        }

        // 計算対象データを行列化するメソッド
        private int makeMartix(double[][] xtra, double[] ytra, bool[] filteringTarget, out double[,] array_data)
        {
            array_data = null;

            // xtra, ytra の配列の要素数の取得
            int xtraNumRow = xtra.Length;
            int xtraNumCol = xtra[0].Length;
            int ytraNumRow = ytra.Length;
            int ytraNumCol = 1;

            // フィルタリング対象の変数の数の取得
            int numFilteringTarget = 0;
            for (int i = 0; i < filteringTarget.Length; i++)
            {
                if (filteringTarget[i] == true)
                {
                    numFilteringTarget++;
                }
            }
            // 行列の作成
            if (xtraNumRow == 0)   // 計算対象データがない場合
            {
                array_data = new double[0, numFilteringTarget];

                return 0;
            }
            else    // 計算対象データがある場合
            {
                array_data = new double[xtraNumRow, numFilteringTarget];
            }

            // データの取得
            int counter = 0;
            for (int j = 0; j < xtraNumCol; j++)
            {
                if (filteringTarget[j] == true)
                {
                    for (int i = 0; i < xtraNumRow; i++)
                    {
                        array_data[i, counter] = xtra[i][j];
                    }

                    counter++;
                }
            }
            if (filteringTarget[xtraNumCol + ytraNumCol - 1] == true)
            {
                for (int i = 0; i < ytraNumRow; i++)
                {
                    array_data[i, counter] = ytra[i];
                }
            }

            return 0;
        }

        // マハラノビス距離を計算するメソッド（Math.NET Numerics ライブラリ利用）
        private int MathNetNumericsMD(double[,] array_data, out double[] array_output)
        {
            int status;
            string strErrorMessage;

            array_output = null;

            try
            {
                // 計算対象データ
                Matrix<double> X = DenseMatrix.OfArray(array_data);
                int row = X.RowCount;
                int col = X.ColumnCount;

                // 平均値
                Vector<double> mean_data = X.ColumnSums() / row;
                Matrix<double> mu = CreateMatrix.DenseOfColumnVectors(mean_data);
                for (int i = 0; i < row - 1; i++)
                {
                    mu = mu.Append(CreateMatrix.DenseOfColumnVectors(mean_data));
                }
                mu = mu.Transpose();

                // センタリング
                Matrix<double> nor_X = X - mu;

                // 共分散行列
                Matrix<double> cov_nor_X = 1.0 / (row - 1.0) * nor_X.Transpose() * nor_X;

                // マハラノビス距離
                Matrix<double> t_nor_X = nor_X.Transpose();
                Matrix<double> inv_cov_nor_X = cov_nor_X.Inverse();
                array_output = new double[row];
                for (int i = 0; i < row; i++)
                {
                    array_output[i] = t_nor_X.Column(i) * inv_cov_nor_X * nor_X.Row(i);
                }

                // 正常終了
                status = 0;
            }
            catch (Exception e)
            {
                //808: マハラノビス距離の計算に失敗した//
                // 想定していないエラーを補足する
                status = Error.filteringMDCalculationError;     // エラー番号
                strErrorMessage = e.StackTrace;                 // スタックトレース
            }

            return status;
        }

        // カイ二乗分布を用いた閾値を計算するメソッド（Math.NET Numerics ライブラリ利用）
        private int MathNetNumericsThreshold(double outlierRate, double FreedomDegree, out double Threshold)
        {
            int status;
            string strErrorMessage;

            Threshold = 0;

            try
            {
                // 自由度 FreedomDegree のカイ二乗分布から標本の 1-FilteringAlpha を超える値を計算する

                // カイ二乗分布
                ChiSquared cs = new ChiSquared(FreedomDegree);

                // カイ二乗累積分布関数から閾値を求める
                Threshold = cs.InverseCumulativeDistribution(1 - outlierRate);


                // 正常終了
                status = 0;
            }
            catch (Exception e)
            {
                //809: カイ二乗分布の計算に失敗した//
                // 想定していないエラーを補足する
                status = Error.filteringChiSquaredCalculationError;     // エラー番号
                strErrorMessage = e.StackTrace;                         // スタックトレース
            }

            return status;
        }
    }

    public class FilterFactory
    {
        public static IFilter CreatFilter(IFilteringHyperParameter fhp)
        {
            switch (fhp)
            {
                case MinMaxHyperParameter MinMaxhp:
                    return new MinMaxFilter(MinMaxhp);
                case MaharanobisHyperParameter Maharanobishp:
                    return new MaharanobisFilter(Maharanobishp);
                default:
                    throw new ArgumentOutOfRangeException("fhp", "Invalid filter hyper parameter class is given");
            }
        }
    }

    //-------------------------------------------予測機能
    public interface IHyperParameter
    {
    }
    
    public class MLRHyperParameter : IHyperParameter
    {
        internal double[] modPara;

        public MLRHyperParameter(double[] modPara)
        {
            this.modPara = modPara;
        }
    }

    public class PLSHyperParameter : IHyperParameter
    {
        internal double[] modPara;
        internal int numLV;
        public PLSHyperParameter(double[] modPara, int numLV)
        {
            this.modPara = modPara;
            this.numLV = numLV;
        }
    }

    public class RFHyperParameter : IHyperParameter
    {
        internal double[] modPara;
        internal int numTree;
        internal Nullable<int> numMaxDepth;
        internal int numMinSplit;
        public RFHyperParameter(double[] modPara, int numTree, Nullable<int> numMaxDepth, int numMinSplit)
        {
            this.modPara = modPara;
            this.numTree = numTree;
            this.numMaxDepth = numMaxDepth;
            this.numMinSplit = numMinSplit;
        }
    }

    public interface IModel
    {
        int Fit(double[][] xtra, double[] ytra);
        int Predict(double[][] xpre, out double[] ypre);
        int ModPredict(double[] ypre, double[][] modData, int[][] filtTra, int[][] filtPre, out double[] yPreMod, out double[][] confInt, out int[] actMod);
        int Serialize(out string serialized);
        int Deserialize(string serialized);
    }

    [DataContract]
    public class MLRModel : IModel
    {
        [DataMember(IsRequired = true)]
        double[] coef;
        [DataMember(IsRequired = true)]
        double[] modPara;
        //epsilon//
        const double epsSTD = 1E-7;

        public MLRModel(MLRHyperParameter hp)
        {
            modPara = hp.modPara;
        }

        public int Fit(double[][] xtra, double[] ytra)
        {
            int errorFlag, errorFlag1, errorFlag2;
            //Input Error Check//
            //100: 説明変数のデータ数と目的変数のデータ数が一致していない//
            if (xtra.Length != ytra.Length)
            {
                return Error.FitDataSizeError1;
            }
            //101: 説明変数のデータ数と目的変数のデータ数は説明変数の数より多く、かつ2以上である必要がある//
            if (xtra[0].Length >= xtra.Length || xtra[0].Length >= ytra.Length || xtra.Length < 2 || ytra.Length < 2)
            {
                return Error.FitDataSizeError2;
            }
            //102:説明変数あるいは目的変数にNaNが含まれている//
            helper.CheckDouble2D(xtra, out errorFlag1);
            helper.Check1D(ytra, out errorFlag2);
            if (errorFlag1 == 1 || errorFlag2 == 1)
            {
                return Error.FitDataNaNError1;
            }

            //jagg配列から2D配列に変換//
            Matrix<double> X = DenseMatrix.OfRowArrays(xtra);
            Matrix<double> Y = DenseMatrix.OfRowArrays(ytra).Transpose();
            
            //サンプル数//
            int n = X.RowCount;
            //説明変数の数//
            int p = X.ColumnCount;
            //目的変数の数//
            int q = Y.ColumnCount;

            //初期化//
            Matrix<double> C = DenseMatrix.OfRowArrays(Enumerable.Repeat<double>(0, p).ToArray()).Transpose();
            Matrix<double> D = DenseMatrix.OfRowArrays(Enumerable.Repeat<double>(0, n).ToArray());
            double[] modelModedouble = Enumerable.Repeat<double>(0, 1).ToArray();
            double[] d = Enumerable.Repeat<double>(0, 1).ToArray();

            //scaling//
            Matrix<double> yCal, xCal;
            //centering and scaling//
            //centering: yの0.1%の誤差が発生した//
            int centering_flag = 1;
            int scaling_flag = 1;

            double meanY = Statistics.Mean(ytra);
            double stdY = Statistics.StandardDeviation(ytra);

            if (Math.Abs(stdY / meanY) < epsSTD)
            {
                stdY = 1;
            }

            double[] meanX = new double[p];
            double[] stdX = new double[p];
            double[][] xTemp = X.Transpose().ToRowArrays();
            for (int j = 0; j < p; j++)
            {
                stdX[j] = Statistics.StandardDeviation(xTemp[j]);
                meanX[j] = Statistics.Mean(xTemp[j]);
                if (Math.Abs(stdX[j] / meanX[j]) < epsSTD)
                {
                    stdX[j] = 1;
                }
            }

            helper.CenteringScaling(X, Y, meanX, meanY, stdX, stdY, centering_flag, scaling_flag, out xCal, out yCal);

            //予測計算//
            C = (xCal.Transpose().Multiply(xCal)).Inverse().Multiply(xCal.Transpose()).Multiply(yCal);


            //scaling//
            if (scaling_flag == 1)
            {
                double[][] cTemp = C.ToRowArrays();
                for (int j = 0; j < p; j++)
                {
                    cTemp[j][0] = cTemp[j][0] / stdX[j] * stdY;
                }
                C = DenseMatrix.OfRowArrays(cTemp);
            }

            //切片//
            if (centering_flag == 1)
            {
                d[0] = meanY - C.Column(0).DotProduct(DenseVector.OfArray(meanX));
            }
            else
            {
                d[0] = 0;
            }
            


            
            //回帰係数//
            double[] para = C.Transpose().ToRowArrays()[0];

            this.coef = (new double[] { d[0] }).ToArray().Concat(para).ToArray();

            //this.coefにNaNの代入(手動チェックするときだけコメントアウト)//
            //this.coef[0] = Double.NaN;

            //out Error Check//
            //700: 出力の予測値にNaNが含まれている//
            helper.Check1D(this.coef, out errorFlag);
            if (errorFlag == 1)
            {
                return Error.FitDataNaNError2;
            }

            return 0;
        }

        public int Predict(double[][] xpre, out double[] ypre)
        {
            int errorFlag;
            //Input Error Check//
            //200: 学習期間と予測期間の説明変数の数は一致していない
            ypre = new double[] { };
            if (xpre[0].Length != this.coef.Length - 1)
            {
                return Error.PredDataSizeError1;
            }
            //201:入力の説明変数にNaNが含まれている
            helper.CheckDouble2D(xpre, out errorFlag);
            if (errorFlag == 1)
            {
                return Error.PredDataNaNError1;
            }


            //モデルの切片//
            double[] c = this.coef;
            double d = c[0];
            //モデルの回帰係数//
            int paraSize = c.Length - 1;
            double[] para = new double[paraSize];
            Array.Copy(c, 1, para, 0, paraSize);
            //jagg配列から2D配列に変換//
            Matrix X = DenseMatrix.OfRowArrays(xpre);
            Matrix Para = DenseMatrix.OfRowArrays(para);
            //予測計算//
            Matrix<double> P = Para.Multiply(X.Transpose()) + d;
            //jagg配列に変換//
            ypre = P.ToRowArrays()[0];

            //ypreにNaNの代入(手動チェックするときだけコメントアウト)//
            //ypre[0] = Double.NaN;

            //out Error Check//
            //300: 出力の予測値にNaNが含まれている//
            helper.Check1D(ypre, out errorFlag);
            if (errorFlag == 1)
            {
                return Error.PredDataNaNError2;
            }

            return 0;
        }

        public int ModPredict(double[] ypre, double[][] modData, int[][] filtTra, int[][] filtPre, out double[] yPreMod, out double[][] confInt, out int[] actMod)
        {
            yPreMod = new double[] { };
            confInt = new double[][] { };
            actMod = new int[] { };
            int errorFlag, errorFlag1, errorFlag2;
            
            //Hyperparameter Error Check//
            int modModeMax = 1;
            //400: 補正用パラメータのサイズは2である必要があります//
            if (modPara.Length != 2)
            {
                return Error.modParaSizeError;
            }
            //401; 補正用パラメータの0列目の値（補正モード）は1以上の整数である必要があります
            if (modPara[0] == 0) //0モードはない
            {
                return Error.modParaError1;
            }
            if (modPara[0] < 0)
            {
                return Error.modParaError1;
            }
            //402: 現在、補正モードはmodModMax=1までしか対応できません//
            if (modPara[0] > modModeMax)
            {
                return Error.modParaError2;
            }
            //403: 「補正モード１による補正を指定したとき、補正用パラメータの1列目の値（区間の幅パラメータ）は、0以上の数である必要があります」
            if (modPara[0] == 1 & modPara[1] == 0)
            {
                return Error.modParaError3;
            }
            //404: 補正用パラメータにNaNが含まれています
            helper.Check1D(modPara, out errorFlag);
            if (errorFlag == 1)
            {
                return Error.modParaNaNError;
            }

            //Input Error Check//
            //405: 補正モードを1に指定したとき、予測期間におけるフィルタリングデータのデータ数と目的変数のデータ数は一致しない//
            if (modPara[0] == 1 & filtPre.Length != ypre.Length)
            {
                return Error.modDataError1;
            }
            //406: 補正モードを1に指定したとき、学習期間におけるフィルタリングデータのデータ数と補正データのデータ数は一致しない//
            if (modPara[0] == 1 & filtTra.Length != modData.Length)
            {
                return Error.modDataError2;
            }
            //407: 補正モードを1に指定したとき、学習期間におけるフィルタリングデータの種類の数（列数）と、予測期間におけるフィルタリングデータの種類の数（列数）は一致しない//
            if (modPara[0] == 1 & filtTra[0].Length != filtPre[0].Length)
            {
                return Error.modDataError3;
            }

            //予測期間のステップ数//
            int T = ypre.Length;
            //フィルタデータのステップ数//
            int TT = filtTra.Length;
            double[] low = new double[T];
            double[] up = new double[T];
            int modMode = (int)modPara[0];

            //正常区間の計算
            for (int t = 0; t < T; t++)
            {
                //予測対象と条件合致する行を抽出し、補正用データから対象行を追加
                double[][] abstModData = Enumerable.Range(0, TT)
                                         .Where(tt => filtTra[tt].SequenceEqual(filtPre[t]))
                                         .Select(tt => modData[tt])
                                         .ToArray();
                //ListからJagg配列に変換
                double[][] Y = DenseMatrix.OfRowArrays(abstModData).Transpose().ToRowArrays();

                if (Y[0].Length > 1)
                {
                    //正常区間の上下限値を計算
                    if (modMode == 1)
                    {
                        //補正パラメータ：正常区間の幅パラメータ//
                        double kappa = modPara[1];
                        double[] y = Y[0];

                        //標準偏差と平均値を計算
                        double mu = y.Mean();
                        double sigma = y.StandardDeviation();

                        //正常区間の上下限値を計算
                        low[t] = mu - kappa * sigma;
                        up[t] = mu + kappa * sigma;

                        //正常区間の上下限値が0以下なら、0に補正
                        low[t] = Math.Max(low[t], 0);
                        up[t] = Math.Max(up[t], 0);
                    }
                }
                //408: 補正モードを1に指定したとき、予測期間におけるフィルタリングデータの各データに対して、学習期間におけるフィルタリングデータの中に合致するデータは一つしかない//
                else
                {
                    return Error.modDataError4;
                }
            }
            //409: 補正用データにNaNが含まれています//
            helper.CheckDouble2D(modData, out errorFlag);
            if (errorFlag == 1)
            {
                return Error.modDataError5;
            }

            //410: 学習期間におけるフィルタリングデータにNaNが含まれています//
            helper.CheckInt2D(filtTra, out errorFlag);
            if (errorFlag == 1)
            {
                return Error.modDataError6;
            }

            //411: 予測期間におけるフィルタリングデータにNaNが含まれています//
            helper.CheckInt2D(filtPre, out errorFlag);
            if (errorFlag == 1)
            {
                return Error.modDataError7;
            }


            //補正済予測値の計算
            //異常判定(異常なら近い正常区間の上下限値に補正)
            yPreMod = Enumerable.Range(0, T)
                             .Select(t => Math.Min(Math.Max(low[t], ypre[t]), up[t]))
                             .ToArray();

            //正常区間
            confInt = DenseMatrix.OfRowArrays(new double[][] { low, up }).Transpose().ToRowArrays();

            //補正フラグ
            actMod = new int[T];
            
            for ( int i = 0; i < T; i++)
            {
                if (low[i] > ypre[i] | ypre[i] > up[i])
                {
                    actMod[i] = 1;
                }
                else
                {
                    actMod[i] = 0;

                }
            }

            //ypreにNaNの代入(手動チェックするときだけコメントアウト)//
            //yPreMod[0] = Double.NaN;

            //500: 補正済予測値にNaNが含まれています
            helper.Check1D(yPreMod, out errorFlag1);
            helper.CheckDouble2D(confInt, out errorFlag2);
            if (errorFlag1 == 1 || errorFlag2 == 1)
            {
                return Error.modPredictError;
            }

            return 0;
        }

        public int Serialize(out string serialized)
        {
            return ModelFactory.Serialize(this, out serialized);
        }

        public int Deserialize(string serialized)
        {

            return ModelFactory.Deserialize(serialized, this);
        }
    }

    [DataContract]
    public class PLSModel : IModel
    {
        [DataMember(IsRequired = true)]
        double[] coef;
        [DataMember(IsRequired = true)]
        double[] modPara;
        [DataMember(IsRequired = true)]
        int numLV;
        //epsilon//
        const double epsSTD = 1E-7;
        const double machineEps = 2.2204460492503131e-16;

        public PLSModel(PLSHyperParameter hp)
        {
            modPara = hp.modPara;
            numLV = hp.numLV;
        }

        private static double InnerProduct(Matrix<double> x, Matrix<double> y)
        {
            double p;return p = x.Transpose().Multiply(y).L2Norm();
        }

        private static void PLSRegression(int comp, Matrix<double> xCal, Matrix<double> yCal, out Matrix<double> C)
        {
            Matrix<double> xScores, yScores, xScoresV, yScoresV, xWeightsV, yWeightsV, xLoadingsV, yLoadingsV;

            //0にならないための残差//
            double eps = 1e-06;

            //サンプル数//
            int n = xCal.RowCount;
            //説明変数の数//
            int p = xCal.ColumnCount;
            //目的変数の数//
            int q = yCal.ColumnCount;

            //配列の初期化//
            double[][] xScoresArray = Enumerable.Repeat<double[]>((Enumerable.Repeat<double>(0, n).ToArray()), comp).ToArray();
            double[][] yScoresArray = Enumerable.Repeat<double[]>((Enumerable.Repeat<double>(0, n).ToArray()), comp).ToArray();

            //Matrixの初期化 T,U//
            xScores = DenseMatrix.OfRowArrays(xScoresArray).Transpose();
            yScores = DenseMatrix.OfRowArrays(yScoresArray).Transpose();

            //残差行列の初期化//
            Matrix<double> ResXk = xCal; Matrix<double> ResYk = yCal;

            double innerProduct;

            for (int k = 0; k < comp; k++)
            {
                if (InnerProduct(yCal, yCal) < machineEps)
                {
                    break;
                }

                //重み推定//
                //yScoresの初期化（uの初期化）//
                //uベクトル（n*1）//
                yScoresV = yCal;

                //xWeightsの更新（wの更新）//
                //wベクトル（p*1）//
                innerProduct = InnerProduct(yScoresV, yScoresV);
                xWeightsV = ResXk.Transpose().Multiply(yScoresV).Divide(innerProduct + eps);
                //xWeightsの正規化（wの正規化）//
                xWeightsV = xWeightsV.Divide(xWeightsV.L2Norm() + eps);

                //xScoresの更新（tの更新）//
                //tベクトル（n*1）//
                xScoresV = ResXk.Multiply(xWeightsV);

                //yWeightsの更新（cの更新）//
                //cベクトル（q*1）//
                innerProduct = InnerProduct(xScoresV, xScoresV);
                yWeightsV = ResYk.Transpose().Multiply(xScoresV).Divide(innerProduct + eps);
                //yWeightsの更新（cの正規化）//
                yWeightsV = yWeightsV.Divide(yWeightsV.L2Norm() + eps);

                //yScoresの更新（uの更新）//
                //uベクトル（n*1）//
                innerProduct = InnerProduct(yWeightsV, yWeightsV);
                yScoresV = ResYk.Multiply(yWeightsV).Divide(innerProduct + eps);

                //xLoadingsの更新（pの更新）//
                //pベクトル（p*1）//
                innerProduct = InnerProduct(xScoresV, xScoresV);
                xLoadingsV = ResXk.Transpose().Multiply(xScoresV).Divide(innerProduct + eps);
                //yLoadingの更新（qの更新）//
                //qベクトル（q*1）//
                innerProduct = InnerProduct(xScoresV, xScoresV);
                yLoadingsV = ResYk.Transpose().Multiply(xScoresV).Divide(innerProduct + eps);

                //Xの残差をxのスコアで回帰//
                //残差行列X(n*p）//
                ResXk = ResXk - xScoresV.Multiply(xLoadingsV.Transpose());
                //Yの残差をxのスコアで回帰//
                //残差行列Y(n*q）//
                ResYk = ResYk - xScoresV.Multiply(yLoadingsV.Transpose());

                //スコアのベクトルとして保存//
                xScoresArray[k] = xScoresV.Transpose().ToRowArrays()[0];
                yScoresArray[k] = yScoresV.Transpose().ToRowArrays()[0];
            }
            //行列T（n*comp）=[t1,t2,…,tcomp]//
            xScores = DenseMatrix.OfRowArrays(xScoresArray).Transpose();
            //行列U（n*comp）=[u1,u2,…,ucomp]//
            yScores = DenseMatrix.OfRowArrays(yScoresArray).Transpose();

            //逆行列//
            Matrix<double> E = (xScores.Transpose().Multiply(xCal).Multiply(xCal.Transpose()).Multiply(yScores)).PseudoInverse();
            for (int i = 0; i < E.RowCount; i++)
            {
                for (int j = 0; j < E.ColumnCount; j++)
                {
                    if (Double.IsNaN(E[i, j]))
                    {
                        E[i, j] = 0;
                    }
                }
            }
            //Xの回帰係数//
            C = xCal.Transpose().Multiply(yScores).Multiply(E).Multiply(xScores.Transpose()).Multiply(yCal);
        }

        public int Fit(double[][] xtra, double[] ytra)
        {
            int errorFlag, errorFlag1, errorFlag2;

            //Input Error Check//
            //100: 説明変数のデータ数と目的変数のデータ数が一致していない//
            if (xtra.Length != ytra.Length)
            {
                return Error.FitDataSizeError1;
            }
            //111: 潜在変数の数と説明変数の数が一致する場合、説明変数のデータ数と目的変数のデータ数は説明変数の数より多い必要がある//
            if (numLV == xtra[0].Length && ((xtra[0].Length >= xtra.Length) || (xtra[0].Length >= ytra.Length)))
            {
                return Error.FitDataSizeError3;
            }
            //112: 説明変数のデータ数と目的変数のデータ数は2以上である必要がある//
            if (xtra.Length < 2 || ytra.Length < 2)
            {
                return Error.FitDataSizeError4;
            }
            //102:説明変数あるいは目的変数にNaNが含まれている//
            helper.CheckDouble2D(xtra, out errorFlag1);
            helper.Check1D(ytra, out errorFlag2);
            if (errorFlag1 == 1 || errorFlag2 == 1)
            {
                return Error.FitDataNaNError1;
            }

            //103:入力のPLS潜在変数の数が0//
            if (numLV == 0 || numLV > xtra[0].Length)
            {
                return Error.PLSHpyperparameterError;
            }
            else if (Double.IsNaN(numLV))
            {
                return Error.PLSHpyperparameterNaNError;
            }

            Matrix<double> C, D, X, Y, xCal, yCal;
            double[] para, modelModedouble, d;
            int comp, n, p, q, scaling_flag, centering_flag;

            //jagg配列から2D配列に変換//
            X = DenseMatrix.OfRowArrays(xtra);
            Y = DenseMatrix.OfRowArrays(ytra).Transpose();

            //サンプル数//
            n = X.RowCount;
            //説明変数の数//
            p = X.ColumnCount;
            //目的変数の数//
            q = Y.ColumnCount;

            //centering and scaling//
            centering_flag = 1;
            scaling_flag = 1;

            double meanY = Statistics.Mean(ytra);
            double stdY = Statistics.StandardDeviation(ytra);

            if (Math.Abs(stdY / meanY) < epsSTD)
            {
                stdY = 1;
            }

            double[] meanX = new double[p];
            double[] stdX = new double[p];
            double[][] xTemp = X.Transpose().ToRowArrays();
            for (int j = 0; j < p; j++)
            {
                stdX[j] = Statistics.StandardDeviation(xTemp[j]);
                meanX[j] = Statistics.Mean(xTemp[j]);
                if (Math.Abs(stdX[j] / meanX[j]) < epsSTD)
                {
                    stdX[j] = 1;
                }
            }

            helper.CenteringScaling(X, Y, meanX, meanY, stdX, stdY, centering_flag, scaling_flag, out xCal, out yCal);

            //初期化//
            C = DenseMatrix.OfRowArrays(Enumerable.Repeat<double>(0, p).ToArray());
            modelModedouble = Enumerable.Repeat<double>(0, 1).ToArray();
            d = Enumerable.Repeat<double>(0, 1).ToArray();

            //潜在変数の数の取得//
            comp = numLV;


            //PLS//
            PLSRegression(comp, xCal, yCal, out C);

            //scaling//
            if (scaling_flag == 1)
            {
                double[][] cTemp = C.ToRowArrays();
                for (int j = 0; j < p; j++)
                {
                    cTemp[j][0] = cTemp[j][0] / stdX[j] * stdY;
                }
                C = DenseMatrix.OfRowArrays(cTemp);
            }

            //切片//
            if (centering_flag == 1)
            {
                d[0] = meanY - C.Column(0).DotProduct(DenseVector.OfArray(meanX));
            }
            else
            {
                d[0] = 0;
            }

            //回帰係数//
            para = C.Transpose().ToRowArrays()[0];

            this.coef = (new double[] { d[0] }).ToArray().Concat(para).ToArray();

            //this.coefにNaNの代入(手動チェックするときだけコメントアウト)//
            //this.coef[0] = Double.NaN;

            //out Error Check//
            //700: 出力の予測値にNaNが含まれている//
            helper.Check1D(this.coef, out errorFlag);
            if (errorFlag == 1)
            {
                return Error.FitDataNaNError2;
            }

            return 0;
        }

        public int Predict(double[][] xpre, out double[] ypre)
        {
            int errorFlag;

            //Input Error Check//
            ypre = new double[] { };

            //201:入力の説明変数にNaNが含まれている
            helper.CheckDouble2D(xpre, out errorFlag);
            if (errorFlag == 1)
            {
                return Error.PredDataNaNError1;
            }

            //200:PLS回帰による予測において、説明変数の数と回帰係数の数が一致していない//
            if (xpre[0].Length != (this.coef.Length - 1))
            {
                return Error.PredDataSizeError1;
            }

            //モデルの切片//
            double[] c = this.coef;
            double d = c[0];
            //モデルの回帰係数//
            int paraSize = c.Length - 1;
            double[] para = new double[paraSize];
            Array.Copy(c, 1, para, 0, paraSize);
            //jagg配列から2D配列に変換//
            Matrix X = DenseMatrix.OfRowArrays(xpre);
            Matrix Para = DenseMatrix.OfRowArrays(para);
            //予測計算//
            Matrix<double> P = Para.Multiply(X.Transpose()) + d;
            //jagg配列に変換//
            ypre = P.ToRowArrays()[0];


            //ypreにNaNの代入(手動チェックするときだけコメントアウト)//
            //ypre[0] = Double.NaN;

            //Output Error Check//
            //400:予測値にNaNが含まれている//
            helper.Check1D(ypre, out errorFlag);
            if (errorFlag == 1)
            {
                return Error.PredDataNaNError2;
            }

            return 0;
        }

        public int ModPredict(double[] ypre, double[][] modData, int[][] filtTra, int[][] filtPre, out double[] yPreMod, out double[][] confInt, out int[] actMod)
        {
            yPreMod = new double[] { };
            confInt = new double[][] { };
            actMod = new int[] { };
            int errorFlag, errorFlag1, errorFlag2;

            //Hyperparameter Error Check//
            int modModeMax = 1;
            //400: 補正用パラメータのサイズは2である必要があります//
            if (modPara.Length != 2)
            {
                return Error.modParaSizeError;
            }
            //401; 補正用パラメータの0列目の値（補正モード）は1以上の整数である必要があります
            if (modPara[0] == 0) //0モードはない
            {
                return Error.modParaError1;
            }
            if (modPara[0] < 0)
            {
                return Error.modParaError1;
            }
            //402: 現在、補正モードはmodModMax=1までしか対応できません//
            if (modPara[0] > modModeMax)
            {
                return Error.modParaError2;
            }
            //403: 「補正モード１による補正を指定したとき、補正用パラメータの1列目の値（区間の幅パラメータ）は、0以上の数である必要があります」
            if (modPara[0] == 1 & modPara[1] == 0)
            {
                return Error.modParaError3;
            }
            //404: 補正用パラメータにNaNが含まれています
            helper.Check1D(modPara, out errorFlag);
            if (errorFlag == 1)
            {
                return Error.modParaNaNError;
            }

            //Input Error Check//
            //405: 補正モードを1に指定したとき、予測期間におけるフィルタリングデータのデータ数と目的変数のデータ数は一致しない//
            if (modPara[0] == 1 & filtPre.Length != ypre.Length)
            {
                return Error.modDataError1;
            }
            //406: 補正モードを1に指定したとき、学習期間におけるフィルタリングデータのデータ数と補正データのデータ数は一致しない//
            if (modPara[0] == 1 & filtTra.Length != modData.Length)
            {
                return Error.modDataError2;
            }
            //407: 補正モードを1に指定したとき、学習期間におけるフィルタリングデータの種類の数（列数）と、予測期間におけるフィルタリングデータの種類の数（列数）は一致しない//
            if (modPara[0] == 1 & filtTra[0].Length != filtPre[0].Length)
            {
                return Error.modDataError3;
            }

            //予測期間のステップ数//
            int T = ypre.Length;
            //フィルタデータのステップ数//
            int TT = filtTra.Length;
            double[] low = new double[T];
            double[] up = new double[T];
            int modMode = (int)modPara[0];

            //正常区間の計算
            for (int t = 0; t < T; t++)
            {
                //予測対象と条件合致する行を抽出し、補正用データから対象行を追加
                double[][] abstModData = Enumerable.Range(0, TT)
                                         .Where(tt => filtTra[tt].SequenceEqual(filtPre[t]))
                                         .Select(tt => modData[tt])
                                         .ToArray();
                //ListからJagg配列に変換
                double[][] Y = DenseMatrix.OfRowArrays(abstModData).Transpose().ToRowArrays();

                if (Y[0].Length > 1)
                {
                    //正常区間の上下限値を計算
                    if (modMode == 1)
                    {
                        //補正パラメータ：正常区間の幅パラメータ//
                        double kappa = modPara[1];
                        double[] y = Y[0];

                        //標準偏差と平均値を計算
                        double mu = y.Mean();
                        double sigma = y.StandardDeviation();

                        //正常区間の上下限値を計算
                        low[t] = mu - kappa * sigma;
                        up[t] = mu + kappa * sigma;

                        //正常区間の上下限値が0以下なら、0に補正
                        low[t] = Math.Max(low[t], 0);
                        up[t] = Math.Max(up[t], 0);
                    }
                }
                //408: 補正モードを1に指定したとき、予測期間におけるフィルタリングデータの各データに対して、学習期間におけるフィルタリングデータの中に合致するデータは一つしかない//
                else
                {
                    return Error.modDataError4;
                }
            }
            //409: 「補正用データにNaNが含まれています」//
            helper.CheckDouble2D(modData, out errorFlag);
            if (errorFlag == 1)
            {
                return Error.modDataError5;
            }

            //補正済予測値の計算
            //異常判定(異常なら近い正常区間の上下限値に補正)
            yPreMod = Enumerable.Range(0, T)
                             .Select(t => Math.Min(Math.Max(low[t], ypre[t]), up[t]))
                             .ToArray();

            //正常区間
            confInt = DenseMatrix.OfRowArrays(new double[][] { low, up }).Transpose().ToRowArrays();

            //補正フラグ
            actMod = new int[T];

            for (int i = 0; i < T; i++)
            {
                if (low[i] > ypre[i] | ypre[i] > up[i])
                {
                    actMod[i] = 1;
                }
                else
                {
                    actMod[i] = 0;

                }
            }

            //ypreにNaNの代入(手動チェックするときだけコメントアウト)//
            //yPreMod[0] = Double.NaN;

            //500: 補正済予測値にNaNが含まれています
            helper.Check1D(yPreMod, out errorFlag1);
            helper.CheckDouble2D(confInt, out errorFlag2);
            if (errorFlag1 == 1 || errorFlag2 == 1)
            {
                return Error.modPredictError;
            }

            return 0;
        }

        public int Serialize(out string serialized)
        {
            return ModelFactory.Serialize(this, out serialized);
        }

        public int Deserialize(string serialized)
        {
            return ModelFactory.Deserialize(serialized, this);
        }

    }

    [DataContract]
    public class RFModel:IModel
    {
        List<List<Node>> forest;
        // ノード数が非常に大きくなりうるので、シリアライズ結果のサイズを抑えるため、
        // XMLではなくコンパクトな表現でシリアライズする。
        // forestStrはそのための文字列で、Serialize/Deserializeの中だけで使用し、
        // それ以外の場面では常にnullを取る。
        // (C#の文字列はUTF-16で最大サイズが2 GBなので、1 G文字が最大という制約もある。)
        [DataMember(IsRequired = true, Name = "forest1")]
        string forestStr;
        [DataMember(IsRequired = true)]
        double[] modPara;
        [DataMember(IsRequired = true)]
        int numTree, numMinSplit;
        [DataMember(IsRequired = true)]
        Nullable<int> numMaxDepth;
        [DataMember(IsRequired = true)]
        int numFeature;
        
        public RFModel(RFHyperParameter hp)
        {
            modPara = hp.modPara;
            numTree = hp.numTree;
            numMaxDepth = hp.numMaxDepth;
            numMinSplit = hp.numMinSplit;
            numFeature = 0;
        }

        private class BootstrapSampling
        {
            internal int resamplingSize { get; set; }
            internal int featureSamplingMode { get; set; }
            List<double> featureWeights;
            Random rng;

            internal BootstrapSampling()
            {
                this.resamplingSize = 0;
                this.featureSamplingMode = 0;
                this.featureWeights = new List<double>();
                rng = new Random();
            }

            internal double getFeatureWeights(int indexNumber)
            {
                return this.featureWeights[indexNumber];
            }

            internal void setFeatureWeights(int indexNumber, double value)
            {
                this.featureWeights[indexNumber] = value;
            }

            internal void addFeatureWeights(double value)
            {
                this.featureWeights.Add(value);
            }

            internal int getFeatureWeightsCount()
            {
                return this.featureWeights.Count;
            }


            internal int Resampling(double[][] x_train, double[] y_train, int selectedFeatureSize, out double[][] bootstrap_x, out double[] bootstrap_y)
            {
                bootstrap_x = null;
                bootstrap_y = null;

                int status = 0;

                int sampleSize = x_train.Length;
                List<int> resampleIndexes;
                int featureSize = x_train[0].Length;
                List<int> selectedFeatureIndexes;


                // サンプルのインデックスの抽出
                status = getResampleIndex(sampleSize, out resampleIndexes);
                if (status != 0)
                {
                    return status;
                }

                // 特徴量のインデックスの抽出
                status = getFeatureIndex(featureSize, selectedFeatureSize, out selectedFeatureIndexes);
                if(status != 0)
                {
                    return status;
                }

                // 抽出されたサンプルと特徴量のインデックスに基づいたリサンプリングの実施
                status = getResample(x_train, y_train, resampleIndexes, selectedFeatureIndexes, out bootstrap_x, out bootstrap_y);
                if(status != 0)
                {
                    return status;
                }

                return 0;
            }

            private int getResampleIndex(int sampleSize, out List<int> resampleIndexes)
            {
                int status = 0;

                int resamplingSize;
                if (this.resamplingSize == 0)
                {
                    resamplingSize = sampleSize;    // 抽出されるサンプルの数が未設定の場合、元のサンプル数とする
                }
                else
                {
                    resamplingSize = this.resamplingSize;
                }

                // 一様な出現確率（重み）の復元抽出
                SamplingWithReplacement samplingWithReplacement = new SamplingWithReplacement();
                status = samplingWithReplacement.UniformedRandomSampling(rng, sampleSize, resamplingSize, out resampleIndexes);
                if(status != 0)
                {
                    return status;
                }

                return 0;
            }

            private int getFeatureIndex(int featureSize, int selectedFeatureSize, out List<int> selectedFeatureIndexes)
            {
                int status = 0;

                double defaultFeatureWeight = 1.0;

                SamplingWithoutReplacement samplingWithoutReplacement = new SamplingWithoutReplacement();
                if (this.featureSamplingMode == 0)
                {
                    // 一様な出現確率（重み）の非復元抽出
                    status = samplingWithoutReplacement.UiniformedRandomSampling(rng, featureSize, selectedFeatureSize, out selectedFeatureIndexes);
                    if (status != 0)
                    {
                        return status;
                    }
                }
                else
                {
                    // 重み付き非復元抽出
                    List<double> featureWeights = new List<double>();
                    if (this.getFeatureWeightsCount() == 0)
                    {
                        for (int i = 0; i < featureSize; i++)
                        {
                            featureWeights.Add(defaultFeatureWeight);   // 特徴量の重みが設定されていない場合、全て 1.0 とする
                        }
                    }
                    status = samplingWithoutReplacement.WeightedRandomSampling(rng, featureSize, featureWeights, selectedFeatureSize, out selectedFeatureIndexes);
                    if (status != 0)
                    {
                        return status;
                    }
                }

                return 0;
            }

            private int getResample(double[][] x_train, double[] y_train, List<int> resampleIndexes, List<int> selectedFeatureIndexes, out double[][] bootstrap_x, out double[] bootstrap_y)
            {
                bootstrap_x = new double[resampleIndexes.Count][];
                for (int i = 0; i < resampleIndexes.Count; i++)
                {
                    bootstrap_x[i] = new double[selectedFeatureIndexes.Count];
                }
                bootstrap_y = new double[resampleIndexes.Count];

                int row = 0;
                foreach(int resampleIndex in resampleIndexes)
                {
                    int colum = 0;
                    foreach(int selectedFeatureIndex in selectedFeatureIndexes)
                    {
                        bootstrap_x[row][colum] = x_train[resampleIndex][selectedFeatureIndex];

                        colum++;
                    }
                    bootstrap_y[row] = y_train[resampleIndex];

                    row++;
                }

                return 0;
            }

            private class SamplingWithReplacement
            {
                // 一様な出現確率（重み）の復元抽出
                internal int UniformedRandomSampling(Random rng, int sampleSize, int resampleSize, out List<int> resampleIndexes)
                {
                    resampleIndexes = new List<int>();

                    // resampleSize 抽出されるサンプルの数のチェック
                    if (resampleSize < 0)
                    {
                        return Error.RFResampleNegativeError;
                    }

                    // sampleSize と resampleSize の大小関係のチェック
                    if (sampleSize < resampleSize)
                    {
                        return Error.RFResampleSizeError;
                    }

                    // サンプリング
                    for (int i = 0; i < resampleSize; i++)
                    {
                        int selectedIndex = rng.Next(sampleSize);
                        resampleIndexes.Add(selectedIndex);
                    }
                    
                    return 0;
                }
            }

            private class SamplingWithoutReplacement
            {
                // 一様な出現確率（重み）の非復元抽出
                internal int UiniformedRandomSampling(Random rng, int featureSize, int selectedFeatureSize, out List<int> selectedFeatureIndexes)
                {
                    selectedFeatureIndexes = new List<int>();

                    // selectedFeatureSize 抽出される特徴量の数のチェック
                    if (selectedFeatureSize == 0)
                    {
                        return Error.RFSelectedFeatureZeroError;
                    }

                    // featureSize と selectedFeatureSize の大小関係のチェック
                    if (featureSize < selectedFeatureSize)
                    {
                        return Error.RFSelectedFeatureSizeError;
                    }

                    // サンプリング　Selection sampling technique by Knuth
                    int n = selectedFeatureSize;
                    int N = featureSize;

                    int t = 0;
                    int m = 0;
                    double U;

                    while (m < n)
                    {
                        U = rng.NextDouble();

                        if ((N - t) * U >= n - m)
                        {
                            t++;
                        }
                        else
                        {
                            selectedFeatureIndexes.Add(t);
                            t++;
                            m++;
                        }
                    }

                    return 0;
                }

                // 重み付き非復元抽出　（未実装）
                internal int WeightedRandomSampling(Random rng, int featureSize, List<double> featureWeights, int selectedFeatureSize, out List<int> selectedFeatureIndexes)
                {
                    selectedFeatureIndexes = new List<int>();

                    for (int i = 0; i < featureSize; i++)
                    {
                        selectedFeatureIndexes.Add(i);
                    }

                    return 0;
                }
            }
        }

        private void BuildForest(double[][] xtra, double[] ytra, int numTree, int numMinSplit, Nullable<int> numMaxDepth)//森の学習//
        {
            int selectedFeature = xtra[0].Length;
            numFeature = selectedFeature;
            double[][] bootstrap_x;
            double[] bootstrap_y;
            forest = new List<List<Node>>(numTree) { };
            BootstrapSampling bs = new BootstrapSampling();
            DecisionTree dt = new DecisionTree(numMinSplit, numMaxDepth);
            for (int i = 0; i < numTree; i++)
            {
                bs.Resampling(xtra, ytra, selectedFeature, out bootstrap_x, out bootstrap_y);
                dt.BuildTree(bootstrap_x, bootstrap_y, out List<Node> treeModel);
                forest.Add(treeModel);
            }
        }

        private void ForestPredict(List<List<Node>> forest, double[][] xpre, out double[] ypre)//森の予測//
        {
            double[] yy = new double[numTree];
            ypre = new double[xpre.Length];
            DecisionTree dt = new DecisionTree(numMinSplit, numMaxDepth);
            for (int i = 0; i < xpre.Length; i++)
            {
                for (int j = 0; j < numTree; j++)
                {
                    dt.TreePredict(forest[j], xpre[i], out yy[j]);
                }
                ypre[i] = Enumerable.Average(yy);
            }
        }

        private class DecisionTree //決定木クラス//
        {
            int numMinSplit;
            Nullable<int> numMaxDepth;

            internal DecisionTree(int numMinSplit, Nullable<int> numMaxDepth)
            {
                this.numMinSplit = numMinSplit;
                this.numMaxDepth = numMaxDepth;
            }

            internal void BuildTree(double[][] bootstrap_x, double[] bootstrap_y, out List<Node> tree)//決定木学習//
            {
                int k = 0;
                int depth = 0;
                int last_k_in_this_depth = 0;
                tree = new List<Node> { new Node() };
                // rootノードは、0から(bootstrap_x.Length - 1)までのすべてのrowから始める。
                tree[0].rows = Enumerable.Range(0, bootstrap_x.Length).ToList();
                tree[0].predicted = Avg(bootstrap_y, tree[0].rows);
                tree[0].isFeatureConstant = new bool[bootstrap_x[0].Length];
                int a = bootstrap_x[0].Length;

                while (true)
                {
                    tree[k].rowsCount = tree[k].rows.Count;

                    bool SplitFlag = false;
                    if (this.numMaxDepth != null)
                    {
                        if (tree[k].rows.Count >= 2)
                        {
                            SplitFlag = true;
                        }
                    }
                    else
                    {
                        if (tree[k].rows.Count >= this.numMinSplit)
                        {
                            SplitFlag = true;
                        }
                    }

                    if (SplitFlag)
                    {
                        SplitInfo si = GetInfo(bootstrap_x, bootstrap_y, tree[k]); //ノード分岐用メソッド
                        if (si.lessRows.Count > 0 && si.greaterRows.Count > 0)
                        {
                            tree[k].SplitCol = si.splitCol;
                            tree[k].SplitVal = si.splitVal;
                            int leftChild = tree.Count;
                            int rightChild = tree.Count + 1;
                            tree[k].leftNode = leftChild;
                            tree[k].rightNode = rightChild;
                            // Fitで生成されたモデルとDeserializeで生成されたモデルの挙動をなるべく合わせるため、non-leafノードのpredictedはクリアする。
                            tree[k].predicted = 0;
                            tree.Add(new Node());
                            tree.Add(new Node());
                            tree[leftChild].rows = si.lessRows;
                            tree[rightChild].rows = si.greaterRows;
                            tree[leftChild].predicted = si.leftYmean;
                            tree[rightChild].predicted = si.rightYmean;
                            // 親のisFeatureConstantはもう使わず後でnullにするので、片方の子供にはコピーせず渡してよい。
                            tree[leftChild].isFeatureConstant = (bool[])tree[k].isFeatureConstant.Clone();
                            tree[rightChild].isFeatureConstant = tree[k].isFeatureConstant;
                        }
                        else
                            tree[k].rowsCount = -tree[k].rows.Count;//numMinSplitを満たしていないがそれ以上分割できない例外
                    }
                    // メモリ節約のため、分割点の決定後は親側の情報は消す。
                    tree[k].rows = null;
                    tree[k].isFeatureConstant = null;

                    if (k == last_k_in_this_depth)//depthの更新
                    {
                        depth++;
                        last_k_in_this_depth = tree.Count - 1;
                    }

                    // numMaxDepthによる終了判定。
                    if (this.numMaxDepth != null && depth == this.numMaxDepth)
                    {
                        // この先のノードに対する処理は行わないが、メモリ節約のため分割点決定用の情報を消す。
                        for (k++; k < tree.Count; k++)
                        {
                            tree[k].rows = null;
                            tree[k].isFeatureConstant = null;
                        }
                        break;
                    }
                    // すべてのノードの分割判定を終えたので、終了。
                    // numMinSplitによって終了する場合は、この条件にマッチする。
                    // numMaxDepthが指定された場合でも、これ以上分割できなくなったらこの条件にマッチする。
                    if (k == tree.Count - 1)
                    {
                        break;
                    }
                    k++;
                }
            }

            static double Avg(double[] y, List<int> rows)
            {
                double ysum = 0;
                if (rows != null)
                {
                    for (int iy = 0; iy < rows.Count; iy++)
                    {
                        ysum += y[rows[iy]];
                    }
                    return ysum / rows.Count;
                }
                else
                    return 0;
            }

            static SplitInfo GetInfo(double[][] dataX, double[] dataY, Node node)
            {
                SplitInfo result = new SplitInfo();
                int n = dataX[0].Length;
                double bestSplitVal = 0.0;
                int bestSplitCol = 0;
                List<int> bestRightIndex = new List<int>();
                List<int> bestLeftIndex = new List<int>();
                double bestE = double.MaxValue;
                double bestLeftYMean = double.NaN;
                double bestRightYMean = double.NaN;
                int[] rows = node.rows.ToArray();
                int numRow = rows.Length;
                double[] keys = new double[numRow];
                double[] cumsumY = new double[numRow + 1];

                for (int j = 0; j < n; ++j)
                {
                    if (node.isFeatureConstant[j] == true)
                        continue;
                    // rowsを着目しているxの変数の大小で並び替える。
                    for (int i = 0; i < numRow; i++)
                    {
                        keys[i] = dataX[rows[i]][j];
                    }
                    Array.Sort(keys, rows);

                    // yの累積和計算
                    // これをあらかじめ計算しておくことで、左側と右側のyの平均値を計算するときにループが不要になる。
                    cumsumY[0] = 0;
                    for (int i = 0; i < numRow; i++)
                    {
                        cumsumY[i + 1] = cumsumY[i] + dataY[rows[i]];
                    }
                    // 評価関数の初期値を計算 (すべてのノードを右側に分割した場合を計算)
                    // 分割点を変えた時に評価関数を再計算するのではなく、前回の分割点からの
                    // 差分を計算することで、ループ計算をを不要にする。
                    double prevLeftMean = 0;
                    double prevRightMean = cumsumY.Last() / numRow;
                    double Eleft = 0;
                    double Eright = 0;
                    int prevIdx = 0;
                    foreach (int idx in rows)
                    {
                        double err = dataY[idx] - prevRightMean;
                        Eright += err * err;
                    }

                    for (int i = 1; i < numRow; i++)
                    {
                        // 値が同じであればそこでsplitされることはあり得ないので飛ばす。
                        if (dataX[rows[i]][j] == dataX[rows[i - 1]][j])
                            continue;
                        double splitVal = dataX[rows[i]][j];

                        double leftMean = cumsumY[i] / i;
                        double rightMean = (cumsumY[numRow] - cumsumY[i]) / (numRow - i);

                        // 前回の評価値 sum_i (y_i - yavg_old)^2 を、
                        // 新たな評価値 sum_i (y_i - yavg_new)^2 に更新する。差分は次の通り。
                        // sum_i (y_i - yavg_new)^2 - sum_i (y_i - yavg_old)^2
                        //   = sum_i (y_i^2 - 2 * y_i * yavg_new + yavg_new^2) - sum_i (y_i^2 - 2 * y_i * y_avg_old + y_avg_old^2)
                        //   = sum_i {yavg_new^2 - yavg_old^2 - 2 * y_i * (yavg_new - y_avg_old)}
                        //   = (yavg_new - yavg_old) * {(yavg_new + yavg_old) * N - 2 * sum_i y_i}
                        // ここで、sum_i y_i は、cumsumY を用いることでループなしで計算できる。
                        // yavg_old と yavg_new はそれぞれ以下の通り。
                        //   左側の子ノードの部分: prevLeftMean  --> leftMean
                        //   右から左に移った部分: prevRightMean --> leftMean
                        //   右側の子ノードの部分: prevRightMean --> rightMean
                        // 右から左に移った部分については、EleftとErightが分かれている都合上、
                        // 差分計算をせずにループで再計算しているが、速度に大きな影響はなさそう。
                        // (計算量オーダーの評価的にも、移る部分は支配的でない。)
                        Eleft += (leftMean - prevLeftMean) * ((leftMean + prevLeftMean) * prevIdx - 2 * cumsumY[prevIdx]);
                        for (int t = prevIdx; t < i; t++)
                        {
                            double yt = dataY[rows[t]];
                            double err = yt - leftMean;
                            Eleft += err * err;
                            err = yt - prevRightMean;
                            Eright -= err * err;
                        }
                        Eright += (rightMean - prevRightMean) * ((rightMean + prevRightMean) * (numRow - i) - 2 * (cumsumY[numRow] - cumsumY[i]));
                        prevIdx = i;
                        prevLeftMean = leftMean;
                        prevRightMean = rightMean;

                        double E = (Eleft + Eright) / numRow;

                        if (E < bestE)
                        {
                            bestLeftIndex = new ArraySegment<int>(rows, 0, i).ToList();
                            bestRightIndex = new ArraySegment<int>(rows, i, numRow - i).ToList();
                            bestE = E;
                            bestSplitVal = splitVal;
                            bestSplitCol = j;
                            bestLeftYMean = leftMean;
                            bestRightYMean = rightMean;
                        }
                    }
                    // prevIdx == 0 でループを抜けたということは、すべてのXが同じだったということ。
                    // 子ノードにおいて、この変数で分割を試すのは (時間コストの高いソート処理が) 無駄
                    // なので覚えておいてスキップする。
                    if (prevIdx == 0)
                        node.isFeatureConstant[j] = true;
                }

                result.splitVal = bestSplitVal;
                result.splitCol = bestSplitCol;
                result.lessRows = bestLeftIndex;
                result.greaterRows = bestRightIndex;
                result.leftYmean = bestLeftYMean;
                result.rightYmean = bestRightYMean;
                return result;
            }

            internal void TreePredict(List<Node> tree, double[] xpre, out double ypre)//決定木予測//
            {
                Node currNode = tree[0];
                while (true)
                {
                    if (xpre[currNode.SplitCol] < currNode.SplitVal)
                    {
                        if (currNode.leftNode == 0)
                            break;
                        currNode = tree[currNode.leftNode];
                    }
                    else
                    {
                        if (currNode.rightNode == 0)
                            break;
                        currNode = tree[currNode.rightNode];
                    }
                }
                ypre = currNode.predicted;
            }
            
            class SplitInfo
            {
                internal int splitCol;
                internal double splitVal;
                internal List<int> lessRows;
                internal List<int> greaterRows;
                internal double leftYmean;
                internal double rightYmean;
            }
        }

        // leafノードでは、leftNodeとrightNodeは0なので、EmitDefaultValue = falseにして容量を節約する。
        // leafではさらにSplitVal, SplitColにも意味はなく、non-leafではpredictedに意味がないので、
        // これらにもEmitDefaultValueを指定するのもありうるが、意味がある場合にたまたま
        // デフォルト値が入っているものまで省略されてしまうのは分かりにくいので、指定していない。
        [DataContract(Name = "Node")]
        internal class Node
        {
            [DataMember(IsRequired = true, Name = "V")]
            internal double SplitVal;
            [DataMember(IsRequired = true, Name = "F")]
            internal int SplitCol;
            [DataMember(IsRequired = true, Name = "P")]
            internal double predicted;
            [DataMember(IsRequired = false, Name = "L", EmitDefaultValue = false)]
            internal int leftNode;
            [DataMember(IsRequired = false, Name = "R", EmitDefaultValue = false)]
            internal int rightNode;
            internal List<int> rows;
            internal int rowsCount;
            internal bool[] isFeatureConstant;
        }

        public int Fit(double[][] xtra, double[] ytra)
        {
            int errorFlag1, errorFlag2;

            //Input Error Check//
            //100: 説明変数のデータ数と目的変数のデータ数が一致していない//
            if (xtra.Length != ytra.Length)
            {
                return Error.FitDataSizeError1;
            }
            //102:説明変数あるいは目的変数にNaNが含まれている//
            helper.CheckDouble2D(xtra, out errorFlag1);
            helper.Check1D(ytra, out errorFlag2);
            if (errorFlag1 == 1 || errorFlag2 == 1)
            {
                return Error.FitDataNaNError1;
            }

            //105: 説明変数のデータ数と目的変数のデータ数は2以上の整数かつRFの分岐条件のデータ数より大きい必要がある//
            if (xtra.Length < 2 || ytra.Length < 2 || xtra.Length < numMinSplit || ytra.Length < numMinSplit)
            {
                return Error.RFDataSizeError;
            }
            //106: RFの木の数は1以上の整数であることが必要//
            if (numTree < 1)
            {
                return Error.RFHpyperparameterError1;
            }
            //107: RFの木の数はNaNになっている//
            if (Double.IsNaN(numTree))
            {
                return Error.RFHpyperparameterNaNError1;
            }
            //108: RFの分岐条件のデータ数は1以上の整数であることが必要//
            if (numMinSplit < 1)
            {
                return Error.RFHpyperparameterError2;
            }
            //109: RFの分岐条件のデータ数はNaNになっている//
            if (Double.IsNaN(numMinSplit))
            {
                return Error.RFHpyperparameterNaNError2;
            }
            //110: RFの木の深さは1以上の整数かNaNであることが必要。ただし、NaNに設定した場合、各葉ノードに含まれるデータ数がRFの分岐条件のデータ数もしくは単一データまでRFの木の深さを伸ばす//
            if (numMaxDepth < 1)
            {
                return Error.RFHpyperparameterError3;
            }

            BuildForest(xtra, ytra, numTree, numMinSplit, numMaxDepth);

            return 0;
        }

        public int Predict(double[][] xpre, out double[] ypre)
        {
            int errorFlag;
            ypre = new double[] { };

            //Input Error Check//
            //200: 学習期間と予測期間の説明変数の数は一致している必要があります//
            if (this.numFeature != xpre[0].Length)
                return Error.PredDataSizeError1;

            //201: 説明変数にNaNが含まれています
            helper.CheckDouble2D(xpre, out errorFlag);
            if (errorFlag == 1)
            {
                return Error.PredDataNaNError1;
            }
            
            ForestPredict(this.forest, xpre, out ypre);
            

            //ypreにNaNの代入(手動チェックするときだけコメントアウト)//
            //ypre[0] = Double.NaN;

            //Output Error Check//
            //400:予測値にNaNが含まれている//
            helper.Check1D(ypre, out errorFlag);
            if (errorFlag == 1)
            {
                return Error.PredDataNaNError2;
            }

            return 0;
        }

        public int ModPredict(double[] ypre, double[][] modData, int[][] filtTra, int[][] filtPre, out double[] yPreMod, out double[][] confInt, out int[] actMod)
        {
            yPreMod = new double[] { };
            confInt = new double[][] { };
            actMod = new int[] { };
            int errorFlag, errorFlag1, errorFlag2;

            //Hyperparameter Error Check//
            int modModeMax = 1;
            //400: 補正用パラメータのサイズは2である必要があります//
            if (modPara.Length != 2)
            {
                return Error.modParaSizeError;
            }
            //401; 補正用パラメータの0列目の値（補正モード）は1以上の整数である必要があります
            if (modPara[0] == 0) //0モードはない
            {
                return Error.modParaError1;
            }
            if (modPara[0] < 0)
            {
                return Error.modParaError1;
            }
            //402: 現在、補正モードはmodModMax=1までしか対応できません//
            if (modPara[0] > modModeMax)
            {
                return Error.modParaError2;
            }
            //403: 「補正モード１による補正を指定したとき、補正用パラメータの1列目の値（区間の幅パラメータ）は、0以上の数である必要があります」
            if (modPara[0] == 1 & modPara[1] == 0)
            {
                return Error.modParaError3;
            }

            //404: 補正用パラメータにNaNが含まれています
            helper.Check1D(modPara, out errorFlag);
            if (errorFlag == 1)
            {
                return Error.modParaNaNError;
            }

            //Input Error Check//
            //405: 補正モードを1に指定したとき、予測期間におけるフィルタリングデータのデータ数と目的変数のデータ数は一致しない//
            if (modPara[0] == 1 & filtPre.Length != ypre.Length)
            {
                return Error.modDataError1;
            }
            //406: 補正モードを1に指定したとき、学習期間におけるフィルタリングデータのデータ数と補正データのデータ数は一致しない//
            if (modPara[0] == 1 & filtTra.Length != modData.Length)
            {
                return Error.modDataError2;
            }
            //407: 補正モードを1に指定したとき、学習期間におけるフィルタリングデータの種類の数（列数）と、予測期間におけるフィルタリングデータの種類の数（列数）は一致しない//
            if (modPara[0] == 1 & filtTra[0].Length != filtPre[0].Length)
            {
                return Error.modDataError3;
            }

            //予測期間のステップ数//
            int T = ypre.Length;
            //フィルタデータのステップ数//
            int TT = filtTra.Length;
            double[] low = new double[T];
            double[] up = new double[T];
            int modMode = (int)modPara[0];

            //正常区間の計算
            for (int t = 0; t < T; t++)
            {
                //予測対象と条件合致する行を抽出し、補正用データから対象行を追加
                double[][] abstModData = Enumerable.Range(0, TT)
                                         .Where(tt => filtTra[tt].SequenceEqual(filtPre[t]))
                                         .Select(tt => modData[tt])
                                         .ToArray();
                //ListからJagg配列に変換
                double[][] Y = DenseMatrix.OfRowArrays(abstModData).Transpose().ToRowArrays();

                if (Y[0].Length > 1)
                {
                    //正常区間の上下限値を計算
                    if (modMode == 1)
                    {
                        //補正パラメータ：正常区間の幅パラメータ//
                        double kappa = modPara[1];
                        double[] y = Y[0];

                        //標準偏差と平均値を計算
                        double mu = y.Mean();
                        double sigma = y.StandardDeviation();

                        //正常区間の上下限値を計算
                        low[t] = mu - kappa * sigma;
                        up[t] = mu + kappa * sigma;

                        //正常区間の上下限値が0以下なら、0に補正
                        low[t] = Math.Max(low[t], 0);
                        up[t] = Math.Max(up[t], 0);
                    }
                }
                //408: 補正モードを1に指定したとき、予測期間におけるフィルタリングデータの各データに対して、学習期間におけるフィルタリングデータの中に合致するデータは一つしかない//
                else
                {
                    return Error.modDataError4;
                }
            }
            //409: 「補正用データにNaNが含まれています」//
            helper.CheckDouble2D(modData, out errorFlag);
            if (errorFlag == 1)
            {
                return Error.modDataError5;
            }

            //補正済予測値の計算
            //異常判定(異常なら近い正常区間の上下限値に補正)
            yPreMod = Enumerable.Range(0, T)
                             .Select(t => Math.Min(Math.Max(low[t], ypre[t]), up[t]))
                             .ToArray();

            //正常区間
            confInt = DenseMatrix.OfRowArrays(new double[][] { low, up }).Transpose().ToRowArrays();

            //補正フラグ
            actMod = new int[T];

            for (int i = 0; i < T; i++)
            {
                if (low[i] > ypre[i] | ypre[i] > up[i])
                {
                    actMod[i] = 1;
                }
                else
                {
                    actMod[i] = 0;

                }
            }

            //ypreにNaNの代入(手動チェックするときだけコメントアウト)//
            //yPreMod[0] = Double.NaN;

            //500: 補正済予測値にNaNが含まれています
            helper.Check1D(yPreMod, out errorFlag1);
            helper.CheckDouble2D(confInt, out errorFlag2);
            if (errorFlag1 == 1 || errorFlag2 == 1)
            {
                return Error.modPredictError;
            }

            return 0;
        }

        public int Serialize(out string serialized)
        {
            // forestはサイズ削減のため独自形式でシリアライズする。
            // forest   := tree*
            // tree     := "T" node*
            // node     := leaf | non-leaf
            // leaf     := "L" predicted
            // non-leaf := "N" split-col split-val
            // predicted, split-valはIEEE 754倍精度、split-colは4バイト整数で
            // いずれもビット列を整数として見たものを16進文字列として格納する。
            // 木構造を幅優先で作っているため、left, rightは保存せずとも復元できる。
            int capacity = forest.Select(t => t.Count).Sum() * 21 + 1000;
            StringBuilder sb = new StringBuilder(capacity);
            foreach (var tree in forest)
            {
                int nextChild = 1;
                sb.Append("T");
                foreach (var node in tree)
                {
                    if (node.leftNode == 0 && node.rightNode == 0)
                    {
                        sb.AppendFormat("L{0:x16}", (ulong)BitConverter.DoubleToInt64Bits(node.predicted));
                        if (node.SplitCol != 0)
                            throw new ArgumentException("Leaf node has the split column");
                        if (node.SplitVal != 0)
                            throw new ArgumentException("Leaf node has the split value");
                    }
                    else
                    {
                        sb.AppendFormat("N{0:x8}{1:x16}",
                            node.SplitCol, (ulong)BitConverter.DoubleToInt64Bits(node.SplitVal));
                        if (node.predicted != 0)
                            throw new ArgumentException("Non-leaf node has the prediction value");
                        if (node.leftNode != nextChild++)
                            throw new ArgumentException("Inconsistent left node");
                        if (node.rightNode != nextChild++)
                            throw new ArgumentException("Inconsistent right node");
                    }
                }
            }
            forestStr = sb.ToString();
            int ret = ModelFactory.Serialize(this, out serialized);
            forestStr = null;
            return ret;
        }

        public int Deserialize(string serialized)
        {
            int ret = ModelFactory.Deserialize(serialized, this);
            if (ret != 0)
                return ret;

            forest = new List<List<Node>>();
            int idx = 0;
            while (idx < forestStr.Length)
            {
                if (forestStr[idx] != 'T')
                    throw new FormatException("Invalid tree");
                idx++;
                int nextChild = 1;
                List<Node> tree = new List<Node>();
                while (idx < forestStr.Length)
                {
                    if (forestStr[idx] == 'L')
                    {
                        if (forestStr.Length - idx < 17)
                            throw new FormatException("Truncated leaf");
                        Node node = new Node();
                        node.predicted = BitConverter.Int64BitsToDouble(Convert.ToInt64(forestStr.Substring(idx + 1, 16), 16));
                        tree.Add(node);
                        idx += 17;
                    }
                    else if (forestStr[idx] == 'N')
                    {
                        if (forestStr.Length - idx < 25)
                            throw new FormatException("Truncated non-leaf");
                        Node node = new Node();
                        node.SplitCol = Convert.ToInt32(forestStr.Substring(idx + 1, 8), 16);
                        node.SplitVal = BitConverter.Int64BitsToDouble(Convert.ToInt64(forestStr.Substring(idx + 9, 16), 16));
                        node.leftNode = nextChild++;
                        node.rightNode = nextChild++;
                        tree.Add(node);
                        idx += 25;
                    }
                    else if (forestStr[idx] == 'T')
                        break;
                    else
                        throw new FormatException("Invalid node");
                }
                if (tree.Count != nextChild)
                    throw new FormatException("Inconsistent node count");
                forest.Add(tree);
            }
            forestStr = null;

            // データ破損で無限ループに入ることを防ぐため、枝がループしていないか検証する。
            foreach (var tree in forest)
            {
                for (int i = 0; i < tree.Count; i++)
                {
                    if (tree[i].leftNode != 0 && tree[i].leftNode <= i)
                        throw new FormatException("Backward-referencing left node");
                    if (tree[i].rightNode != 0 && tree[i].rightNode <= i)
                        throw new FormatException("Backward-referencing right node");
                }
            }
            return 0;
        }
    }

    public class ModelFactory
    {
        public static IModel CreateModel(IHyperParameter hp)
        {
            switch (hp)
            {
                case MLRHyperParameter mlrhp:
                    return new MLRModel(mlrhp);
                case PLSHyperParameter plshp:
                    return new PLSModel(plshp);
                case RFHyperParameter rfhp:
                    return new RFModel(rfhp);
                default:
                    throw new ArgumentOutOfRangeException("hp", "Invalid hyper parameter class is given");
            }
        }

        internal static int Serialize<T>(T m, out string serialized)
        {
            var dcs = new DataContractSerializer(typeof(T));
            var sw = new System.IO.StringWriter();
            using (var xw = System.Xml.XmlWriter.Create(sw))
            {
                dcs.WriteObject(xw, m);
            }
            serialized = sw.ToString();
            return 0;
        }

        internal static int Deserialize<T>(string serialized, T m)
        {
            var dcs = new DataContractSerializer(typeof(T));
            //var xdr = System.Xml.XmlDictionaryReader.CreateTextReader(
            //    System.Text.Encoding.GetEncoding("UTF-16").GetBytes(serialized),
            //    new System.Xml.XmlDictionaryReaderQuotas());
            var xr = System.Xml.XmlReader.Create(new System.IO.StringReader(serialized));

            T loaded;
            try
            {
                loaded = (T)dcs.ReadObject(xr, true);
            }
            catch (SerializationException)
            {
                return Error.BadSerializedData;
            }
            var bflags =
                System.Reflection.BindingFlags.Public |
                System.Reflection.BindingFlags.NonPublic |
                System.Reflection.BindingFlags.Instance;
            foreach (var p in m.GetType().GetFields(bflags))
            {
                p.SetValue(m, p.GetValue(loaded));
            }
            return 0;
        }
    }

    internal class helper//データ処理のヘルパー//
    {
        public static void CenteringScaling(Matrix<double> X, Matrix<double> Y, double[] meanX, double meanY, double[] stdX, double stdY, int centering_flag, int scaling_flag, out Matrix<double> xCal, out Matrix<double> yCal)
        {
            //サンプル数//
            int n = X.RowCount;
            //説明変数の数//
            int p = X.ColumnCount;
            if (centering_flag == 1 && scaling_flag == 0)
            {
                yCal = Y - meanY;
                double[][] xTemp = X.Transpose().ToRowArrays();
                for (int j = 0; j < p; j++)
                {
                    for (int h = 0; h < n; h++)
                    {
                        xTemp[j][h] = xTemp[j][h] - meanX[j];
                    }
                }
                xCal = DenseMatrix.OfRowArrays(xTemp).Transpose();
            }
            else if (centering_flag == 0 && scaling_flag == 1)
            {
                yCal = Y.Divide(stdY);
                double[][] xTemp = X.Transpose().ToRowArrays();
                for (int j = 0; j < p; j++)
                {
                    for (int h = 0; h < n; h++)
                    {
                        xTemp[j][h] = xTemp[j][h] / stdX[j];
                    }
                }
                xCal = DenseMatrix.OfRowArrays(xTemp).Transpose();
            }
            else if (centering_flag == 1 && scaling_flag == 1)
            {
                yCal = (Y - meanY).Divide(stdY);
                double[][] xTemp = X.Transpose().ToRowArrays();
                for (int j = 0; j < p; j++)
                {
                    for (int h = 0; h < n; h++)
                    {
                        xTemp[j][h] = (xTemp[j][h] - meanX[j]) / stdX[j];
                    }
                }
                xCal = DenseMatrix.OfRowArrays(xTemp).Transpose();
            }
            else
            {
                xCal = X; yCal = Y;
            }
        }

        public static void Check1D(double[] x, out int errorFlag)
        {
            errorFlag = 0;
            if (x.Any(elm => Double.IsNaN(elm)))
            {
                errorFlag = 1;
            }
        }

        public static void CheckDouble2D(double[][] x, out int errorFlag)
        {
            errorFlag = 0;
            for (int i = 0; i < x.Length; i++)
            {
                if (x[i].Any(elm => Double.IsNaN(elm)))
                {
                    errorFlag = 1;
                }
            }
        }

        public static void CheckInt2D(int[][] x, out int errorFlag)
        {
            errorFlag = 0;
            for (int i = 0; i < x.Length; i++)
            {
                if (x[i].Any(elm => Double.IsNaN(elm)))
                {
                    errorFlag = 1;
                }
            }
        }

    }
}