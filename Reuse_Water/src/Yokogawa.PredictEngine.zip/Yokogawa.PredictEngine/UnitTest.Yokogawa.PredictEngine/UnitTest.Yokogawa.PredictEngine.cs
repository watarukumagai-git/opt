﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Yokogawa.PredictEngine;
using System.Collections.Generic;
using System.Data;
using Microsoft.VisualBasic.FileIO;
using MathNet.Numerics;

namespace UnitTest.Yokogawa.PredictEngine
{
    public static class GetParentDirectory
    {
        public static string GetParentDir(string pathName, int level)
        {
            int x = pathName.Length;
            for (int i = 0; i < level; i++)
            {
                x = pathName.LastIndexOf(Path.DirectorySeparatorChar, x - 1);
                if (x < 0) return null;
            }
            if (x == 2) x++;
            return pathName.Substring(0, x);
        }
    }

    public static class LoadCSV
    {
        public static DataTable CsvReader(string filename)
        {
            System.Text.Encoding encord = System.Text.Encoding.GetEncoding("Shift_JIS");
            string[] data;
            DataTable dt = new DataTable();
            TextFieldParser parser = new TextFieldParser(filename, encord);
            parser.TextFieldType = FieldType.Delimited;
            // 区切り文字はコンマ 
            parser.SetDelimiters(",");
            //データがあるか確認します。 
            if (!parser.EndOfData)
            {
                //CSVファイルから1行読み取ります。 
                data = parser.ReadFields();
                //カラムの数を取得します。 
                int cols = data.Length;
                for (int i = 0; i < cols; i++)
                {
                    //カラム名をセットします 
                    dt.Columns.Add(data[i]);
                }
            }

            // CSVをデータテーブルに格納 
            while (!parser.EndOfData)
            {
                data = parser.ReadFields();
                DataRow row = dt.NewRow();
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    row[i] = data[i];
                }
                dt.Rows.Add(row);
            }
            parser.Dispose();
            return dt;
        }


        public static int DataTableToCsv(DataTable dt, string FileName)
        {
            string sp = string.Empty;
            List<int> filterIndex = new List<int>();
            System.Text.Encoding encode = System.Text.Encoding.GetEncoding("Shift_JIS");

            using (StreamWriter sw = new StreamWriter(FileName, false, encode))
            {
                //----------------------------------------------------------//
                // DataColumnの型から値を出力するかどうか判別します         //
                // 出力対象外となった項目は[データ]という形で出力します     //
                //----------------------------------------------------------//
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    switch (dt.Columns[i].DataType.ToString())
                    {
                        case "System.Boolean":
                        case "System.Byte":
                        case "System.Char":
                        case "System.DateTime":
                        case "System.Decimal":
                        case "System.Double":
                        case "System.Int16":
                        case "System.Int32":
                        case "System.Int64":
                        case "System.SByte":
                        case "System.Single":
                        case "System.String":
                        case "System.TimeSpan":
                        case "System.UInt16":
                        case "System.UInt32":
                        case "System.UInt64":
                            break;

                        default:
                            filterIndex.Add(i);
                            break;
                    }
                }
                //----------------------------------------------------------//
                // ヘッダーを出力します。                                   //
                //----------------------------------------------------------//
                foreach (DataColumn col in dt.Columns)
                {
                    sw.Write(sp + "\"" + col.ToString().Replace("\"", "\"\"") + "\"");
                    sp = ",";
                }
                sw.WriteLine();
                //----------------------------------------------------------//
                // 内容を出力します。                                       //
                //----------------------------------------------------------//
                foreach (DataRow row in dt.Rows)
                {
                    sp = string.Empty;
                    for (int i = 0; i < dt.Columns.Count; i++)
                    {
                        if (filterIndex.Contains(i))
                        {
                            sw.Write(sp + "\"[データ]\"");
                            sp = ",";
                        }
                        else
                        {
                            sw.Write(sp + "\"" + row[i].ToString().Replace("\"", "\"\"") + "\"");
                            sp = ",";
                        }
                    }
                    sw.WriteLine();
                }
            }
            return 0;
        }
    }

    public static class TransformData
    {
        public static void DataTableToArrayMLR(DataTable input_xtra_dt, DataTable input_ytra_dt, DataTable input_xpre_dt, DataTable input_mod_para_dt, DataTable input_mod_data_dt, DataTable input_filter_training_dt, DataTable input_filter_predict_dt, out double[][] xtra, out double[] ytra, out double[][] xpre, out double[][] modData, out int[][] filterTraining, out int[][] filterPredict, out double[] modPara)
        {
            //学習期間の説明変数//
            DataTableToArray2D<double>(input_xtra_dt, out xtra);
            //学習期間の目的変数//
            DataTableToArray1DRow<double>(input_ytra_dt, out ytra);
            //検証期間の説明変数//
            DataTableToArray2D<double>(input_xpre_dt, out xpre);
            //検証用データ//
            DataTableToArray2D<double>(input_mod_data_dt, out modData);
            //学習期間のフィルタリングデータ//
            DataTableToArray2D<int>(input_filter_training_dt, out filterTraining);
            //予測期間のフィルタリングデータ//
            DataTableToArray2D<int>(input_filter_predict_dt, out filterPredict);
            //補正用パラメータ//
            DataTableToArray1DCol<double>(input_mod_para_dt, out modPara);
        }

        public static void DataTableToArrayPLS(DataTable input_xtra_dt, DataTable input_ytra_dt, DataTable input_xpre_dt, DataTable input_mod_para_dt, DataTable input_mod_data_dt, DataTable input_filter_training_dt, DataTable input_filter_predict_dt, DataTable input_numLV_dt, out double[][] xtra, out double[] ytra, out double[][] xpre, out double[][] modData, out int[][] filterTraining, out int[][] filterPredict, out double[] modPara, out int numLV)
        {
            //学習期間の説明変数//
            DataTableToArray2D<double>(input_xtra_dt, out xtra);
            //学習期間の目的変数//
            DataTableToArray1DRow<double>(input_ytra_dt, out ytra);
            //検証期間の説明変数//
            DataTableToArray2D<double>(input_xpre_dt, out xpre);
            //検証用データ//
            DataTableToArray2D<double>(input_mod_data_dt, out modData);
            //学習期間のフィルタリングデータ//
            DataTableToArray2D<int>(input_filter_training_dt, out filterTraining);
            //予測期間のフィルタリングデータ//
            DataTableToArray2D<int>(input_filter_predict_dt, out filterPredict);
            //補正用パラメータ//
            DataTableToArray1DCol<double>(input_mod_para_dt, out modPara);
            //潜在変数//
            DataTableToArray1Dint<int>(input_numLV_dt, out numLV);
        }

        public static void DataTableToArrayRF(DataTable input_xtra_dt, DataTable input_ytra_dt, DataTable input_xpre_dt, DataTable input_mod_para_dt, DataTable input_mod_data_dt, DataTable input_filter_training_dt, DataTable input_filter_predict_dt, DataTable output_yval_dt, out double[][] xtra, out double[] ytra, out double[][] xpre, out double[][] modData, out int[][] filterTraining, out int[][] filterPredict, out double[] modPara, out double[] yval)
        {
            //学習期間の説明変数//
            DataTableToArray2D<double>(input_xtra_dt, out xtra);
            //学習期間の目的変数//
            DataTableToArray1DRow<double>(input_ytra_dt, out ytra);
            //検証期間の説明変数//
            DataTableToArray2D<double>(input_xpre_dt, out xpre);
            //検証期間の目的変数//
            DataTableToArray1DRow<double>(output_yval_dt, out yval);
            //検証用データ//
            DataTableToArray2D<double>(input_mod_data_dt, out modData);
            //学習期間のフィルタリングデータ//
            DataTableToArray2D<int>(input_filter_training_dt, out filterTraining);
            //予測期間のフィルタリングデータ//
            DataTableToArray2D<int>(input_filter_predict_dt, out filterPredict);
            //補正用パラメータ//
            DataTableToArray1DCol<double>(input_mod_para_dt, out modPara);
        }

        public static void DataTableToArrayFilter(DataTable input_xtra_dt, DataTable input_ytra_dt, DataTable output_filtered_x_dt, DataTable output_filtered_y_dt, DataTable output_filtered_act_dt, out double[][] xtra, out double[] ytra, out double[][] xtraFiltered_val, out double[] ytraFiltered_val, out int[] actFiltered_val)
        {
            //学習期間の説明変数//
            DataTableToArray2D<double>(input_xtra_dt, out xtra);
            //学習期間の目的変数//
            DataTableToArray1DRow<double>(input_ytra_dt, out ytra);
            //フィルタリング済み学習期間の説明変数//
            DataTableToArray2D<double>(output_filtered_x_dt, out xtraFiltered_val);
            //フィルタリング済み学習期間の目的変数//
            DataTableToArray1DRow<double>(output_filtered_y_dt, out ytraFiltered_val);
            //フィルタリング済み学習期間の外れ値情報//
            DataTableToArray1DRowint(output_filtered_act_dt, out actFiltered_val);
        }

        //public static void MLRDataTableToArray(string method, DataTable xtra_dt, DataTable ytra_dt, DataTable mod_para_dt, DataTable parav_dt, DataTable xpre_dt, DataTable yval_dt,
        //                                       DataTable mod_data_dt, DataTable filter_training_dt, DataTable filter_predict_dt, DataTable modyval_dt, DataTable conf_int_dt, DataTable act_mod_dt, 
        //                                       out double[][] xtra, out double[] ytra, out double[] modPara, out double[] parav, out double[][] xpre, out double[] yval, 
        //                                       out double[][] modData, out int[][] filterTraining, out int[][] filterPredict, out double[] yValModTrue, out double[][] confIntTrue, out int[] actModTrue)
        //{
        //    //学習期間の説明変数//
        //    xtra = new double[][] { };
        //    //学習期間の目的変数//
        //    ytra = new double[] { };
        //    //モデルパラメータ//
        //    parav = new double[] { };
        //    //予測期間の説明変数//
        //    xpre = new double[][] { };
        //    //予測期間の目的変数//
        //    yval = new double[] { };
        //    //学習期間のフィルタリングデータ//
        //    filterTraining = new int[][] { };
        //    //予測期間のフィルタリングデータ//
        //    filterPredict = new int[][] { };
        //    //検証用データ//
        //    modData = new double[][] { };
        //    //予測期間の補正目的変数//
        //    yValModTrue = new double[] { };
        //    //予測期間の補正幅//
        //    confIntTrue = new double[][] { };
        //    //予測期間の補正実績フラグ//
        //    actModTrue = new int[] { };


        //    //補正用パラメータ//
        //    DataTableToArray1DCol<double>(mod_para_dt, out modPara);

        //    if (method == "fit")
        //    {
        //        //学習期間の説明変数//
        //        DataTableToArray2D<double>(xtra_dt, out xtra);
        //        //学習期間の目的変数//
        //        DataTableToArray1DRow<double>(ytra_dt, out ytra);
        //        //モデルパラメータ//
        //        if (parav_dt.Rows.Count > 0)
        //        {
        //            DataTableToArray1DCol<double>(parav_dt, out parav);
        //        }
        //    }
        //    else if (method == "pre")
        //    {
        //        //予測期間の説明変数//
        //        DataTableToArray2D<double>(xpre_dt, out xpre);
        //        //モデルパラメータ//
        //        DataTableToArray1DCol<double>(parav_dt, out parav);
        //        //予測期間の目的変数//
        //        DataTableToArray1DRow<double>(yval_dt, out yval);
        //    }
        //    else if (method == "mod")
        //    {
        //        //予測期間の目的変数//
        //        DataTableToArray1DRow<double>(yval_dt, out yval);
        //        //検証用データ//
        //        DataTableToArray2D<double>(mod_data_dt, out modData);
        //        //学習期間のフィルタリングデータ//
        //        DataTableToArray2D<int>(filter_training_dt, out filterTraining);
        //        //予測期間のフィルタリングデータ//
        //        DataTableToArray2D<int>(filter_predict_dt, out filterPredict);
        //        //予測期間の目的変数//
        //        DataTableToArray1DRow<double>(modyval_dt, out yValModTrue);
        //        //予測期間の目的変数//
        //        DataTableToArray2D<double>(conf_int_dt, out confIntTrue);
        //        //予測期間の目的変数//
        //        DataTableToArray1DRowint(act_mod_dt, out actModTrue);
        //    }
        //    else if (method == "all")
        //    {
        //        //学習期間の説明変数//
        //        DataTableToArray2D<double>(xtra_dt, out xtra);
        //        //学習期間の目的変数//
        //        DataTableToArray1DRow<double>(ytra_dt, out ytra);
        //        //検証期間の説明変数//
        //        DataTableToArray2D<double>(xpre_dt, out xpre);
        //        //検証用データ//
        //        DataTableToArray2D<double>(mod_data_dt, out modData);
        //        //学習期間のフィルタリングデータ//
        //        DataTableToArray2D<int>(filter_training_dt, out filterTraining);
        //        //予測期間のフィルタリングデータ//
        //        DataTableToArray2D<int>(filter_predict_dt, out filterPredict);
        //    }
        //}

        public static void MLRDataTableToArray1(DataTable input_xtra_dt, DataTable input_ytra_dt, DataTable input_mod_para_dt, DataTable output_parav_dt, out double[][] xtra, out double[] ytra, out double[] modPara, out double[] parav)
        {
            //学習期間の説明変数//
            DataTableToArray2D<double>(input_xtra_dt, out xtra);
            //学習期間の目的変数//
            DataTableToArray1DRow<double>(input_ytra_dt, out ytra);
            //補正用パラメータ//
            DataTableToArray1DCol<double>(input_mod_para_dt, out modPara);
            //モデルパラメータ//
            if (output_parav_dt.Rows.Count == 0)
            {
                parav = new double[] { };
            }
            else
            {
                DataTableToArray1DCol<double>(output_parav_dt, out parav);
            }
        }

        public static void MLRDataTableToArray2(DataTable input_xpre_dt, DataTable input_parav_dt, DataTable input_mod_para_dt, DataTable output_yval_dt, out double[][] xpre, out double[] parav, out double[] modPara, out double[] yval)
        {
            //予測期間の説明変数//
            DataTableToArray2D<double>(input_xpre_dt, out xpre);
            //モデルパラメータ//
            DataTableToArray1DCol<double>(input_parav_dt, out parav);
            //補正用パラメータ//
            DataTableToArray1DCol<double>(input_mod_para_dt, out modPara);
            //予測期間の目的変数//
            DataTableToArray1DRow<double>(output_yval_dt, out yval);
        }

        public static void MLRDataTableToArray3(DataTable input_ypre_dt, DataTable input_mod_para_dt, DataTable input_mod_data_dt, DataTable input_filter_training_dt, DataTable input_filter_predict_dt, DataTable output_modyval_dt, DataTable output_conf_int_dt, DataTable output_act_mod_dt, out double[] yval, out double[] modPara, out double[][] modData, out int[][] filterTraining, out int[][] filterPredict, out double[] yValModTrue, out double[][] confIntTrue, out int[] actModTrue)
        {
            //予測期間の目的変数//
            DataTableToArray1DRow<double>(input_ypre_dt, out yval);
            //検証用データ//
            DataTableToArray2D<double>(input_mod_data_dt, out modData);
            //補正用パラメータ//
            DataTableToArray1DCol<double>(input_mod_para_dt, out modPara);
            //学習期間のフィルタリングデータ//
            DataTableToArray2D<int>(input_filter_training_dt, out filterTraining);
            //予測期間のフィルタリングデータ//
            DataTableToArray2D<int>(input_filter_predict_dt, out filterPredict);
            //予測期間の目的変数//
            DataTableToArray1DRow<double>(output_modyval_dt, out yValModTrue);
            //予測期間の目的変数//
            DataTableToArray2D<double>(output_conf_int_dt, out confIntTrue);
            //予測期間の目的変数//
            DataTableToArray1DRowint(output_act_mod_dt, out actModTrue);
        }
        
        public static void PLSDataTableToArray1(DataTable input_xtra_dt, DataTable input_ytra_dt, DataTable input_mod_para_dt, DataTable input_numLV_dt, DataTable output_parav_dt, out double[][] xtra, out double[] ytra, out double[] modPara, out int numLV, out double[] parav)
        {
            //学習期間の説明変数//
            DataTableToArray2D<double>(input_xtra_dt, out xtra);
            //学習期間の目的変数//
            DataTableToArray1DRow<double>(input_ytra_dt, out ytra);
            //補正用パラメータ//
            DataTableToArray1DCol<double>(input_mod_para_dt, out modPara);
            //潜在変数//
            DataTableToArray1Dint<int>(input_numLV_dt, out numLV);
            //モデルパラメータ//
            if (output_parav_dt.Rows.Count == 0)
            {
                parav = new double[] { };
            }
            else
            {
                DataTableToArray1DCol<double>(output_parav_dt, out parav);
            }
        }

        public static void PLSDataTableToArray2(DataTable input_xpre_dt, DataTable input_parav_dt, DataTable input_mod_para_dt, DataTable input_numLV_dt, DataTable output_yval_dt, out double[][] xpre, out double[] parav, out double[] modPara, out int numLV, out double[] yval)
        {
            //予測期間の説明変数//
            DataTableToArray2D<double>(input_xpre_dt, out xpre);
            //モデルパラメータ//
            DataTableToArray1DCol<double>(input_parav_dt, out parav);
            //補正用パラメータ//
            DataTableToArray1DCol<double>(input_mod_para_dt, out modPara);
            //潜在変数//
            DataTableToArray1Dint<int>(input_numLV_dt, out numLV);
            //予測期間の目的変数//
            DataTableToArray1DRow<double>(output_yval_dt, out yval);
        }

        public static void PLSDataTableToArray3(DataTable input_ypre_dt, DataTable input_mod_para_dt, DataTable input_mod_data_dt, DataTable input_filter_training_dt, DataTable input_filter_predict_dt, DataTable input_numLV_dt, DataTable output_modyval_dt, DataTable output_conf_int_dt, DataTable output_act_mod_dt, out double[] yval, out double[] modPara, out double[][] modData, out int[][] filterTraining, out int[][] filterPredict, out int numLV, out double[] yValModTrue, out double[][] confIntTrue, out int[] actModTrue)
        {
            //予測期間の目的変数//
            DataTableToArray1DRow<double>(input_ypre_dt, out yval);
            //検証用データ//
            DataTableToArray2D<double>(input_mod_data_dt, out modData);
            //補正用パラメータ//
            DataTableToArray1DCol<double>(input_mod_para_dt, out modPara);
            //潜在変数//
            DataTableToArray1Dint<int>(input_numLV_dt, out numLV);
            //学習期間のフィルタリングデータ//
            DataTableToArray2D<int>(input_filter_training_dt, out filterTraining);
            //予測期間のフィルタリングデータ//
            DataTableToArray2D<int>(input_filter_predict_dt, out filterPredict);
            //予測期間の目的変数//
            DataTableToArray1DRow<double>(output_modyval_dt, out yValModTrue);
            //予測期間の目的変数//
            DataTableToArray2D<double>(output_conf_int_dt, out confIntTrue);
            //予測期間の目的変数//
            DataTableToArray1DRowint(output_act_mod_dt, out actModTrue);
        }

        //public static void RFDataTableToArray(string method, DataTable input_numRandomState_dt, DataTable input_pythonPickle_dt, DataTable input_numTree_dt, DataTable input_numMaxDepth_dt, DataTable input_numMinSplit_dt, DataTable input_xtra_dt, DataTable input_ytra_dt, DataTable input_xpre_dt, DataTable input_mod_para_dt, DataTable input_mod_data_dt, DataTable input_filter_training_dt, DataTable input_filter_predict_dt, out double[][] xtra, out double[] ytra, out double[][] xpre, out double[][] modData, out int[][] filterTraining, out int[][] filterPredict, out double[] modPara, out int numTree, out dynamic numMaxDepth, out int numMinSplit, out string pythonPickle, out dynamic numRandomState)
        //{
        //    //空配列を入れておく//
        //    xtra = new double[][] { };
        //    ytra = new double[] { };
        //    modPara = new double[] { };
        //    numTree = new int { };
        //    numMaxDepth = new int { };
        //    numMinSplit = new int { };
        //    numRandomState = new int { };
        //    xpre = new double[][] { };
        //    modData = new double[][] { };
        //    filterTraining = new int[][] { };
        //    filterPredict = new int[][] { };
        //    pythonPickle = "";

        //    if (method == "predict" || method == "mod")
        //    {
        //        //検証期間の説明変数//
        //        DataTableToArray2D<double>(input_xpre_dt, out xpre);
        //        //pick model//
        //        DataTableToString<string>(input_pythonPickle_dt, out pythonPickle);
        //    }
        //    else if (method == "mod")
        //    {
        //        //検証用データ//
        //        DataTableToArray2D<double>(input_mod_data_dt, out modData);
        //        //学習期間のフィルタリングデータ//
        //        DataTableToArray2D<int>(input_filter_training_dt, out filterTraining);
        //        //予測期間のフィルタリングデータ//
        //        DataTableToArray2D<int>(input_filter_predict_dt, out filterPredict);
        //    }
        //    else if (method == "fit")
        //    {
        //        //学習期間の説明変数//
        //        DataTableToArray2D<double>(input_xtra_dt, out xtra);
        //        //学習期間の目的変数//
        //        DataTableToArray1DRow<double>(input_ytra_dt, out ytra);
        //        //補正用パラメータ//
        //        DataTableToArray1DCol<double>(input_mod_para_dt, out modPara);
        //        //決定木の数//
        //        DataTableToArray1Dint<int>(input_numTree_dt, out numTree);
        //        //決定木の深さ//
        //        DataTableToArray1DNull<int>(input_numMaxDepth_dt, out numMaxDepth);
        //        //分岐条件のデータ数//
        //        DataTableToArray1Dint<int>(input_numMinSplit_dt, out numMinSplit);
        //        //random_state//
        //        DataTableToArray1DNull<int>(input_numRandomState_dt, out numRandomState);
        //        //pick model//
        //        DataTableToString<string>(input_pythonPickle_dt, out pythonPickle);
        //    }
        //}

        public static void RFDataTableToArray1(DataTable input_xtra_dt, DataTable input_ytra_dt, DataTable input_xpre_dt, DataTable input_mod_para_dt, DataTable output_yval_dt, out double[][] xtra, out double[] ytra, out double[][] xpre, out double[] modPara, out double[] yValTrue)
        {
            //学習期間の説明変数//
            DataTableToArray2D<double>(input_xtra_dt, out xtra);
            //学習期間の目的変数//
            DataTableToArray1DRow<double>(input_ytra_dt, out ytra);
            //補正用パラメータ//
            DataTableToArray1DCol<double>(input_mod_para_dt, out modPara);

            //予測期間の説明変数//
            if (input_xpre_dt == null)
            {
                xpre = new double[][] { };
            }
            else
            {
                DataTableToArray2D<double>(input_xpre_dt, out xpre);
            }

            //予測期間の目的変数//
            if (output_yval_dt == null)
            {
                yValTrue = new double[] { };
            }
            else
            {
                DataTableToArray1DRow<double>(output_yval_dt, out yValTrue);
            }
        }

        public static void RFDataTableToArray2(DataTable input_xtra_dt, DataTable input_ytra_dt, DataTable input_xpre_dt, DataTable input_mod_para_dt, DataTable input_num_tree_dt, DataTable input_num_max_depth_dt, DataTable input_num_min_split_dt, DataTable output_yval_dt, out double[][] xtra, out double[] ytra, out double[][] xpre, out double[] modPara, out int numTree, out Nullable<int> numMaxDepth, out int numMinSplit, out double[] yValTrue)
        {
            //予測期間の目的変数//
            DataTableToArray2D<double>(input_xtra_dt, out xtra);
            //予測期間の目的変数//
            DataTableToArray1DRow<double>(input_ytra_dt, out ytra);
            //予測期間の説明変数//
            DataTableToArray2D<double>(input_xpre_dt, out xpre);
            //補正用パラメータ//
            DataTableToArray1DCol<double>(input_mod_para_dt, out modPara);
            //決定木の数//
            DataTableToArray1Dint<int>(input_num_tree_dt, out numTree);
            //決定木の深さ//
            numMaxDepth = new Nullable<int>();
            //分岐条件のデータ数//
            DataTableToArray1Dint<int>(input_num_min_split_dt, out numMinSplit);
            //予測期間の目的変数//
            DataTableToArray1DRow<double>(output_yval_dt, out yValTrue);
        }

        public static void RFDataTableToArray3(DataTable input_ypre_dt, DataTable input_mod_para_dt, DataTable input_mod_data_dt, DataTable input_filter_training_dt, DataTable input_filter_predict_dt, DataTable input_num_tree_dt, DataTable input_num_max_depth_dt, DataTable input_num_min_split_dt, DataTable output_modyval_dt, DataTable output_conf_int_dt, DataTable output_act_mod_dt, out double[] yval, out double[] modPara, out double[][] modData, out int[][] filterTraining, out int[][] filterPredict, out int numTree, out Nullable<int> numMaxDepth, out int numMinSplit, out double[] yValModTrue, out double[][] confIntTrue, out int[] actModTrue)
        {
            //予測期間の目的変数//
            DataTableToArray1DRow<double>(input_ypre_dt, out yval);
            //検証用データ//
            DataTableToArray2D<double>(input_mod_data_dt, out modData);
            //補正用パラメータ//
            DataTableToArray1DCol<double>(input_mod_para_dt, out modPara);
            //学習期間のフィルタリングデータ//
            DataTableToArray2D<int>(input_filter_training_dt, out filterTraining);
            //予測期間のフィルタリングデータ//
            DataTableToArray2D<int>(input_filter_predict_dt, out filterPredict);
            //予測期間の目的変数//
            DataTableToArray1DRow<double>(output_modyval_dt, out yValModTrue);
            //予測期間の目的変数//
            DataTableToArray2D<double>(output_conf_int_dt, out confIntTrue);
            //予測期間の目的変数//
            DataTableToArray1DRowint(output_act_mod_dt, out actModTrue);
            //決定木の数//
            DataTableToArray1Dint<int>(input_num_tree_dt, out numTree);
            //決定木の深さ//
            numMaxDepth = new Nullable<int>();
            //分岐条件のデータ数//
            DataTableToArray1Dint<int>(input_num_min_split_dt, out numMinSplit);
        }

        public static void DataTableToArray2D<T>(DataTable vs_dt, out T[][] vs)
        {
            //配列のサイズを取得//
            int column_size = vs_dt.Columns.Count;
            int row_size = vs_dt.Rows.Count;
            int j = 0;

            vs = new T[row_size][];

            foreach (DataRow dRow in vs_dt.Rows)
            {
                vs[j] = Enumerable.Range(0, column_size)
                                  .Select(n => (T)Convert.ChangeType(dRow[n] as string, typeof(T)))
                                  .ToArray();
                j = j + 1;
            }
        }

        public static void DataTableToString<T>(DataTable vs_dt, out string vs)
        {
            vs = vs_dt.Columns[0].ToString();
        }
        
        public static void DataTableToArray1DRow<T>(DataTable vs_dt, out T[] vs)
        {
            T[][] temp;
            //配列のサイズを取得//
            int row_size = vs_dt.Rows.Count;
            DataTableToArray2D<T>(vs_dt, out temp);
            vs = temp.Select(xx => xx[0]).ToArray();
        }

        public static void DataTableToArray1DCol<T>(DataTable vs_dt, out T[] vs)
        {
            T[][] temp;
            DataTableToArray2D<T>(vs_dt, out temp);
            vs = temp[0];
        }

        public static void DataTableToArray1Dint<T>(DataTable vs_dt, out T vs)
        {
            T[] temp;
            DataTableToArray1DRow<T>(vs_dt, out temp);
            vs = temp[0];
        }

        public static void DataTableToArray1DRowint(DataTable vs_dt, out int[] vs)
        {
            double[][] temp;
            int[][] temp_int;
            DataTableToArray2D<double>(vs_dt, out temp);
            temp_int = temp.Select(xx => xx.Select(yy => (int)yy).ToArray()).ToArray();
            vs = temp_int.Select(xx => xx[0]).ToArray();
        }

        public static void DataTableToArray1DNull<T>(DataTable vs_dt, out dynamic vs)
        {
            T[] temp;
            DataTableToArray1DRow<T>(vs_dt, out temp);
            if (temp.Count() == 0)
            {
                vs = null;
            }
            else
            {
                vs = temp[0];
            }
        }

        public static void ArrayToDataTable(int testNum, double[] ypre, double[] yPreMod, double[][] confInt, int[] actMod, out DataTable output_ypre_dt, out DataTable output_ypremod_dt, out DataTable output_confint_dt, out DataTable output_actmod_dt)
        {
            //配列からDataTableへ変換//
            output_ypre_dt = new DataTable();
            output_ypremod_dt = new DataTable();
            output_confint_dt = new DataTable();
            output_actmod_dt = new DataTable();

            string ypre_name = "prediction";
            string ypremod_name = "prediction mod";
            string actmod_name = "actual mod";
            string[] colnamelist = new string[] { "lower", "upper" };

            Array1DRowToDataTable<double>(ypre, ypre_name, out output_ypre_dt);
            Array1DRowToDataTable<double>(yPreMod, ypremod_name, out output_ypremod_dt);
            Array2DToDataTable<double>(confInt, colnamelist, out output_confint_dt);
            Array1DRowToDataTable<int>(actMod, actmod_name, out output_actmod_dt);
        }
        
        public static void ArrayToDataTable1(int testNum, double[] c, out DataTable output_dt)
        {
            //配列のサイズを取得//
            int variable_size = c.Length;

            //Column名の作成//
            //List<T>クラスのインスタンス化//
            List<string> ColumnName = new List<string>();
            ColumnName.Add("bias");
            for (int i = 1; i <= variable_size - 1; i++)
            {
                ColumnName.Add("coef_" + (i.ToString()));
            }

            //配列からDataTableへ変換//
            output_dt = new DataTable();
            foreach (string s in ColumnName)
            {
                output_dt.Columns.Add(s, typeof(double));
            }

            DataRow row = output_dt.NewRow();
            for (int i = 0; i < variable_size; i++)
            {
                row[ColumnName[i]] = c[i];
            }
            output_dt.Rows.Add(row);
        }

        public static void ArrayToDataTable2(int testNum, double[] p, out DataTable output_dt)
        {
            //配列のサイズを取得//
            int timestamp_val_size = p.Length;

            //List<T>クラスのインスタンス化//
            List<string> ColumnName = new List<string>();

            //Column名の作成//
            ColumnName.Add("Prediction");

            //配列からDataTableへ変換//
            output_dt = new DataTable();
            foreach (string s in ColumnName)
            {
                output_dt.Columns.Add(s, typeof(double));
            }

            for (int i = 0; i < timestamp_val_size; i++)
            {
                DataRow row = output_dt.NewRow();
                row[ColumnName[0]] = p[i];
                output_dt.Rows.Add(row);
            }
        }
        
        public static void Array2DToDataTable<T>(T[][] vs, string[] colnamelist, out DataTable vs_dt)
        {
            int row_size = vs.Length;
            int col_size = vs[0].Length;

            //List<T>クラスのインスタンス化//
            List<string> ColumnName = new List<string>();

            //Column名の作成//
            foreach (string colname in colnamelist)
            {
                ColumnName.Add(colname);
            }

            vs_dt = new DataTable();
            foreach (string s in ColumnName)
            {
                vs_dt.Columns.Add(s, typeof(double));
            }


            for (int i = 0; i < row_size; i++)
            {
                DataRow row = vs_dt.NewRow();
                for (int j = 0; j < col_size; j++)
                {
                    row[ColumnName[j]] = vs[i][j];
                }
                vs_dt.Rows.Add(row);
            }
        }

        public static void Array1DRowToDataTable<T>(T[] vs, string colname, out DataTable vs_dt)
        {
            //List<T>クラスのインスタンス化//
            List<string> ColumnName = new List<string>();

            //Column名の作成//
            ColumnName.Add(colname);

            vs_dt = new DataTable();

            foreach (string s in ColumnName)
            {
                vs_dt.Columns.Add(s, typeof(double));
            }

            //配列のサイズを取得//
            int row_size = vs.Length;
            for (int i = 0; i < row_size; i++)
            {
                DataRow row = vs_dt.NewRow();
                row[ColumnName[0]] = vs[i];
                vs_dt.Rows.Add(row);
            }
        }

        public static void Array1DColToDataTable<T>(T[] vs, out DataTable vs_dt)
        {
            vs_dt = new DataTable();

            //配列のサイズを取得//
            int col_size = vs.Length;
            DataRow row = vs_dt.NewRow();
            for (int i = 0; i < col_size; i++)
            {
                row[i] = vs[i];
            }
            vs_dt.Rows.Add(row);
        }

    }

    public static class GetData
    {
        public static void MLRCSVToDataTable(string method, int modelingMode, string functionMode, int testNum, out DataTable input_xtra_dt, out DataTable input_ytra_dt, out DataTable input_mod_para_dt, out DataTable input_mod_data_dt, out DataTable input_filter_training_dt, out DataTable input_filter_predict_dt, out DataTable input_xpre_dt, out DataTable input_parav_dt, out DataTable input_ypre_dt, out DataTable output_parav_dt, out DataTable output_yval_dt, out DataTable output_modyval_dt, out DataTable output_act_mod_dt, out DataTable output_conf_int_dt)
        {
            string testName;
            string modelingName = ModelingModeToName(modelingMode);
            if (method == "all")
            {
                testName = string.Format("test{0}-{1}", modelingMode, functionMode);
            }
            else
            {
                testName = string.Format("test{0}-{1}-{2}", modelingMode, functionMode, testNum);
            }

            //カレントディレクトリのパスを取得//
            string strCurrentDir = System.IO.Directory.GetCurrentDirectory();
            //親のフォルダ（ソリューションファイルのフォルダ）のパスを取得//
            string strParentPath = GetParentDirectory.GetParentDir(strCurrentDir, 5);
            //テスト用サンプルファイルのパスを取得//
            string fileDirPath = Path.Combine(strParentPath, "test_sample", modelingName + "-Test", testName);
            string fileDirInPath = Path.Combine(fileDirPath, "input_file");
            string fileDirOutPath = Path.Combine(fileDirPath, "output_file");
            string fileInModParaName = Path.Combine(fileDirInPath, "input_mod_param.csv");

            //CSVからDataTableとして変数を取得//
            input_mod_para_dt = LoadCSV.CsvReader(fileInModParaName);

            input_xtra_dt = new DataTable();
            input_ytra_dt = new DataTable();
            input_xpre_dt = new DataTable();
            input_mod_data_dt = new DataTable();
            input_filter_training_dt = new DataTable();
            input_filter_predict_dt = new DataTable();
            input_parav_dt = new DataTable();
            input_ypre_dt = new DataTable();
            output_parav_dt = new DataTable();
            output_yval_dt = new DataTable();
            output_modyval_dt = new DataTable();
            output_act_mod_dt = new DataTable();
            output_conf_int_dt = new DataTable();

            if (method == "fit")
            {
                string fileInXTraName = Path.Combine(fileDirInPath, "input_training_x.csv");
                string fileInYTraName = Path.Combine(fileDirInPath, "input_training_y.csv");
                input_xtra_dt = LoadCSV.CsvReader(fileInXTraName);
                input_ytra_dt = LoadCSV.CsvReader(fileInYTraName);

                if ((testNum >= 5 & testNum <= 11) | testNum == 14)
                {
                    string fileOutModelParaName = Path.Combine(fileDirOutPath, "output_modelparameter_python.csv");
                    output_parav_dt = LoadCSV.CsvReader(fileOutModelParaName);
                }
            }
            else if (method == "predict")
            {
                string fileInXValName = Path.Combine(fileDirInPath, "input_validation_x.csv");
                string fileInModelParaName = Path.Combine(fileDirInPath, "input_modelparameter.csv");
                input_xpre_dt = LoadCSV.CsvReader(fileInXValName);
                input_parav_dt = LoadCSV.CsvReader(fileInModelParaName);

                if (testNum >= 4)
                {
                    string fileOutYValName = Path.Combine(fileDirOutPath, "output_validation_y_python.csv");
                    output_yval_dt = LoadCSV.CsvReader(fileOutYValName);
                }
            }
            else if (method == "mod")
            {
                string fileInModDataName = Path.Combine(fileDirInPath, "input_mod_data.csv");
                string fileInFilterTrainingName = Path.Combine(fileDirInPath, "input_filtertraining.csv");
                string fileInFilterPredictName = Path.Combine(fileDirInPath, "input_filterpredict.csv");
                string fileInYValName = Path.Combine(fileDirInPath, "input_validation_y.csv");

                input_mod_data_dt = LoadCSV.CsvReader(fileInModDataName);
                input_filter_training_dt = LoadCSV.CsvReader(fileInFilterTrainingName);
                input_filter_predict_dt = LoadCSV.CsvReader(fileInFilterPredictName);
                input_ypre_dt = LoadCSV.CsvReader(fileInYValName);

                if (testNum >= 13)
                {
                    string fileOutModYValName = Path.Combine(fileDirOutPath, "output_mod_validation_y_python.csv");
                    string fileOutActModName = Path.Combine(fileDirOutPath, "output_act_mod_python.csv");
                    string fileOutConfIntName = Path.Combine(fileDirOutPath, "output_conf_int_python.csv");

                    output_modyval_dt = LoadCSV.CsvReader(fileOutModYValName);
                    output_act_mod_dt = LoadCSV.CsvReader(fileOutActModName);
                    output_conf_int_dt = LoadCSV.CsvReader(fileOutConfIntName);
                }
            }
            else if (method == "all")
            {
                string fileInXTraName = Path.Combine(fileDirInPath, "input_training_x.csv");
                string fileInYTraName = Path.Combine(fileDirInPath, "input_training_y.csv");
                string fileInXValName = Path.Combine(fileDirInPath, "input_validation_x.csv");
                string fileInModDataName = Path.Combine(fileDirInPath, "input_mod_data.csv");
                string fileInFilterTrainingName = Path.Combine(fileDirInPath, "input_filtertraining.csv");
                string fileInFilterPredictName = Path.Combine(fileDirInPath, "input_filterpredict.csv");

                input_xtra_dt = LoadCSV.CsvReader(fileInXTraName);
                input_ytra_dt = LoadCSV.CsvReader(fileInYTraName);
                input_xpre_dt = LoadCSV.CsvReader(fileInXValName);
                input_mod_data_dt = LoadCSV.CsvReader(fileInModDataName);
                input_filter_training_dt = LoadCSV.CsvReader(fileInFilterTrainingName);
                input_filter_predict_dt = LoadCSV.CsvReader(fileInFilterPredictName);
            }
        }

        public static void PLSCSVToDataTable(string method, int modelingMode, string functionMode, int testNum, out DataTable input_xtra_dt, out DataTable input_ytra_dt, out DataTable input_mod_para_dt, out DataTable input_mod_data_dt, out DataTable input_filter_training_dt, out DataTable input_filter_predict_dt, out DataTable input_xpre_dt, out DataTable input_parav_dt, out DataTable input_ypre_dt, out DataTable input_numLV_dt, out DataTable output_parav_dt, out DataTable output_yval_dt, out DataTable output_modyval_dt, out DataTable output_act_mod_dt, out DataTable output_conf_int_dt)
        {
            string testName;
            string modelingName = ModelingModeToName(modelingMode);
            if (method == "all")
            {
                testName = string.Format("test{0}-{1}", modelingMode, functionMode);
            }
            else
            {
                testName = string.Format("test{0}-{1}-{2}", modelingMode, functionMode, testNum);
            }

            //カレントディレクトリのパスを取得//
            string strCurrentDir = System.IO.Directory.GetCurrentDirectory();
            //親のフォルダ（ソリューションファイルのフォルダ）のパスを取得//
            string strParentPath = GetParentDirectory.GetParentDir(strCurrentDir, 5);
            //テスト用サンプルファイルのパスを取得//
            string fileDirPath = Path.Combine(strParentPath, "test_sample", modelingName + "-Test", testName);
            string fileDirInPath = Path.Combine(fileDirPath, "input_file");
            string fileDirOutPath = Path.Combine(fileDirPath, "output_file");
            string fileInModParaName = Path.Combine(fileDirInPath, "input_mod_param.csv");
            string fileInnumLVName = Path.Combine(fileDirInPath, "input_numLV.csv");


            //CSVからDataTableとして変数を取得//
            input_mod_para_dt = LoadCSV.CsvReader(fileInModParaName);
            input_numLV_dt = LoadCSV.CsvReader(fileInnumLVName);

            input_xtra_dt = new DataTable();
            input_ytra_dt = new DataTable();
            input_xpre_dt = new DataTable();
            input_mod_data_dt = new DataTable();
            input_filter_training_dt = new DataTable();
            input_filter_predict_dt = new DataTable();
            input_parav_dt = new DataTable();
            input_ypre_dt = new DataTable();
            output_parav_dt = new DataTable();
            output_yval_dt = new DataTable();
            output_modyval_dt = new DataTable();
            output_act_mod_dt = new DataTable();
            output_conf_int_dt = new DataTable();


            if (method == "fit")
            {
                string fileInXTraName = Path.Combine(fileDirInPath, "input_training_x.csv");
                string fileInYTraName = Path.Combine(fileDirInPath, "input_training_y.csv");
                input_xtra_dt = LoadCSV.CsvReader(fileInXTraName);
                input_ytra_dt = LoadCSV.CsvReader(fileInYTraName);

                if ((testNum >= 7 & testNum <= 15)| (testNum >= 18 & testNum <= 20)| testNum==25)
                {
                    string fileOutModelParaName = Path.Combine(fileDirOutPath, "output_modelparameter_python.csv");
                    output_parav_dt = LoadCSV.CsvReader(fileOutModelParaName);
                }
            }
            else if (method == "predict")
            {
                string fileInXValName = Path.Combine(fileDirInPath, "input_validation_x.csv");
                string fileInModelParaName = Path.Combine(fileDirInPath, "input_modelparameter.csv");
                input_xpre_dt = LoadCSV.CsvReader(fileInXValName);
                input_parav_dt = LoadCSV.CsvReader(fileInModelParaName);

                if (testNum >= 4)
                {
                    string fileOutYValName = Path.Combine(fileDirOutPath, "output_validation_y_python.csv");
                    output_yval_dt = LoadCSV.CsvReader(fileOutYValName);
                }
            }
            else if (method == "mod")
            {
                string fileInModDataName = Path.Combine(fileDirInPath, "input_mod_data.csv");
                string fileInFilterTrainingName = Path.Combine(fileDirInPath, "input_filtertraining.csv");
                string fileInFilterPredictName = Path.Combine(fileDirInPath, "input_filterpredict.csv");
                string fileInYValName = Path.Combine(fileDirInPath, "input_validation_y.csv");

                input_mod_data_dt = LoadCSV.CsvReader(fileInModDataName);
                input_filter_training_dt = LoadCSV.CsvReader(fileInFilterTrainingName);
                input_filter_predict_dt = LoadCSV.CsvReader(fileInFilterPredictName);
                input_ypre_dt = LoadCSV.CsvReader(fileInYValName);

                if (testNum >= 13)
                {
                    string fileOutModYValName = Path.Combine(fileDirOutPath, "output_mod_validation_y_python.csv");
                    string fileOutActModName = Path.Combine(fileDirOutPath, "output_act_mod_python.csv");
                    string fileOutConfIntName = Path.Combine(fileDirOutPath, "output_conf_int_python.csv");

                    output_modyval_dt = LoadCSV.CsvReader(fileOutModYValName);
                    output_act_mod_dt = LoadCSV.CsvReader(fileOutActModName);
                    output_conf_int_dt = LoadCSV.CsvReader(fileOutConfIntName);
                }
            }
            else if (method == "all")
            {
                string fileInXTraName = Path.Combine(fileDirInPath, "input_training_x.csv");
                string fileInYTraName = Path.Combine(fileDirInPath, "input_training_y.csv");
                string fileInXValName = Path.Combine(fileDirInPath, "input_validation_x.csv");
                string fileInModDataName = Path.Combine(fileDirInPath, "input_mod_data.csv");
                string fileInFilterTrainingName = Path.Combine(fileDirInPath, "input_filtertraining.csv");
                string fileInFilterPredictName = Path.Combine(fileDirInPath, "input_filterpredict.csv");

                input_xtra_dt = LoadCSV.CsvReader(fileInXTraName);
                input_ytra_dt = LoadCSV.CsvReader(fileInYTraName);
                input_xpre_dt = LoadCSV.CsvReader(fileInXValName);
                input_mod_data_dt = LoadCSV.CsvReader(fileInModDataName);
                input_filter_training_dt = LoadCSV.CsvReader(fileInFilterTrainingName);
                input_filter_predict_dt = LoadCSV.CsvReader(fileInFilterPredictName);
            }
        }

        public static void RFALLCSVToDataTable(int modelingMode, string functionMode, out DataTable input_xtra_dt, out DataTable input_ytra_dt, out DataTable input_mod_para_dt, out DataTable input_mod_data_dt, out DataTable input_filter_training_dt, out DataTable input_filter_predict_dt, out DataTable input_hyperparameter_dt, out int input_numTree, out Nullable<int> input_numMaxDepth, out int input_numMinSplit, out DataTable input_xpre_dt, out DataTable output_yval_dt)
        {
            string modelingName = ModelingModeToName(modelingMode);
            string testName = string.Format("test{0}-{1}", modelingMode, functionMode);

            //カレントディレクトリのパスを取得//
            string strCurrentDir = System.IO.Directory.GetCurrentDirectory();
            //親のフォルダ（ソリューションファイルのフォルダ）のパスを取得//
            string strParentPath = GetParentDirectory.GetParentDir(strCurrentDir, 5);
            //テスト用サンプルファイルのパスを取得//
            string fileDirPath = Path.Combine(strParentPath, "test_sample", modelingName + "-Test", testName);
            string fileDirInPath = Path.Combine(fileDirPath, "input_file");
            string fileDirOutPath = Path.Combine(fileDirPath, "output_file");
            string fileInXTraName = Path.Combine(fileDirInPath, "input_training_x.csv");
            string fileInYTraName = Path.Combine(fileDirInPath, "input_training_y.csv");
            string fileInXValName = Path.Combine(fileDirInPath, "input_validation_x.csv");
            string fileInModParaName = Path.Combine(fileDirInPath, "input_mod_param.csv");
            string fileInModDataName = Path.Combine(fileDirInPath, "input_mod_data.csv");
            string fileInFilterTrainingName = Path.Combine(fileDirInPath, "input_filtertraining.csv");
            string fileInFilterPredictName = Path.Combine(fileDirInPath, "input_filterpredict.csv");
            string fileInHyperParam = Path.Combine(fileDirInPath, "input_hyperparameter.csv");
            string fileOutYValName = Path.Combine(fileDirOutPath, "output_validation_y_act.csv");

            //CSVからDataTableとして変数を取得//
            input_xpre_dt = LoadCSV.CsvReader(fileInXValName);
            input_xtra_dt = LoadCSV.CsvReader(fileInXTraName);
            input_ytra_dt = LoadCSV.CsvReader(fileInYTraName);
            input_mod_para_dt = LoadCSV.CsvReader(fileInModParaName);
            input_mod_data_dt = LoadCSV.CsvReader(fileInModDataName);
            input_filter_training_dt = LoadCSV.CsvReader(fileInFilterTrainingName);
            input_filter_predict_dt = LoadCSV.CsvReader(fileInFilterPredictName);
            input_hyperparameter_dt = LoadCSV.CsvReader(fileInHyperParam);
            output_yval_dt = LoadCSV.CsvReader(fileOutYValName);

            input_numTree = int.Parse((string)input_hyperparameter_dt.Rows[0]["numTree"]);
            int tmp;
            input_numMaxDepth = int.TryParse((string)input_hyperparameter_dt.Rows[0]["numMaxDepth"], out tmp) ? (Nullable<int>)tmp : null;
            input_numMinSplit = int.Parse((string)input_hyperparameter_dt.Rows[0]["numMinSplit"]);
        }

        public static void RFCSVToDataTable(string method, int modelingMode, string functionMode, int testNum, out DataTable input_xtra_dt, out DataTable input_ytra_dt, out DataTable input_mod_para_dt, out int input_numTree, out Nullable<int> input_numMaxDepth, out int input_numMinSplit, out DataTable input_xval_dt, out DataTable output_yval_dt)
        {
            string modelingName = ModelingModeToName(modelingMode);
            string testName = string.Format("test{0}-{1}-{2}", modelingMode, functionMode, testNum);
            //カレントディレクトリのパスを取得//
            string strCurrentDir = System.IO.Directory.GetCurrentDirectory();
            //親のフォルダ（ソリューションファイルのフォルダ）のパスを取得//
            string strParentPath = GetParentDirectory.GetParentDir(strCurrentDir, 5);
            //テスト用サンプルファイルのパスを取得//
            string fileDirPath = Path.Combine(strParentPath, "test_sample", modelingName + "-Test", testName);
            string fileDirInPath = Path.Combine(fileDirPath, "input_file");
            string fileDirOutPath = Path.Combine(fileDirPath, "output_file");
            string fileInXTraName = Path.Combine(fileDirInPath, "input_training_x.csv");
            string fileInYTraName = Path.Combine(fileDirInPath, "input_training_y.csv");
            string fileInModParaName = Path.Combine(fileDirInPath, "input_mod_param.csv");
            string fileInHyperParam = Path.Combine(fileDirInPath, "input_hyperparameter.csv");

            //CSVからDataTableとして変数を取得//
            input_mod_para_dt = LoadCSV.CsvReader(fileInModParaName);
            input_xtra_dt = LoadCSV.CsvReader(fileInXTraName);
            input_ytra_dt = LoadCSV.CsvReader(fileInYTraName);
            DataTable input_hyperparameter_dt = LoadCSV.CsvReader(fileInHyperParam);
            if (method == "fit" && testNum >= 12)
            {
                string fileInXValName = Path.Combine(fileDirInPath, "input_validation_x.csv");
                string fileOutYValName = Path.Combine(fileDirOutPath, "output_validation_y_act.csv");
                input_xval_dt = LoadCSV.CsvReader(fileInXValName);
                output_yval_dt = LoadCSV.CsvReader(fileOutYValName);
            }
            else
            {
                input_xval_dt = null;
                output_yval_dt = null;
            }

            input_numTree = int.Parse((string)input_hyperparameter_dt.Rows[0]["numTree"]);
            int tmp;
            input_numMaxDepth = int.TryParse((string)input_hyperparameter_dt.Rows[0]["numMaxDepth"], out tmp) ? (Nullable<int>)tmp : null;
            input_numMinSplit = int.Parse((string)input_hyperparameter_dt.Rows[0]["numMinSplit"]);
        }

        public static void RFCSVToDataTable23(string method, int modelingMode, string functionMode, int testNum, out DataTable input_xtra_dt, out DataTable input_ytra_dt, out DataTable input_mod_para_dt, out DataTable input_mod_data_dt, out DataTable input_filter_training_dt, out DataTable input_filter_predict_dt, out DataTable input_xpre_dt, out DataTable input_ypre_dt, out DataTable input_num_tree_dt, out DataTable input_num_max_depth_dt, out DataTable input_num_min_split_dt, out DataTable output_yval_dt, out DataTable output_modyval_dt, out DataTable output_act_mod_dt, out DataTable output_conf_int_dt)
        {
            string modelingName = ModelingModeToName(modelingMode);
            string testName = string.Format("test{0}-{1}-{2}", modelingMode, functionMode, testNum);

            //カレントディレクトリのパスを取得//
            string strCurrentDir = System.IO.Directory.GetCurrentDirectory();
            //親のフォルダ（ソリューションファイルのフォルダ）のパスを取得//
            string strParentPath = GetParentDirectory.GetParentDir(strCurrentDir, 5);
            //テスト用サンプルファイルのパスを取得//
            string fileDirPath = Path.Combine(strParentPath, "test_sample", modelingName + "-Test", testName);
            string fileDirInPath = Path.Combine(fileDirPath, "input_file");
            string fileDirOutPath = Path.Combine(fileDirPath, "output_file");
            string fileInModParaName = Path.Combine(fileDirInPath, "input_mod_param.csv");
            string fileInHyperParam = Path.Combine(fileDirInPath, "input_hyperparameter.csv");


            //CSVからDataTableとして変数を取得//
            DataTable input_hyper_param_dt;

            input_xtra_dt = new DataTable();
            input_ytra_dt = new DataTable();
            input_xpre_dt = new DataTable();
            input_mod_data_dt = new DataTable();
            input_filter_training_dt = new DataTable();
            input_filter_predict_dt = new DataTable();
            input_ypre_dt = new DataTable();
            input_num_tree_dt = new DataTable();
            input_num_max_depth_dt = new DataTable();
            input_num_min_split_dt = new DataTable();

            output_yval_dt = new DataTable();
            output_modyval_dt = new DataTable();
            output_act_mod_dt = new DataTable();
            output_conf_int_dt = new DataTable();

            input_mod_para_dt = LoadCSV.CsvReader(fileInModParaName);
            input_hyper_param_dt = LoadCSV.CsvReader(fileInHyperParam);
            input_num_tree_dt.Columns.Add("numTree");
            input_num_tree_dt.Rows.Add((string)input_hyper_param_dt.Rows[0]["numTree"]);
            input_num_min_split_dt.Columns.Add("numMinSplit");
            input_num_min_split_dt.Rows.Add(input_hyper_param_dt.Rows[0]["numMinSplit"]);

            if (method == "predict")
            {
                string fileInXTraName = Path.Combine(fileDirInPath, "input_training_x.csv");
                string fileInYTraName = Path.Combine(fileDirInPath, "input_training_y.csv");
                string fileInXValName = Path.Combine(fileDirInPath, "input_validation_x.csv");

                input_xtra_dt = LoadCSV.CsvReader(fileInXTraName);
                input_ytra_dt = LoadCSV.CsvReader(fileInYTraName);
                input_xpre_dt = LoadCSV.CsvReader(fileInXValName);

                if (testNum >= 4)
                {
                    string fileOutYValName = Path.Combine(fileDirOutPath, "output_validation_y_act.csv");
                    output_yval_dt = LoadCSV.CsvReader(fileOutYValName);
                }
            }
            else if (method == "mod")
            {
                string fileInModDataName = Path.Combine(fileDirInPath, "input_mod_data.csv");
                string fileInFilterTrainingName = Path.Combine(fileDirInPath, "input_filtertraining.csv");
                string fileInFilterPredictName = Path.Combine(fileDirInPath, "input_filterpredict.csv");
                string fileInYValName = Path.Combine(fileDirInPath, "input_validation_y.csv");

                input_mod_data_dt = LoadCSV.CsvReader(fileInModDataName);
                input_filter_training_dt = LoadCSV.CsvReader(fileInFilterTrainingName);
                input_filter_predict_dt = LoadCSV.CsvReader(fileInFilterPredictName);
                input_ypre_dt = LoadCSV.CsvReader(fileInYValName);

                if (testNum >= 13)
                {
                    string fileOutModYValName = Path.Combine(fileDirOutPath, "output_mod_validation_y_python.csv");
                    string fileOutActModName = Path.Combine(fileDirOutPath, "output_act_mod_python.csv");
                    string fileOutConfIntName = Path.Combine(fileDirOutPath, "output_conf_int_python.csv");

                    output_modyval_dt = LoadCSV.CsvReader(fileOutModYValName);
                    output_act_mod_dt = LoadCSV.CsvReader(fileOutActModName);
                    output_conf_int_dt = LoadCSV.CsvReader(fileOutConfIntName);
                }
            }
        }

        public static void MinMaxFilterCSVToDataTable(string method, int filteringMode, string functionMode, int testNum, out DataTable input_xtra_dt, out DataTable input_ytra_dt, out DataTable input_filter_para_dt, out int[] filterTarget, out double[] MinBounds, out double[] MaxBounds, out DataTable output_filtered_act_dt, out DataTable output_filtered_x_dt, out DataTable output_filtered_y_dt)
        {
            string testName;
            string filteringName = FilteringModeToName(filteringMode);
            if (method == "all")
            {
                testName = string.Format("test{0}-{1}", filteringMode, functionMode);
            }
            else
            {
                testName = string.Format("test{0}-{1}-{2}", filteringMode, functionMode, testNum);
            }

            //カレントディレクトリのパスを取得//
            string strCurrentDir = System.IO.Directory.GetCurrentDirectory();
            //親のフォルダ（ソリューションファイルのフォルダ）のパスを取得//
            string strParentPath = GetParentDirectory.GetParentDir(strCurrentDir, 5);
            //テスト用サンプルファイルのパスを取得//
            string fileDirPath = Path.Combine(strParentPath, "test_sample", "Filtering-Test", filteringName, testName);
            string fileDirInPath = Path.Combine(fileDirPath, "input_file");
            string fileDirOutPath = Path.Combine(fileDirPath, "output_file");
            string fileInFilterHyperParam = Path.Combine(fileDirInPath, "input_Filter_param.csv");
            string fileInXTraName = Path.Combine(fileDirInPath, "input_training_x.csv");
            string fileInYTraName = Path.Combine(fileDirInPath, "input_training_y.csv");

            //CSVからDataTableとして変数を取得//
            input_filter_para_dt = LoadCSV.CsvReader(fileInFilterHyperParam);
            input_xtra_dt = LoadCSV.CsvReader(fileInXTraName);
            input_ytra_dt = LoadCSV.CsvReader(fileInYTraName);
            int i;
            //int[] filterTarget_;
            int[] filterTarget_ = new int[input_filter_para_dt.Rows.Count];
            double[] MinBounds_ = new double[input_filter_para_dt.Rows.Count];
            double[] MaxBounds_ = new double[input_filter_para_dt.Rows.Count];

            for (i = 0; i < input_filter_para_dt.Rows.Count; i++)
            {
                filterTarget_[i] = int.Parse((string)input_filter_para_dt.Rows[i]["filterTarget"]);
                MinBounds_[i] = double.Parse((string)input_filter_para_dt.Rows[i]["MinBounds"]);
                MaxBounds_[i] = double.Parse((string)input_filter_para_dt.Rows[i]["MaxBounds"]);

            }
            filterTarget = filterTarget_;
            MinBounds = MinBounds_;
            MaxBounds = MaxBounds_;

            output_filtered_act_dt = new DataTable();
            output_filtered_x_dt = new DataTable();
            output_filtered_y_dt = new DataTable();

            if (testNum >= 13)
            {
                string fileOutFilteredActName = Path.Combine(fileDirOutPath, "output_filtered_act_python.csv");
                string fileOutFilteredXName = Path.Combine(fileDirOutPath, "output_filtered_x_python.csv");
                string fileOutFilteredYName = Path.Combine(fileDirOutPath, "output_filtered_y_python.csv");

                output_filtered_act_dt = LoadCSV.CsvReader(fileOutFilteredActName);
                output_filtered_x_dt = LoadCSV.CsvReader(fileOutFilteredXName);
                output_filtered_y_dt = LoadCSV.CsvReader(fileOutFilteredYName);
            }
        }

        public static void MaharanobisFilterCSVToDataTable(string method, int filteringMode, string functionMode, int testNum, out DataTable input_xtra_dt, out DataTable input_ytra_dt, out DataTable input_filter_para_dt, out int[] filterTarget, out double OutlierRate, out DataTable output_filtered_act_dt, out DataTable output_filtered_x_dt, out DataTable output_filtered_y_dt)
        {
            string testName;
            string filteringName = FilteringModeToName(filteringMode);
            if (method == "all")
            {
                testName = string.Format("test{0}-{1}", filteringMode, functionMode);
            }
            else
            {
                testName = string.Format("test{0}-{1}-{2}", filteringMode, functionMode, testNum);
            }

            //カレントディレクトリのパスを取得//
            string strCurrentDir = System.IO.Directory.GetCurrentDirectory();
            //親のフォルダ（ソリューションファイルのフォルダ）のパスを取得//
            string strParentPath = GetParentDirectory.GetParentDir(strCurrentDir, 5);
            //テスト用サンプルファイルのパスを取得//
            string fileDirPath = Path.Combine(strParentPath, "test_sample", "Filtering-Test", filteringName, testName);
            string fileDirInPath = Path.Combine(fileDirPath, "input_file");
            string fileDirOutPath = Path.Combine(fileDirPath, "output_file");
            string fileInFilterHyperParam = Path.Combine(fileDirInPath, "input_Filter_param.csv");
            string fileInXTraName = Path.Combine(fileDirInPath, "input_training_x.csv");
            string fileInYTraName = Path.Combine(fileDirInPath, "input_training_y.csv");

            //CSVからDataTableとして変数を取得//
            input_filter_para_dt = LoadCSV.CsvReader(fileInFilterHyperParam);
            input_xtra_dt = LoadCSV.CsvReader(fileInXTraName);
            input_ytra_dt = LoadCSV.CsvReader(fileInYTraName);
            int i;
            //int[] filterTarget_;
            int[] filterTarget_ = new int[input_filter_para_dt.Rows.Count];

            for (i = 0; i < input_filter_para_dt.Rows.Count; i++)
            {
                filterTarget_[i] = int.Parse((string)input_filter_para_dt.Rows[i]["filterTarget"]);
            }
            filterTarget = filterTarget_;
            OutlierRate = double.Parse((string)input_filter_para_dt.Rows[0]["OutlierRate"]);

            output_filtered_act_dt = new DataTable();
            output_filtered_x_dt = new DataTable();
            output_filtered_y_dt = new DataTable();

            if (testNum >= 10)
            {
                string fileOutFilteredActName = Path.Combine(fileDirOutPath, "output_filtered_act_python.csv");
                string fileOutFilteredXName = Path.Combine(fileDirOutPath, "output_filtered_x_python.csv");
                string fileOutFilteredYName = Path.Combine(fileDirOutPath, "output_filtered_y_python.csv");

                output_filtered_act_dt = LoadCSV.CsvReader(fileOutFilteredActName);
                output_filtered_x_dt = LoadCSV.CsvReader(fileOutFilteredXName);
                output_filtered_y_dt = LoadCSV.CsvReader(fileOutFilteredYName);
            }
        }

        public static void DataTableToCSV(string method, int modelingMode, string functionMode, int testNum, DataTable output_dt, string filename)
        {
            string testName;
            string modelingName = ModelingModeToName(modelingMode);
            if (method == "all")
            {
                testName = string.Format("test{0}-{1}", modelingMode, functionMode);
            }
            else
            {
                testName = string.Format("test{0}-{1}-{2}", modelingMode, functionMode, testNum);
            }
            //カレントディレクトリのパスを取得//
            string strCurrentDir = System.IO.Directory.GetCurrentDirectory();
            //親のフォルダ（ソリューションファイルのフォルダ）のパスを取得//
            string strParentPath = GetParentDirectory.GetParentDir(strCurrentDir, 5);
            //テスト用サンプルファイルのパスを取得//
            string fileDirPath = Path.Combine(strParentPath, "test_sample", modelingName + "-Test", testName);
            string fileDirOutPath = Path.Combine(fileDirPath, "output_file");
            string fileOutName = Path.Combine(fileDirOutPath, filename);
            LoadCSV.DataTableToCsv(output_dt, fileOutName);
        }

        public static void FilterDataTableToCSV(string method, int filteringMode, string functionMode, int testNum, DataTable output_dt, string filename)
        {
            string testName;
            string filteringName = FilteringModeToName(filteringMode);
            if (method == "all")
            {
                testName = string.Format("test{0}-{1}", filteringMode, functionMode);
            }
            else
            {
                testName = string.Format("test{0}-{1}-{2}", filteringMode, functionMode, testNum);
            }
            //カレントディレクトリのパスを取得//
            string strCurrentDir = System.IO.Directory.GetCurrentDirectory();
            //親のフォルダ（ソリューションファイルのフォルダ）のパスを取得//
            string strParentPath = GetParentDirectory.GetParentDir(strCurrentDir, 5);
            //テスト用サンプルファイルのパスを取得//
            string fileDirPath = Path.Combine(strParentPath, "test_sample", "Filtering-Test", filteringName, testName);
            string fileDirOutPath = Path.Combine(fileDirPath, "output_file");
            string fileOutName = Path.Combine(fileDirOutPath, filename);
            LoadCSV.DataTableToCsv(output_dt, fileOutName);
        }

        public static void StringToTxt(string method, int modelingMode, string functionMode, int testNum, string output_str)
        {
            string testName;
            string modelingName = ModelingModeToName(modelingMode);
            if (method == "all")
            {
                testName = string.Format("test{0}-{1}", modelingMode, functionMode);
            }
            else
            {
                testName = string.Format("test{0}-{1}-{2}", modelingMode, functionMode, testNum);
            }
            //カレントディレクトリのパスを取得//
            string strCurrentDir = System.IO.Directory.GetCurrentDirectory();
            //親のフォルダ（ソリューションファイルのフォルダ）のパスを取得//
            string strParentPath = GetParentDirectory.GetParentDir(strCurrentDir, 5);
            //テスト用サンプルファイルのパスを取得//
            string fileDirPath = Path.Combine(strParentPath, "test_sample", modelingName + "-Test", testName);
            string fileDirOutPath = Path.Combine(fileDirPath, "output_file");
            //現状では文字列を出力するのはシリアライズ結果のみなので、決め打ち//
            string fileOutName = Path.Combine(fileDirOutPath, "output_serialized.txt");
            using (var sWrite = new StreamWriter(fileOutName))
            {
                sWrite.Write(output_str);
            }
        }

        static string ModelingModeToName(int modelingMode)
        {
            switch (modelingMode)
            {
                case 1:
                    return "MLR";
                case 2:
                    return "PLS";
                case 3:
                    return "RF";
                default:
                    throw new ArgumentOutOfRangeException("modelingMode", "Invalid modeling mode");
            }
        }

        static string FilteringModeToName(int filteringMode)
        {
            switch (filteringMode)
            {
                case 4:
                    return "MinMax";
                case 5:
                    return "Maharanobis";
                default:
                    throw new ArgumentOutOfRangeException("filteringMode", "Invalid filtering mode");
            }
        }
    }

    public static class CalcError
    {
        const double BigM = 10E+7;

        public static double[] ConvertNaNToNum(double[] error1)
        {
            double[] error = new double[error1.Length];
            Array.Copy(error1, error, error1.Length);
            int[] indexListNan = Enumerable.Range(0, error1.Length).Where(tt => Double.IsNaN(error1[tt])).ToArray();
            foreach (int iRel in indexListNan)
            {
                error[iRel] = BigM;
            }
            return error;
        }

        public static void CalcRelativeError(double[] realValue, double[] trueValue, out double[] error)
        {
            if (trueValue.Any(elm => elm == 0))
            {
                int[] indexList = Enumerable.Range(0, trueValue.Length).Where(tt => trueValue[tt] != 0).ToArray();
                error = trueValue.Zip(realValue, (trueval, realval) => Math.Abs((trueval - realval))).ToArray();
                foreach (int iRel in indexList)
                {
                    error[iRel] = error[iRel] / trueValue[iRel];
                }
            }
            else
            {
                error = trueValue.Zip(realValue, (trueval, realval) => Math.Abs((trueval - realval) / trueval)).ToArray();
            }

            if (error.Any(elm => Double.IsNaN(elm)))
            {
                error = ConvertNaNToNum(error);
            }
        }

        public static void CalcRelativeErrorint(int[] realValue, int[] trueValue, out double[] error)
        {
            if (trueValue.Any(elm => elm == 0))
            {
                int[] indexList = Enumerable.Range(0, trueValue.Length).Where(tt => trueValue[tt] != 0).ToArray();
                error = trueValue.Zip(realValue, (trueval, realval) => Math.Abs((Convert.ToDouble(trueval) - Convert.ToDouble(realval)))).ToArray();
                foreach (int iRel in indexList)
                {
                    error[iRel] = error[iRel] / trueValue[iRel];
                }
            }
            else
            {
                error = trueValue.Zip(realValue, (trueval, realval) => Math.Abs((Convert.ToDouble(trueval) - Convert.ToDouble(realval)) / trueval)).ToArray();
            }

            if (error.Any(elm => Double.IsNaN(elm)))
            {
                error = ConvertNaNToNum(error);
            }
        }

        public static void ErrorCalculation(double[] realValue, double[] trueValue, out double error)
        {
            CalcRelativeError(realValue, trueValue, out double[] relativeError);
            error = relativeError.Max();
        }

        public static void ErrorCalculationint(int[] realValue, int[] trueValue, out double error)
        {
            CalcRelativeErrorint(realValue, trueValue, out double[] relativeError);
            error = relativeError.Max();
        }

        public static void ErrorCalculation2Ddouble(double[][] realValue, double[][] trueValue, out double error)
        {
            int rowSize = trueValue.Length;
            List<double> errorList = new List<double> { };
            for (int i = 0; i < rowSize; i++)
            {
                ErrorCalculation(realValue[i], trueValue[i], out double elem);
                errorList.Add(elem);
            }
            error = errorList.Max();
        }

        public static void CalcMAPE(double[] realValue, double[] trueValue, out double mape)
        {
            CalcRelativeError(realValue, trueValue, out double[] relativeError);
            mape = relativeError.Average();
        }

    }

    public class ExecTest
    {
        const double targetAccuracy1 = 0.2;
        const double targetAccuracy2 = 0.3;
        const double targetTime = 300;

        public static double[] Threshold(string method, int testNum)
        {
            int[] testNumSpecial = new int[] { };
            double targetAccuracy;
            //特殊ケースの場合、精度閾値を緩和する。
            if (method == "fit")
            {
                testNumSpecial = new int[4] { 13, 15, 19, 20 };
            }
            else if (method == "predict")
            {
                testNumSpecial = new int[1] { 5 };
            }

            if (testNumSpecial.Contains(testNum))
            {
                targetAccuracy = targetAccuracy2;
            }
            else
            {
                targetAccuracy = targetAccuracy1;
            }
            double[] ThresholdArray = new double[2] { targetAccuracy, targetTime };
            return ThresholdArray;
        }

        public static int RFModelTest(dynamic forest_dynamic, int numTree, Nullable<int> numMaxDepth, int numMinSplit)
        {
            List<List<RFModel.Node>> forest = forest_dynamic;
            int numTreeGet = forest.Count;

            // depth: 各木において、分岐可能なノードの場合、分岐先のノードの深さとして+1していき、最後のノードの値が深さ
            // split: 各木において、葉ノード内のサンプル数をカウントしていき、その最大値が全葉ノードの最大サンプル数
            int[] depthGet = new int[numTreeGet];
            int[] splitGet = new int[numTreeGet];
            for (int i = 0; i < numTreeGet; i++)
            {
                List<RFModel.Node> tree = forest[i];
                int[] depths = new int[tree.Count];
                List<int> splits = new List<int> { };
                depths[0] = 0;
                for (int j = 0; j < tree.Count; j++)//
                {
                    RFModel.Node node = tree[j];
                    if (node.leftNode > 0)
                    {
                        depths[node.leftNode] = depths[j] + 1;
                        depths[node.leftNode + 1] = depths[j] + 1;
                    }
                    else
                    {
                        // 例外処理された葉ノードの場合、nodes.rowsCountを負にしているため、正常処理された葉ノードのサンプル数だけをAddする
                        if (node.rowsCount > 0)
                        {
                           splits.Add(node.rowsCount);
                        }
                    }
                }
                depthGet[i] = depths.Last();
                // 全ての葉ノードが例外処理された場合、0とする
                if (splits.Count == 0)
                {
                    splitGet[i] = 0;
                }
                else
                { 
                    splitGet[i] = splits.Max();
                }
            }

            //ハイパーパラメータの設定が、学習したモデルに反映されているか//
            int Err = 0;
            int element = 0;
            if (numTree != numTreeGet)
            {
                Err = 1;
            }

            // numSplit <= numMinSplit or numDepth <= numMaxDepth   => OK
            // numSplit >  numMinSplit or numDepth >  numMaxDepth   => NG
            element = (numMaxDepth == null) ? splitGet.Count(numSplitGet => numMinSplit < numSplitGet) : depthGet.Count(numDepthGet => numMaxDepth < numDepthGet);
            if (element > 0)
            {
                Err = 1;
            }

            return Err;
        }

        public static void RFPreTest(string method, int testNum, double timeSecond, double[] ypre, double[] yval, out double[][] resultArray, out int Err)
        {
            Err = 0;
            double[] ThresholdArray = Threshold(method, testNum);
            double targetAccuracy = ThresholdArray[0];
            double targetTime = ThresholdArray[1];
            MakeResult(timeSecond, ypre, yval, ThresholdArray, out resultArray, out double mape);

            //モデル精度と計算時間が基準を満たしているか//
            if (timeSecond > targetTime)
            {
                Err = 1;
            }
            if (mape > targetAccuracy)
            {
                Err = 1;
            }
            return;
        }

        public static void MakeResult(double timeSecond, double[] ypre, double[] yval, double[] ThresholdArray, out double[][] resultArray, out double mape)
        {
            resultArray = new double[2][];
            resultArray[0] = new double[2];
            resultArray[1] = new double[2];
            double targetAccuracy = ThresholdArray[0];
            double targetTime = ThresholdArray[1];

            //予測精度//
            CalcError.CalcMAPE(ypre, yval, out mape);
            resultArray[0][0] = mape * 100;
            resultArray[1][0] = targetAccuracy * 100;

            //時間計測//
            resultArray[0][1] = timeSecond;
            resultArray[1][1] = targetTime;

            return;
        }

    }


    [TestClass]
    public class MLR_Test
    {
        const double relTolerance = 1E-7;
        const double relTolerance1 = 1.1;

        [TestMethod]
        public void Test1_basic()
        {
            int modelingMode = 1;
            string functionMode = "basic";
            int testNum = 0;
            string method = "all";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, 
                                      out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, 
                                      out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_pre_size = input_xpre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 予測期間データ//
            double[][] xpre = new double[timestamp_pre_size][];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_x_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            //シリアライズモデル//
            string serializedModel;

            //output//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size + 1];
            //補正済予測//
            double[] yPreMod = new double[timestamp_pre_size];
            //予測区間//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績フラグ//
            int[] actMod = new int[timestamp_pre_size];


            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayMLR(input_xtra_dt, input_ytra_dt, input_xpre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, out xtra, out ytra, out xpre, out modData, out filtTra, out filtPre, out modPara);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            m.Fit(xtra, ytra);

            //シリアライズ//
            m.Serialize(out serializedModel);

            //デシリアライズ//
            m.Deserialize(serializedModel);

            //予測//
            m.Predict(xpre, out ypre);

            //予測値補正//
            m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output_dt, output1_dt, output2_dt, output3_dt;
            TransformData.Array1DRowToDataTable(ypre, "Actual", out output_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_validation_y.csv");
            TransformData.Array1DRowToDataTable(yPreMod, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output1_dt, "output_mod_validation_y.csv");
            TransformData.Array2DToDataTable(confInt, new string[] { "Lower", "Upper" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output2_dt, "output_conf_int.csv");
            TransformData.Array1DRowToDataTable(actMod, "Actual Modify", out output3_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output3_dt, "output_act_mod.csv");
        }

        [TestMethod]
        public void Test1_1_1()
        {
            int modelingMode = 1;
            string functionMode = "1";
            int testNum = 1;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //正解のモデルパラメータ//
            double[] parav;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, output_parav_dt, out xtra, out ytra, out modPara, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(100, m.Fit(xtra, ytra));
        }

        [TestMethod]
        public void Test1_1_2()
        {
            int modelingMode = 1;
            string functionMode = "1";
            int testNum = 2;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //正解のモデルパラメータ//
            double[] parav;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, output_parav_dt, out xtra, out ytra, out modPara, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(101, m.Fit(xtra, ytra));
        }

        [TestMethod]
        public void Test1_1_3()
        {
            int modelingMode = 1;
            string functionMode = "1";
            int testNum = 3;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //正解のモデルパラメータ//
            double[] parav;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, output_parav_dt, out xtra, out ytra, out modPara, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //NaNの代入//
            xtra[0][0] = Double.NaN;

            //学習//
            Assert.AreEqual(102, m.Fit(xtra, ytra));
        }

        [TestMethod]
        public void Test1_1_4()
        {
            int modelingMode = 1;
            string functionMode = "1";
            int testNum = 4;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //正解のモデルパラメータ//
            double[] parav;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, output_parav_dt, out xtra, out ytra, out modPara, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //NaNの代入//
            ytra[0] = Double.NaN;

            //学習//
            Assert.AreEqual(102, m.Fit(xtra, ytra));
        }

        [TestMethod]
        public void Test1_1_5()
        {
            int modelingMode = 1;
            string functionMode = "1";
            int testNum = 5;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, output_parav_dt, out xtra, out ytra, out modPara, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(0, m.Fit(xtra, ytra));

            //モデルパラメータ//
            //model objectを取得//
            dynamic coef = new PrivateObject(m).GetField("coef");

            //Jagg配列からDataTableに変換//
            DataTable output_dt = new DataTable();
            TransformData.ArrayToDataTable1(testNum, coef, out output_dt);

            //DataTableをcsvとして出力//
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_modelparameter.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(coef, parav, out relError);
            Assert.AreEqual(0, relError, relTolerance1);
        }

        [TestMethod]
        public void Test1_1_6()
        {
            int modelingMode = 1;
            string functionMode = "1";
            int testNum = 6;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);


            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, output_parav_dt, out xtra, out ytra, out modPara, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(0, m.Fit(xtra, ytra));

            //モデルパラメータ//
            //model objectを取得//
            dynamic coef = new PrivateObject(m).GetField("coef");

            //Jagg配列からDataTableに変換//
            DataTable output_dt = new DataTable();
            TransformData.ArrayToDataTable1(testNum, coef, out output_dt);

            //DataTableをcsvとして出力//
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_modelparameter.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(coef, parav, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test1_1_7()
        {
            int modelingMode = 1;
            string functionMode = "1";
            int testNum = 7;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, output_parav_dt, out xtra, out ytra, out modPara, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(0, m.Fit(xtra, ytra));

            //モデルパラメータ//
            //model objectを取得//
            dynamic coef = new PrivateObject(m).GetField("coef");

            //Jagg配列からDataTableに変換//
            DataTable output_dt = new DataTable();
            TransformData.ArrayToDataTable1(testNum, coef, out output_dt);

            //DataTableをcsvとして出力//
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_modelparameter.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(coef, parav, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test1_1_8()
        {
            int modelingMode = 1;
            string functionMode = "1";
            int testNum = 8;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, output_parav_dt, out xtra, out ytra, out modPara, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(0, m.Fit(xtra, ytra));

            //モデルパラメータ//
            //model objectを取得//
            dynamic coef = new PrivateObject(m).GetField("coef");

            //Jagg配列からDataTableに変換//
            DataTable output_dt = new DataTable();
            TransformData.ArrayToDataTable1(testNum, coef, out output_dt);

            //DataTableをcsvとして出力//
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_modelparameter.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(coef, parav, out relError);
            Assert.AreEqual(0, relError, relTolerance);

        }

        [TestMethod]
        public void Test1_1_9()
        {
            int modelingMode = 1;
            string functionMode = "1";
            int testNum = 9;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, output_parav_dt, out xtra, out ytra, out modPara, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(0, m.Fit(xtra, ytra));

            //モデルパラメータ//
            //model objectを取得//
            dynamic coef = new PrivateObject(m).GetField("coef");

            //Jagg配列からDataTableに変換//
            DataTable output_dt = new DataTable();
            TransformData.ArrayToDataTable1(testNum, coef, out output_dt);

            //DataTableをcsvとして出力//
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_modelparameter.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(coef, parav, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test1_1_10()
        {
            int modelingMode = 1;
            string functionMode = "1";
            int testNum = 10;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, output_parav_dt, out xtra, out ytra, out modPara, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(0, m.Fit(xtra, ytra));

            //モデルパラメータ//
            //model objectを取得//
            dynamic coef = new PrivateObject(m).GetField("coef");

            //Jagg配列からDataTableに変換//
            DataTable output_dt = new DataTable();
            TransformData.ArrayToDataTable1(testNum, coef, out output_dt);

            //DataTableをcsvとして出力//
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_modelparameter.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(coef, parav, out relError);
            Assert.AreEqual(0, relError, relTolerance1);
        }

        [TestMethod]
        public void Test1_1_11()
        {
            int modelingMode = 1;
            string functionMode = "1";
            int testNum = 11;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, output_parav_dt, out xtra, out ytra, out modPara, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(0, m.Fit(xtra, ytra));

            //モデルパラメータ//
            //model objectを取得//
            dynamic coef = new PrivateObject(m).GetField("coef");

            //Jagg配列からDataTableに変換//
            DataTable output_dt = new DataTable();
            TransformData.ArrayToDataTable1(testNum, coef, out output_dt);

            //DataTableをcsvとして出力//
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_modelparameter.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(coef, parav, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test1_1_12()
        {
            int modelingMode = 1;
            string functionMode = "1";
            int testNum = 12;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //正解のモデルパラメータ//
            double[] parav;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, output_parav_dt, out xtra, out ytra, out modPara, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            //Assert.AreEqual(700, m.Fit(xtra, ytra));
            Assert.AreEqual(0, m.Fit(xtra, ytra));
        }

        [TestMethod]
        public void Test1_1_13()
        {
            int modelingMode = 1;
            string functionMode = "1";
            int testNum = 13;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //正解のモデルパラメータ//
            double[] parav;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, output_parav_dt, out xtra, out ytra, out modPara, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(101, m.Fit(xtra, ytra));
        }

        [TestMethod]
        public void Test1_1_14()
        {
            int modelingMode = 1;
            string functionMode = "1";
            int testNum = 14;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, output_parav_dt, out xtra, out ytra, out modPara, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(0, m.Fit(xtra, ytra));

            //モデルパラメータ//
            //model objectを取得//
            dynamic coef = new PrivateObject(m).GetField("coef");

            //Jagg配列からDataTableに変換//
            DataTable output_dt = new DataTable();
            TransformData.ArrayToDataTable1(testNum, coef, out output_dt);

            //DataTableをcsvとして出力//
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_modelparameter.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(coef, parav, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test1_1_15()
        {
            int modelingMode = 1;
            string functionMode = "1";
            int testNum = 15;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //正解のモデルパラメータ//
            double[] parav;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, output_parav_dt, out xtra, out ytra, out modPara, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(700, m.Fit(xtra, ytra));
        }

        [TestMethod]
        public void Test1_1_16()
        {
            int modelingMode = 1;
            string functionMode = "1";
            int testNum = 16;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //正解のモデルパラメータ//
            double[] parav;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, output_parav_dt, out xtra, out ytra, out modPara, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(700, m.Fit(xtra, ytra));
        }

        [TestMethod]
        [ExpectedException(typeof(DivideByZeroException))]
        public void Test1_1_17()
        {
            int modelingMode = 1;
            string functionMode = "1";
            int testNum = 17;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //正解のモデルパラメータ//
            double[] parav;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, output_parav_dt, out xtra, out ytra, out modPara, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            //exception error: System.DivideByZeroException
            Assert.AreEqual(700, m.Fit(xtra, ytra));
        }

        [TestMethod]
        public void Test1_1_18()
        {
            int modelingMode = 1;
            string functionMode = "1";
            int testNum = 18;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //正解のモデルパラメータ//
            double[] parav;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, output_parav_dt, out xtra, out ytra, out modPara, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(700, m.Fit(xtra, ytra));
        }

        [TestMethod]
        public void Test1_1_19()
        {
            int modelingMode = 1;
            string functionMode = "1";
            int testNum = 19;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //正解のモデルパラメータ//
            double[] parav;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, output_parav_dt, out xtra, out ytra, out modPara, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(700, m.Fit(xtra, ytra));
        }

        [TestMethod]
        public void Test1_2_1()
        {
            int modelingMode = 1;
            string functionMode = "2";
            int testNum = 1;
            string method = "predict";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xpre_dt.Columns.Count;
            int timestamp_pre_size = input_xpre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int parav_size = input_parav_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 予測期間データ//
            double[][] xpre = new double[timestamp_pre_size][];
            //モデルパラメータ//
            double[] parav = new double[variable_size + 1];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];

            //output//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yval;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray2(input_xpre_dt, input_parav_dt, input_mod_para_dt, output_yval_dt, out xpre, out parav, out modPara, out yval);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //モデルパラメータの代入//
            new PrivateObject(m).SetField("coef", parav);

            //予測//
            Assert.AreEqual(200, m.Predict(xpre, out ypre));

        }

        [TestMethod]
        public void Test1_2_2()
        {
            int modelingMode = 1;
            string functionMode = "2";
            int testNum = 2;
            string method = "predict";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xpre_dt.Columns.Count;
            int timestamp_pre_size = input_xpre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int parav_size = input_parav_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 予測期間データ//
            double[][] xpre = new double[timestamp_pre_size][];
            //モデルパラメータ//
            double[] parav = new double[variable_size + 1];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];

            //output//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yval;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray2(input_xpre_dt, input_parav_dt, input_mod_para_dt, output_yval_dt, out xpre, out parav, out modPara, out yval);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //モデルパラメータの代入//
            new PrivateObject(m).SetField("coef", parav);

            //NaNの代入//
            xpre[0][0] = Double.NaN;

            //予測//
            Assert.AreEqual(201, m.Predict(xpre, out ypre));
        }

        [TestMethod]
        public void Test1_2_3()
        {
            int modelingMode = 1;
            string functionMode = "2";
            int testNum = 3;
            string method = "predict";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xpre_dt.Columns.Count;
            int timestamp_pre_size = input_xpre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int parav_size = input_parav_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 予測期間データ//
            double[][] xpre = new double[timestamp_pre_size][];
            //モデルパラメータ//
            double[] parav = new double[variable_size + 1];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];

            //output//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yval;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray2(input_xpre_dt, input_parav_dt, input_mod_para_dt, output_yval_dt, out xpre, out parav, out modPara, out yval);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //モデルパラメータの代入//
            new PrivateObject(m).SetField("coef", parav);


            //予測//
            //Assert.AreEqual(300, m.Predict(xpre, out ypre));
            Assert.AreEqual(0, m.Predict(xpre, out ypre));
        }

        [TestMethod]
        public void Test1_2_4()
        {
            int modelingMode = 1;
            string functionMode = "2";
            int testNum = 4;
            string method = "predict";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xpre_dt.Columns.Count;
            int timestamp_pre_size = input_xpre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int parav_size = input_parav_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 予測期間データ//
            double[][] xpre = new double[timestamp_pre_size][];
            //モデルパラメータ//
            double[] parav = new double[variable_size + 1];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];

            //output//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yval;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray2(input_xpre_dt, input_parav_dt, input_mod_para_dt, output_yval_dt, out xpre, out parav, out modPara, out yval);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //モデルパラメータの代入//
            new PrivateObject(m).SetField("coef", parav);

            //予測//
            m.Predict(xpre, out ypre);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output_dt;
            TransformData.Array1DRowToDataTable(ypre, "Actual", out output_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_validation_y.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(ypre, yval, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test1_2_5()
        {
            int modelingMode = 1;
            string functionMode = "2";
            int testNum = 5;
            string method = "predict";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xpre_dt.Columns.Count;
            int timestamp_pre_size = input_xpre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int parav_size = input_parav_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 予測期間データ//
            double[][] xpre = new double[timestamp_pre_size][];
            //モデルパラメータ//
            double[] parav = new double[variable_size + 1];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];

            //output//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yval;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray2(input_xpre_dt, input_parav_dt, input_mod_para_dt, output_yval_dt, out xpre, out parav, out modPara, out yval);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //モデルパラメータの代入//
            new PrivateObject(m).SetField("coef", parav);

            //予測//
            m.Predict(xpre, out ypre);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output_dt;
            TransformData.Array1DRowToDataTable(ypre, "Actual", out output_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_validation_y.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(ypre, yval, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test1_2_6()
        {
            int modelingMode = 1;
            string functionMode = "2";
            int testNum = 6;
            string method = "predict";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xpre_dt.Columns.Count;
            int timestamp_pre_size = input_xpre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int parav_size = input_parav_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 予測期間データ//
            double[][] xpre = new double[timestamp_pre_size][];
            //モデルパラメータ//
            double[] parav = new double[variable_size + 1];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];

            //output//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yval;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray2(input_xpre_dt, input_parav_dt, input_mod_para_dt, output_yval_dt, out xpre, out parav, out modPara, out yval);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //モデルパラメータの代入//
            new PrivateObject(m).SetField("coef", parav);

            //予測//
            m.Predict(xpre, out ypre);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output_dt;
            TransformData.Array1DRowToDataTable(ypre, "Actual", out output_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_validation_y.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(ypre, yval, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test1_2_7()
        {
            int modelingMode = 1;
            string functionMode = "2";
            int testNum = 7;
            string method = "predict";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xpre_dt.Columns.Count;
            int timestamp_pre_size = input_xpre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int parav_size = input_parav_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 予測期間データ//
            double[][] xpre = new double[timestamp_pre_size][];
            //モデルパラメータ//
            double[] parav = new double[variable_size + 1];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];

            //output//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yval;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray2(input_xpre_dt, input_parav_dt, input_mod_para_dt, output_yval_dt, out xpre, out parav, out modPara, out yval);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //モデルパラメータの代入//
            new PrivateObject(m).SetField("coef", parav);

            //予測//
            m.Predict(xpre, out ypre);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output_dt;
            TransformData.Array1DRowToDataTable(ypre, "Actual", out output_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_validation_y.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(ypre, yval, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test1_2_8()
        {
            int modelingMode = 1;
            string functionMode = "2";
            int testNum = 8;
            string method = "predict";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xpre_dt.Columns.Count;
            int timestamp_pre_size = input_xpre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int parav_size = input_parav_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 予測期間データ//
            double[][] xpre = new double[timestamp_pre_size][];
            //モデルパラメータ//
            double[] parav = new double[variable_size + 1];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];

            //output//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yval;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray2(input_xpre_dt, input_parav_dt, input_mod_para_dt, output_yval_dt, out xpre, out parav, out modPara, out yval);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //モデルパラメータの代入//
            new PrivateObject(m).SetField("coef", parav);

            //予測//
            m.Predict(xpre, out ypre);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output_dt;
            TransformData.Array1DRowToDataTable(ypre, "Actual", out output_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_validation_y.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(ypre, yval, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test1_3_1()
        {
            int modelingMode = 1;
            string functionMode = "3";
            int testNum = 1;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            Assert.AreEqual(400, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test1_3_2()
        {
            int modelingMode = 1;
            string functionMode = "3";
            int testNum = 2;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            Assert.AreEqual(401, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test1_3_3()
        {
            int modelingMode = 1;
            string functionMode = "3";
            int testNum = 3;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            Assert.AreEqual(401, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test1_3_4()
        {
            int modelingMode = 1;
            string functionMode = "3";
            int testNum = 4;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            Assert.AreEqual(402, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test1_3_5()
        {
            int modelingMode = 1;
            string functionMode = "3";
            int testNum = 5;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            Assert.AreEqual(403, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test1_3_6()
        {
            int modelingMode = 1;
            string functionMode = "3";
            int testNum = 6;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out yValModTrue, out confIntTrue, out actModTrue);

            //NaNの代入//
            modPara[0] = Double.NaN;

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            Assert.AreEqual(404, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test1_3_7()
        {
            int modelingMode = 1;
            string functionMode = "3";
            int testNum = 7;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            Assert.AreEqual(405, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test1_3_8()
        {
            int modelingMode = 1;
            string functionMode = "3";
            int testNum = 8;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            Assert.AreEqual(406, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test1_3_9()
        {
            int modelingMode = 1;
            string functionMode = "3";
            int testNum = 9;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            Assert.AreEqual(407, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test1_3_10()
        {
            int modelingMode = 1;
            string functionMode = "3";
            int testNum = 10;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            Assert.AreEqual(408, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test1_3_11()
        {
            int modelingMode = 1;
            string functionMode = "3";
            int testNum = 11;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //NaNの代入//
            modData[0][0] = Double.NaN;

            //予測//
            Assert.AreEqual(409, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test1_3_12()
        {
            int modelingMode = 1;
            string functionMode = "3";
            int testNum = 12;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            //Assert.AreEqual(500, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
            Assert.AreEqual(0, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));

        }

        [TestMethod]
        public void Test1_3_13()
        {
            int modelingMode = 1;
            string functionMode = "3";
            int testNum = 13;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            TransformData.Array1DRowToDataTable(yPreMod, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output1_dt, "output_mod_validation_y.csv");
            TransformData.Array2DToDataTable(confInt, new string[] { "Lower", "Upper" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output2_dt, "output_conf_int.csv");
            TransformData.Array1DRowToDataTable(actMod, "Actual Modify", out output3_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output3_dt, "output_act_mod.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(yPreMod, yValModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(confInt, confIntTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculationint(actMod, actModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test1_3_14()
        {
            int modelingMode = 1;
            string functionMode = "3";
            int testNum = 14;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            TransformData.Array1DRowToDataTable(yPreMod, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output1_dt, "output_mod_validation_y.csv");
            TransformData.Array2DToDataTable(confInt, new string[] { "Lower", "Upper" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output2_dt, "output_conf_int.csv");
            TransformData.Array1DRowToDataTable(actMod, "Actual Modify", out output3_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output3_dt, "output_act_mod.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(yPreMod, yValModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(confInt, confIntTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculationint(actMod, actModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test1_3_15()
        {
            int modelingMode = 1;
            string functionMode = "3";
            int testNum = 15;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            TransformData.Array1DRowToDataTable(yPreMod, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output1_dt, "output_mod_validation_y.csv");
            TransformData.Array2DToDataTable(confInt, new string[] { "Lower", "Upper" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output2_dt, "output_conf_int.csv");
            TransformData.Array1DRowToDataTable(actMod, "Actual Modify", out output3_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output3_dt, "output_act_mod.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(yPreMod, yValModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(confInt, confIntTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculationint(actMod, actModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test1_3_16()
        {
            int modelingMode = 1;
            string functionMode = "3";
            int testNum = 16;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            TransformData.Array1DRowToDataTable(yPreMod, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output1_dt, "output_mod_validation_y.csv");
            TransformData.Array2DToDataTable(confInt, new string[] { "Lower", "Upper" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output2_dt, "output_conf_int.csv");
            TransformData.Array1DRowToDataTable(actMod, "Actual Modify", out output3_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output3_dt, "output_act_mod.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(yPreMod, yValModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(confInt, confIntTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculationint(actMod, actModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test1_3_17()
        {
            int modelingMode = 1;
            string functionMode = "3";
            int testNum = 17;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            TransformData.Array1DRowToDataTable(yPreMod, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output1_dt, "output_mod_validation_y.csv");
            TransformData.Array2DToDataTable(confInt, new string[] { "Lower", "Upper" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output2_dt, "output_conf_int.csv");
            TransformData.Array1DRowToDataTable(actMod, "Actual Modify", out output3_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output3_dt, "output_act_mod.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(yPreMod, yValModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(confInt, confIntTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculationint(actMod, actModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test1_3_18()
        {
            int modelingMode = 1;
            string functionMode = "3";
            int testNum = 18;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            TransformData.Array1DRowToDataTable(yPreMod, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output1_dt, "output_mod_validation_y.csv");
            TransformData.Array2DToDataTable(confInt, new string[] { "Lower", "Upper" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output2_dt, "output_conf_int.csv");
            TransformData.Array1DRowToDataTable(actMod, "Actual Modify", out output3_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output3_dt, "output_act_mod.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(yPreMod, yValModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(confInt, confIntTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculationint(actMod, actModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test1_3_19()
        {
            int modelingMode = 1;
            string functionMode = "3";
            int testNum = 19;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MLRCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.MLRDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new MLRHyperParameter(modPara);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            TransformData.Array1DRowToDataTable(yPreMod, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output1_dt, "output_mod_validation_y.csv");
            TransformData.Array2DToDataTable(confInt, new string[] { "Lower", "Upper" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output2_dt, "output_conf_int.csv");
            TransformData.Array1DRowToDataTable(actMod, "Actual Modify", out output3_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output3_dt, "output_act_mod.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(yPreMod, yValModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(confInt, confIntTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculationint(actMod, actModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }



    }

    [TestClass]
    public class PLS_Test
    {
        const double relTolerance = 1E-7;
        const double relTolerance1 = 1E-1;

        [TestMethod]
        public void Test2_basic()
        {
            int modelingMode = 2;
            string functionMode = "basic";
            int testNum = 0;
            string method = "all";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_pre_size = input_xpre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 予測期間データ//
            double[][] xpre = new double[timestamp_pre_size][];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_x_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            //潜在変数//
            int numLV = new int();
            //シリアライズモデル//
            string serializedModel;

            //output//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size + 1];
            //補正済予測//
            double[] yPreMod = new double[timestamp_pre_size];
            //予測区間//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績フラグ//
            int[] actMod = new int[timestamp_pre_size];

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayPLS(input_xtra_dt, input_ytra_dt, input_xpre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_numLV_dt, out xtra, out ytra, out xpre, out modData, out filtTra, out filtPre, out modPara, out numLV);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            m.Fit(xtra, ytra);

            //シリアライズ//
            m.Serialize(out serializedModel);

            //デシリアライズ//
            m.Deserialize(serializedModel);

            //予測//
            m.Predict(xpre, out ypre);

            //予測値補正//
            m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output_dt, output1_dt, output2_dt, output3_dt;
            TransformData.Array1DRowToDataTable(ypre, "Actual", out output_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_validation_y.csv");
            TransformData.Array1DRowToDataTable(yPreMod, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output1_dt, "output_mod_validation_y.csv");
            TransformData.Array2DToDataTable(confInt, new string[] { "Lower", "Upper" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output2_dt, "output_conf_int.csv");
            TransformData.Array1DRowToDataTable(actMod, "Actual Modify", out output3_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output3_dt, "output_act_mod.csv");
        }

        [TestMethod]
        public void Test2_1_1()
        {
            int modelingMode = 2;
            string functionMode = "1";
            int testNum = 1;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_numLV_dt, output_parav_dt, out xtra, out ytra, out modPara, out numLV, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(100, m.Fit(xtra, ytra));

        }

        [TestMethod]
        public void Test2_1_2()
        {
            int modelingMode = 2;
            string functionMode = "1";
            int testNum = 2;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_numLV_dt, output_parav_dt, out xtra, out ytra, out modPara, out numLV, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(111, m.Fit(xtra, ytra));

        }

        [TestMethod]
        public void Test2_1_3()
        {
            int modelingMode = 2;
            string functionMode = "1";
            int testNum = 3;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_numLV_dt, output_parav_dt, out xtra, out ytra, out modPara, out numLV, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //NaNの代入//
            xtra[0][0] = Double.NaN;

            //学習//
            Assert.AreEqual(102, m.Fit(xtra, ytra));

        }

        [TestMethod]
        public void Test2_1_4()
        {
            int modelingMode = 2;
            string functionMode = "1";
            int testNum = 4;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_numLV_dt, output_parav_dt, out xtra, out ytra, out modPara, out numLV, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //NaNの代入//
            ytra[0] = Double.NaN;

            //学習//
            Assert.AreEqual(102, m.Fit(xtra, ytra));

        }

        [TestMethod]
        public void Test2_1_5()
        {
            int modelingMode = 2;
            string functionMode = "1";
            int testNum = 5;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_numLV_dt, output_parav_dt, out xtra, out ytra, out modPara, out numLV, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(103, m.Fit(xtra, ytra));

        }

        [TestMethod]
        public void Test2_1_6()
        {
            int modelingMode = 2;
            string functionMode = "1";
            int testNum = 6;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_numLV_dt, output_parav_dt, out xtra, out ytra, out modPara, out numLV, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(103, m.Fit(xtra, ytra));

        }

        [TestMethod]
        public void Test2_1_7()
        {
            int modelingMode = 2;
            string functionMode = "1";
            int testNum = 7;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_numLV_dt, output_parav_dt, out xtra, out ytra, out modPara, out numLV, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(0, m.Fit(xtra, ytra));

            //モデルパラメータ//
            //model objectを取得//
            dynamic coef = new PrivateObject(m).GetField("coef");

            //Jagg配列からDataTableに変換//
            DataTable output_dt = new DataTable();
            TransformData.ArrayToDataTable1(testNum, coef, out output_dt);

            //DataTableをcsvとして出力//
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_modelparameter.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(coef, parav, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test2_1_8()
        {
            int modelingMode = 2;
            string functionMode = "1";
            int testNum = 8;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_numLV_dt, output_parav_dt, out xtra, out ytra, out modPara, out numLV, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(0, m.Fit(xtra, ytra));

            //モデルパラメータ//
            //model objectを取得//
            dynamic coef = new PrivateObject(m).GetField("coef");

            //Jagg配列からDataTableに変換//
            DataTable output_dt = new DataTable();
            TransformData.ArrayToDataTable1(testNum, coef, out output_dt);

            //DataTableをcsvとして出力//
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_modelparameter.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(coef, parav, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test2_1_9()
        {
            int modelingMode = 2;
            string functionMode = "1";
            int testNum = 9;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_numLV_dt, output_parav_dt, out xtra, out ytra, out modPara, out numLV, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(0, m.Fit(xtra, ytra));

            //モデルパラメータ//
            //model objectを取得//
            dynamic coef = new PrivateObject(m).GetField("coef");

            //Jagg配列からDataTableに変換//
            DataTable output_dt = new DataTable();
            TransformData.ArrayToDataTable1(testNum, coef, out output_dt);

            //DataTableをcsvとして出力//
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_modelparameter.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(coef, parav, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test2_1_10()
        {
            int modelingMode = 2;
            string functionMode = "1";
            int testNum = 10;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_numLV_dt, output_parav_dt, out xtra, out ytra, out modPara, out numLV, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(0, m.Fit(xtra, ytra));

            //モデルパラメータ//
            //model objectを取得//
            dynamic coef = new PrivateObject(m).GetField("coef");

            //Jagg配列からDataTableに変換//
            DataTable output_dt = new DataTable();
            TransformData.ArrayToDataTable1(testNum, coef, out output_dt);

            //DataTableをcsvとして出力//
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_modelparameter.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(coef, parav, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test2_1_11()
        {
            int modelingMode = 2;
            string functionMode = "1";
            int testNum = 11;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_numLV_dt, output_parav_dt, out xtra, out ytra, out modPara, out numLV, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(0, m.Fit(xtra, ytra));

            //モデルパラメータ//
            //model objectを取得//
            dynamic coef = new PrivateObject(m).GetField("coef");

            //Jagg配列からDataTableに変換//
            DataTable output_dt = new DataTable();
            TransformData.ArrayToDataTable1(testNum, coef, out output_dt);

            //DataTableをcsvとして出力//
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_modelparameter.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(coef, parav, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test2_1_12()
        {
            int modelingMode = 2;
            string functionMode = "1";
            int testNum = 12;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_numLV_dt, output_parav_dt, out xtra, out ytra, out modPara, out numLV, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(0, m.Fit(xtra, ytra));

            //モデルパラメータ//
            //model objectを取得//
            dynamic coef = new PrivateObject(m).GetField("coef");

            //Jagg配列からDataTableに変換//
            DataTable output_dt = new DataTable();
            TransformData.ArrayToDataTable1(testNum, coef, out output_dt);

            //DataTableをcsvとして出力//
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_modelparameter.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(coef, parav, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test2_1_13()
        {
            int modelingMode = 2;
            string functionMode = "1";
            int testNum = 13;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_numLV_dt, output_parav_dt, out xtra, out ytra, out modPara, out numLV, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(0, m.Fit(xtra, ytra));

            //モデルパラメータ//
            //model objectを取得//
            dynamic coef = new PrivateObject(m).GetField("coef");

            //Jagg配列からDataTableに変換//
            DataTable output_dt = new DataTable();
            TransformData.ArrayToDataTable1(testNum, coef, out output_dt);

            //DataTableをcsvとして出力//
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_modelparameter.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(coef, parav, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test2_1_14()
        {
            int modelingMode = 2;
            string functionMode = "1";
            int testNum = 14;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_numLV_dt, output_parav_dt, out xtra, out ytra, out modPara, out numLV, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(0, m.Fit(xtra, ytra));

            //モデルパラメータ//
            //model objectを取得//
            dynamic coef = new PrivateObject(m).GetField("coef");

            //Jagg配列からDataTableに変換//
            DataTable output_dt = new DataTable();
            TransformData.ArrayToDataTable1(testNum, coef, out output_dt);

            //DataTableをcsvとして出力//
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_modelparameter.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(coef, parav, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test2_1_15()
        {
            int modelingMode = 2;
            string functionMode = "1";
            int testNum = 15;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_numLV_dt, output_parav_dt, out xtra, out ytra, out modPara, out numLV, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(0, m.Fit(xtra, ytra));

            //モデルパラメータ//
            //model objectを取得//
            dynamic coef = new PrivateObject(m).GetField("coef");

            //Jagg配列からDataTableに変換//
            DataTable output_dt = new DataTable();
            TransformData.ArrayToDataTable1(testNum, coef, out output_dt);

            //DataTableをcsvとして出力//
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_modelparameter.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(coef, parav, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test2_1_16()
        {
            int modelingMode = 2;
            string functionMode = "1";
            int testNum = 16;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_numLV_dt, output_parav_dt, out xtra, out ytra, out modPara, out numLV, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            //Assert.AreEqual(700, m.Fit(xtra, ytra));
            Assert.AreEqual(0, m.Fit(xtra, ytra));
        }

        [TestMethod]
        public void Test2_1_17()
        {
            int modelingMode = 2;
            string functionMode = "1";
            int testNum = 17;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_numLV_dt, output_parav_dt, out xtra, out ytra, out modPara, out numLV, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(112, m.Fit(xtra, ytra));

        }

        [TestMethod]
        public void Test2_1_18()
        {
            int modelingMode = 2;
            string functionMode = "1";
            int testNum = 18;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_numLV_dt, output_parav_dt, out xtra, out ytra, out modPara, out numLV, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(0, m.Fit(xtra, ytra));

            //モデルパラメータ//
            //model objectを取得//
            dynamic coef = new PrivateObject(m).GetField("coef");

            //Jagg配列からDataTableに変換//
            DataTable output_dt = new DataTable();
            TransformData.ArrayToDataTable1(testNum, coef, out output_dt);

            //DataTableをcsvとして出力//
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_modelparameter.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(coef, parav, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test2_1_19()
        {
            int modelingMode = 2;
            string functionMode = "1";
            int testNum = 19;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_numLV_dt, output_parav_dt, out xtra, out ytra, out modPara, out numLV, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(0, m.Fit(xtra, ytra));

            //モデルパラメータ//
            //model objectを取得//
            dynamic coef = new PrivateObject(m).GetField("coef");

            //Jagg配列からDataTableに変換//
            DataTable output_dt = new DataTable();
            TransformData.ArrayToDataTable1(testNum, coef, out output_dt);

            //DataTableをcsvとして出力//
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_modelparameter.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(coef, parav, out relError);
            Assert.AreEqual(0, relError, relTolerance1);
        }

        [TestMethod]
        public void Test2_1_20()
        {
            int modelingMode = 2;
            string functionMode = "1";
            int testNum = 20;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_numLV_dt, output_parav_dt, out xtra, out ytra, out modPara, out numLV, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(0, m.Fit(xtra, ytra));

            //モデルパラメータ//
            //model objectを取得//
            dynamic coef = new PrivateObject(m).GetField("coef");

            //Jagg配列からDataTableに変換//
            DataTable output_dt = new DataTable();
            TransformData.ArrayToDataTable1(testNum, coef, out output_dt);

            //DataTableをcsvとして出力//
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_modelparameter.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(coef, parav, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        [ExpectedException(typeof(DivideByZeroException))]
        public void Test2_1_21()
        {
            int modelingMode = 2;
            string functionMode = "1";
            int testNum = 21;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_numLV_dt, output_parav_dt, out xtra, out ytra, out modPara, out numLV, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            // exception error
            Assert.AreEqual(700, m.Fit(xtra, ytra));

        }

        [TestMethod]
        [ExpectedException(typeof(NonConvergenceException))]
        public void Test2_1_22()
        {
            int modelingMode = 2;
            string functionMode = "1";
            int testNum = 22;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_numLV_dt, output_parav_dt, out xtra, out ytra, out modPara, out numLV, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            // exception error
            Assert.AreEqual(700, m.Fit(xtra, ytra));

        }

        [TestMethod]
        [ExpectedException(typeof(NonConvergenceException))]
        public void Test2_1_23()
        {
            int modelingMode = 2;
            string functionMode = "1";
            int testNum = 23;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_numLV_dt, output_parav_dt, out xtra, out ytra, out modPara, out numLV, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            // exception error
            Assert.AreEqual(700, m.Fit(xtra, ytra));

        }

        [TestMethod]
        public void Test2_1_24()
        {
            int modelingMode = 2;
            string functionMode = "1";
            int testNum = 24;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_numLV_dt, output_parav_dt, out xtra, out ytra, out modPara, out numLV, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(700, m.Fit(xtra, ytra));

        }

        [TestMethod]
        public void Test2_1_25()
        {
            int modelingMode = 2;
            string functionMode = "1";
            int testNum = 25;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_numLV_dt, output_parav_dt, out xtra, out ytra, out modPara, out numLV, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(0, m.Fit(xtra, ytra));

            //モデルパラメータ//
            //model objectを取得//
            dynamic coef = new PrivateObject(m).GetField("coef");

            //Jagg配列からDataTableに変換//
            DataTable output_dt = new DataTable();
            TransformData.ArrayToDataTable1(testNum, coef, out output_dt);

            //DataTableをcsvとして出力//
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_modelparameter.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(coef, parav, out relError);
            Assert.AreEqual(0, relError, relTolerance1);
        }

        [TestMethod]
        public void Test2_1_26()
        {
            int modelingMode = 2;
            string functionMode = "1";
            int testNum = 26;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_numLV_dt, output_parav_dt, out xtra, out ytra, out modPara, out numLV, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(700, m.Fit(xtra, ytra));

        }

        [TestMethod]
        [ExpectedException(typeof(DivideByZeroException))]
        public void Test2_1_27()
        {
            int modelingMode = 2;
            string functionMode = "1";
            int testNum = 27;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_numLV_dt, output_parav_dt, out xtra, out ytra, out modPara, out numLV, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            // exception error
            Assert.AreEqual(700, m.Fit(xtra, ytra));

        }

        [TestMethod]
        public void Test2_1_28()
        {
            int modelingMode = 2;
            string functionMode = "1";
            int testNum = 28;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_numLV_dt, output_parav_dt, out xtra, out ytra, out modPara, out numLV, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(700, m.Fit(xtra, ytra));

        }

        [TestMethod]
        public void Test2_1_29()
        {
            int modelingMode = 2;
            string functionMode = "1";
            int testNum = 29;
            string method = "fit";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //正解のモデルパラメータ//
            double[] parav = new double[variable_size + 1];

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray1(input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_numLV_dt, output_parav_dt, out xtra, out ytra, out modPara, out numLV, out parav);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(700, m.Fit(xtra, ytra));

        }

        [TestMethod]
        public void Test2_2_1()
        {
            int modelingMode = 2;
            string functionMode = "2";
            int testNum = 1;
            string method = "predict";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xpre_dt.Columns.Count;
            int timestamp_pre_size = input_xpre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;
            int parav_size = input_parav_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 予測期間データ//
            double[][] xpre = new double[timestamp_pre_size][];
            //モデルパラメータ//
            double[] parav = new double[variable_size + 1];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yval;

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray2(input_xpre_dt, input_parav_dt, input_mod_para_dt, input_numLV_dt, output_yval_dt, out xpre, out parav, out modPara, out numLV, out yval);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //モデルパラメータの代入//
            new PrivateObject(m).SetField("coef", parav);

            //予測//
            Assert.AreEqual(200, m.Predict(xpre, out ypre));
        }

        [TestMethod]
        public void Test2_2_2()
        {
            int modelingMode = 2;
            string functionMode = "2";
            int testNum = 2;
            string method = "predict";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xpre_dt.Columns.Count;
            int timestamp_pre_size = input_xpre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;
            int parav_size = input_parav_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 予測期間データ//
            double[][] xpre = new double[timestamp_pre_size][];
            //モデルパラメータ//
            double[] parav = new double[variable_size + 1];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yval;

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray2(input_xpre_dt, input_parav_dt, input_mod_para_dt, input_numLV_dt, output_yval_dt, out xpre, out parav, out modPara, out numLV, out yval);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //モデルパラメータの代入//
            new PrivateObject(m).SetField("coef", parav);

            //NaNの代入//
            xpre[0][0] = Double.NaN;

            //予測//
            Assert.AreEqual(201, m.Predict(xpre, out ypre));
        }

        [TestMethod]
        public void Test2_2_3()
        {
            int modelingMode = 2;
            string functionMode = "2";
            int testNum = 3;
            string method = "predict";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xpre_dt.Columns.Count;
            int timestamp_pre_size = input_xpre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;
            int parav_size = input_parav_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 予測期間データ//
            double[][] xpre = new double[timestamp_pre_size][];
            //モデルパラメータ//
            double[] parav = new double[variable_size + 1];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yval;

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray2(input_xpre_dt, input_parav_dt, input_mod_para_dt, input_numLV_dt, output_yval_dt, out xpre, out parav, out modPara, out numLV, out yval);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //モデルパラメータの代入//
            new PrivateObject(m).SetField("coef", parav);

            //予測//
            Assert.AreEqual(0, m.Predict(xpre, out ypre));
            //Assert.AreEqual(300, m.Predict(xpre, out ypre));
        }

        [TestMethod]
        public void Test2_2_4()
        {
            int modelingMode = 2;
            string functionMode = "2";
            int testNum = 4;
            string method = "predict";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xpre_dt.Columns.Count;
            int timestamp_pre_size = input_xpre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;
            int parav_size = input_parav_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 予測期間データ//
            double[][] xpre = new double[timestamp_pre_size][];
            //モデルパラメータ//
            double[] parav = new double[variable_size + 1];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yval;

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray2(input_xpre_dt, input_parav_dt, input_mod_para_dt, input_numLV_dt, output_yval_dt, out xpre, out parav, out modPara, out numLV, out yval);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //モデルパラメータの代入//
            new PrivateObject(m).SetField("coef", parav);

            //予測//
            m.Predict(xpre, out ypre);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output_dt;
            TransformData.Array1DRowToDataTable(ypre, "Actual", out output_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_validation_y.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(ypre, yval, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test2_2_5()
        {
            int modelingMode = 2;
            string functionMode = "2";
            int testNum = 5;
            string method = "predict";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xpre_dt.Columns.Count;
            int timestamp_pre_size = input_xpre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;
            int parav_size = input_parav_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 予測期間データ//
            double[][] xpre = new double[timestamp_pre_size][];
            //モデルパラメータ//
            double[] parav = new double[variable_size + 1];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yval;

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray2(input_xpre_dt, input_parav_dt, input_mod_para_dt, input_numLV_dt, output_yval_dt, out xpre, out parav, out modPara, out numLV, out yval);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //モデルパラメータの代入//
            new PrivateObject(m).SetField("coef", parav);

            //予測//
            m.Predict(xpre, out ypre);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output_dt;
            TransformData.Array1DRowToDataTable(ypre, "Actual", out output_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_validation_y.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(ypre, yval, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test2_2_6()
        {
            int modelingMode = 2;
            string functionMode = "2";
            int testNum = 6;
            string method = "predict";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xpre_dt.Columns.Count;
            int timestamp_pre_size = input_xpre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;
            int parav_size = input_parav_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 予測期間データ//
            double[][] xpre = new double[timestamp_pre_size][];
            //モデルパラメータ//
            double[] parav = new double[variable_size + 1];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yval;

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray2(input_xpre_dt, input_parav_dt, input_mod_para_dt, input_numLV_dt, output_yval_dt, out xpre, out parav, out modPara, out numLV, out yval);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //モデルパラメータの代入//
            new PrivateObject(m).SetField("coef", parav);

            //予測//
            m.Predict(xpre, out ypre);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output_dt;
            TransformData.Array1DRowToDataTable(ypre, "Actual", out output_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_validation_y.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(ypre, yval, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test2_2_7()
        {
            int modelingMode = 2;
            string functionMode = "2";
            int testNum = 7;
            string method = "predict";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xpre_dt.Columns.Count;
            int timestamp_pre_size = input_xpre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;
            int parav_size = input_parav_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 予測期間データ//
            double[][] xpre = new double[timestamp_pre_size][];
            //モデルパラメータ//
            double[] parav = new double[variable_size + 1];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yval;

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray2(input_xpre_dt, input_parav_dt, input_mod_para_dt, input_numLV_dt, output_yval_dt, out xpre, out parav, out modPara, out numLV, out yval);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //モデルパラメータの代入//
            new PrivateObject(m).SetField("coef", parav);

            //予測//
            m.Predict(xpre, out ypre);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output_dt;
            TransformData.Array1DRowToDataTable(ypre, "Actual", out output_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_validation_y.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(ypre, yval, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test2_2_8()
        {
            int modelingMode = 2;
            string functionMode = "2";
            int testNum = 8;
            string method = "predict";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int variable_size = input_xpre_dt.Columns.Count;
            int timestamp_pre_size = input_xpre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;
            int parav_size = input_parav_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 予測期間データ//
            double[][] xpre = new double[timestamp_pre_size][];
            //モデルパラメータ//
            double[] parav = new double[variable_size + 1];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //潜在変数//
            int numLV = new int();

            //output//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yval;

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray2(input_xpre_dt, input_parav_dt, input_mod_para_dt, input_numLV_dt, output_yval_dt, out xpre, out parav, out modPara, out numLV, out yval);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //モデルパラメータの代入//
            new PrivateObject(m).SetField("coef", parav);

            //予測//
            m.Predict(xpre, out ypre);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output_dt;
            TransformData.Array1DRowToDataTable(ypre, "Actual", out output_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_validation_y.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(ypre, yval, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test2_3_1()
        {
            int modelingMode = 2;
            string functionMode = "3";
            int testNum = 1;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            //潜在変数//
            int numLV = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_numLV_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numLV, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            Assert.AreEqual(400, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test2_3_2()
        {
            int modelingMode = 2;
            string functionMode = "3";
            int testNum = 2;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            //潜在変数//
            int numLV = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_numLV_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numLV, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            Assert.AreEqual(401, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test2_3_3()
        {
            int modelingMode = 2;
            string functionMode = "3";
            int testNum = 3;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            //潜在変数//
            int numLV = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_numLV_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numLV, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            Assert.AreEqual(401, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test2_3_4()
        {
            int modelingMode = 2;
            string functionMode = "3";
            int testNum = 4;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            //潜在変数//
            int numLV = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_numLV_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numLV, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            Assert.AreEqual(402, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test2_3_5()
        {
            int modelingMode = 2;
            string functionMode = "3";
            int testNum = 5;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            //潜在変数//
            int numLV = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_numLV_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numLV, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            Assert.AreEqual(403, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test2_3_6()
        {
            int modelingMode = 2;
            string functionMode = "3";
            int testNum = 6;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            //潜在変数//
            int numLV = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_numLV_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numLV, out yValModTrue, out confIntTrue, out actModTrue);

            //NaNの代入//
            modPara[0] = Double.NaN;

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            Assert.AreEqual(404, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test2_3_7()
        {
            int modelingMode = 2;
            string functionMode = "3";
            int testNum = 7;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            //潜在変数//
            int numLV = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_numLV_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numLV, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            Assert.AreEqual(405, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test2_3_8()
        {
            int modelingMode = 2;
            string functionMode = "3";
            int testNum = 8;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            //潜在変数//
            int numLV = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_numLV_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numLV, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            Assert.AreEqual(406, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test2_3_9()
        {
            int modelingMode = 2;
            string functionMode = "3";
            int testNum = 9;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            //潜在変数//
            int numLV = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_numLV_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numLV, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            Assert.AreEqual(407, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test2_3_10()
        {
            int modelingMode = 2;
            string functionMode = "3";
            int testNum = 10;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            //潜在変数//
            int numLV = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_numLV_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numLV, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            Assert.AreEqual(408, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test2_3_11()
        {
            int modelingMode = 2;
            string functionMode = "3";
            int testNum = 11;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            //潜在変数//
            int numLV = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_numLV_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numLV, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //NaNの代入//
            modData[0][0] = Double.NaN;

            //予測//
            Assert.AreEqual(409, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test2_3_12()
        {
            int modelingMode = 2;
            string functionMode = "3";
            int testNum = 12;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            //潜在変数//
            int numLV = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_numLV_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numLV, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            //Assert.AreEqual(500, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
            Assert.AreEqual(0, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test2_3_13()
        {
            int modelingMode = 2;
            string functionMode = "3";
            int testNum = 13;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            //潜在変数//
            int numLV = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_numLV_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numLV, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            TransformData.Array1DRowToDataTable(yPreMod, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output1_dt, "output_mod_validation_y.csv");
            TransformData.Array2DToDataTable(confInt, new string[] { "Lower", "Upper" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output2_dt, "output_conf_int.csv");
            TransformData.Array1DRowToDataTable(actMod, "Actual Modify", out output3_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output3_dt, "output_act_mod.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(yPreMod, yValModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(confInt, confIntTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculationint(actMod, actModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test2_3_14()
        {
            int modelingMode = 2;
            string functionMode = "3";
            int testNum = 14;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            //潜在変数//
            int numLV = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_numLV_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numLV, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            TransformData.Array1DRowToDataTable(yPreMod, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output1_dt, "output_mod_validation_y.csv");
            TransformData.Array2DToDataTable(confInt, new string[] { "Lower", "Upper" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output2_dt, "output_conf_int.csv");
            TransformData.Array1DRowToDataTable(actMod, "Actual Modify", out output3_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output3_dt, "output_act_mod.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(yPreMod, yValModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(confInt, confIntTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculationint(actMod, actModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test2_3_15()
        {
            int modelingMode = 2;
            string functionMode = "3";
            int testNum = 15;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            //潜在変数//
            int numLV = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_numLV_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numLV, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            TransformData.Array1DRowToDataTable(yPreMod, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output1_dt, "output_mod_validation_y.csv");
            TransformData.Array2DToDataTable(confInt, new string[] { "Lower", "Upper" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output2_dt, "output_conf_int.csv");
            TransformData.Array1DRowToDataTable(actMod, "Actual Modify", out output3_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output3_dt, "output_act_mod.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(yPreMod, yValModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(confInt, confIntTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculationint(actMod, actModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test2_3_16()
        {
            int modelingMode = 2;
            string functionMode = "3";
            int testNum = 16;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            //潜在変数//
            int numLV = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_numLV_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numLV, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            TransformData.Array1DRowToDataTable(yPreMod, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output1_dt, "output_mod_validation_y.csv");
            TransformData.Array2DToDataTable(confInt, new string[] { "Lower", "Upper" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output2_dt, "output_conf_int.csv");
            TransformData.Array1DRowToDataTable(actMod, "Actual Modify", out output3_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output3_dt, "output_act_mod.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(yPreMod, yValModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(confInt, confIntTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculationint(actMod, actModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test2_3_17()
        {
            int modelingMode = 2;
            string functionMode = "3";
            int testNum = 17;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            //潜在変数//
            int numLV = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_numLV_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numLV, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            TransformData.Array1DRowToDataTable(yPreMod, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output1_dt, "output_mod_validation_y.csv");
            TransformData.Array2DToDataTable(confInt, new string[] { "Lower", "Upper" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output2_dt, "output_conf_int.csv");
            TransformData.Array1DRowToDataTable(actMod, "Actual Modify", out output3_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output3_dt, "output_act_mod.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(yPreMod, yValModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(confInt, confIntTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculationint(actMod, actModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test2_3_18()
        {
            int modelingMode = 2;
            string functionMode = "3";
            int testNum = 18;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            //潜在変数//
            int numLV = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_numLV_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numLV, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            TransformData.Array1DRowToDataTable(yPreMod, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output1_dt, "output_mod_validation_y.csv");
            TransformData.Array2DToDataTable(confInt, new string[] { "Lower", "Upper" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output2_dt, "output_conf_int.csv");
            TransformData.Array1DRowToDataTable(actMod, "Actual Modify", out output3_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output3_dt, "output_act_mod.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(yPreMod, yValModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(confInt, confIntTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculationint(actMod, actModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test2_3_19()
        {
            int modelingMode = 2;
            string functionMode = "3";
            int testNum = 19;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_parav_dt, input_ypre_dt, input_numLV_dt;
            DataTable output_parav_dt, output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.PLSCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_parav_dt, out input_ypre_dt, out input_numLV_dt, out output_parav_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;
            int numLV_size = input_numLV_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            //潜在変数//
            int numLV = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.PLSDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_numLV_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numLV, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new PLSHyperParameter(modPara, numLV);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            TransformData.Array1DRowToDataTable(yPreMod, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output1_dt, "output_mod_validation_y.csv");
            TransformData.Array2DToDataTable(confInt, new string[] { "Lower", "Upper" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output2_dt, "output_conf_int.csv");
            TransformData.Array1DRowToDataTable(actMod, "Actual Modify", out output3_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output3_dt, "output_act_mod.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(yPreMod, yValModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(confInt, confIntTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculationint(actMod, actModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

    }

    [TestClass]
    public class RF_Test
    {
        const double relTolerance = 1E-7;
        const double relTolerance1 = 0.01;
        const double relTolerance2 = 0.1;

        [TestMethod]
        public void Test3_basic()
        {
            int modelingMode = 3;
            string functionMode = "basic";
            int testNum = 0;
            string method = "all";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_hyperparameter_dt, output_yval_dt;
            int numTree;
            Nullable<int> numMaxDepth;
            int numMinSplit;

            //CSVからDataTableとして変数を取得//
            GetData.RFALLCSVToDataTable(modelingMode, functionMode, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_hyperparameter_dt, out numTree, out numMaxDepth, out numMinSplit, out input_xpre_dt, out output_yval_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_pre_size = input_xpre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 予測期間データ//
            double[][] xpre = new double[timestamp_pre_size][];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_x_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            //シリアライズモデル//
            string serializedModel;

            //output//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正済予測//
            double[] yPreMod = new double[timestamp_pre_size];
            //予測区間//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績フラグ//
            int[] actMod = new int[timestamp_pre_size];
            //目的変数 検証期間 正解データ//
            double[] yval = new double[timestamp_pre_size];

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayRF(input_xtra_dt, input_ytra_dt, input_xpre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, output_yval_dt, 
                                             out xtra, out ytra, out xpre, out modData, out filtTra, out filtPre, out modPara, out yval);

            // 計測開始
            var sw = new System.Diagnostics.Stopwatch();
            sw.Start();

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, numTree, numMaxDepth, numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            m.Fit(xtra, ytra);

            //シリアライズ//
            m.Serialize(out serializedModel);
            GetData.StringToTxt(method, modelingMode, functionMode, testNum, serializedModel);

            //デシリアライズ//
            m.Deserialize(serializedModel);

            //予測//
            m.Predict(xpre, out ypre);

            //予測値補正//
            m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod);

            // 計測停止
            sw.Stop();
            double timeSecond = sw.Elapsed.TotalSeconds;

            ExecTest.MakeResult(timeSecond, yPreMod, yval, ExecTest.Threshold(method, testNum), out double[][] resultArray, out double mape);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output_dt, output1_dt, output2_dt, output3_dt, output4_dt;
            TransformData.Array1DRowToDataTable(ypre, "Actual", out output_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output_dt, "output_validation_y.csv");
            TransformData.Array1DRowToDataTable(yPreMod, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output1_dt, "output_mod_validation_y.csv");
            TransformData.Array2DToDataTable(confInt, new string[] { "Lower", "Upper" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output2_dt, "output_conf_int.csv");
            TransformData.Array1DRowToDataTable(actMod, "Actual Modify", out output3_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output3_dt, "output_act_mod.csv");
            TransformData.Array2DToDataTable(resultArray, new string[] { "MAPE[%]", "Time[sec]" }, out output4_dt);
            GetData.DataTableToCSV(method, modelingMode, Convert.ToString(functionMode), testNum, output4_dt, "output_result.csv");
        }

        [TestMethod]
        public void Test3_1_1()
        {
            int modelingMode = 3;
            string functionMode = "1";
            int testNum = 1;
            string method = "fit";

            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt;
            int input_numTree;
            Nullable<int> input_numMaxDepth;
            int input_numMinSplit;
            DataTable _input_xval_dt, _output_yval_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_numTree, out input_numMaxDepth, out input_numMinSplit, out _input_xval_dt, out _output_yval_dt);

            //説明変数 学習期間データ//
            double[][] xtra;
            //目的変数 学習期間データ//
            double[] ytra;
            //補正用パラメータ//
            double[] modPara;

            //説明変数 予測期間データ//
            double[][] xpre;
            //目的変数 検証期間データ//
            double[] yValTrue;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray1(input_xtra_dt, input_ytra_dt, _input_xval_dt, input_mod_para_dt, _output_yval_dt, out xtra, out ytra, out xpre, out modPara, out yValTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, input_numTree, input_numMaxDepth, input_numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(100, m.Fit(xtra, ytra));
        }

        [TestMethod]
        public void Test3_1_2()
        {
            int modelingMode = 3;
            string functionMode = "1";
            int testNum = 2;
            string method = "fit";

            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt;
            int input_numTree;
            Nullable<int> input_numMaxDepth;
            int input_numMinSplit;
            DataTable _input_xval_dt, _output_yval_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_numTree, out input_numMaxDepth, out input_numMinSplit, out _input_xval_dt, out _output_yval_dt);

            //説明変数 学習期間データ//
            double[][] xtra;
            //目的変数 学習期間データ//
            double[] ytra;
            //補正用パラメータ//
            double[] modPara;

            //説明変数 予測期間データ//
            double[][] xpre;
            //目的変数 検証期間データ//
            double[] yValTrue;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray1(input_xtra_dt, input_ytra_dt, _input_xval_dt, input_mod_para_dt, _output_yval_dt, out xtra, out ytra, out xpre, out modPara, out yValTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, input_numTree, input_numMaxDepth, input_numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //NaNの代入//
            xtra[0][0] = Double.NaN;

            //学習//
            Assert.AreEqual(102, m.Fit(xtra, ytra));
        }

        [TestMethod]
        public void Test3_1_3()
        {
            int modelingMode = 3;
            string functionMode = "1";
            int testNum = 3;
            string method = "fit";

            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt;
            int input_numTree;
            Nullable<int> input_numMaxDepth;
            int input_numMinSplit;
            DataTable _input_xval_dt, _output_yval_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_numTree, out input_numMaxDepth, out input_numMinSplit, out _input_xval_dt, out _output_yval_dt);

            //説明変数 学習期間データ//
            double[][] xtra;
            //目的変数 学習期間データ//
            double[] ytra;
            //補正用パラメータ//
            double[] modPara;

            //説明変数 予測期間データ//
            double[][] xpre;
            //目的変数 検証期間データ//
            double[] yValTrue;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray1(input_xtra_dt, input_ytra_dt, _input_xval_dt, input_mod_para_dt, _output_yval_dt, out xtra, out ytra, out xpre, out modPara, out yValTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, input_numTree, input_numMaxDepth, input_numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //NaNの代入//
            ytra[0] = Double.NaN;

            //学習//
            Assert.AreEqual(102, m.Fit(xtra, ytra));
        }

        [TestMethod]
        public void Test3_1_4()
        {
            int modelingMode = 3;
            string functionMode = "1";
            int testNum = 4;
            string method = "fit";

            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt;
            int input_numTree;
            Nullable<int> input_numMaxDepth;
            int input_numMinSplit;
            DataTable _input_xval_dt, _output_yval_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_numTree, out input_numMaxDepth, out input_numMinSplit, out _input_xval_dt, out _output_yval_dt);

            //説明変数 学習期間データ//
            double[][] xtra;
            //目的変数 学習期間データ//
            double[] ytra;
            //補正用パラメータ//
            double[] modPara;

            //説明変数 予測期間データ//
            double[][] xpre;
            //目的変数 検証期間データ//
            double[] yValTrue;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray1(input_xtra_dt, input_ytra_dt, _input_xval_dt, input_mod_para_dt, _output_yval_dt, out xtra, out ytra, out xpre, out modPara, out yValTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, input_numTree, input_numMaxDepth, input_numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(105, m.Fit(xtra, ytra));
        }

        [TestMethod]
        public void Test3_1_5()
        {
            int modelingMode = 3;
            string functionMode = "1";
            int testNum = 5;
            string method = "fit";

            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt;
            int input_numTree;
            Nullable<int> input_numMaxDepth;
            int input_numMinSplit;
            DataTable _input_xval_dt, _output_yval_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_numTree, out input_numMaxDepth, out input_numMinSplit, out _input_xval_dt, out _output_yval_dt);

            //説明変数 学習期間データ//
            double[][] xtra;
            //目的変数 学習期間データ//
            double[] ytra;
            //補正用パラメータ//
            double[] modPara;

            //説明変数 予測期間データ//
            double[][] xpre;
            //目的変数 検証期間データ//
            double[] yValTrue;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray1(input_xtra_dt, input_ytra_dt, _input_xval_dt, input_mod_para_dt, _output_yval_dt, out xtra, out ytra, out xpre, out modPara, out yValTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, input_numTree, input_numMaxDepth, input_numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(105, m.Fit(xtra, ytra));
        }

        [TestMethod]
        public void Test3_1_6()
        {
            int modelingMode = 3;
            string functionMode = "1";
            int testNum = 6;
            string method = "fit";

            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt;
            int input_numTree;
            Nullable<int> input_numMaxDepth;
            int input_numMinSplit;
            DataTable _input_xval_dt, _output_yval_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_numTree, out input_numMaxDepth, out input_numMinSplit, out _input_xval_dt, out _output_yval_dt);

            //説明変数 学習期間データ//
            double[][] xtra;
            //目的変数 学習期間データ//
            double[] ytra;
            //補正用パラメータ//
            double[] modPara;

            //説明変数 予測期間データ//
            double[][] xpre;
            //目的変数 検証期間データ//
            double[] yValTrue;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray1(input_xtra_dt, input_ytra_dt, _input_xval_dt, input_mod_para_dt, _output_yval_dt, out xtra, out ytra, out xpre, out modPara, out yValTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, input_numTree, input_numMaxDepth, input_numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(106, m.Fit(xtra, ytra));
        }

        [TestMethod]
        public void Test3_1_7()
        {
            int modelingMode = 3;
            string functionMode = "1";
            int testNum = 7;
            string method = "fit";

            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt;
            int input_numTree;
            Nullable<int> input_numMaxDepth;
            int input_numMinSplit;
            DataTable _input_xval_dt, _output_yval_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_numTree, out input_numMaxDepth, out input_numMinSplit, out _input_xval_dt, out _output_yval_dt);

            //説明変数 学習期間データ//
            double[][] xtra;
            //目的変数 学習期間データ//
            double[] ytra;
            //補正用パラメータ//
            double[] modPara;

            //説明変数 予測期間データ//
            double[][] xpre;
            //目的変数 検証期間データ//
            double[] yValTrue;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray1(input_xtra_dt, input_ytra_dt, _input_xval_dt, input_mod_para_dt, _output_yval_dt, out xtra, out ytra, out xpre, out modPara, out yValTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, input_numTree, input_numMaxDepth, input_numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(106, m.Fit(xtra, ytra));
        }

        [TestMethod]
        public void Test3_1_8()
        {
            int modelingMode = 3;
            string functionMode = "1";
            int testNum = 8;
            string method = "fit";

            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt;
            int input_numTree;
            Nullable<int> input_numMaxDepth;
            int input_numMinSplit;
            DataTable _input_xval_dt, _output_yval_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_numTree, out input_numMaxDepth, out input_numMinSplit, out _input_xval_dt, out _output_yval_dt);

            //説明変数 学習期間データ//
            double[][] xtra;
            //目的変数 学習期間データ//
            double[] ytra;
            //補正用パラメータ//
            double[] modPara;

            //説明変数 予測期間データ//
            double[][] xpre;
            //目的変数 検証期間データ//
            double[] yValTrue;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray1(input_xtra_dt, input_ytra_dt, _input_xval_dt, input_mod_para_dt, _output_yval_dt, out xtra, out ytra, out xpre, out modPara, out yValTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, input_numTree, input_numMaxDepth, input_numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(108, m.Fit(xtra, ytra));
        }

        [TestMethod]
        public void Test3_1_9()
        {
            int modelingMode = 3;
            string functionMode = "1";
            int testNum = 9;
            string method = "fit";

            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt;
            int input_numTree;
            Nullable<int> input_numMaxDepth;
            int input_numMinSplit;
            DataTable _input_xval_dt, _output_yval_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_numTree, out input_numMaxDepth, out input_numMinSplit, out _input_xval_dt, out _output_yval_dt);

            //説明変数 学習期間データ//
            double[][] xtra;
            //目的変数 学習期間データ//
            double[] ytra;
            //補正用パラメータ//
            double[] modPara;

            //説明変数 予測期間データ//
            double[][] xpre;
            //目的変数 検証期間データ//
            double[] yValTrue;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray1(input_xtra_dt, input_ytra_dt, _input_xval_dt, input_mod_para_dt, _output_yval_dt, out xtra, out ytra, out xpre, out modPara, out yValTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, input_numTree, input_numMaxDepth, input_numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(108, m.Fit(xtra, ytra));
        }

        [TestMethod]
        public void Test3_1_10()
        {
            int modelingMode = 3;
            string functionMode = "1";
            int testNum = 10;
            string method = "fit";

            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt;
            int input_numTree;
            Nullable<int> input_numMaxDepth;
            int input_numMinSplit;
            DataTable _input_xval_dt, _output_yval_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_numTree, out input_numMaxDepth, out input_numMinSplit, out _input_xval_dt, out _output_yval_dt);

            //説明変数 学習期間データ//
            double[][] xtra;
            //目的変数 学習期間データ//
            double[] ytra;
            //補正用パラメータ//
            double[] modPara;

            //説明変数 予測期間データ//
            double[][] xpre;
            //目的変数 検証期間データ//
            double[] yValTrue;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray1(input_xtra_dt, input_ytra_dt, _input_xval_dt, input_mod_para_dt, _output_yval_dt, out xtra, out ytra, out xpre, out modPara, out yValTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, input_numTree, input_numMaxDepth, input_numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(110, m.Fit(xtra, ytra));
        }

        [TestMethod]
        public void Test3_1_11()
        {
            int modelingMode = 3;
            string functionMode = "1";
            int testNum = 11;
            string method = "fit";

            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt;
            int input_numTree;
            Nullable<int> input_numMaxDepth;
            int input_numMinSplit;
            DataTable _input_xval_dt, _output_yval_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_numTree, out input_numMaxDepth, out input_numMinSplit, out _input_xval_dt, out _output_yval_dt);

            //説明変数 学習期間データ//
            double[][] xtra;
            //目的変数 学習期間データ//
            double[] ytra;
            //補正用パラメータ//
            double[] modPara;

            //説明変数 予測期間データ//
            double[][] xpre;
            //目的変数 検証期間データ//
            double[] yValTrue;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray1(input_xtra_dt, input_ytra_dt, _input_xval_dt, input_mod_para_dt, _output_yval_dt, out xtra, out ytra, out xpre, out modPara, out yValTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, input_numTree, input_numMaxDepth, input_numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            Assert.AreEqual(110, m.Fit(xtra, ytra));
        }

        [TestMethod]
        public void Test3_1_12()
        {
            int modelingMode = 3;
            string functionMode = "1";
            int testNum = 12;
            string method = "fit";

            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_xval_dt, output_yval_dt;
            int input_numTree;
            Nullable<int> input_numMaxDepth;
            int input_numMinSplit;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_numTree, out input_numMaxDepth, out input_numMinSplit, out input_xval_dt, out output_yval_dt);

            int timestamp_pre_size = input_xval_dt.Rows.Count;

            //説明変数 学習期間データ//
            double[][] xtra;
            //目的変数 学習期間データ//
            double[] ytra;
            //補正用パラメータ//
            double[] modPara;

            //説明変数 予測期間データ//
            double[][] xpre = new double[timestamp_pre_size][];
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yValTrue;
            string output_serialized;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray1(input_xtra_dt, input_ytra_dt, input_xval_dt, input_mod_para_dt, output_yval_dt, out xtra, out ytra, out xpre, out modPara, out yValTrue);

            //input_numMaxDepthにNaNを代入//
            input_numMaxDepth = null;

            // 計測開始
            var sw = new System.Diagnostics.Stopwatch();
            sw.Start();

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, input_numTree, input_numMaxDepth, input_numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);
                        
            //学習//
            m.Fit(xtra, ytra);

            // 計測停止
            sw.Stop();
            double timeSecond = sw.Elapsed.TotalSeconds;

            m.Predict(xpre, out ypre);

            //シリアライズされたモデルをテキストファイルとして出力//
            m.Serialize(out output_serialized);
            GetData.StringToTxt(method, modelingMode, functionMode, testNum, output_serialized);

            //model objectを取得//
            dynamic model = new PrivateObject(m).GetField("forest");
            List<List<RFModel.Node>> forest = model;
            int Err1 = ExecTest.RFModelTest(forest, input_numTree, input_numMaxDepth, input_numMinSplit);
            ExecTest.RFPreTest(method, testNum, timeSecond, ypre, yValTrue, out double[][] resultArray, out int Err2);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt;
            TransformData.Array1DRowToDataTable(ypre, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, Convert.ToString(functionMode), testNum, output1_dt, "output_validation_y.csv");
            TransformData.Array2DToDataTable(resultArray, new string[] { "MAPE[%]", "Time[sec]" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, Convert.ToString(functionMode), testNum, output2_dt, "output_result.csv");

            //ハイパーパラメータの設定が、学習したモデルに反映されているか//
            Assert.AreEqual(0, Err1);
            //モデル精度と計算時間が基準を満たしているか//
            Assert.AreEqual(0, Err2);
        }

        [TestMethod]
        public void Test3_1_13()
        {
            int modelingMode = 3;
            string functionMode = "1";
            int testNum = 13;
            string method = "fit";

            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_xval_dt, output_yval_dt;
            int input_numTree;
            Nullable<int> input_numMaxDepth;
            int input_numMinSplit;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_numTree, out input_numMaxDepth, out input_numMinSplit, out input_xval_dt, out output_yval_dt);

            int timestamp_pre_size = input_xval_dt.Rows.Count;

            //説明変数 学習期間データ//
            double[][] xtra;
            //目的変数 学習期間データ//
            double[] ytra;
            //補正用パラメータ//
            double[] modPara;

            //説明変数 予測期間データ//
            double[][] xpre = new double[timestamp_pre_size][];
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yValTrue;
            string output_serialized;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray1(input_xtra_dt, input_ytra_dt, input_xval_dt, input_mod_para_dt, output_yval_dt, out xtra, out ytra, out xpre, out modPara, out yValTrue);

            //input_numMaxDepthにNaNを代入//
            input_numMaxDepth = null;

            // 計測開始
            var sw = new System.Diagnostics.Stopwatch();
            sw.Start();

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, input_numTree, input_numMaxDepth, input_numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            m.Fit(xtra, ytra);

            // 計測停止
            sw.Stop();
            double timeSecond = sw.Elapsed.TotalSeconds;

            m.Predict(xpre, out ypre);

            //シリアライズされたモデルをテキストファイルとして出力//
            m.Serialize(out output_serialized);
            GetData.StringToTxt(method, modelingMode, functionMode, testNum, output_serialized);

            //model objectを取得//
            dynamic model = new PrivateObject(m).GetField("forest");
            List<List<RFModel.Node>> forest = model;
            int Err1 = ExecTest.RFModelTest(forest, input_numTree, input_numMaxDepth, input_numMinSplit);
            ExecTest.RFPreTest(method, testNum, timeSecond, ypre, yValTrue, out double[][] resultArray, out int Err2);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt;
            TransformData.Array1DRowToDataTable(ypre, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, Convert.ToString(functionMode), testNum, output1_dt, "output_validation_y.csv");
            TransformData.Array2DToDataTable(resultArray, new string[] { "MAPE[%]", "Time[sec]" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, Convert.ToString(functionMode), testNum, output2_dt, "output_result.csv");

            //ハイパーパラメータの設定が、学習したモデルに反映されているか//
            Assert.AreEqual(0, Err1);
            //モデル精度と計算時間が基準を満たしているか//
            //予測の最大値・最小値が、検証データの最大値・最小値の範囲内か//
            Assert.IsTrue(ypre.Max() <= ytra.Max());
            Assert.IsTrue(ypre.Min() >= ytra.Min());
        }

        [TestMethod]
        public void Test3_1_14()
        {
            int modelingMode = 3;
            string functionMode = "1";
            int testNum = 14;
            string method = "fit";

            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_xval_dt, output_yval_dt; ;
            int input_numTree;
            Nullable<int> input_numMaxDepth;
            int input_numMinSplit;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_numTree, out input_numMaxDepth, out input_numMinSplit, out input_xval_dt, out output_yval_dt);

            int timestamp_pre_size = input_xval_dt.Rows.Count;

            //説明変数 学習期間データ//
            double[][] xtra;
            //目的変数 学習期間データ//
            double[] ytra;
            //補正用パラメータ//
            double[] modPara;

            //説明変数 予測期間データ//
            double[][] xpre = new double[timestamp_pre_size][];
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yValTrue;
            string output_serialized;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray1(input_xtra_dt, input_ytra_dt, input_xval_dt, input_mod_para_dt, output_yval_dt, out xtra, out ytra, out xpre, out modPara, out yValTrue);

            //input_numMaxDepthにNaNを代入//
            input_numMaxDepth = null;

            // 計測開始
            var sw = new System.Diagnostics.Stopwatch();
            sw.Start();

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, input_numTree, input_numMaxDepth, input_numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            m.Fit(xtra, ytra);

            // 計測停止
            sw.Stop();
            double timeSecond = sw.Elapsed.TotalSeconds;

            m.Predict(xpre, out ypre);

            //シリアライズされたモデルをテキストファイルとして出力//
            m.Serialize(out output_serialized);
            GetData.StringToTxt(method, modelingMode, functionMode, testNum, output_serialized);

            //model objectを取得//
            dynamic model = new PrivateObject(m).GetField("forest");
            List<List<RFModel.Node>> forest = model;
            int Err1 = ExecTest.RFModelTest(forest, input_numTree, input_numMaxDepth, input_numMinSplit);
            ExecTest.RFPreTest(method, testNum, timeSecond, ypre, yValTrue, out double[][] resultArray, out int Err2);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt;
            TransformData.Array1DRowToDataTable(ypre, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, Convert.ToString(functionMode), testNum, output1_dt, "output_validation_y.csv");
            TransformData.Array2DToDataTable(resultArray, new string[] { "MAPE[%]", "Time[sec]" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, Convert.ToString(functionMode), testNum, output2_dt, "output_result.csv");

            //ハイパーパラメータの設定が、学習したモデルに反映されているか//
            Assert.AreEqual(0, Err1);
            //モデル精度と計算時間が基準を満たしているか//
            Assert.AreEqual(0, Err2);
        }

        [TestMethod]
        public void Test3_1_15()
        {
            int modelingMode = 3;
            string functionMode = "1";
            int testNum = 15;
            string method = "fit";

            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_xval_dt, output_yval_dt;
            int input_numTree;
            Nullable<int> input_numMaxDepth;
            int input_numMinSplit;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_numTree, out input_numMaxDepth, out input_numMinSplit, out input_xval_dt, out output_yval_dt);

            int timestamp_pre_size = input_xval_dt.Rows.Count;

            //説明変数 学習期間データ//
            double[][] xtra;
            //目的変数 学習期間データ//
            double[] ytra;
            //補正用パラメータ//
            double[] modPara;

            //説明変数 予測期間データ//
            double[][] xpre = new double[timestamp_pre_size][];
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yValTrue;
            string output_serialized;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray1(input_xtra_dt, input_ytra_dt, input_xval_dt, input_mod_para_dt, output_yval_dt, out xtra, out ytra, out xpre, out modPara, out yValTrue);

            //input_numMaxDepthにNaNを代入//
            input_numMaxDepth = null;

            // 計測開始
            var sw = new System.Diagnostics.Stopwatch();
            sw.Start();

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, input_numTree, input_numMaxDepth, input_numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            m.Fit(xtra, ytra);

            // 計測停止
            sw.Stop();
            double timeSecond = sw.Elapsed.TotalSeconds;


            m.Predict(xpre, out ypre);

            //シリアライズされたモデルをテキストファイルとして出力//
            m.Serialize(out output_serialized);
            GetData.StringToTxt(method, modelingMode, functionMode, testNum, output_serialized);

            //model objectを取得//
            dynamic model = new PrivateObject(m).GetField("forest");
            List<List<RFModel.Node>> forest = model;
            int Err1 = ExecTest.RFModelTest(forest, input_numTree, input_numMaxDepth, input_numMinSplit);
            ExecTest.RFPreTest(method, testNum, timeSecond, ypre, yValTrue, out double[][] resultArray, out int Err2);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt;
            TransformData.Array1DRowToDataTable(ypre, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, Convert.ToString(functionMode), testNum, output1_dt, "output_validation_y.csv");
            TransformData.Array2DToDataTable(resultArray, new string[] { "MAPE[%]", "Time[sec]" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, Convert.ToString(functionMode), testNum, output2_dt, "output_result.csv");

            //ハイパーパラメータの設定が、学習したモデルに反映されているか//
            Assert.AreEqual(0, Err1);
            //モデル精度と計算時間が基準を満たしているか//
            Assert.AreEqual(0, Err2);
        }

        [TestMethod]
        public void Test3_1_16()
        {
            int modelingMode = 3;
            string functionMode = "1";
            int testNum = 16;
            string method = "fit";

            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_xval_dt, output_yval_dt;
            int input_numTree;
            Nullable<int> input_numMaxDepth;
            int input_numMinSplit;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_numTree, out input_numMaxDepth, out input_numMinSplit, out input_xval_dt, out output_yval_dt);

            int timestamp_pre_size = input_xval_dt.Rows.Count;

            //説明変数 学習期間データ//
            double[][] xtra;
            //目的変数 学習期間データ//
            double[] ytra;
            //補正用パラメータ//
            double[] modPara;

            //説明変数 予測期間データ//
            double[][] xpre = new double[timestamp_pre_size][];
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yValTrue;
            string output_serialized;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray1(input_xtra_dt, input_ytra_dt, input_xval_dt, input_mod_para_dt, output_yval_dt, out xtra, out ytra, out xpre, out modPara, out yValTrue);

            //input_numMaxDepthにNaNを代入//
            input_numMaxDepth = null;

            // 計測開始
            var sw = new System.Diagnostics.Stopwatch();
            sw.Start();

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, input_numTree, input_numMaxDepth, input_numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            m.Fit(xtra, ytra);

            // 計測停止
            sw.Stop();
            double timeSecond = sw.Elapsed.TotalSeconds;


            m.Predict(xpre, out ypre);

            //シリアライズされたモデルをテキストファイルとして出力//
            m.Serialize(out output_serialized);
            GetData.StringToTxt(method, modelingMode, functionMode, testNum, output_serialized);

            //model objectを取得//
            dynamic model = new PrivateObject(m).GetField("forest");
            List<List<RFModel.Node>> forest = model;
            int Err1 = ExecTest.RFModelTest(forest, input_numTree, input_numMaxDepth, input_numMinSplit);
            ExecTest.RFPreTest(method, testNum, timeSecond, ypre, yValTrue, out double[][] resultArray, out int Err2);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt;
            TransformData.Array1DRowToDataTable(ypre, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, Convert.ToString(functionMode), testNum, output1_dt, "output_validation_y.csv");
            TransformData.Array2DToDataTable(resultArray, new string[] { "MAPE[%]", "Time[sec]" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, Convert.ToString(functionMode), testNum, output2_dt, "output_result.csv");

            //ハイパーパラメータの設定が、学習したモデルに反映されているか//
            Assert.AreEqual(0, Err1);
            //モデル精度と計算時間が基準を満たしているか//
            Assert.AreEqual(0, Err2);
        }

        [TestMethod]
        public void Test3_1_17()
        {
            int modelingMode = 3;
            string functionMode = "1";
            int testNum = 17;
            string method = "fit";

            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_xval_dt, output_yval_dt;
            int input_numTree;
            Nullable<int> input_numMaxDepth;
            int input_numMinSplit;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_numTree, out input_numMaxDepth, out input_numMinSplit, out input_xval_dt, out output_yval_dt);

            int timestamp_pre_size = input_xval_dt.Rows.Count;

            //説明変数 学習期間データ//
            double[][] xtra;
            //目的変数 学習期間データ//
            double[] ytra;
            //補正用パラメータ//
            double[] modPara;

            //説明変数 予測期間データ//
            double[][] xpre = new double[timestamp_pre_size][];
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yValTrue;
            string output_serialized;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray1(input_xtra_dt, input_ytra_dt, input_xval_dt, input_mod_para_dt, output_yval_dt, out xtra, out ytra, out xpre, out modPara, out yValTrue);

            //input_numMaxDepthにNaNを代入//
            input_numMaxDepth = null;

            // 計測開始
            var sw = new System.Diagnostics.Stopwatch();
            sw.Start();

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, input_numTree, input_numMaxDepth, input_numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            m.Fit(xtra, ytra);

            // 計測停止
            sw.Stop();
            double timeSecond = sw.Elapsed.TotalSeconds;


            m.Predict(xpre, out ypre);

            //シリアライズされたモデルをテキストファイルとして出力//
            m.Serialize(out output_serialized);
            GetData.StringToTxt(method, modelingMode, functionMode, testNum, output_serialized);

            //model objectを取得//
            dynamic model = new PrivateObject(m).GetField("forest");
            List<List<RFModel.Node>> forest = model;
            int Err1 = ExecTest.RFModelTest(forest, input_numTree, input_numMaxDepth, input_numMinSplit);
            ExecTest.RFPreTest(method, testNum, timeSecond, ypre, yValTrue, out double[][] resultArray, out int Err2);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt;
            TransformData.Array1DRowToDataTable(ypre, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, Convert.ToString(functionMode), testNum, output1_dt, "output_validation_y.csv");
            TransformData.Array2DToDataTable(resultArray, new string[] { "MAPE[%]", "Time[sec]" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, Convert.ToString(functionMode), testNum, output2_dt, "output_result.csv");

            //ハイパーパラメータの設定が、学習したモデルに反映されているか//
            Assert.AreEqual(0, Err1);
            //モデル精度と計算時間が基準を満たしているか//
            Assert.AreEqual(0, Err2);
        }

        [TestMethod]
        public void Test3_1_18()
        {
            int modelingMode = 3;
            string functionMode = "1";
            int testNum = 18;
            string method = "fit";

            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_xval_dt, output_yval_dt;
            int input_numTree;
            Nullable<int> input_numMaxDepth;
            int input_numMinSplit;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_numTree, out input_numMaxDepth, out input_numMinSplit, out input_xval_dt, out output_yval_dt);

            int timestamp_pre_size = input_xval_dt.Rows.Count;

            //説明変数 学習期間データ//
            double[][] xtra;
            //目的変数 学習期間データ//
            double[] ytra;
            //補正用パラメータ//
            double[] modPara;

            //説明変数 予測期間データ//
            double[][] xpre = new double[timestamp_pre_size][];
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yValTrue;
            string output_serialized;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray1(input_xtra_dt, input_ytra_dt, input_xval_dt, input_mod_para_dt, output_yval_dt, out xtra, out ytra, out xpre, out modPara, out yValTrue);

            //input_numMaxDepthにNaNを代入//
            input_numMaxDepth = null;

            // 計測開始
            var sw = new System.Diagnostics.Stopwatch();
            sw.Start();

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, input_numTree, input_numMaxDepth, input_numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            m.Fit(xtra, ytra);

            // 計測停止
            sw.Stop();
            double timeSecond = sw.Elapsed.TotalSeconds;

            m.Predict(xpre, out ypre);


            //シリアライズされたモデルをテキストファイルとして出力//
            m.Serialize(out output_serialized);
            GetData.StringToTxt(method, modelingMode, functionMode, testNum, output_serialized);

            //model objectを取得//
            dynamic model = new PrivateObject(m).GetField("forest");
            List<List<RFModel.Node>> forest = model;
            int Err1 = ExecTest.RFModelTest(forest, input_numTree, input_numMaxDepth, input_numMinSplit);
            ExecTest.RFPreTest(method, testNum, timeSecond, ypre, yValTrue, out double[][] resultArray, out int Err2);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt;
            TransformData.Array1DRowToDataTable(ypre, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, Convert.ToString(functionMode), testNum, output1_dt, "output_validation_y.csv");
            TransformData.Array2DToDataTable(resultArray, new string[] { "MAPE[%]", "Time[sec]" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, Convert.ToString(functionMode), testNum, output2_dt, "output_result.csv");

            //ハイパーパラメータの設定が、学習したモデルに反映されているか//
            Assert.AreEqual(0, Err1);
            //モデル精度と計算時間が基準を満たしているか//
            Assert.AreEqual(0, Err2);
        }

        [TestMethod]
        public void Test3_1_19()
        {
            int modelingMode = 3;
            string functionMode = "1";
            int testNum = 19;
            string method = "fit";

            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_xval_dt, output_yval_dt;
            int input_numTree;
            Nullable<int> input_numMaxDepth;
            int input_numMinSplit;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_numTree, out input_numMaxDepth, out input_numMinSplit, out input_xval_dt, out output_yval_dt);

            int timestamp_pre_size = input_xval_dt.Rows.Count;

            //説明変数 学習期間データ//
            double[][] xtra;
            //目的変数 学習期間データ//
            double[] ytra;
            //補正用パラメータ//
            double[] modPara;

            //説明変数 予測期間データ//
            double[][] xpre = new double[timestamp_pre_size][];
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yValTrue;
            string output_serialized;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray1(input_xtra_dt, input_ytra_dt, input_xval_dt, input_mod_para_dt, output_yval_dt, out xtra, out ytra, out xpre, out modPara, out yValTrue);

            //input_numMaxDepthにNaNを代入//
            input_numMaxDepth = null;

            // 計測開始
            var sw = new System.Diagnostics.Stopwatch();
            sw.Start();

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, input_numTree, input_numMaxDepth, input_numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            m.Fit(xtra, ytra);

            // 計測停止
            sw.Stop();
            double timeSecond = sw.Elapsed.TotalSeconds;


            m.Predict(xpre, out ypre);

            //シリアライズされたモデルをテキストファイルとして出力//
            m.Serialize(out output_serialized);
            GetData.StringToTxt(method, modelingMode, functionMode, testNum, output_serialized);

            //model objectを取得//
            dynamic model = new PrivateObject(m).GetField("forest");
            List<List<RFModel.Node>> forest = model;
            int Err1 = ExecTest.RFModelTest(forest, input_numTree, input_numMaxDepth, input_numMinSplit);
            ExecTest.RFPreTest(method, testNum, timeSecond, ypre, yValTrue, out double[][] resultArray, out int Err2);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt;
            TransformData.Array1DRowToDataTable(ypre, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, Convert.ToString(functionMode), testNum, output1_dt, "output_validation_y.csv");
            TransformData.Array2DToDataTable(resultArray, new string[] { "MAPE[%]", "Time[sec]" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, Convert.ToString(functionMode), testNum, output2_dt, "output_result.csv");

            //ハイパーパラメータの設定が、学習したモデルに反映されているか//
            Assert.AreEqual(0, Err1);
            //モデル精度と計算時間が基準を満たしているか//
            //分岐したノードの数が正しいかどうか//
            for (int i = 0; i < forest.Count; i++)
            {
                Assert.AreEqual(3, forest[i].Count);
            }
        }

        [TestMethod]
        public void Test3_1_20()
        {
            int modelingMode = 3;
            string functionMode = "1";
            int testNum = 20;
            string method = "fit";

            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_xval_dt, output_yval_dt;
            int input_numTree;
            Nullable<int> input_numMaxDepth;
            int input_numMinSplit;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_numTree, out input_numMaxDepth, out input_numMinSplit, out input_xval_dt, out output_yval_dt);

            int timestamp_pre_size = input_xval_dt.Rows.Count;

            //説明変数 学習期間データ//
            double[][] xtra;
            //目的変数 学習期間データ//
            double[] ytra;
            //補正用パラメータ//
            double[] modPara;

            //説明変数 予測期間データ//
            double[][] xpre = new double[timestamp_pre_size][];
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yValTrue;
            string output_serialized;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray1(input_xtra_dt, input_ytra_dt, input_xval_dt, input_mod_para_dt, output_yval_dt, out xtra, out ytra, out xpre, out modPara, out yValTrue);

            // 計測開始
            var sw = new System.Diagnostics.Stopwatch();
            sw.Start();

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, input_numTree, input_numMaxDepth, input_numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            m.Fit(xtra, ytra);

            // 計測停止
            sw.Stop();
            double timeSecond = sw.Elapsed.TotalSeconds;


            m.Predict(xpre, out ypre);

            //シリアライズされたモデルをテキストファイルとして出力//
            m.Serialize(out output_serialized);
            GetData.StringToTxt(method, modelingMode, functionMode, testNum, output_serialized);

            //model objectを取得//
            dynamic model = new PrivateObject(m).GetField("forest");
            List<List<RFModel.Node>> forest = model;
            int Err1 = ExecTest.RFModelTest(forest, input_numTree, input_numMaxDepth, input_numMinSplit);
            ExecTest.RFPreTest(method, testNum, timeSecond, ypre, yValTrue, out double[][] resultArray, out int Err2);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt;
            TransformData.Array1DRowToDataTable(ypre, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, Convert.ToString(functionMode), testNum, output1_dt, "output_validation_y.csv");
            TransformData.Array2DToDataTable(resultArray, new string[] { "MAPE[%]", "Time[sec]" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, Convert.ToString(functionMode), testNum, output2_dt, "output_result.csv");

            //ハイパーパラメータの設定が、学習したモデルに反映されているか//
            Assert.AreEqual(0, Err1);
            //モデル精度と計算時間が基準を満たしているか//
            //分岐したノードの数が正しいかどうか//
            for (int i = 0; i < forest.Count; i++)
            {
                Assert.AreEqual(3, forest[i].Count);
            }
        }

        [TestMethod]
        public void Test3_1_21()
        {
            int modelingMode = 3;
            string functionMode = "1";
            int testNum = 21;
            string method = "fit";

            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_xval_dt, output_yval_dt;
            int input_numTree;
            Nullable<int> input_numMaxDepth;
            int input_numMinSplit;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_numTree, out input_numMaxDepth, out input_numMinSplit, out input_xval_dt, out output_yval_dt);

            int timestamp_pre_size = input_xval_dt.Rows.Count;

            //説明変数 学習期間データ//
            double[][] xtra;
            //目的変数 学習期間データ//
            double[] ytra;
            //補正用パラメータ//
            double[] modPara;

            //説明変数 予測期間データ//
            double[][] xpre = new double[timestamp_pre_size][];
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yValTrue;
            string output_serialized;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray1(input_xtra_dt, input_ytra_dt, input_xval_dt, input_mod_para_dt, output_yval_dt, out xtra, out ytra, out xpre, out modPara, out yValTrue);

            // 計測開始
            var sw = new System.Diagnostics.Stopwatch();
            sw.Start();

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, input_numTree, input_numMaxDepth, input_numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            m.Fit(xtra, ytra);

            // 計測停止
            sw.Stop();
            double timeSecond = sw.Elapsed.TotalSeconds;


            m.Predict(xpre, out ypre);

            //シリアライズされたモデルをテキストファイルとして出力//
            m.Serialize(out output_serialized);
            GetData.StringToTxt(method, modelingMode, functionMode, testNum, output_serialized);

            //model objectを取得//
            dynamic model = new PrivateObject(m).GetField("forest");
            List<List<RFModel.Node>> forest = model;
            int Err1 = ExecTest.RFModelTest(forest, input_numTree, input_numMaxDepth, input_numMinSplit);
            ExecTest.RFPreTest(method, testNum, timeSecond, ypre, yValTrue, out double[][] resultArray, out int Err2);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt;
            TransformData.Array1DRowToDataTable(ypre, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, Convert.ToString(functionMode), testNum, output1_dt, "output_validation_y.csv");
            TransformData.Array2DToDataTable(resultArray, new string[] { "MAPE[%]", "Time[sec]" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, Convert.ToString(functionMode), testNum, output2_dt, "output_result.csv");

            //ハイパーパラメータの設定が、学習したモデルに反映されているか//
            Assert.AreEqual(0, Err1);
            //モデル精度と計算時間が基準を満たしているか//
            Assert.AreEqual(0, Err2);
        }

        [TestMethod]
        public void Test3_2_1()
        {
            int modelingMode = 3;
            string functionMode = "2";
            int testNum = 1;
            string method = "predict";

            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_ypre_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt;
            DataTable output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable23(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_ypre_dt, out input_num_tree_dt, out input_num_max_depth_dt, out input_num_min_split_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            int timestamp_pre_size = input_xpre_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra;
            //目的変数 学習期間データ//
            double[] ytra;
            //補正用パラメータ//
            double[] modPara;
            //説明変数 検証期間データ//
            double[][] xpre;
            int numTree;
            Nullable<int> numMaxDepth;
            int numMinSplit;

            //output//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yValTrue;


            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray2(input_xtra_dt, input_ytra_dt, input_xpre_dt, input_mod_para_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt, output_yval_dt, out xtra, out ytra, out xpre, out modPara, out numTree, out numMaxDepth, out numMinSplit, out yValTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, numTree, numMaxDepth, numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            m.Fit(xtra, ytra);

            //予測//
            Assert.AreEqual(200, m.Predict(xpre, out ypre));
        }

        [TestMethod]
        public void Test3_2_2()
        {
            int modelingMode = 3;
            string functionMode = "2";
            int testNum = 2;
            string method = "predict";

            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_ypre_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt;
            DataTable output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable23(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_ypre_dt, out input_num_tree_dt, out input_num_max_depth_dt, out input_num_min_split_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            int timestamp_pre_size = input_xpre_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra;
            //目的変数 学習期間データ//
            double[] ytra;
            //補正用パラメータ//
            double[] modPara;
            //説明変数 検証期間データ//
            double[][] xpre;
            int numTree;
            Nullable<int> numMaxDepth;
            int numMinSplit;

            //output//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yValTrue;


            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray2(input_xtra_dt, input_ytra_dt, input_xpre_dt, input_mod_para_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt, output_yval_dt, out xtra, out ytra, out xpre, out modPara, out numTree, out numMaxDepth, out numMinSplit, out yValTrue);

            //NaNの代入//
            xpre[0][0] = Double.NaN;

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, numTree, numMaxDepth, numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            m.Fit(xtra, ytra);

            //予測//
            Assert.AreEqual(201, m.Predict(xpre, out ypre));
        }

        [TestMethod]
        public void Test3_2_3()
        {
            int modelingMode = 3;
            string functionMode = "2";
            int testNum = 3;
            string method = "predict";

            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_ypre_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt;
            DataTable output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable23(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_ypre_dt, out input_num_tree_dt, out input_num_max_depth_dt, out input_num_min_split_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            int timestamp_pre_size = input_xpre_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra;
            //目的変数 学習期間データ//
            double[] ytra;
            //補正用パラメータ//
            double[] modPara;
            //説明変数 検証期間データ//
            double[][] xpre;
            int numTree;
            Nullable<int> numMaxDepth;
            int numMinSplit;

            //output//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yValTrue;


            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray2(input_xtra_dt, input_ytra_dt, input_xpre_dt, input_mod_para_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt, output_yval_dt, out xtra, out ytra, out xpre, out modPara, out numTree, out numMaxDepth, out numMinSplit, out yValTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, numTree, numMaxDepth, numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            m.Fit(xtra, ytra);

            //予測//
            //Assert.AreEqual(300, m.Predict(xpre, out ypre));
            Assert.AreEqual(0, m.Predict(xpre, out ypre));
        }

        [TestMethod]
        public void Test3_2_4()
        {
            int modelingMode = 3;
            string functionMode = "2";
            int testNum = 4;
            string method = "predict";

            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_ypre_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt;
            DataTable output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable23(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_ypre_dt, out input_num_tree_dt, out input_num_max_depth_dt, out input_num_min_split_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            int timestamp_pre_size = input_xpre_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra;
            //目的変数 学習期間データ//
            double[] ytra;
            //補正用パラメータ//
            double[] modPara;
            //説明変数 検証期間データ//
            double[][] xpre;
            int numTree;
            Nullable<int> numMaxDepth;
            int numMinSplit;

            //output//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yValTrue;


            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray2(input_xtra_dt, input_ytra_dt, input_xpre_dt, input_mod_para_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt, output_yval_dt, out xtra, out ytra, out xpre, out modPara, out numTree, out numMaxDepth, out numMinSplit, out yValTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, numTree, numMaxDepth, numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            m.Fit(xtra, ytra);

            // 計測開始
            var sw = new System.Diagnostics.Stopwatch();
            sw.Start();

            //予測//
            m.Predict(xpre, out ypre);

            // 計測停止
            sw.Stop();
            double timeSecond = sw.Elapsed.TotalSeconds;

            ExecTest.RFPreTest(method, testNum, timeSecond, ypre, yValTrue, out double[][] resultArray, out int Err2);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt;
            TransformData.Array1DRowToDataTable(ypre, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output1_dt, "output_validation_y.csv");
            TransformData.Array2DToDataTable(resultArray, new string[] { "MAPE[%]", "Time[sec]" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output2_dt, "output_result.csv");

            //モデル精度と計算時間が基準を満たしているか//
            Assert.AreEqual(0, Err2);
        }

        [TestMethod]
        public void Test3_2_5()
        {
            int modelingMode = 3;
            string functionMode = "2";
            int testNum = 5;
            string method = "predict";

            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_ypre_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt;
            DataTable output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable23(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_ypre_dt, out input_num_tree_dt, out input_num_max_depth_dt, out input_num_min_split_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            int timestamp_pre_size = input_xpre_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra;
            //目的変数 学習期間データ//
            double[] ytra;
            //補正用パラメータ//
            double[] modPara;
            //説明変数 検証期間データ//
            double[][] xpre;
            int numTree;
            Nullable<int> numMaxDepth;
            int numMinSplit;

            //output//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yValTrue;


            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray2(input_xtra_dt, input_ytra_dt, input_xpre_dt, input_mod_para_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt, output_yval_dt, out xtra, out ytra, out xpre, out modPara, out numTree, out numMaxDepth, out numMinSplit, out yValTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, numTree, numMaxDepth, numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            m.Fit(xtra, ytra);

            // 計測開始
            var sw = new System.Diagnostics.Stopwatch();
            sw.Start();

            //予測//
            m.Predict(xpre, out ypre);

            // 計測停止
            sw.Stop();
            double timeSecond = sw.Elapsed.TotalSeconds;

            ExecTest.RFPreTest(method, testNum, timeSecond, ypre, yValTrue, out double[][] resultArray, out int Err2);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt;
            TransformData.Array1DRowToDataTable(ypre, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output1_dt, "output_validation_y.csv");
            TransformData.Array2DToDataTable(resultArray, new string[] { "MAPE[%]", "Time[sec]" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output2_dt, "output_result.csv");

            //モデル精度と計算時間が基準を満たしているか//
            Assert.AreEqual(0, Err2);
        }

        [TestMethod]
        public void Test3_2_6()
        {
            int modelingMode = 3;
            string functionMode = "2";
            int testNum = 6;
            string method = "predict";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_ypre_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt;
            DataTable output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable23(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_ypre_dt, out input_num_tree_dt, out input_num_max_depth_dt, out input_num_min_split_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            int timestamp_pre_size = input_xpre_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra;
            //目的変数 学習期間データ//
            double[] ytra;
            //補正用パラメータ//
            double[] modPara;
            //説明変数 検証期間データ//
            double[][] xpre;
            int numTree;
            Nullable<int> numMaxDepth;
            int numMinSplit;

            //output//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yValTrue;


            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray2(input_xtra_dt, input_ytra_dt, input_xpre_dt, input_mod_para_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt, output_yval_dt, out xtra, out ytra, out xpre, out modPara, out numTree, out numMaxDepth, out numMinSplit, out yValTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, numTree, numMaxDepth, numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            m.Fit(xtra, ytra);

            // 計測開始
            var sw = new System.Diagnostics.Stopwatch();
            sw.Start();

            //予測//
            m.Predict(xpre, out ypre);

            // 計測停止
            sw.Stop();
            double timeSecond = sw.Elapsed.TotalSeconds;

            ExecTest.RFPreTest(method, testNum, timeSecond, ypre, yValTrue, out double[][] resultArray, out int Err2);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt;
            TransformData.Array1DRowToDataTable(ypre, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output1_dt, "output_validation_y.csv");
            TransformData.Array2DToDataTable(resultArray, new string[] { "MAPE[%]", "Time[sec]" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output2_dt, "output_result.csv");

            //モデル精度と計算時間が基準を満たしているか//
            Assert.AreEqual(0, Err2);
        }

        [TestMethod]
        public void Test3_2_7()
        {
            int modelingMode = 3;
            string functionMode = "2";
            int testNum = 7;
            string method = "predict";

            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_ypre_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt;
            DataTable output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable23(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_ypre_dt, out input_num_tree_dt, out input_num_max_depth_dt, out input_num_min_split_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            int timestamp_pre_size = input_xpre_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra;
            //目的変数 学習期間データ//
            double[] ytra;
            //補正用パラメータ//
            double[] modPara;
            //説明変数 検証期間データ//
            double[][] xpre;
            int numTree;
            Nullable<int> numMaxDepth;
            int numMinSplit;

            //output//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yValTrue;


            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray2(input_xtra_dt, input_ytra_dt, input_xpre_dt, input_mod_para_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt, output_yval_dt, out xtra, out ytra, out xpre, out modPara, out numTree, out numMaxDepth, out numMinSplit, out yValTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, numTree, numMaxDepth, numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            m.Fit(xtra, ytra);

            // 計測開始
            var sw = new System.Diagnostics.Stopwatch();
            sw.Start();

            //予測//
            m.Predict(xpre, out ypre);

            // 計測停止
            sw.Stop();
            double timeSecond = sw.Elapsed.TotalSeconds;

            ExecTest.RFPreTest(method, testNum, timeSecond, ypre, yValTrue, out double[][] resultArray, out int Err2);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt;
            TransformData.Array1DRowToDataTable(ypre, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output1_dt, "output_validation_y.csv");
            TransformData.Array2DToDataTable(resultArray, new string[] { "MAPE[%]", "Time[sec]" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output2_dt, "output_result.csv");

            //モデル精度と計算時間が基準を満たしているか//
            Assert.AreEqual(0, Err2);
        }

        [TestMethod]
        public void Test3_2_8()
        {
            int modelingMode = 3;
            string functionMode = "2";
            int testNum = 8;
            string method = "predict";

            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_ypre_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt;
            DataTable output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable23(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_ypre_dt, out input_num_tree_dt, out input_num_max_depth_dt, out input_num_min_split_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            int timestamp_pre_size = input_xpre_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra;
            //目的変数 学習期間データ//
            double[] ytra;
            //補正用パラメータ//
            double[] modPara;
            //説明変数 検証期間データ//
            double[][] xpre;
            int numTree;
            Nullable<int> numMaxDepth;
            int numMinSplit;

            //output//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //目的変数 検証期間データ//
            double[] yValTrue;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray2(input_xtra_dt, input_ytra_dt, input_xpre_dt, input_mod_para_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt, output_yval_dt, out xtra, out ytra, out xpre, out modPara, out numTree, out numMaxDepth, out numMinSplit, out yValTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, numTree, numMaxDepth, numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //学習//
            m.Fit(xtra, ytra);

            // 計測開始
            var sw = new System.Diagnostics.Stopwatch();
            sw.Start();

            //予測//
            m.Predict(xpre, out ypre);

            // 計測停止
            sw.Stop();
            double timeSecond = sw.Elapsed.TotalSeconds;

            ExecTest.RFPreTest(method, testNum, timeSecond, ypre, yValTrue, out double[][] resultArray, out int Err2);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt;
            TransformData.Array1DRowToDataTable(ypre, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output1_dt, "output_validation_y.csv");
            TransformData.Array2DToDataTable(resultArray, new string[] { "MAPE[%]", "Time[sec]" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output2_dt, "output_result.csv");

            //モデル精度と計算時間が基準を満たしているか//
            Assert.AreEqual(0, Err2);
        }

        [TestMethod]
        public void Test3_3_1()
        {
            int modelingMode = 3;
            string functionMode = "3";
            int testNum = 1;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_ypre_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt;
            DataTable output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable23(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_ypre_dt, out input_num_tree_dt, out input_num_max_depth_dt, out input_num_min_split_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            int numTree = new int();
            Nullable<int> numMaxDepth;
            int numMinSplit = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numTree, out numMaxDepth, out numMinSplit, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, numTree, numMaxDepth, numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            Assert.AreEqual(400, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test3_3_2()
        {
            int modelingMode = 3;
            string functionMode = "3";
            int testNum = 2;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_ypre_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt;
            DataTable output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable23(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_ypre_dt, out input_num_tree_dt, out input_num_max_depth_dt, out input_num_min_split_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            int numTree = new int();
            Nullable<int> numMaxDepth = new int();
            int numMinSplit = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numTree, out numMaxDepth, out numMinSplit, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, numTree, numMaxDepth, numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            Assert.AreEqual(401, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test3_3_3()
        {
            int modelingMode = 3;
            string functionMode = "3";
            int testNum = 3;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_ypre_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt;
            DataTable output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable23(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_ypre_dt, out input_num_tree_dt, out input_num_max_depth_dt, out input_num_min_split_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            int numTree = new int();
            Nullable<int> numMaxDepth = new int();
            int numMinSplit = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numTree, out numMaxDepth, out numMinSplit, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, numTree, numMaxDepth, numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            Assert.AreEqual(401, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test3_3_4()
        {
            int modelingMode = 3;
            string functionMode = "3";
            int testNum = 4;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_ypre_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt;
            DataTable output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable23(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_ypre_dt, out input_num_tree_dt, out input_num_max_depth_dt, out input_num_min_split_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            int numTree = new int();
            Nullable<int> numMaxDepth = new int();
            int numMinSplit = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numTree, out numMaxDepth, out numMinSplit, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, numTree, numMaxDepth, numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            Assert.AreEqual(402, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test3_3_5()
        {
            int modelingMode = 3;
            string functionMode = "3";
            int testNum = 5;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_ypre_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt;
            DataTable output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable23(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_ypre_dt, out input_num_tree_dt, out input_num_max_depth_dt, out input_num_min_split_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            int numTree = new int();
            Nullable<int> numMaxDepth = new int();
            int numMinSplit = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numTree, out numMaxDepth, out numMinSplit, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, numTree, numMaxDepth, numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            Assert.AreEqual(403, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test3_3_6()
        {
            int modelingMode = 3;
            string functionMode = "3";
            int testNum = 6;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_ypre_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt;
            DataTable output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable23(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_ypre_dt, out input_num_tree_dt, out input_num_max_depth_dt, out input_num_min_split_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            int numTree = new int();
            Nullable<int> numMaxDepth = new int();
            int numMinSplit = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numTree, out numMaxDepth, out numMinSplit, out yValModTrue, out confIntTrue, out actModTrue);

            //NaNの代入//
            modPara[0] = Double.NaN;

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, numTree, numMaxDepth, numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            Assert.AreEqual(404, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test3_3_7()
        {
            int modelingMode = 3;
            string functionMode = "3";
            int testNum = 7;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_ypre_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt;
            DataTable output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable23(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_ypre_dt, out input_num_tree_dt, out input_num_max_depth_dt, out input_num_min_split_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            int numTree = new int();
            Nullable<int> numMaxDepth = new int();
            int numMinSplit = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numTree, out numMaxDepth, out numMinSplit, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, numTree, numMaxDepth, numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            Assert.AreEqual(405, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test3_3_8()
        {
            int modelingMode = 3;
            string functionMode = "3";
            int testNum = 8;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_ypre_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt;
            DataTable output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable23(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_ypre_dt, out input_num_tree_dt, out input_num_max_depth_dt, out input_num_min_split_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            int numTree = new int();
            Nullable<int> numMaxDepth = new int();
            int numMinSplit = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numTree, out numMaxDepth, out numMinSplit, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, numTree, numMaxDepth, numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            Assert.AreEqual(406, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test3_3_9()
        {
            int modelingMode = 3;
            string functionMode = "3";
            int testNum = 9;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_ypre_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt;
            DataTable output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable23(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_ypre_dt, out input_num_tree_dt, out input_num_max_depth_dt, out input_num_min_split_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            int numTree = new int();
            Nullable<int> numMaxDepth = new int();
            int numMinSplit = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numTree, out numMaxDepth, out numMinSplit, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, numTree, numMaxDepth, numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            Assert.AreEqual(407, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test3_3_10()
        {
            int modelingMode = 3;
            string functionMode = "3";
            int testNum = 10;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_ypre_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt;
            DataTable output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable23(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_ypre_dt, out input_num_tree_dt, out input_num_max_depth_dt, out input_num_min_split_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            int numTree = new int();
            Nullable<int> numMaxDepth = new int();
            int numMinSplit = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numTree, out numMaxDepth, out numMinSplit, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, numTree, numMaxDepth, numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            Assert.AreEqual(408, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test3_3_11()
        {
            int modelingMode = 3;
            string functionMode = "3";
            int testNum = 11;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_ypre_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt;
            DataTable output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable23(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_ypre_dt, out input_num_tree_dt, out input_num_max_depth_dt, out input_num_min_split_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            int numTree = new int();
            Nullable<int> numMaxDepth = new int();
            int numMinSplit = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numTree, out numMaxDepth, out numMinSplit, out yValModTrue, out confIntTrue, out actModTrue);

            //NaNの代入//
            modData[0][0] = Double.NaN;

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, numTree, numMaxDepth, numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            Assert.AreEqual(409, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test3_3_12()
        {
            int modelingMode = 3;
            string functionMode = "3";
            int testNum = 12;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_ypre_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt;
            DataTable output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable23(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_ypre_dt, out input_num_tree_dt, out input_num_max_depth_dt, out input_num_min_split_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            int numTree = new int();
            Nullable<int> numMaxDepth = new int();
            int numMinSplit = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numTree, out numMaxDepth, out numMinSplit, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, numTree, numMaxDepth, numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            //Assert.AreEqual(500, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
            Assert.AreEqual(0, m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod));
        }

        [TestMethod]
        public void Test3_3_13()
        {
            int modelingMode = 3;
            string functionMode = "3";
            int testNum = 13;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_ypre_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt;
            DataTable output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable23(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_ypre_dt, out input_num_tree_dt, out input_num_max_depth_dt, out input_num_min_split_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            int numTree = new int();
            Nullable<int> numMaxDepth = new int();
            int numMinSplit = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numTree, out numMaxDepth, out numMinSplit, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, numTree, numMaxDepth, numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            TransformData.Array1DRowToDataTable(yPreMod, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output1_dt, "output_mod_validation_y.csv");
            TransformData.Array2DToDataTable(confInt, new string[] { "Lower", "Upper" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output2_dt, "output_conf_int.csv");
            TransformData.Array1DRowToDataTable(actMod, "Actual Modify", out output3_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output3_dt, "output_act_mod.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(yPreMod, yValModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(confInt, confIntTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculationint(actMod, actModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test3_3_14()
        {
            int modelingMode = 3;
            string functionMode = "3";
            int testNum = 14;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_ypre_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt;
            DataTable output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable23(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_ypre_dt, out input_num_tree_dt, out input_num_max_depth_dt, out input_num_min_split_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            int numTree = new int();
            Nullable<int> numMaxDepth = new int();
            int numMinSplit = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numTree, out numMaxDepth, out numMinSplit, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, numTree, numMaxDepth, numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            TransformData.Array1DRowToDataTable(yPreMod, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output1_dt, "output_mod_validation_y.csv");
            TransformData.Array2DToDataTable(confInt, new string[] { "Lower", "Upper" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output2_dt, "output_conf_int.csv");
            TransformData.Array1DRowToDataTable(actMod, "Actual Modify", out output3_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output3_dt, "output_act_mod.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(yPreMod, yValModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(confInt, confIntTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculationint(actMod, actModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test3_3_15()
        {
            int modelingMode = 3;
            string functionMode = "3";
            int testNum = 15;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_ypre_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt;
            DataTable output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable23(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_ypre_dt, out input_num_tree_dt, out input_num_max_depth_dt, out input_num_min_split_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            int numTree = new int();
            Nullable<int> numMaxDepth = new int();
            int numMinSplit = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numTree, out numMaxDepth, out numMinSplit, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, numTree, numMaxDepth, numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            TransformData.Array1DRowToDataTable(yPreMod, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output1_dt, "output_mod_validation_y.csv");
            TransformData.Array2DToDataTable(confInt, new string[] { "Lower", "Upper" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output2_dt, "output_conf_int.csv");
            TransformData.Array1DRowToDataTable(actMod, "Actual Modify", out output3_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output3_dt, "output_act_mod.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(yPreMod, yValModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(confInt, confIntTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculationint(actMod, actModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test3_3_16()
        {
            int modelingMode = 3;
            string functionMode = "3";
            int testNum = 16;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_ypre_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt;
            DataTable output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable23(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_ypre_dt, out input_num_tree_dt, out input_num_max_depth_dt, out input_num_min_split_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            int numTree = new int();
            Nullable<int> numMaxDepth = new int();
            int numMinSplit = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numTree, out numMaxDepth, out numMinSplit, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, numTree, numMaxDepth, numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            TransformData.Array1DRowToDataTable(yPreMod, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output1_dt, "output_mod_validation_y.csv");
            TransformData.Array2DToDataTable(confInt, new string[] { "Lower", "Upper" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output2_dt, "output_conf_int.csv");
            TransformData.Array1DRowToDataTable(actMod, "Actual Modify", out output3_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output3_dt, "output_act_mod.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(yPreMod, yValModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(confInt, confIntTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculationint(actMod, actModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test3_3_17()
        {
            int modelingMode = 3;
            string functionMode = "3";
            int testNum = 17;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_ypre_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt;
            DataTable output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable23(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_ypre_dt, out input_num_tree_dt, out input_num_max_depth_dt, out input_num_min_split_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            int numTree = new int();
            Nullable<int> numMaxDepth = new int();
            int numMinSplit = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numTree, out numMaxDepth, out numMinSplit, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, numTree, numMaxDepth, numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            TransformData.Array1DRowToDataTable(yPreMod, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output1_dt, "output_mod_validation_y.csv");
            TransformData.Array2DToDataTable(confInt, new string[] { "Lower", "Upper" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output2_dt, "output_conf_int.csv");
            TransformData.Array1DRowToDataTable(actMod, "Actual Modify", out output3_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output3_dt, "output_act_mod.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(yPreMod, yValModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(confInt, confIntTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculationint(actMod, actModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test3_3_18()
        {
            int modelingMode = 3;
            string functionMode = "3";
            int testNum = 18;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_ypre_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt;
            DataTable output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable23(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_ypre_dt, out input_num_tree_dt, out input_num_max_depth_dt, out input_num_min_split_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            int numTree = new int();
            Nullable<int> numMaxDepth = new int();
            int numMinSplit = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numTree, out numMaxDepth, out numMinSplit, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, numTree, numMaxDepth, numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            TransformData.Array1DRowToDataTable(yPreMod, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output1_dt, "output_mod_validation_y.csv");
            TransformData.Array2DToDataTable(confInt, new string[] { "Lower", "Upper" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output2_dt, "output_conf_int.csv");
            TransformData.Array1DRowToDataTable(actMod, "Actual Modify", out output3_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output3_dt, "output_act_mod.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(yPreMod, yValModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(confInt, confIntTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculationint(actMod, actModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }

        [TestMethod]
        public void Test3_3_19()
        {
            int modelingMode = 3;
            string functionMode = "3";
            int testNum = 19;
            string method = "mod";
            DataTable input_xtra_dt, input_ytra_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_xpre_dt, input_ypre_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt;
            DataTable output_yval_dt, output_modyval_dt, output_act_mod_dt, output_conf_int_dt;

            //CSVからDataTableとして変数を取得//
            GetData.RFCSVToDataTable23(method, modelingMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_mod_para_dt, out input_mod_data_dt, out input_filter_training_dt, out input_filter_predict_dt, out input_xpre_dt, out input_ypre_dt, out input_num_tree_dt, out input_num_max_depth_dt, out input_num_min_split_dt, out output_yval_dt, out output_modyval_dt, out output_act_mod_dt, out output_conf_int_dt);

            //配列のサイズを取得//
            int timestamp_tra_size = input_mod_data_dt.Rows.Count;
            int timestamp_pre_size = input_ypre_dt.Rows.Count;
            int mod_para_size = input_mod_para_dt.Columns.Count;
            int mod_data_size = input_mod_data_dt.Columns.Count;

            //Jagg配列//
            //input//
            //目的変数 予測期間データ//
            double[] ypre = new double[timestamp_pre_size];
            //補正用パラメータ//
            double[] modPara = new double[mod_para_size];
            //補正用データ//
            double[][] modData = new double[mod_data_size][];
            //学習期間データフィルタリング用データ//
            int[][] filtTra = new int[timestamp_tra_size][];
            //予測期間データフィルタリング用データ//
            int[][] filtPre = new int[timestamp_pre_size][];
            int numTree = new int();
            Nullable<int> numMaxDepth = new int();
            int numMinSplit = new int();

            //output//
            //補正済目的変数 予測期間データ//
            double[] yPreMod = new double[timestamp_pre_size];
            //補正用上下限データ//
            double[][] confInt = new double[timestamp_pre_size][];
            //補正実績データ//
            int[] actMod = new int[timestamp_pre_size];
            //補正済目的変数 検証期間データ//
            double[] yValModTrue;
            //補正済目的変数 検証期間データ//
            double[][] confIntTrue;
            //補正済目的変数 検証期間データ//
            int[] actModTrue;

            //DataTableからJagg配列に変換//
            TransformData.RFDataTableToArray3(input_ypre_dt, input_mod_para_dt, input_mod_data_dt, input_filter_training_dt, input_filter_predict_dt, input_num_tree_dt, input_num_max_depth_dt, input_num_min_split_dt, output_modyval_dt, output_conf_int_dt, output_act_mod_dt, out ypre, out modPara, out modData, out filtTra, out filtPre, out numTree, out numMaxDepth, out numMinSplit, out yValModTrue, out confIntTrue, out actModTrue);

            //IHyperParameterのインスタンス化//
            IHyperParameter hp = new RFHyperParameter(modPara, numTree, numMaxDepth, numMinSplit);

            //IModelのインスタンス化//
            IModel m = ModelFactory.CreateModel(hp);

            //予測//
            m.ModPredict(ypre, modData, filtTra, filtPre, out yPreMod, out confInt, out actMod);

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            TransformData.Array1DRowToDataTable(yPreMod, "Actual", out output1_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output1_dt, "output_mod_validation_y.csv");
            TransformData.Array2DToDataTable(confInt, new string[] { "Lower", "Upper" }, out output2_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output2_dt, "output_conf_int.csv");
            TransformData.Array1DRowToDataTable(actMod, "Actual Modify", out output3_dt);
            GetData.DataTableToCSV(method, modelingMode, functionMode, testNum, output3_dt, "output_act_mod.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(yPreMod, yValModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(confInt, confIntTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculationint(actMod, actModTrue, out relError);
            Assert.AreEqual(0, relError, relTolerance);
        }
    }

    [TestClass]
    public class Filtering_Test
    {
        const double relTolerance = 1E-7;

        [TestMethod]
        public void Test4_basic()
        {
            string method = "all";
            int filteringMode = 4;
            string functionMode = "basic";
            int testNum = 0;
            int[] filtertarget_;
            double[] MinBounds, MaxBounds;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MinMaxFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out MinBounds, out MaxBounds, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[input_xtra_dt.Columns.Count + 1];
            int i;
            for (i = 0; i < input_xtra_dt.Columns.Count + 1; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            // 処理時間の計測開始
            System.Diagnostics.Stopwatch sw = System.Diagnostics.Stopwatch.StartNew();

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MinMaxHyperParameter(filtertarget, MinBounds, MaxBounds);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //フィルタリング//
            int status = 0;
            status = f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter);

            // 処理時間の計測終了
            sw.Stop();
            Console.WriteLine("Processing Time: {0} sec.", sw.Elapsed);  // 処理時間の表示

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            List<string> listColNames = new List<string>();
            foreach (DataColumn colName in input_xtra_dt.Columns)
            {
                listColNames.Add(colName.ColumnName);
            }
            string[] colNames = listColNames.ToArray();
            TransformData.Array2DToDataTable(xtraFiltered, colNames, out output1_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output1_dt, "output_filtered_x.csv");
            TransformData.Array1DRowToDataTable(ytraFiltered, input_ytra_dt.Columns[0].ColumnName, out output2_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output2_dt, "output_filtered_y.csv");
            TransformData.Array1DRowToDataTable(actFilter, "Outlier", out output3_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output3_dt, "output_filtered_act.csv");
        }

        [TestMethod]
        public void Test4_1_1()
        {
            string method = "filtering";
            int filteringMode = 4;
            string functionMode = "1";
            int testNum = 1;
            int[] filtertarget_;
            double[] MinBounds, MaxBounds;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MinMaxFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out MinBounds, out MaxBounds, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MinMaxHyperParameter(filtertarget, MinBounds, MaxBounds);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //理想値と一致するかどうかを判断//
            Assert.AreEqual(800, f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter));
        }

        [TestMethod]
        public void Test4_1_2()
        {
            string method = "filtering";
            int filteringMode = 4;
            string functionMode = "1";
            int testNum = 2;
            int[] filtertarget_;
            double[] MinBounds, MaxBounds;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MinMaxFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out MinBounds, out MaxBounds, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MinMaxHyperParameter(filtertarget, MinBounds, MaxBounds);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //理想値と一致するかどうかを判断//
            Assert.AreEqual(801, f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter));
        }

        [TestMethod]
        public void Test4_1_3()
        {
            string method = "filtering";
            int filteringMode = 4;
            string functionMode = "1";
            int testNum = 3;
            int[] filtertarget_;
            double[] MinBounds, MaxBounds;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MinMaxFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out MinBounds, out MaxBounds, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MinMaxHyperParameter(filtertarget, MinBounds, MaxBounds);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //理想値と一致するかどうかを判断//
            Assert.AreEqual(802, f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter));
        }

        [TestMethod]
        public void Test4_1_4()
        {
            string method = "filtering";
            int filteringMode = 4;
            string functionMode = "1";
            int testNum = 4;
            int[] filtertarget_;
            double[] MinBounds, MaxBounds;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MinMaxFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out MinBounds, out MaxBounds, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MinMaxHyperParameter(filtertarget, MinBounds, MaxBounds);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //理想値と一致するかどうかを判断//
            Assert.AreEqual(802, f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter));
        }

        [TestMethod]
        public void Test4_1_5()
        {
            string method = "filtering";
            int filteringMode = 4;
            string functionMode = "1";
            int testNum = 5;
            int[] filtertarget_;
            double[] MinBounds, MaxBounds;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MinMaxFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out MinBounds, out MaxBounds, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MinMaxHyperParameter(filtertarget, MinBounds, MaxBounds);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //理想値と一致するかどうかを判断//
            Assert.AreEqual(802, f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter));
        }

        [TestMethod]
        public void Test4_1_6()
        {
            string method = "filtering";
            int filteringMode = 4;
            string functionMode = "1";
            int testNum = 6;
            int[] filtertarget_;
            double[] MinBounds, MaxBounds;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MinMaxFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out MinBounds, out MaxBounds, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MinMaxHyperParameter(filtertarget, MinBounds, MaxBounds);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //理想値と一致するかどうかを判断//
            Assert.AreEqual(803, f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter));
        }

        [TestMethod]
        public void Test4_1_7()
        {
            string method = "filtering";
            int filteringMode = 4;
            string functionMode = "1";
            int testNum = 7;
            int[] filtertarget_;
            double[] MinBounds_, MaxBounds_;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MinMaxFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out MinBounds_, out MaxBounds_, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }
            // テスト用にパラメータのサイズ変更
            double[] MinBounds = new double[MinBounds_.Length - 1];
            double[] MaxBounds = new double[MaxBounds_.Length - 1];
            for (i = 0; i < MinBounds.Length; i++)
            {
                MinBounds[i] = MinBounds_[i];
                MaxBounds[i] = MaxBounds_[i];
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MinMaxHyperParameter(filtertarget, MinBounds, MaxBounds);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //理想値と一致するかどうかを判断//
            Assert.AreEqual(804, f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter));
        }

        [TestMethod]
        public void Test4_1_8()
        {
            string method = "filtering";
            int filteringMode = 4;
            string functionMode = "1";
            int testNum = 8;
            int[] filtertarget_;
            double[] MinBounds, MaxBounds_;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MinMaxFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out MinBounds, out MaxBounds_, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }
            // テスト用にパラメータのサイズ変更
            double[] MaxBounds = new double[MaxBounds_.Length - 1];
            for (i = 0; i < MaxBounds.Length; i++)
            {
                MaxBounds[i] = MaxBounds_[i];
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MinMaxHyperParameter(filtertarget, MinBounds, MaxBounds);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //理想値と一致するかどうかを判断//
            Assert.AreEqual(804, f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter));
        }

        [TestMethod]
        public void Test4_1_9()
        {
            string method = "filtering";
            int filteringMode = 4;
            string functionMode = "1";
            int testNum = 9;
            int[] filtertarget_;
            double[] MinBounds_, MaxBounds;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MinMaxFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out MinBounds_, out MaxBounds, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }
            // テスト用にパラメータのサイズ変更
            double[] MinBounds = new double[MinBounds_.Length - 1];
            for (i = 0; i < MinBounds.Length; i++)
            {
                MinBounds[i] = MinBounds_[i];
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MinMaxHyperParameter(filtertarget, MinBounds, MaxBounds);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //理想値と一致するかどうかを判断//
            Assert.AreEqual(804, f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter));
        }

        [TestMethod]
        public void Test4_1_10()
        {
            string method = "filtering";
            int filteringMode = 4;
            string functionMode = "1";
            int testNum = 10;
            int[] filtertarget_;
            double[] MinBounds_, MaxBounds_;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MinMaxFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out MinBounds_, out MaxBounds_, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }
            // テスト用にパラメータのサイズ変更
            double[] MinBounds = new double[MinBounds_.Length - 2];
            double[] MaxBounds = new double[MaxBounds_.Length - 1];
            for (i = 0; i < MinBounds.Length; i++)
            {
                MinBounds[i] = MinBounds_[i];
            }
            for (i = 0; i < MaxBounds.Length; i++)
            {
                MaxBounds[i] = MaxBounds_[i];
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MinMaxHyperParameter(filtertarget, MinBounds, MaxBounds);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //理想値と一致するかどうかを判断//
            Assert.AreEqual(804, f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter));
        }

        [TestMethod]
        public void Test4_1_11()
        {
            string method = "filtering";
            int filteringMode = 4;
            string functionMode = "1";
            int testNum = 11;
            int[] filtertarget_;
            double[] MinBounds, MaxBounds;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MinMaxFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out MinBounds, out MaxBounds, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MinMaxHyperParameter(filtertarget, MinBounds, MaxBounds);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //理想値と一致するかどうかを判断//
            Assert.AreEqual(805, f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter));
        }

        [TestMethod]
        public void Test4_1_12()
        {
            string method = "filtering";
            int filteringMode = 4;
            string functionMode = "1";
            int testNum = 12;
            int[] filtertarget_;
            double[] MinBounds, MaxBounds;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MinMaxFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out MinBounds, out MaxBounds, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MinMaxHyperParameter(filtertarget, MinBounds, MaxBounds);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //理想値と一致するかどうかを判断//
            Assert.AreEqual(806, f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter));
        }

        [TestMethod]
        public void Test4_1_13()
        {
            string method = "filtering";
            int filteringMode = 4;
            string functionMode = "1";
            int testNum = 13;
            int[] filtertarget_;
            double[] MinBounds, MaxBounds;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MinMaxFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out MinBounds, out MaxBounds, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;
            int[] iActFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            // 処理時間の計測開始
            System.Diagnostics.Stopwatch sw = System.Diagnostics.Stopwatch.StartNew();

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MinMaxHyperParameter(filtertarget, MinBounds, MaxBounds);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //フィルタリング//
            int status = 0;
            status = f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter);

            // 処理時間の計測終了
            sw.Stop();
            Console.WriteLine("Processing Time: {0} sec.", sw.Elapsed);  // 処理時間の表示

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            List<string> listColNames = new List<string>();
            foreach (DataColumn colName in input_xtra_dt.Columns)
            {
                listColNames.Add(colName.ColumnName);
            }
            string[] colNames = listColNames.ToArray();
            TransformData.Array2DToDataTable(xtraFiltered, colNames, out output1_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output1_dt, "output_filtered_x.csv");
            TransformData.Array1DRowToDataTable(ytraFiltered, input_ytra_dt.Columns[0].ColumnName, out output2_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output2_dt, "output_filtered_y.csv");
            TransformData.Array1DRowToDataTable(actFilter, "Outlier", out output3_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output3_dt, "output_filtered_act.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(ytraFiltered_val, ytraFiltered, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(xtraFiltered_val, xtraFiltered, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            iActFilter = new int[actFilter.Length];
            for (i = 0; i < actFilter.Length; i++)
            {
                iActFilter[i] = Convert.ToInt32(actFilter[i]);
            }
            CalcError.ErrorCalculationint(actFiltered_val, iActFilter, out relError);
            Assert.AreEqual(0, relError, 0);
        }

        [TestMethod]
        public void Test4_1_14()
        {
            string method = "filtering";
            int filteringMode = 4;
            string functionMode = "1";
            int testNum = 14;
            int[] filtertarget_;
            double[] MinBounds, MaxBounds;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MinMaxFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out MinBounds, out MaxBounds, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;
            int[] iActFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            // 処理時間の計測開始
            System.Diagnostics.Stopwatch sw = System.Diagnostics.Stopwatch.StartNew();

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MinMaxHyperParameter(filtertarget, MinBounds, MaxBounds);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //フィルタリング//
            int status = 0;
            status = f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter);

            // 処理時間の計測終了
            sw.Stop();
            Console.WriteLine("Processing Time: {0} sec.", sw.Elapsed);  // 処理時間の表示

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            List<string> listColNames = new List<string>();
            foreach (DataColumn colName in input_xtra_dt.Columns)
            {
                listColNames.Add(colName.ColumnName);
            }
            string[] colNames = listColNames.ToArray();
            TransformData.Array2DToDataTable(xtraFiltered, colNames, out output1_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output1_dt, "output_filtered_x.csv");
            TransformData.Array1DRowToDataTable(ytraFiltered, input_ytra_dt.Columns[0].ColumnName, out output2_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output2_dt, "output_filtered_y.csv");
            TransformData.Array1DRowToDataTable(actFilter, "Outlier", out output3_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output3_dt, "output_filtered_act.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(ytraFiltered_val, ytraFiltered, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(xtraFiltered_val, xtraFiltered, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            iActFilter = new int[actFilter.Length];
            for (i = 0; i < actFilter.Length; i++)
            {
                iActFilter[i] = Convert.ToInt32(actFilter[i]);
            }
            CalcError.ErrorCalculationint(actFiltered_val, iActFilter, out relError);
            Assert.AreEqual(0, relError, 0);
        }

        [TestMethod]
        public void Test4_1_15()
        {
            string method = "filtering";
            int filteringMode = 4;
            string functionMode = "1";
            int testNum = 15;
            int[] filtertarget_;
            double[] MinBounds, MaxBounds;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MinMaxFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out MinBounds, out MaxBounds, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;
            int[] iActFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            // 処理時間の計測開始
            System.Diagnostics.Stopwatch sw = System.Diagnostics.Stopwatch.StartNew();

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MinMaxHyperParameter(filtertarget, MinBounds, MaxBounds);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //フィルタリング//
            int status = 0;
            status = f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter);

            // 処理時間の計測終了
            sw.Stop();
            Console.WriteLine("Processing Time: {0} sec.", sw.Elapsed);  // 処理時間の表示

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            List<string> listColNames = new List<string>();
            foreach (DataColumn colName in input_xtra_dt.Columns)
            {
                listColNames.Add(colName.ColumnName);
            }
            string[] colNames = listColNames.ToArray();
            TransformData.Array2DToDataTable(xtraFiltered, colNames, out output1_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output1_dt, "output_filtered_x.csv");
            TransformData.Array1DRowToDataTable(ytraFiltered, input_ytra_dt.Columns[0].ColumnName, out output2_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output2_dt, "output_filtered_y.csv");
            TransformData.Array1DRowToDataTable(actFilter, "Outlier", out output3_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output3_dt, "output_filtered_act.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(ytraFiltered_val, ytraFiltered, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(xtraFiltered_val, xtraFiltered, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            iActFilter = new int[actFilter.Length];
            for (i = 0; i < actFilter.Length; i++)
            {
                iActFilter[i] = Convert.ToInt32(actFilter[i]);
            }
            CalcError.ErrorCalculationint(actFiltered_val, iActFilter, out relError);
            Assert.AreEqual(0, relError, 0);
        }

        [TestMethod]
        public void Test4_1_16()
        {
            string method = "filtering";
            int filteringMode = 4;
            string functionMode = "1";
            int testNum = 16;
            int[] filtertarget_;
            double[] MinBounds, MaxBounds;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MinMaxFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out MinBounds, out MaxBounds, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;
            int[] iActFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            // 処理時間の計測開始
            System.Diagnostics.Stopwatch sw = System.Diagnostics.Stopwatch.StartNew();

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MinMaxHyperParameter(filtertarget, MinBounds, MaxBounds);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //フィルタリング//
            int status = 0;
            status = f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter);

            // 処理時間の計測終了
            sw.Stop();
            Console.WriteLine("Processing Time: {0} sec.", sw.Elapsed);  // 処理時間の表示

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            List<string> listColNames = new List<string>();
            foreach (DataColumn colName in input_xtra_dt.Columns)
            {
                listColNames.Add(colName.ColumnName);
            }
            string[] colNames = listColNames.ToArray();
            TransformData.Array2DToDataTable(xtraFiltered, colNames, out output1_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output1_dt, "output_filtered_x.csv");
            TransformData.Array1DRowToDataTable(ytraFiltered, input_ytra_dt.Columns[0].ColumnName, out output2_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output2_dt, "output_filtered_y.csv");
            TransformData.Array1DRowToDataTable(actFilter, "Outlier", out output3_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output3_dt, "output_filtered_act.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(ytraFiltered_val, ytraFiltered, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(xtraFiltered_val, xtraFiltered, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            iActFilter = new int[actFilter.Length];
            for (i = 0; i < actFilter.Length; i++)
            {
                iActFilter[i] = Convert.ToInt32(actFilter[i]);
            }
            CalcError.ErrorCalculationint(actFiltered_val, iActFilter, out relError);
            Assert.AreEqual(0, relError, 0);
        }

        [TestMethod]
        public void Test4_1_17()
        {
            string method = "filtering";
            int filteringMode = 4;
            string functionMode = "1";
            int testNum = 17;
            int[] filtertarget_;
            double[] MinBounds, MaxBounds;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MinMaxFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out MinBounds, out MaxBounds, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;
            int[] iActFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            // 処理時間の計測開始
            System.Diagnostics.Stopwatch sw = System.Diagnostics.Stopwatch.StartNew();

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MinMaxHyperParameter(filtertarget, MinBounds, MaxBounds);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //フィルタリング//
            int status = 0;
            status = f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter);

            // 処理時間の計測終了
            sw.Stop();
            Console.WriteLine("Processing Time: {0} sec.", sw.Elapsed);  // 処理時間の表示

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            List<string> listColNames = new List<string>();
            foreach (DataColumn colName in input_xtra_dt.Columns)
            {
                listColNames.Add(colName.ColumnName);
            }
            string[] colNames = listColNames.ToArray();
            TransformData.Array2DToDataTable(xtraFiltered, colNames, out output1_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output1_dt, "output_filtered_x.csv");
            TransformData.Array1DRowToDataTable(ytraFiltered, input_ytra_dt.Columns[0].ColumnName, out output2_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output2_dt, "output_filtered_y.csv");
            TransformData.Array1DRowToDataTable(actFilter, "Outlier", out output3_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output3_dt, "output_filtered_act.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(ytraFiltered_val, ytraFiltered, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(xtraFiltered_val, xtraFiltered, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            iActFilter = new int[actFilter.Length];
            for (i = 0; i < actFilter.Length; i++)
            {
                iActFilter[i] = Convert.ToInt32(actFilter[i]);
            }
            CalcError.ErrorCalculationint(actFiltered_val, iActFilter, out relError);
            Assert.AreEqual(0, relError, 0);
        }

        [TestMethod]
        public void Test4_1_18()
        {
            string method = "filtering";
            int filteringMode = 4;
            string functionMode = "1";
            int testNum = 18;
            int[] filtertarget_;
            double[] MinBounds, MaxBounds;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MinMaxFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out MinBounds, out MaxBounds, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;
            int[] iActFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            // 処理時間の計測開始
            System.Diagnostics.Stopwatch sw = System.Diagnostics.Stopwatch.StartNew();

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MinMaxHyperParameter(filtertarget, MinBounds, MaxBounds);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //フィルタリング//
            int status = 0;
            status = f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter);

            // 処理時間の計測終了
            sw.Stop();
            Console.WriteLine("Processing Time: {0} sec.", sw.Elapsed);  // 処理時間の表示

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            List<string> listColNames = new List<string>();
            foreach (DataColumn colName in input_xtra_dt.Columns)
            {
                listColNames.Add(colName.ColumnName);
            }
            string[] colNames = listColNames.ToArray();
            TransformData.Array2DToDataTable(xtraFiltered, colNames, out output1_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output1_dt, "output_filtered_x.csv");
            TransformData.Array1DRowToDataTable(ytraFiltered, input_ytra_dt.Columns[0].ColumnName, out output2_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output2_dt, "output_filtered_y.csv");
            TransformData.Array1DRowToDataTable(actFilter, "Outlier", out output3_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output3_dt, "output_filtered_act.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(ytraFiltered_val, ytraFiltered, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(xtraFiltered_val, xtraFiltered, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            iActFilter = new int[actFilter.Length];
            for (i = 0; i < actFilter.Length; i++)
            {
                iActFilter[i] = Convert.ToInt32(actFilter[i]);
            }
            CalcError.ErrorCalculationint(actFiltered_val, iActFilter, out relError);
            Assert.AreEqual(0, relError, 0);
        }

        [TestMethod]
        public void Test4_1_19()
        {
            string method = "filtering";
            int filteringMode = 4;
            string functionMode = "1";
            int testNum = 19;
            int[] filtertarget_;
            double[] MinBounds, MaxBounds;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MinMaxFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out MinBounds, out MaxBounds, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;
            int[] iActFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            // 処理時間の計測開始
            System.Diagnostics.Stopwatch sw = System.Diagnostics.Stopwatch.StartNew();

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MinMaxHyperParameter(filtertarget, MinBounds, MaxBounds);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //フィルタリング//
            int status = 0;
            status = f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter);

            // 処理時間の計測終了
            sw.Stop();
            Console.WriteLine("Processing Time: {0} sec.", sw.Elapsed);  // 処理時間の表示

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            List<string> listColNames = new List<string>();
            foreach (DataColumn colName in input_xtra_dt.Columns)
            {
                listColNames.Add(colName.ColumnName);
            }
            string[] colNames = listColNames.ToArray();
            TransformData.Array2DToDataTable(xtraFiltered, colNames, out output1_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output1_dt, "output_filtered_x.csv");
            TransformData.Array1DRowToDataTable(ytraFiltered, input_ytra_dt.Columns[0].ColumnName, out output2_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output2_dt, "output_filtered_y.csv");
            TransformData.Array1DRowToDataTable(actFilter, "Outlier", out output3_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output3_dt, "output_filtered_act.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(ytraFiltered_val, ytraFiltered, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(xtraFiltered_val, xtraFiltered, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            iActFilter = new int[actFilter.Length];
            for (i = 0; i < actFilter.Length; i++)
            {
                iActFilter[i] = Convert.ToInt32(actFilter[i]);
            }
            CalcError.ErrorCalculationint(actFiltered_val, iActFilter, out relError);
            Assert.AreEqual(0, relError, 0);
        }

        [TestMethod]
        public void Test4_1_20()
        {
            string method = "filtering";
            int filteringMode = 4;
            string functionMode = "1";
            int testNum = 20;
            int[] filtertarget_;
            double[] MinBounds, MaxBounds;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MinMaxFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out MinBounds, out MaxBounds, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;
            int[] iActFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            // テスト用に最大値を+Infにする
            for (i = 0; i < MaxBounds.Length; i++)
            {
                MaxBounds[i] = Double.PositiveInfinity;
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            // 処理時間の計測開始
            System.Diagnostics.Stopwatch sw = System.Diagnostics.Stopwatch.StartNew();

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MinMaxHyperParameter(filtertarget, MinBounds, MaxBounds);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //フィルタリング//
            int status = 0;
            status = f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter);

            // 処理時間の計測終了
            sw.Stop();
            Console.WriteLine("Processing Time: {0} sec.", sw.Elapsed);  // 処理時間の表示

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            List<string> listColNames = new List<string>();
            foreach (DataColumn colName in input_xtra_dt.Columns)
            {
                listColNames.Add(colName.ColumnName);
            }
            string[] colNames = listColNames.ToArray();
            TransformData.Array2DToDataTable(xtraFiltered, colNames, out output1_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output1_dt, "output_filtered_x.csv");
            TransformData.Array1DRowToDataTable(ytraFiltered, input_ytra_dt.Columns[0].ColumnName, out output2_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output2_dt, "output_filtered_y.csv");
            TransformData.Array1DRowToDataTable(actFilter, "Outlier", out output3_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output3_dt, "output_filtered_act.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(ytraFiltered_val, ytraFiltered, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(xtraFiltered_val, xtraFiltered, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            iActFilter = new int[actFilter.Length];
            for (i = 0; i < actFilter.Length; i++)
            {
                iActFilter[i] = Convert.ToInt32(actFilter[i]);
            }
            CalcError.ErrorCalculationint(actFiltered_val, iActFilter, out relError);
            Assert.AreEqual(0, relError, 0);
        }

        [TestMethod]
        public void Test4_1_21()
        {
            string method = "filtering";
            int filteringMode = 4;
            string functionMode = "1";
            int testNum = 21;
            int[] filtertarget_;
            double[] MinBounds, MaxBounds;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MinMaxFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out MinBounds, out MaxBounds, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;
            int[] iActFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            // テスト用に最小値を-Infにする
            for (i = 0; i < MinBounds.Length; i++)
            {
                MinBounds[i] = Double.NegativeInfinity;
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            // 処理時間の計測開始
            System.Diagnostics.Stopwatch sw = System.Diagnostics.Stopwatch.StartNew();

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MinMaxHyperParameter(filtertarget, MinBounds, MaxBounds);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //フィルタリング//
            int status = 0;
            status = f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter);

            // 処理時間の計測終了
            sw.Stop();
            Console.WriteLine("Processing Time: {0} sec.", sw.Elapsed);  // 処理時間の表示

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            List<string> listColNames = new List<string>();
            foreach (DataColumn colName in input_xtra_dt.Columns)
            {
                listColNames.Add(colName.ColumnName);
            }
            string[] colNames = listColNames.ToArray();
            TransformData.Array2DToDataTable(xtraFiltered, colNames, out output1_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output1_dt, "output_filtered_x.csv");
            TransformData.Array1DRowToDataTable(ytraFiltered, input_ytra_dt.Columns[0].ColumnName, out output2_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output2_dt, "output_filtered_y.csv");
            TransformData.Array1DRowToDataTable(actFilter, "Outlier", out output3_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output3_dt, "output_filtered_act.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(ytraFiltered_val, ytraFiltered, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(xtraFiltered_val, xtraFiltered, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            iActFilter = new int[actFilter.Length];
            for (i = 0; i < actFilter.Length; i++)
            {
                iActFilter[i] = Convert.ToInt32(actFilter[i]);
            }
            CalcError.ErrorCalculationint(actFiltered_val, iActFilter, out relError);
            Assert.AreEqual(0, relError, 0);
        }

        [TestMethod]
        public void Test5_basic()
        {
            string method = "all";
            int filteringMode = 5;
            string functionMode = "basic";
            int testNum = 0;
            int[] filtertarget_;
            double OutlierRate;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MaharanobisFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out OutlierRate, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[input_xtra_dt.Columns.Count + 1];
            int i;
            for (i = 0; i < input_xtra_dt.Columns.Count + 1; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            // 処理時間の計測開始
            System.Diagnostics.Stopwatch sw = System.Diagnostics.Stopwatch.StartNew();

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MaharanobisHyperParameter(filtertarget, OutlierRate);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //フィルタリング//
            int status = 0;
            status = f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter);

            // 処理時間の計測終了
            sw.Stop();
            Console.WriteLine("Processing Time: {0} sec.", sw.Elapsed);  // 処理時間の表示

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            List<string> listColNames = new List<string>();
            foreach (DataColumn colName in input_xtra_dt.Columns)
            {
                listColNames.Add(colName.ColumnName);
            }
            string[] colNames = listColNames.ToArray();
            TransformData.Array2DToDataTable(xtraFiltered, colNames, out output1_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output1_dt, "output_filtered_x.csv");
            TransformData.Array1DRowToDataTable(ytraFiltered, input_ytra_dt.Columns[0].ColumnName, out output2_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output2_dt, "output_filtered_y.csv");
            TransformData.Array1DRowToDataTable(actFilter, "Outlier", out output3_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output3_dt, "output_filtered_act.csv");
        }

        [TestMethod]
        public void Test5_1_1()
        {
            string method = "filtering";
            int filteringMode = 5;
            string functionMode = "1";
            int testNum = 1;
            int[] filtertarget_;
            double OutlierRate;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MaharanobisFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out OutlierRate, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MaharanobisHyperParameter(filtertarget, OutlierRate);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //理想値と一致するかどうかを判断//
            Assert.AreEqual(800, f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter));
        }

        [TestMethod]
        public void Test5_1_2()
        {
            string method = "filtering";
            int filteringMode = 5;
            string functionMode = "1";
            int testNum = 2;
            int[] filtertarget_;
            double OutlierRate;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MaharanobisFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out OutlierRate, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MaharanobisHyperParameter(filtertarget, OutlierRate);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //理想値と一致するかどうかを判断//
            Assert.AreEqual(801, f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter));
        }

        [TestMethod]
        public void Test5_1_3()
        {
            string method = "filtering";
            int filteringMode = 5;
            string functionMode = "1";
            int testNum = 3;
            int[] filtertarget_;
            double OutlierRate;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MaharanobisFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out OutlierRate, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MaharanobisHyperParameter(filtertarget, OutlierRate);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //理想値と一致するかどうかを判断//
            Assert.AreEqual(802, f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter));
        }

        [TestMethod]
        public void Test5_1_4()
        {
            string method = "filtering";
            int filteringMode = 5;
            string functionMode = "1";
            int testNum = 4;
            int[] filtertarget_;
            double OutlierRate;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MaharanobisFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out OutlierRate, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MaharanobisHyperParameter(filtertarget, OutlierRate);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //理想値と一致するかどうかを判断//
            Assert.AreEqual(802, f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter));
        }

        [TestMethod]
        public void Test5_1_5()
        {
            string method = "filtering";
            int filteringMode = 5;
            string functionMode = "1";
            int testNum = 5;
            int[] filtertarget_;
            double OutlierRate;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MaharanobisFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out OutlierRate, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MaharanobisHyperParameter(filtertarget, OutlierRate);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //理想値と一致するかどうかを判断//
            Assert.AreEqual(802, f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter));
        }

        [TestMethod]
        public void Test5_1_6()
        {
            string method = "filtering";
            int filteringMode = 5;
            string functionMode = "1";
            int testNum = 6;
            int[] filtertarget_;
            double OutlierRate;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MaharanobisFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out OutlierRate, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MaharanobisHyperParameter(filtertarget, OutlierRate);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //理想値と一致するかどうかを判断//
            Assert.AreEqual(803, f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter));
        }

        [TestMethod]
        public void Test5_1_7()
        {
            string method = "filtering";
            int filteringMode = 5;
            string functionMode = "1";
            int testNum = 7;
            int[] filtertarget_;
            double OutlierRate;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MaharanobisFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out OutlierRate, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //目的変数 予測期間データ//
            //double[] ypre = new double[timestamp_pre_size + 1];
            //補正済予測//
            //double[] yPreMod = new double[timestamp_pre_size];
            //予測区間//
            //double[][] confInt = new double[timestamp_pre_size][];
            //補正実績フラグ//
            //int[] actMod = new int[timestamp_pre_size];
            //フィルタリング済 学習データ//
            double[][] xtraFiltered;
            double[] ytraFiltered;
            bool[] actFilter;
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MaharanobisHyperParameter(filtertarget, OutlierRate);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //理想値と一致するかどうかを判断//
            Assert.AreEqual(805, f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter));
        }

        [TestMethod]
        public void Test5_1_8()
        {
            string method = "filtering";
            int filteringMode = 5;
            string functionMode = "1";
            int testNum = 8;
            int[] filtertarget_;
            double OutlierRate;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MaharanobisFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out OutlierRate, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MaharanobisHyperParameter(filtertarget, OutlierRate);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //理想値と一致するかどうかを判断//
            Assert.AreEqual(807, f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter));
        }

        [TestMethod]
        public void Test5_1_9()
        {
            string method = "filtering";
            int filteringMode = 5;
            string functionMode = "1";
            int testNum = 9;
            int[] filtertarget_;
            double OutlierRate;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MaharanobisFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out OutlierRate, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //目的変数 予測期間データ//
            //double[] ypre = new double[timestamp_pre_size + 1];
            //補正済予測//
            //double[] yPreMod = new double[timestamp_pre_size];
            //予測区間//
            //double[][] confInt = new double[timestamp_pre_size][];
            //補正実績フラグ//
            //int[] actMod = new int[timestamp_pre_size];
            //フィルタリング済 学習データ//
            double[][] xtraFiltered;
            double[] ytraFiltered;
            bool[] actFilter;
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MaharanobisHyperParameter(filtertarget, OutlierRate);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //理想値と一致するかどうかを判断//
            Assert.AreEqual(807, f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter));
        }

        [TestMethod]
        public void Test5_1_10()
        {
            string method = "filtering";
            int filteringMode = 5;
            string functionMode = "1";
            int testNum = 10;
            int[] filtertarget_;
            double OutlierRate;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MaharanobisFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out OutlierRate, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;
            int[] iActFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            // 処理時間の計測開始
            System.Diagnostics.Stopwatch sw = System.Diagnostics.Stopwatch.StartNew();

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MaharanobisHyperParameter(filtertarget, OutlierRate);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //フィルタリング//
            int status = 0;
            status = f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter);

            // 処理時間の計測終了
            sw.Stop();
            Console.WriteLine("Processing Time: {0} sec.", sw.Elapsed);  // 処理時間の表示

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            List<string> listColNames = new List<string>();
            foreach (DataColumn colName in input_xtra_dt.Columns)
            {
                listColNames.Add(colName.ColumnName);
            }
            string[] colNames = listColNames.ToArray();
            TransformData.Array2DToDataTable(xtraFiltered, colNames, out output1_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output1_dt, "output_filtered_x.csv");
            TransformData.Array1DRowToDataTable(ytraFiltered, input_ytra_dt.Columns[0].ColumnName, out output2_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output2_dt, "output_filtered_y.csv");
            TransformData.Array1DRowToDataTable(actFilter, "Outlier", out output3_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output3_dt, "output_filtered_act.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(ytraFiltered_val, ytraFiltered, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(xtraFiltered_val, xtraFiltered, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            iActFilter = new int[actFilter.Length];
            for (i = 0; i < actFilter.Length; i++)
            {
                iActFilter[i] = Convert.ToInt32(actFilter[i]);
            }
            CalcError.ErrorCalculationint(actFiltered_val, iActFilter, out relError);
            Assert.AreEqual(0, relError, 0);
        }

        [TestMethod]
        public void Test5_1_11()
        {
            string method = "filtering";
            int filteringMode = 5;
            string functionMode = "1";
            int testNum = 11;
            int[] filtertarget_;
            double OutlierRate;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MaharanobisFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out OutlierRate, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;
            int[] iActFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            // 処理時間の計測開始
            System.Diagnostics.Stopwatch sw = System.Diagnostics.Stopwatch.StartNew();

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MaharanobisHyperParameter(filtertarget, OutlierRate);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //フィルタリング//
            int status = 0;
            status = f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter);

            // 処理時間の計測終了
            sw.Stop();
            Console.WriteLine("Processing Time: {0} sec.", sw.Elapsed);  // 処理時間の表示

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            List<string> listColNames = new List<string>();
            foreach (DataColumn colName in input_xtra_dt.Columns)
            {
                listColNames.Add(colName.ColumnName);
            }
            string[] colNames = listColNames.ToArray();
            TransformData.Array2DToDataTable(xtraFiltered, colNames, out output1_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output1_dt, "output_filtered_x.csv");
            TransformData.Array1DRowToDataTable(ytraFiltered, input_ytra_dt.Columns[0].ColumnName, out output2_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output2_dt, "output_filtered_y.csv");
            TransformData.Array1DRowToDataTable(actFilter, "Outlier", out output3_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output3_dt, "output_filtered_act.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(ytraFiltered_val, ytraFiltered, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(xtraFiltered_val, xtraFiltered, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            iActFilter = new int[actFilter.Length];
            for (i = 0; i < actFilter.Length; i++)
            {
                iActFilter[i] = Convert.ToInt32(actFilter[i]);
            }
            CalcError.ErrorCalculationint(actFiltered_val, iActFilter, out relError);
            Assert.AreEqual(0, relError, 0);
        }

        [TestMethod]
        public void Test5_1_12()
        {
            string method = "filtering";
            int filteringMode = 5;
            string functionMode = "1";
            int testNum = 12;
            int[] filtertarget_;
            double OutlierRate;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MaharanobisFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out OutlierRate, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;
            int[] iActFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            // 処理時間の計測開始
            System.Diagnostics.Stopwatch sw = System.Diagnostics.Stopwatch.StartNew();

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MaharanobisHyperParameter(filtertarget, OutlierRate);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //フィルタリング//
            int status = 0;
            status = f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter);

            // 処理時間の計測終了
            sw.Stop();
            Console.WriteLine("Processing Time: {0} sec.", sw.Elapsed);  // 処理時間の表示

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            List<string> listColNames = new List<string>();
            foreach (DataColumn colName in input_xtra_dt.Columns)
            {
                listColNames.Add(colName.ColumnName);
            }
            string[] colNames = listColNames.ToArray();
            TransformData.Array2DToDataTable(xtraFiltered, colNames, out output1_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output1_dt, "output_filtered_x.csv");
            TransformData.Array1DRowToDataTable(ytraFiltered, input_ytra_dt.Columns[0].ColumnName, out output2_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output2_dt, "output_filtered_y.csv");
            TransformData.Array1DRowToDataTable(actFilter, "Outlier", out output3_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output3_dt, "output_filtered_act.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(ytraFiltered_val, ytraFiltered, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(xtraFiltered_val, xtraFiltered, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            iActFilter = new int[actFilter.Length];
            for (i = 0; i < actFilter.Length; i++)
            {
                iActFilter[i] = Convert.ToInt32(actFilter[i]);
            }
            CalcError.ErrorCalculationint(actFiltered_val, iActFilter, out relError);
            Assert.AreEqual(0, relError, 0);
        }

        [TestMethod]
        public void Test5_1_13()
        {
            string method = "filtering";
            int filteringMode = 5;
            string functionMode = "1";
            int testNum = 13;
            int[] filtertarget_;
            double OutlierRate;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MaharanobisFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out OutlierRate, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;
            int[] iActFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            // 処理時間の計測開始
            System.Diagnostics.Stopwatch sw = System.Diagnostics.Stopwatch.StartNew();

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MaharanobisHyperParameter(filtertarget, OutlierRate);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //フィルタリング//
            int status = 0;
            status = f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter);

            // 処理時間の計測終了
            sw.Stop();
            Console.WriteLine("Processing Time: {0} sec.", sw.Elapsed);  // 処理時間の表示

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            List<string> listColNames = new List<string>();
            foreach (DataColumn colName in input_xtra_dt.Columns)
            {
                listColNames.Add(colName.ColumnName);
            }
            string[] colNames = listColNames.ToArray();
            TransformData.Array2DToDataTable(xtraFiltered, colNames, out output1_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output1_dt, "output_filtered_x.csv");
            TransformData.Array1DRowToDataTable(ytraFiltered, input_ytra_dt.Columns[0].ColumnName, out output2_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output2_dt, "output_filtered_y.csv");
            TransformData.Array1DRowToDataTable(actFilter, "Outlier", out output3_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output3_dt, "output_filtered_act.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(ytraFiltered_val, ytraFiltered, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(xtraFiltered_val, xtraFiltered, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            iActFilter = new int[actFilter.Length];
            for (i = 0; i < actFilter.Length; i++)
            {
                iActFilter[i] = Convert.ToInt32(actFilter[i]);
            }
            CalcError.ErrorCalculationint(actFiltered_val, iActFilter, out relError);
            Assert.AreEqual(0, relError, 0);
        }

        [TestMethod]
        public void Test5_1_14()
        {
            string method = "filtering";
            int filteringMode = 5;
            string functionMode = "1";
            int testNum = 14;
            int[] filtertarget_;
            double OutlierRate;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MaharanobisFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out OutlierRate, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;
            int[] iActFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            // 処理時間の計測開始
            System.Diagnostics.Stopwatch sw = System.Diagnostics.Stopwatch.StartNew();

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MaharanobisHyperParameter(filtertarget, OutlierRate);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //フィルタリング//
            int status = 0;
            status = f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter);

            // 処理時間の計測終了
            sw.Stop();
            Console.WriteLine("Processing Time: {0} sec.", sw.Elapsed);  // 処理時間の表示

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            List<string> listColNames = new List<string>();
            foreach (DataColumn colName in input_xtra_dt.Columns)
            {
                listColNames.Add(colName.ColumnName);
            }
            string[] colNames = listColNames.ToArray();
            TransformData.Array2DToDataTable(xtraFiltered, colNames, out output1_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output1_dt, "output_filtered_x.csv");
            TransformData.Array1DRowToDataTable(ytraFiltered, input_ytra_dt.Columns[0].ColumnName, out output2_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output2_dt, "output_filtered_y.csv");
            TransformData.Array1DRowToDataTable(actFilter, "Outlier", out output3_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output3_dt, "output_filtered_act.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(ytraFiltered_val, ytraFiltered, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(xtraFiltered_val, xtraFiltered, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            iActFilter = new int[actFilter.Length];
            for (i = 0; i < actFilter.Length; i++)
            {
                iActFilter[i] = Convert.ToInt32(actFilter[i]);
            }
            CalcError.ErrorCalculationint(actFiltered_val, iActFilter, out relError);
            Assert.AreEqual(0, relError, 0);
        }

        [TestMethod]
        public void Test5_1_15()
        {
            string method = "filtering";
            int filteringMode = 5;
            string functionMode = "1";
            int testNum = 15;
            int[] filtertarget_;
            double OutlierRate;
            DataTable input_xtra_dt, input_ytra_dt, input_filter_para_dt;
            DataTable output_filtered_act_dt, output_filtered_x_dt, output_filtered_y_dt;

            //CSVからDataTableとして変数を取得//
            GetData.MaharanobisFilterCSVToDataTable(method, filteringMode, functionMode, testNum, out input_xtra_dt, out input_ytra_dt, out input_filter_para_dt, out filtertarget_, out OutlierRate, out output_filtered_act_dt, out output_filtered_x_dt, out output_filtered_y_dt);

            //配列のサイズを取得//
            int variable_size = input_xtra_dt.Columns.Count;
            int timestamp_x_size = input_xtra_dt.Rows.Count;
            int timestamp_y_size = input_ytra_dt.Rows.Count;
            int timestamp_act_val_size = output_filtered_act_dt.Rows.Count;
            int timestamp_x_val_size = output_filtered_x_dt.Rows.Count;
            int timestamp_y_val_size = output_filtered_y_dt.Rows.Count;

            //Jagg配列//
            //input//
            //説明変数 学習期間データ//
            double[][] xtra = new double[timestamp_x_size][];
            //目的変数 学習期間データ//
            double[] ytra = new double[timestamp_y_size];
            //説明変数 フィルタリング済み学習期間データの正解データ
            double[][] xtraFiltered_val = new double[timestamp_x_val_size][];
            //目的変数 フィルタリング済み学習期間データの正解データ//
            double[] ytraFiltered_val = new double[timestamp_y_val_size];
            //外れ値フラグ　フィルタリング済み学習期間データの正解データ//
            int[] actFiltered_val = new int[timestamp_act_val_size];
            bool[] bool_actFiltered_val = new bool[timestamp_act_val_size];

            //output//
            //説明変数 フィルタリング済み学習データ//
            double[][] xtraFiltered;
            //目的変数 フィルタリング済み学習データ//
            double[] ytraFiltered;
            //外れ値フラグ　フィルタリング済み学習期間データ//
            bool[] actFilter;
            int[] iActFilter;

            //フィルタリング対象
            bool[] filtertarget = new bool[filtertarget_.Length];
            int i;
            for (i = 0; i < filtertarget_.Length; i++)
            {
                filtertarget[i] = Convert.ToBoolean(filtertarget_[i]);
            }

            //DataTableからJagg配列に変換//
            TransformData.DataTableToArrayFilter(input_xtra_dt, input_ytra_dt, output_filtered_x_dt, output_filtered_y_dt, output_filtered_act_dt, out xtra, out ytra, out xtraFiltered_val, out ytraFiltered_val, out actFiltered_val);

            // 処理時間の計測開始
            System.Diagnostics.Stopwatch sw = System.Diagnostics.Stopwatch.StartNew();

            //IFilterParameterのインスタンス化//
            IFilteringHyperParameter fhp = new MaharanobisHyperParameter(filtertarget, OutlierRate);

            //IFilterのインスタンス化//
            IFilter f = FilterFactory.CreatFilter(fhp);

            //フィルタリング//
            int status = 0;
            status = f.Filtering(xtra, ytra, out xtraFiltered, out ytraFiltered, out actFilter);

            // 処理時間の計測終了
            sw.Stop();
            Console.WriteLine("Processing Time: {0} sec.", sw.Elapsed);  // 処理時間の表示

            //Jagg配列からDataTableに変換し、それをCSVとして出力//
            DataTable output1_dt, output2_dt, output3_dt;
            List<string> listColNames = new List<string>();
            foreach (DataColumn colName in input_xtra_dt.Columns)
            {
                listColNames.Add(colName.ColumnName);
            }
            string[] colNames = listColNames.ToArray();
            TransformData.Array2DToDataTable(xtraFiltered, colNames, out output1_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output1_dt, "output_filtered_x.csv");
            TransformData.Array1DRowToDataTable(ytraFiltered, input_ytra_dt.Columns[0].ColumnName, out output2_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output2_dt, "output_filtered_y.csv");
            TransformData.Array1DRowToDataTable(actFilter, "Outlier", out output3_dt);
            GetData.FilterDataTableToCSV(method, filteringMode, functionMode, testNum, output3_dt, "output_filtered_act.csv");

            //理想値と一致するかどうかを判断//
            double relError;
            CalcError.ErrorCalculation(ytraFiltered_val, ytraFiltered, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            CalcError.ErrorCalculation2Ddouble(xtraFiltered_val, xtraFiltered, out relError);
            Assert.AreEqual(0, relError, relTolerance);
            iActFilter = new int[actFilter.Length];
            for (i = 0; i < actFilter.Length; i++)
            {
                iActFilter[i] = Convert.ToInt32(actFilter[i]);
            }
            CalcError.ErrorCalculationint(actFiltered_val, iActFilter, out relError);
            Assert.AreEqual(0, relError, 0);
        }
    }

}