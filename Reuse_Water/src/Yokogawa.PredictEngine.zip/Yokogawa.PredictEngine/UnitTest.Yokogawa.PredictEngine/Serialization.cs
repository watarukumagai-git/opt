﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Yokogawa.PredictEngine;

namespace UnitTest.Yokogawa.PredictEngine
{
    [TestClass]
    public class Serialization
    {
        const double atol = 1e-8;
        const string xml_decl = "<?xml version=\"1.0\" encoding=\"utf-16\"?>";
        const string wellformed = @"
<MLRModel xmlns:i=""http://www.w3.org/2001/XMLSchema-instance"" xmlns=""http://schemas.datacontract.org/2004/07/Yokogawa.PredictEngine"">
    <coef xmlns:d2p1=""http://schemas.microsoft.com/2003/10/Serialization/Arrays"">
        <d2p1:double>0</d2p1:double>
        <d2p1:double>1.1</d2p1:double>
    </coef>
    <modPara xmlns:d2p1=""http://schemas.microsoft.com/2003/10/Serialization/Arrays"">
        <d2p1:double>0</d2p1:double>
        <d2p1:double>123</d2p1:double>
    </modPara>
</MLRModel>";
        readonly XNamespace ns;

        public Serialization() {
            ns = "http://schemas.datacontract.org/2004/07/Yokogawa.PredictEngine";
        }

        [TestMethod]
        public void MlrRoundtrip()
        {
            var x1 = new double[][] {
                new double[] { 0 },
                new double[] { 1 },
                new double[] { 2 },
            };
            var y1 = new double[] { 1, 1.5, 2 };
            int ret;

            var m1 = new MLRModel(new MLRHyperParameter(new double[] { 0, 123 }));
            ret = m1.Fit(x1, y1);
            Assert.AreEqual(0, ret);
            string serialized;
            ret = m1.Serialize(out serialized);
            Assert.AreEqual(0, ret);
            var m2 = new MLRModel(new MLRHyperParameter(new double[] { }));
            ret = m2.Deserialize(serialized);
            Assert.AreEqual(0, ret);

            var priv1 = new PrivateObject(m1);
            var priv2 = new PrivateObject(m2);
            CollectionAssert.AreEqual(
                (double[])priv1.GetField("modPara"),
                (double[])priv2.GetField("modPara"));
            CollectionAssert.AreEqual(
                (double[])priv1.GetField("coef"),
                (double[])priv2.GetField("coef"));

            var x2 = new double[][] {
                new double[] { 5 },
                new double[] { 6 },
                new double[] { 7 },
            };
            var y2 = new double[] { 3.5, 4, 4.5 };
            double[] result;
            ret = m2.Predict(x2, out result);
            Assert.AreEqual(0, ret);
            Assert.IsTrue(result.Zip(y2, (x, y) => Math.Abs(x - y) < atol).All(x => x));
        }

        [TestMethod]
        public void MlrWellformed()
        {
            var serialized = xml_decl + wellformed;
            var m = new MLRModel(new MLRHyperParameter(new double[] { }));
            int ret = m.Deserialize(serialized);
            Assert.AreEqual(0, ret);

            var p = new PrivateObject(m);
            CollectionAssert.AreEqual((double[])p.GetField("coef"), new double[] { 0, 1.1 });
            CollectionAssert.AreEqual((double[])p.GetField("modPara"), new double[] { 0, 123 });
        }

        [TestMethod]
        public void MlrMissingField()
        {
            var xml = XElement.Parse(wellformed);
            xml.Element(ns + "coef").Remove();
            var serialized = xml_decl + xml.ToString(SaveOptions.DisableFormatting);
            var m = new MLRModel(new MLRHyperParameter(new double[] { }));
            int ret = m.Deserialize(serialized);
            Assert.AreNotEqual(0, ret);
        }

        [TestMethod]
        public void MlrBadClass()
        {
            var xml = XElement.Parse(wellformed);
            xml.Name = ns + "NotMLRModel";
            var serialized = xml_decl + xml.ToString(SaveOptions.DisableFormatting);
            var m = new MLRModel(new MLRHyperParameter(new double[] { }));
            int ret = m.Deserialize(serialized);
            Assert.AreNotEqual(0, ret);
        }

        [TestMethod]
        public void PlsRoundtrip()
        {
            var x1 = new double[][] {
                new double[] { 6.9, 3.9 },
                new double[] { 6.7, 1.9 },
                new double[] { 1.1, 3.6 },
            };
            var y1 = new double[] { 1.4, 1.1, 8.3 };
            int ret;

            var m1 = new PLSModel(new PLSHyperParameter(new double[] { 0, 123 }, 1));
            ret = m1.Fit(x1, y1);
            Assert.AreEqual(0, ret);
            string serialized;
            ret = m1.Serialize(out serialized);
            Assert.AreEqual(0, ret);
            var m2 = new PLSModel(new PLSHyperParameter(new double[] { }, 2));
            ret = m2.Deserialize(serialized);
            Assert.AreEqual(0, ret);

            var priv1 = new PrivateObject(m1);
            var priv2 = new PrivateObject(m2);
            Assert.AreEqual(
                (int)priv1.GetField("numLV"),
                (int)priv2.GetField("numLV"));
            CollectionAssert.AreEqual(
                (double[])priv1.GetField("modPara"),
                (double[])priv2.GetField("modPara"));
            CollectionAssert.AreEqual(
                (double[])priv1.GetField("coef"),
                (double[])priv2.GetField("coef"));

            var x2 = new double[][] {
                new double[] { 1.1, 2.2 },
                new double[] { 1.8, 1.5 },
                new double[] { 4.8, 8.0 },
            };
            var y2 = new double[] { 6.21499349, 4.65087829, 9.74074235 };
            double[] result;
            ret = m2.Predict(x2, out result);
            Assert.AreEqual(0, ret);
            Assert.IsTrue(result.Zip(y2, (x, y) => Math.Abs(x - y) < atol).All(x => x));
        }

        [TestMethod]
        public void RFRoundtrip()
        {
            var x1 = new double[][] {
                new double[] { 6.9, 3.9 },
                new double[] { 6.7, 1.9 },
                new double[] { 1.1, 3.6 },
            };
            var y1 = new double[] { 1.4, 1.1, 8.3 };
            int ret;

            var m1 = new RFModel(new RFHyperParameter(new double[] { 0, 123 }, 100, null, 2));
            ret = m1.Fit(x1, y1);
            Assert.AreEqual(0, ret);
            string serialized;
            ret = m1.Serialize(out serialized);
            Assert.AreEqual(0, ret);
            var m2 = new RFModel(new RFHyperParameter(new double[] { }, 0, 0, 0));
            ret = m2.Deserialize(serialized);
            Assert.AreEqual(0, ret);

            var priv1 = new PrivateObject(m1);
            var priv2 = new PrivateObject(m2);
            Assert.AreEqual((int)priv1.GetField("numTree"), (int)priv2.GetField("numTree"));
            Assert.AreEqual((int)priv1.GetField("numMinSplit"), (int)priv2.GetField("numMinSplit"));
            Assert.AreEqual((int?)priv1.GetField("numMaxDepth"), (int?)priv2.GetField("numMaxDepth"));
            var forest1 = (List<List<RFModel.Node>>)priv1.GetField("forest");
            var forest2 = (List<List<RFModel.Node>>)priv2.GetField("forest");
            Assert.AreEqual(forest1.Count, forest2.Count);
            for (int fi = 0; fi < forest1.Count; fi++)
            {
                var tree1 = forest1[fi];
                var tree2 = forest2[fi];
                Assert.AreEqual(tree1.Count, tree2.Count);
                for (int ti = 0; ti < tree1.Count; ti++)
                {
                    // DataContractSerializerは浮動小数点数がroundtropで復元されるので、AreEqualでよい。
                    Assert.AreEqual(tree1[ti].SplitVal, tree2[ti].SplitVal);
                    Assert.AreEqual(tree1[ti].SplitCol, tree2[ti].SplitCol);
                    // シリアライズ容量削減のため、leafのみpredictedが保存されている。
                    if (tree1[ti].leftNode == 0 || tree1[ti].rightNode == 0)
                        Assert.AreEqual(tree1[ti].predicted, tree2[ti].predicted);
                    Assert.AreEqual(tree1[ti].leftNode, tree2[ti].leftNode);
                    Assert.AreEqual(tree1[ti].rightNode, tree2[ti].rightNode);
                }
            }
            CollectionAssert.AreEqual(
                (double[])priv1.GetField("modPara"),
                (double[])priv2.GetField("modPara"));

            var x2 = new double[][] {
                new double[] { 1.1, 2.2 },
                new double[] { 1.8, 1.5 },
                new double[] { 4.8, 8.0 },
            };
            double[] result1, result2;
            ret = m1.Predict(x2, out result1);
            Assert.AreEqual(0, ret);
            ret = m2.Predict(x2, out result2);
            Assert.AreEqual(0, ret);
            Assert.IsTrue(result1.Zip(result2, (x, y) => Math.Abs(x - y) < atol).All(x => x));
        }
    }
}
