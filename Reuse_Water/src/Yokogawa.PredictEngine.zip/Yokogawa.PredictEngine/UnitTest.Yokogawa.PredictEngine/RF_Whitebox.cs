﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Yokogawa.PredictEngine;

namespace UnitTest.Yokogawa.PredictEngine
{
    [TestClass]
    public class RF_Whitebox
    {
        [TestMethod]
        public void Random4Trace()
        {
            var sw = new System.Diagnostics.Stopwatch();
            int numTree = 100;
            Nullable<int> numMaxDepth = null;
            int numMinSplit = 2;
            double[] modPara = new double[] { 1, 3 };

            int dim = 2;
            int size = 10000;
            int pre_size = size;

            sw.Restart();
            Random rng = new Random();
            double[][] xtra = new double[size][];
            double[] ytra = new double[size];
            for (int i = 0; i < size; i++)
            {
                var x = new double[dim];
                for (int j = 0; j < dim; j++)
                    x[j] = rng.NextDouble() * 2 + 0.5;
                double y = rng.NextDouble() * 0.01;
                for (int j = 0; j < dim; j++)
                    y += Math.Pow(x[j], 1 + 0.1 * j);
                xtra[i] = x;
                ytra[i] = y;
            }
            double[][] xpre = new double[pre_size][];
            double[] yans = new double[pre_size];
            for (int i = 0; i < pre_size; i++)
            {
                var x = new double[dim];
                for (int j = 0; j < dim; j++)
                    x[j] = rng.NextDouble() + 1;
                double y = 0;
                for (int j = 0; j < dim; j++)
                    y += Math.Pow(x[j], 1 + 0.1 * j);
                xpre[i] = x;
                yans[i] = y;
            }

            IHyperParameter hp = new RFHyperParameter(modPara, numTree, numMaxDepth, numMinSplit);
            IModel m = ModelFactory.CreateModel(hp);
            sw.Stop();
            System.Diagnostics.Trace.WriteLine($"Prepare {sw.Elapsed}");

            sw.Restart();
            m.Fit(xtra, ytra);
            sw.Stop();
            System.Diagnostics.Trace.WriteLine($"Fit {sw.Elapsed}");
            var forest = (List<List<RFModel.Node>>)new PrivateObject(m).GetField("forest");
            System.Diagnostics.Trace.WriteLine($"Total nodes {forest.Select(tree => tree.Count).Sum():N0}");

            sw.Restart();
            m.Serialize(out string serialized);
            sw.Stop();
            System.Diagnostics.Trace.WriteLine($"Serialize {sw.Elapsed}");
            System.Diagnostics.Trace.WriteLine($"Serialized size {serialized.Length:N0}");
            System.Diagnostics.Trace.WriteLine($"Bytes/node {(double)serialized.Length / forest.Select(tree => tree.Count).Sum():F2}");
            sw.Restart();
            m.Deserialize(serialized);
            sw.Stop();
            System.Diagnostics.Trace.WriteLine($"Deserialize {sw.Elapsed}");

            sw.Restart();
            m.Predict(xpre, out double[] ypre);
            sw.Stop();
            System.Diagnostics.Trace.WriteLine($"Predict {sw.Elapsed}");
            var err = yans.Zip(ypre, (a, b) => a - b).ToList();
            var rmse = Math.Sqrt(err.Select(e => e * e).Average());
            System.Diagnostics.Trace.WriteLine($"RMSE {rmse}");
            // dim == 2だとだいたい満たせる。
            Assert.IsTrue(rmse < 0.02);
        }

        // 学習時に境界値がrightノードに分配されているか、
        // また同様に、予測時に境界値はrightノードをたどっているかを確認する。
        [TestMethod]
        public void SplitBoundary()
        {
            int numTree = 100;
            Nullable<int> numMaxDepth = null;
            int numMinSplit = 2;
            double[] modPara = new double[] { 1, 3 };

            double[][] xtra = new double[][] {
                new double[] { 0, 0 },
                new double[] { 1, 0 },
                new double[] { 2, 0 },
            };
            double[] ytra = new double[] { 0, 1, 2 };
            double[][] xpre = new double[][] {
                new double[] { 0, 0 },
                new double[] { 0.9999999999999999, 0 },
                new double[] { 1, 0 },
                new double[] { 1.9999999999999998, 0 },
                new double[] { 2, 0 },
            };
            double[] yans = new double[] { 0, 0, 1, 1, 2 };
            // 失敗の可能性を 1/2^128 = 1e-39 以下くらいにしたい。
            // 3n 個のサンプルから復元抽出で 3n 個を選択する組み合わせ = (3n)^3n 通り
            // {0, 1, 2} が1つも入らない組み合わせ = ({0, 1} のみ or {1, 2} のみ or {2, 0} のみ)
            //                                       - ({0} のみ or {1} のみ or {2} のみ)
            //                                     = 3 (2n)^3n - 3 n^3n
            // 失敗の確率 = 3 {(2/3)^3n - (1/3)^3n}
            // 解くと、n > 74 くらい。木が 100 本でも n > 76 くらいで十分。
            xtra = Enumerable.Range(0, 76).SelectMany(_ => xtra).ToArray();
            ytra = Enumerable.Range(0, 76).SelectMany(_ => ytra).ToArray();

            IHyperParameter hp = new RFHyperParameter(modPara, numTree, numMaxDepth, numMinSplit);
            IModel m = ModelFactory.CreateModel(hp);
            m.Fit(xtra, ytra);
            m.Predict(xpre, out double[] ypre);

            Assert.AreEqual(ypre[0], ypre[1]);
            Assert.AreEqual(ypre[2], ypre[3]);
            // これらは確率的に失敗するが、上で計算した通り十分に確率が低い。
            Assert.AreNotEqual(ypre[1], ypre[2]);
            CollectionAssert.AreEqual(yans, ypre);

            // シリアライズを経由した場合でも同じ結果になるか確認。
            m.Serialize(out string serialized);
            m = ModelFactory.CreateModel(hp);
            m.Deserialize(serialized);
            m.Predict(xpre, out double[] ypre2);
            CollectionAssert.AreEqual(ypre, ypre2);
        }

        // split値を決めて分割する素直な実装とは異なり、
        // 現在の実装はソートしたxに対してsplitするrowを決めている。
        // この実装ではxが同じ値のものをsplitしてしまうバグが混入しうるのでテストする。
        [TestMethod]
        public void Unsplittable()
        {
            int numTree = 1000;
            Nullable<int> numMaxDepth = null;
            int numMinSplit = 2;
            double[] modPara = new double[] { 1, 3 };

            double[][] xtra = new double[][] {
                new double[] { 0, 0 },
                new double[] { 0, 0 },
                new double[] { 0, 0 },
                new double[] { 0, 0 },
                new double[] { 0, 1 },
                new double[] { 0, 1 },
                new double[] { 0, 1 },
                new double[] { 0, 1 },
            };
            double[] ytra = new double[] { 0, 1, 2, 3, 0, -1, -2, -3 };
            double[][] xpre = new double[][] {
                new double[] { 0, 0 },
                new double[] { 0, 1 },
            };
            double[] yans = new double[] { 1.5, -1.5 };
            xtra = Enumerable.Range(0, 10).SelectMany(_ => xtra).ToArray();
            ytra = Enumerable.Range(0, 10).SelectMany(_ => ytra).ToArray();

            IHyperParameter hp = new RFHyperParameter(modPara, numTree, numMaxDepth, numMinSplit);
            IModel m = ModelFactory.CreateModel(hp);
            m.Fit(xtra, ytra);
            m.Predict(xpre, out double[] ypre);

            // サンプルサイズが大きくても、xtraに多様性がないので3ノードまでで分割が止まる。
            var forest = (List<List<RFModel.Node>>)new PrivateObject(m).GetField("forest");
            foreach (var tree in forest)
                Assert.IsTrue(tree.Count <= 3);
            // 確率的に失敗しうるが、ちゃんと確率を計算していない。
            Assert.IsTrue(Math.Abs(ypre[0] - yans[0]) < 0.05);
            Assert.IsTrue(Math.Abs(ypre[1] - yans[1]) < 0.05);
        }
    }
}
