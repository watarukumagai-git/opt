#coding: utf-8
import numpy as np
import pandas as pd
from .model.import_model import Model_class


class Function:
    """
    Objective and constraint functions.

    Attributes
    ----------
    Model : constructor
        model constructor using 'Model_class' at model_path
    """

    def __init__(self, load_pro, alg_type, cost, eval_type, model_path):
        """
        initialization.

        Parameters
        ----------
        model_path : string 
            directory path including model class file 
        """
        self.load_pro = load_pro
        self.N = load_pro.N
        self.eval_type = eval_type
        self.alg_type = alg_type
        self.g_num = 0
        self.cost = cost
        self.Model = Model_class(model_path)

        self.id_alldict = self.load_pro.alltagdict
        self.id_dict = self.load_pro.tagdict
        self.id_allnumdict = self.id_alldict['Num']
        self.id_numdict = self.id_dict['Num']
        self.id_alltagid = list(self.id_alldict['Description'].keys())
        self.id_allseedmode = list(self.id_alldict['SeedMode'].values())
        self.id_allnum = self.get_dict_vallist(self.id_allnumdict, self.id_alltagid)
        self.id_num = self.get_dict_vallist(self.id_numdict, self.load_pro.opt_taglist)
        self.init_big_x_2D = self.get_init_big_x_2D()

        self.modeldict = self.load_pro.modeldict

    def get_dict_vallist(self, d_, l_):
        return [d_[d] for d in l_]

    def get_init_big_x_2D(self):
        x_2D = np.zeros((len(self.id_alltagid), self.load_pro.delta_t))
        j = 0
        h = 0
        for clm, tagid in enumerate(self.id_alltagid):
            if self.id_allseedmode[clm] == '1':
                x_2D[clm, :] = self.load_pro.pattern_fixed[j, :].copy()
                j = j + 1
            elif self.id_allseedmode[clm] == '2':
                x_2D[clm, :] = self.load_pro.pattern_inter[h, :].copy()
                h = h + 1
        return x_2D

    def get_big_x_2D(self, x_2D):
        def _get_prediction(big_x_2D):
            y_list_pre = self.modeldict.keys()
            x_pre_2D = np.zeros((len(y_list_pre), self.load_pro.delta_t))
            for idx, yname in enumerate(y_list_pre):
                x_pre_2D[idx, :] = self.prediction(self.id_allnumdict, big_x_2D, self.modeldict[yname], yname)
                num = self.id_allnumdict[yname]
                big_x_2D[num, :] = x_pre_2D[idx, :].copy()
            return big_x_2D

        # initial copy
        big_x_2D = self.init_big_x_2D.copy()
        # seedmode = 0 clm is modified to variable
        for clm, idnum in enumerate(self.id_num):
            big_x_2D[idnum, :] = x_2D[clm, :].copy()

        # ID1000, ID1001, ID1002 (fouling) prediction
        #l = [S1_Feed_Pre, S3_Conc_Pre, S1_Perm_Flow, S2_Perm_Flow, S3_Perm_Flow, S3_Conc_Flow, UF_Filtrate_Total_Chlorine]
        # execute prediction and update to prediction
        big_x_2D = _get_prediction(big_x_2D)            
        return big_x_2D

    def prediction(self, id_dict, x_2D, x_l, y_l):
        """
        prediction using x_l and y_l variables.

        Parameters
        ----------
        id_dict : dictionary {id_num: tag_id} 
        x_2D : double (num_feat, Time)
            solution
        x_l : list of string (num_feat,)
            explanatory variable name (tag_id)
        y_l : string
            objective variable name (tag_id)

        Returns
        -------
        y : double (Time,)
            prediction value
        """
        
        # from tagID to index in x_2D (matrix)
        idx = self.get_dict_vallist(id_dict, x_l)
        x_input = x_2D[idx, :]
        if y_l == 'ID1000': # S1_perm_EC
            model = self.Model.S1_perm_EC_model
        elif y_l == 'ID2000': # S2_feed_EC
            model = self.Model.S2_feed_EC_model
        elif y_l == 'ID2001': # S2_perm_EC
            model = self.Model.S2_perm_EC_model
        elif y_l == 'ID3000': # S3_feed_EC
            model = self.Model.S3_feed_EC_model
        elif y_l == 'ID3001': # S3_perm_EC
            model = self.Model.S3_perm_EC_model
        elif y_l == 'ID4000': # perm_TOC
            model = self.Model.perm_TOC_model
        y = model.predict(x_input)
        #elif y_l == 'ID1002': # RO fouling
        #    # timestep 1 is initial fouling value because all initial values are fixed. 
        #    y = np.zeros(self.load_pro.delta_t)
        #    model = self.Model.FOULING
        #    y[1:] = model.predict(x_input[:, 1:])
        return y

    def convert_x_to_schedule(self, x_):
        # x: (N, 1)
        # schedule: (num_feat_total, delta_t)
        if np.any(self.load_pro.seedflag!=0):
            schedule = np.where(self.load_pro.seedflag, self.load_pro.pattern, -999)
            schedule[schedule == -999] = x_
        else:
            schedule = x_.copy()
        schedule = schedule.reshape(self.load_pro.num_feat_total, self.load_pro.delta_t)
        return schedule

    def convert_schedule_to_x(self, schedule):
        # schedule: (num_feat_total, delta_t)
        # x: (N, 1)
        x_ = schedule.reshape(self.N)
        if np.any(self.load_pro.seedflag!=0):
            x_ = np.delete(x_, np.where(self.load_pro.seedflag!=0))
        return x_

    def basis_func(self, func_type, x, c):
        # x: (N,)
        # c: (N,) or (N+1,)
        # func_type 1: linear
        if func_type == 1:
            if x.ndim >= 1:
                if len(c) == len(x):
                    f =  np.sum(c*x)
                else:
                    f =  np.sum(c[:-1]*x) + c[-1]
            else:
                f = c*x
        return f

    def object_function(self, x__):
        def _penalty(x_2D, pcoef):
            pattern_2D = self.load_pro.pattern.reshape(self.load_pro.num_feat_total, self.load_pro.delta_t)
            target = np.where(np.arange(self.load_pro.delta_t) <= self.load_pro.deadtime[0]+1, pattern_2D[0, :], self.demand[0, :])
            #target = np.array([pattern_2D[0, t] if t <= self.load_pro.deadtime[0]+1 else self.demand[0, t] for t in range(0, self.load_pro.delta_t) ])
            pepsilon = [0.01]
            g = self.get_vio_demand(x_2D[0,:], np.ones(self.load_pro.delta_t), pepsilon, target)
            g = np.where(g<0, 0, g)
            return pcoef * g.sum()

        # input
        # x__: (N_, )
        # output
        # f: float
        c = self.cost.reshape(self.load_pro.bigN)
        x_2D = self.convert_x_to_schedule(x__)
        f1 = self.basis_func(1, x_2D.reshape(self.load_pro.bigN), c)

        # ID100 penalty for target
        pcoef = pow(10, -1)
        #f2 = _penalty(x_2D, pcoef)
        #f = f1 + f2
        f = f1
        return f

    def get_oneside_vio(self, g_equal, lower, upper):
        return np.where((lower + upper)/2>=g_equal, lower - g_equal, g_equal - upper)

    def relax_const(self, x, coef, lower, upper):
        """
        relax for constarint functions.

        Parameters
        ----------
        eval_const : object
            constraint function
        x : double (num_feat, Time)
            solution
        coef : double (num_feat+1,)
            coefficient and bias for x
        lower : double (Time,)
            lower for x
        upper : double (Time,)
            upper for x

        Returns
        -------
        g_inequal : double (Time,)
            inequality constarints relaxed by lower/upper
        """
        # g_equal: (Time,)
        if x.ndim > 1:
            if len(coef) == x.shape[0]:
                g_equal = np.dot(coef, x)
            elif len(coef) == x.shape[0]+1:
                g_equal = np.dot(coef[:-1], x) + coef[-1]
        else:
            if len(coef) == len(x):
                g_equal = coef*x
            elif len(coef) == len(x) + 1:
                g_equal = coef[:-1]*x + coef[-1]
        g_inequal = self.get_oneside_vio(g_equal, lower, upper)
        return g_inequal

    def get_vio_minmax(self, x__, min__, max__):
        # x__ : (N,)
        # min__ : (N,) self.load_pro.x_ul[:,0]
        # max__ : (N,) self.load_pro.x_ul[:,1]
        return self.get_oneside_vio(x__, min__, max__)

    def get_vio_fac(self, x_2D, coef, epsilon):
        # x_2D: (num_feat, Time)
        # coef: (num_feat+1,)
        lower = -epsilon*np.ones(x_2D.shape[1])
        upper = epsilon*np.ones(x_2D.shape[1])
        # g_inequal : (Time,)
        g_inequal = self.relax_const(x_2D, coef, lower, upper)
        return g_inequal

    def get_vio_demand(self, x_2D, coef, epsilon, demand):
        # x_2D: (num_feat, Time)
        # coef: (num_feat,)
        # demand: (Time,)
        lower = demand - epsilon[0]
        upper = demand + epsilon[0]
        #lower = np.array([demand[t] - epsilon[0] for t in range(0,self.load_pro.delta_t)])
        #upper = np.array([demand[t] + epsilon[0] for t in range(0,self.load_pro.delta_t)])
        # g_inequal : (Time,)
        g_inequal = self.relax_const(x_2D, coef, lower, upper)
        return g_inequal

    def get_vio_diff(self, x_diff, diff_minmax):
        # x_diff: (Time-1,)
        # diff_minmax: [diff_min, diff_max]
        lower = diff_minmax[0]*np.ones(len(x_diff))
        upper = diff_minmax[1]*np.ones(len(x_diff))
        # g_inequal : (Time-1,)
        g_inequal = self.get_oneside_vio(x_diff, lower, upper)
        return g_inequal

    def constraint_function(self, x__):
        def _flatten_list(l):
            for el in l:
                if isinstance(el, list):
                    yield from _flatten_list(el)
                else:
                    yield el        

        def _get_const_diff(x_2D):
            for (j, id) in enumerate(self.load_pro.diff_dict.keys()):
                idx = self.id_allnumdict[id]
                x_diff = np.diff(x_2D[idx, :], n=1)
                epsilon_diff = list(self.load_pro.diff_dict[id].values())
                unit_diff = self.get_vio_diff(x_diff, epsilon_diff)
                if j == 0:
                    g_diff = unit_diff
                else:
                    g_diff = np.concatenate([g_diff, unit_diff])
            return g_diff
        
        
        def _get_minmax_inter(id_dict, x_2D, y_list_pre):
            idx = self.get_dict_vallist(id_dict, y_list_pre)
            x__ = x_2D[idx, :].reshape(-1)
            gminmax = self.get_vio_minmax(x__, self.load_pro.x_ul_inter[:,0], self.load_pro.x_ul_inter[:,1])
            return gminmax
        
        def _get_violation_limit_inter(x_2D):
            def _mod_lower(data, eps):
                if np.any(data <= eps):
                    data = np.where(data <= eps, eps, data)
                return data
            def _get_limit_inter(input, output, lower, upper):
                input = _mod_lower(input, 0.0001)
                output = _mod_lower(output, 0.0001)
                g_equal_rate = np.log10(input / output)
                return self.get_oneside_vio(g_equal_rate, lower, upper)
            g_rate =[]
            lower = [1.0, 1.0, 1.0, 1.0]
            upper = [2.5, 2.5, 2.5, 2.0]
            feed = ['ID0001', 'ID0001', 'ID0001', 'ID0002']
            perm = ['ID1000', 'ID2001', 'ID3001', 'ID4000']
            for idx, feed_ in enumerate(feed):
                g_rate.append(_get_limit_inter(x_2D[self.id_allnumdict[feed_], :], x_2D[self.id_allnumdict[perm[idx]], :], lower[idx], upper[idx]))
            g_rate = np.concatenate(g_rate).reshape(-1)
            return g_rate

        def _get_violation_order_inter(x_2D):
            g_order =[]
            feed = ['ID0002', 'ID0002', 'ID0002', 'ID0003']
            perm = ['ID1000', 'ID2001', 'ID3001', 'ID4000']
            for idx, feed_ in enumerate(feed):
                g_order.append(x_2D[self.id_allnumdict[feed_], :] - x_2D[self.id_allnumdict[perm[idx]], :])
            g_order = np.concatenate(g_order).reshape(-1)
            return g_order


        # (num_feat_total, delta_t)
        x_2D = self.convert_x_to_schedule(x__)
        big_x_2D = self.get_big_x_2D(x_2D)

        # min-max_violation for prediction
        g_minmax = _get_minmax_inter(self.id_allnumdict, big_x_2D, self.modeldict.keys())

        # prediction rate
        g_rate = _get_violation_limit_inter(big_x_2D)

        # order rate
        g_order = _get_violation_order_inter(big_x_2D)

        # diff_violation
        g_diff = _get_const_diff(big_x_2D)

        g = np.ravel(np.concatenate([g_minmax, g_rate, g_order, g_diff]))
        return g