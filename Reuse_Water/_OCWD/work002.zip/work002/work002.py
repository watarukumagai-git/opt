# -*- coding: utf-8 -*-
import time
import os
from os import path

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt


if 'My Drive' in os.getcwd():
    separator = '/'
    work_path = os.getcwd()
else:
    separator = '\\'
    work_path = path.dirname( path.abspath(__file__) )
    os.chdir(work_path)


def make_setfile(dir_base, str_list, num_list):
    f = open(dir_base + separator + 'set_file.txt', 'w')
    for i in range(0,len(str_list)):
        f.write(str_list[i] + ' = ' + str(num_list[i]) + '\n')
    f.close()

    
def get_path():
    dir_base = work_path + separator + 'output'
    my_makedirs(dir_base)
    my_makedirs(dir_base + separator + 'file')
    my_makedirs(dir_base + separator + 'fig')
    return dir_base


def get_parameter():
    dir_base = work_path + separator + 'input'
    df1 = pd.read_csv(dir_base + separator + 'master_2021_2022_30min_edit_ver2.csv', header=0)
    return df1

    
def my_makedirs(path):
    if not os.path.isdir(path):
        os.makedirs(path)


def split_data(df, x_list, y_list, tra_period, test_period):
    def _list_check(list1, list2):
        return set(list1).issubset(list2)

    def _select_idx_dataframe(df, clm, txt):
        if _list_check(clm, np.arange(len(df.columns.tolist())).tolist()):
            df = pd.concat([df.iloc[:, 0], df.iloc[:, clm]], axis=1)
        else:
            df = 0
            print('input data does not contain ' + txt + '.')
        return df

    def _select_clm_dataframe(df, period, txt):
        if _list_check(period, df.index.tolist()):
            df_ = df.loc[period[0]:period[1], :]
        else:
            df_ = 0
            print('input data does not contain ' + txt + '.')
        return df_
    
    #def my_index_multi(l, x):
    #return [i for i, _x in enumerate(l) if _x == x]

    #x_num = []
    #for x in x_list:
    #    x_num.append(my_index_multi(df.columns.tolist(), x))

    # x_select
    #x_list = list(map(lambda x: x+1, x_list))
    df = _select_idx_dataframe(df, x_list, 'x_list')
    print('y = ', df.columns[y_list])
    print('x = ', df.columns[1:].tolist())

    # split
    print('training period: ', tra_period)
    print('predict period: ', test_period)
    df_tra = _select_clm_dataframe(df, tra_period, 'training period')
    df_test = _select_clm_dataframe(df, test_period, 'predict period')
    print('traning data')
    print(df_tra.shape)
    print(df_tra.head())
    print('validation data')
    print(df_test.shape)
    print(df_test.head())
    return df_tra, df_test

def fit_predict(df_tra, df_val, modeling_mode, modeling_list):
    X_tra = df_tra.values[:, 1:]
    y_tra = df_tra.values[:, 0]
    X_val = df_val.values[:, 1:]
    y_val = df_val.values[:, 0]

    if modeling_mode == 'MLR':
        model = LinearRegression()
    elif modeling_mode == 'MLR':
        model = RandomForestRegressor(n_jobs=-1, random_state=2525)
    model.fit(X_tra, y_tra)
    y_pre = model.predict(X_val)

    y_array = np.vstack([y_pre, y_val]).T
    df_y_pre = pd.DataFrame(y_array, 
                            index = df_val.index, 
                            columns=[df_val.columns[0]+'_pre', df_val.columns[0]+'_act'])
    print(df_y_pre.describe())
    print(df_y_pre.head())
    return df_y_pre


def draw_trend_chart(df, fig_file_name):
    fig = plt.figure(figsize=(6,4))
    fig.patch.set_facecolor('white')
    ax = fig.add_subplot(1,1,1)
    x = pd.to_datetime(df.index)
    print('from ', x[0])
    print('to ', x[-1])
    
    ax.plot(x, df.iloc[:, 0], "C1", label=df.columns[0], lw=0.5)
    ax.plot(x, df.iloc[:, 1], "C0", label=df.columns[1], lw=0.5)
    ax.set_xlabel('timestamp', fontsize=10)
    ax.set_ylabel('y predict/actual', fontsize=10)
    ax.legend(loc='center', bbox_to_anchor=(0.5, 1.1), ncol=2)
    ax.tick_params(direction = "in")

    labelss = ax.get_xticklabels()
    plt.setp(labelss, rotation=60)
    plt.tick_params(labelsize=8)
    plt.tight_layout()
    plt.savefig(fig_file_name, bbox_inches="tight")

        
def main():
    # time start
    start_time = time.time()
    print ("calculation started.")
    print('-----------------------------------')

    # x list (column number)
    #x_list = [0,2,4,5]
    x_list = ["RO_B01 FW Press","RO_Feed Cond","RO_01_FirstStageFeedFlow","RO_Feed Temperature","RO_Feed Ph", "Sulfric Acid Usage","Threshold Inhibitor Usage"]
    y_list = 'RO_B01 Blank 1 Perm Cond'

    # training period
    tra_period = ['2022-04-01 00:00:00','2022-05-19 23:30:00']

    # predict period
    pre_period = ['2022-05-20 00:00:00','2022-05-26 23:30:00']

    # get path
    dir_base = get_path()
    # instance
    df = get_parameter()

    # split train and test
    df_tra, df_val = split_data(df, x_list, y_list, tra_period, pre_period)

    # model
    modeling_mode = 'RF'
    df_y_pre = fit_predict(df_tra, df_val, modeling_mode)

    df_y_pre.to_csv(dir_base + separator + "\\output\\file\\predict.csv")
    draw_trend_chart(df_y_pre, dir_base + "\\output\\fig\\predict.png")
        
    print ("figure saving finished.")

    # time finish
    end_time = time.time()
    cal_time = end_time - start_time
    print('time = %f sec = %f min' % (cal_time, cal_time/60))

    
if __name__ == "__main__":
    main()
