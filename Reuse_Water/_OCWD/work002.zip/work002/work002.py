# -*- coding: utf-8 -*-
import time
import math

import numpy as np
import pandas as pd

from pkg.helper import helper_class
from pkg.figure_save import figure_save_class

def index_to_datetime(df, ts_clm):
    df[ts_clm] = pd.to_datetime(df.index)
    df.set_index(ts_clm, inplace=True)
    return df

def split_df_unit(df):
    df_unit = df.loc[['unit', 'description'], :]
    print(df_unit)
    df = df.drop(['unit', 'description'])
    df = df.astype(float)
    return df, df_unit

def processing_df(df, tag_list):
    df = df.loc[:, tag_list]
    df = index_to_datetime(df, 'Date / Time')
    str = '2022-05-01 0:00'
    end = '2022-11-30 23:30'
    #end = df.index[-1]
    df = df[str : end]
    df = df.astype(float)
    # fillna
    print(df.head(2))
    print(df.tail(2))
    return df

def drop_df(df, low_up_dict):
    df_ = df.copy()
    for key, values in low_up_dict.items():
        df_[key] = df_[key].where((df_[key] > values[0])&(df_[key] < values[1]), np.nan)
    return df_

def mean_df(df, timespan, status_id=None):
    df_ = df.copy()
    if timespan == '30min':
        ws=24
        #ws=48
        #ws=96
        resamplespan = timespan
    elif timespan == '1day':
        ws=5
        resamplespan = 'D'
    # status_id => resample_last to 30min => rolling_min
    # nonstatus_id => resample_mean to 30min => rolling_mean
    if status_id != None:
        df_status = df_.loc[:, status_id].resample(resamplespan).last().rolling(window=ws, min_periods=1).min()
        df_nonstatus = df_.drop([status_id], axis=1).resample(resamplespan).mean().rolling(window=ws, min_periods=1).mean()
        df_ = pd.concat([df_nonstatus, df_status], axis=1)
    else:
        df_ = df_.resample(resamplespan).mean().rolling(window=ws, min_periods=1).mean()
    # forward fill => before fill
    df_ = df_.fillna(method='ffill').fillna(method='bfill')
    return df_


def data_addition(data):
    data["RO_01_FirstStageFeedFlow"] = data["RO_B01 Blank 1 Perm Flow"] + data["RO_B01 Blank 2 Perm Flow"] + data["RO_B01 Blank 3 Perm Flow"] + data["RO_B01 Conc Flow"]
    return data

def sorting_df_unit(df_unit, tag_list):
    df_unit = df_unit[tag_list]
    return df_unit

class trend_chart:
    def __init__(self, df, df_unit, low_up_dict):
        self.xmin = df.index[0]
        self.xmax = df.index[-1]
        self.ymin = 0
        self.ymax = 0
        # DatetimeIndex(['2022-11-30 19:00:00',...], dype = 'datetime64[ns])
        self.x = df.index.tolist()
        self.minmax_status = 'minmax'
        self.df_unit = df_unit
        self.low_up_dict = low_up_dict
        self.lang = 'eng'
        # 15-Sep-20 20:30
        # ['%d-%b-%y %H:%M', '%d-%b-%y', '%b-%y']
        self.dateformat = '%d-%b-%y'

    def tag_trend(self, df, fig_name_list):
        for i, tag in enumerate(self.low_up_dict.keys()):
            y = df.loc[:, tag].values
            ylabel = self.df_unit.loc['description', tag] + ' [' + self.df_unit.loc['unit',tag] + ']'
            self.ymin = self.low_up_dict[tag][0]
            self.ymax = self.low_up_dict[tag][1]
            self.minmax_status = 'minmax'
            print(df.index)
            figure_label = ['Date / Time', ylabel, [self.xmin, self.xmax, self.ymin, self.ymax]]
            figure_save_class().draw_trend(fig_name_list[i], figure_label, self.x, y, self.minmax_status, self.lang, self.dateformat)



def main():
    # time start
    start_time = time.time()
    print ("calculation started.")
    print('-----------------------------------')

    # helper constructor
    HELP = helper_class()
    timespan = '30min'

    # x list (column number)
    #x_list = [0,2,4,5]
    low_up_dict = {'RO_B01 Blank 1 Perm Cond': [0, 150],
                   'RO_B01 Blank 2 Perm Cond': [0, 150],
                   'RO_B01 Blank 3 Perm Cond': [0, 150],
                   'RO_B01 FW Press': [0, 200],
                   'RO_Feed TOC': [0, 20], 
                   'RO_Feed Cond': [1000, 2000], 
                   'RO_Permeate TOC': [0, 0.5], 
                   'RO_01_FirstStageFeedFlow': [0, 4500], 
                   'RO_Feed Temperature': [60, 90], 
                   'RO_Feed Ph': [0, 15],
                   'Sulfuric Acid Usage': [0, 15],
                   'Threshold Inhibitor Usage': [0, 1.5],
                   'RO_Feed Total Chlorine': [0, 6]}

    filter_low_up_dict = {'RO_B01 Blank 1 Perm Cond': [0, 25],
                          'RO_B01 Blank 2 Perm Cond': [10, 50],
                          'RO_B01 Blank 3 Perm Cond': [20, 120],
                          'RO_B01 FW Press': [125, 200],
                          'RO_Feed TOC': [0, 20], 
                          'RO_Feed Cond': [1400, 2000], 
                          'RO_Permeate TOC': [0, 0.5], 
                          'RO_01_FirstStageFeedFlow': [3500, 4500], 
                          'RO_Feed Temperature': [75, 90], 
                          'RO_Feed Ph': [0, 15],
                          'Sulfuric Acid Usage': [0, 15],
                          'Threshold Inhibitor Usage': [0, 1.5],
                          'RO_Feed Total Chlorine': [0, 6]}

    tag_list = low_up_dict.keys()
    print(tag_list)

    # get path
    output_dir_base = HELP.get_output_path()
    input_dir_base = HELP.work_path + HELP.separator + 'input'
    df_master = pd.read_csv(input_dir_base + HELP.separator + 'master_2021_2022_30min_edit_ver2.csv', index_col=0, dtype=str)
    df_master["RO_01_FirstStageFeedFlow"] = 0
    df_master.loc["unit", "RO_01_FirstStageFeedFlow"] = "gpm"
    df_master.loc["description", "RO_01_FirstStageFeedFlow"] = "RO_01_FirstStageFeedFlow"


    # select tag and pre-processing


    df_master, df_unit = split_df_unit(df_master)
    df_master = data_addition(df_master)
    df_master = processing_df(df_master, tag_list)
    df_unit = sorting_df_unit(df_unit, tag_list)
    df_proprocessed = drop_df(df_master, filter_low_up_dict)
    df_proprocessed = mean_df(df_proprocessed, timespan)
    print(df_proprocessed)


    # draw trend chart
    idx_list = [i for i in range(0, len(df_master))]
    const = trend_chart(df_master, df_unit, low_up_dict)
    fig_name_list = [output_dir_base + HELP.separator + 'fig' + HELP.separator + df_unit.loc['description', tag] + '_raw.png' for tag in tag_list]
    const.tag_trend(df_master, fig_name_list)

    const = trend_chart(df_proprocessed, df_unit, low_up_dict)
    fig_name_list = [output_dir_base + HELP.separator + 'fig' + HELP.separator + df_unit.loc['description', tag] + '_preprocessed.png' for tag in tag_list]
    const.tag_trend(df_proprocessed, fig_name_list)

    #df_master.rename(columns={tag: df_unit.loc['description', tag] + ' [' + df_unit.loc['unit', tag] + ']' for tag in df_unit.columns}, inplace=True)
    df_proprocessed.to_csv(output_dir_base + HELP.separator + 'file' + HELP.separator + 'master_preprocessed.csv')
    df_proprocessed_edit = pd.concat([df_proprocessed, df_unit], axis=0)
    df_proprocessed_edit.to_csv(output_dir_base + HELP.separator + 'file' + HELP.separator + 'master_preprocessed_edit.csv')


    print ("figure saving finished.")


    # time finish
    end_time = time.time()
    cal_time = end_time - start_time
    print('time = %f sec = %f min' % (cal_time, cal_time/60))

    
if __name__ == "__main__":
    main()
