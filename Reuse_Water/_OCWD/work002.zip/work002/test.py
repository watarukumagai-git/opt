# -*- coding: utf-8 -*-
import pandas as pd

import matplotlib.pyplot as plt
import matplotlib.dates as mdates
plt.rcParams['font.family'] = 'Times New Roman'

class figure_save_class:
    def draw_trend(self, fig_file_name, figure_label, x, y, minmax_status='none', lang='jpn', dateformat = '%d-%b-%y'):
        x_label_name = figure_label[0]
        y_label_name = figure_label[1]
        (x_min, x_max, y_min, y_max) = figure_label[2]

        fig = plt.figure(figsize=(6,4))
        fig.patch.set_facecolor('white')
        ax = fig.add_subplot(1,1,1)
        ax.plot(x, y, 'C0', lw=0.5)
        ax.set_xlabel(x_label_name, fontsize=12)
        ax.set_ylabel(y_label_name, fontsize=12)
        ax.tick_params(labelsize=10)
        ax.set_xlim([x_min, x_max])
        if minmax_status == 'minmax':
            ax.set_ylim([y_min, y_max])
        elif minmax_status == 'max':
            ax.set_ylim(top=y_max)
        elif minmax_status == 'min':
            ax.set_ylim(bottom=y_min)

        if lang == 'eng':
            formatter = mdates.DateFormatter(dateformat)
            ax.xaxis.set_major_formatter(formatter)

        plt.grid(linestyle='dashed', linewidth=0.2)
        plt.xticks(rotation=90)
        plt.tick_params(labelsize=10, direction = "in")
        plt.tight_layout()
        plt.savefig(fig_file_name, bbox_inches="tight")

    
class trend_chart:
    def __init__(self, df):
        self.xmin = df.index[0]
        self.xmax = df.index[-1]
        self.ymin = 0
        self.ymax = 0
        # DatetimeIndex(['2022-11-30 19:00:00',...], dype = 'datetime64[ns])
        self.x = df.index.tolist()
        self.minmax_status = 'minmax'
        self.lang = 'eng'
        # 15-Sep-20 20:30
        # ['%d-%b-%y %H:%M', '%d-%b-%y', '%b-%y']
        self.dateformat = '%d-%b-%y'

    def tag_trend(self, df, fig_name_list):
        for i, tag in enumerate(self.low_up_dict.keys()):
            y = df.loc[:, tag].values
            ylabel = 'description' + ' [unit]'
            self.ymin = 0
            self.ymax = 600
            self.minmax_status = 'minmax'
            figure_label = ['Date / Time', ylabel, [self.xmin, self.xmax, self.ymin, self.ymax]]
            figure_save_class().draw_trend(fig_name_list[i], figure_label, self.x, y, self.minmax_status, self.lang, self.dateformat)


WORK_DIR = ''
fig_name_list = ['.png']
df_master = pd.read_csv(WORK_DIR + 'master_2021_2022_30min_edit_ver2.csv', index_col=0, dtype=str)
const = trend_chart(df_master)
const.tag_trend(df_master, fig_name_list)
