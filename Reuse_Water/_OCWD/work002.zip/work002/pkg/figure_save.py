# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
plt.rcParams['font.family'] = 'Times New Roman'

class figure_save_class:
    def draw_trend(self, fig_file_name, figure_label, x, y, minmax_status='none', lang='jpn', dateformat = '%d-%b-%y'):
        x_label_name = figure_label[0]
        y_label_name = figure_label[1]
        (x_min, x_max, y_min, y_max) = figure_label[2]

        fig = plt.figure(figsize=(6,4))
        fig.patch.set_facecolor('white')
        ax = fig.add_subplot(1,1,1)
        ax.plot(x, y, 'C0', lw=0.5)
        ax.set_xlabel(x_label_name, fontsize=12)
        ax.set_ylabel(y_label_name, fontsize=12)
        ax.tick_params(labelsize=10)
        ax.set_xlim([x_min, x_max])
        if minmax_status == 'minmax':
            ax.set_ylim([y_min, y_max])
        elif minmax_status == 'max':
            ax.set_ylim(top=y_max)
        elif minmax_status == 'min':
            ax.set_ylim(bottom=y_min)

        if lang == 'eng':
            formatter = mdates.DateFormatter(dateformat)
            ax.xaxis.set_major_formatter(formatter)

        plt.grid(linestyle='dashed', linewidth=0.2)
        plt.xticks(rotation=90)
        plt.tick_params(labelsize=10, direction = "in")
        plt.tight_layout()
        plt.savefig(fig_file_name, bbox_inches="tight")