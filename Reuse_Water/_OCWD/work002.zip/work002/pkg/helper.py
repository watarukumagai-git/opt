# -*- coding: utf-8 -*-
import os
from os import path
import glob

class helper_class:
    def __init__(self):
        if 'My Drive' in os.getcwd():
            self.separator = '/'
            self.work_path = os.getcwd()
        else:
            self.separator = '\\'
            self.work_path = path.dirname( path.abspath(__file__+self.separator+'..'+self.separator) ) 
            os.chdir(self.work_path)

    def get_output_path(self):
        dir_base = self.work_path + self.separator + 'output'
        self.my_makedirs(dir_base)
        self.my_makedirs(dir_base + self.separator + 'file')
        self.my_makedirs(dir_base + self.separator + 'fig')
        return dir_base

    def my_makedirs(self, path):
        if not os.path.isdir(path):
            os.makedirs(path)

    def get_file_dir_list(self, root_path, list_type):
        if list_type == 'dir':
            dir_list = [f for f in os.listdir(root_path) if os.path.isdir(os.path.join(root_path, f))]
            return dir_list
        elif list_type == 'file':
            file_list = glob.glob(root_path + '*.csv')
            file_name_list = [one_file.rsplit('\\', 1)[1].split('.')[0] for one_file in file_list]
            #dir_path = pathlib.Path(work_path)
            #file_list = dir_path.glob('*.csv')
            return file_list, file_name_list

    def uni_list(self, l1, l2):
        l = list(set(l1) & set(l2))
        return l
    
    def list_check(list1, list2):
        return set(list1).issubset(list2)

    def rename_iaxis(self, dataframe, axis, n, name):
        # axis:0 => index, 1=> column
        if axis == 0:
            org_namelist = list(dataframe.index)
        elif axis == 1:
            org_namelist = list(dataframe.columns)
        
        # rename n-th index/column name to new name
        new_namelist = org_namelist
        new_namelist[n] = name
        dataframe = dataframe.set_axis(new_namelist, axis = axis, inplace = False)
        return dataframe
