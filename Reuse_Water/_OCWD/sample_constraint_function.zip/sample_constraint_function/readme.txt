sample constraint function
- sample全体の構造
    - ある解xを制約関数g(x)に代入し、計算するサンプルコード
    - g(x)の内部で各予測モデルを呼び出している
    - pkg//functionで、"Model.model1.predict"のメソッドを使い、予測値を計算できるようにする
    - input//taglist.csvを読み込み、taglistのdictionaryを作成している

- import_modelの構造
    - モデルクラスは、pkg//function//model//import_modelで作成し、そこで各自必要なモデルファイルを読み込む
    - 各予測モデルを用いた予測は、pkg//function//model//import_model//submodel_xxで記述する
    - 各クラス・関数では、なるべくdocstringを記述し、外部から呼び出したときにコメントを確認できるようにする

- モデリング側の変更
    - モデリング側は、基本的にpkg//function//modelの内部を変更する
    - モデルのinterfaceを変更するときは、pkg//functionの説明変数のリストやtaglist.csvも合わせて変更する必要がある