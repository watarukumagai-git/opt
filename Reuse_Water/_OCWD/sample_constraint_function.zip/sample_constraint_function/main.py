# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
import os
from os import path

from pkg.function.function import Function


if 'My Drive' in os.getcwd():
    separator = '/'
    work_path = os.getcwd()
else:
    separator = '\\'
    work_path = path.dirname( path.abspath(__file__) )
    os.chdir(work_path)


def get_dictionary():
    dir_base = work_path + separator + 'input'
    df = pd.read_csv(dir_base + separator + 'taglist.csv', header=0, index_col=0)
    df.loc['Num', :] = range(0, len(df.columns))
    id_alldict = df.to_dict(orient='index')
    id_alltagid = list(id_alldict['Description'].keys())
    id_allnumdict = id_alldict['Num']
    return id_allnumdict


def eval_method(func, x_):
    g = func.constraint_function(x_)
    func.g_num = len(g)
    return g


def main():
    id_alldict = get_dictionary()
    model_path = work_path + separator + 'pkg' + separator + 'function' + separator + 'model'
    
    # function instance
    func = Function(model_path, id_alldict)
    func.Time = 6
    func.dim = func.num_feat_total * func.Time
    print('Time = ', func.Time)
    print('num_feat_total = ', func.num_feat_total)

    # calculation constarint function value
    # all elements are 1 
    x = np.ones(func.dim)
    g_ = eval_method(func, x)
    print('each constraint function value = ')
    print(g_)

    print('finished.')
    
if __name__ == "__main__":
    main()
