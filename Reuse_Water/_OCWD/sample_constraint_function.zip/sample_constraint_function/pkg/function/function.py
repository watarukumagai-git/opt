#coding: utf-8
import numpy as np
from .model.import_model import Model_class


class Function:
    """
    Objective and constraint functions.

    Attributes
    ----------
    Model : constructor
        model constructor using 'Model_class' at model_path
    """

    def __init__(self, model_path, id_allnumdict):
        """
        initialization.

        Parameters
        ----------
        model_path : string 
            directory path including model class file 
        id_allnumdict : dictionary (5, num_ID)
            taglist (id_No, Description, SeedMode, tagIDname, column number)
        """
        # initialization
        self.g_num = 0
        self.num_feat_total = len(list(id_allnumdict.keys()))
        self.Time = 0
        self.dim = 0

        # get dictionary
        self.id_allnumdict = id_allnumdict

        # call prediction model
        self.Model = Model_class(model_path)
        self.x_list_pre = [['ID000','ID001'],
                           ['ID000','ID002'],
                           ['ID003','ID004','ID100','ID200','ID300','ID301','ID302']]
        self.y_list_pre = ['ID1000', 'ID1001', 'ID1002']


    def get_dict_vallist(self, d_, l_):
        return [d_[d] for d in l_]


    def get_prediction(self, x_2D):
        # ID1000, ID1001, ID1002 (fouling) prediction
        pred_value = np.array([self.each_prediction(self.id_allnumdict, x_2D, self.x_list_pre[idx], y_list) for idx, y_list in enumerate(self.y_list_pre)])
        return pred_value
    

    def each_prediction(self, id_dict, x_2D, x_l, y_l):
        """
        prediction using x_l and y_l variables.

        Parameters
        ----------
        id_dict : dictionary {id_num: tag_id} 
        x_2D : double (num_feat, Time)
            solution
        x_l : list of string (num_feat,)
            explanatory variable name (tag_id)
        y_l : string
            objective variable name (tag_id)

        Returns
        -------
        y : double (Time,)
            prediction value
        """
        
        # from tagID to index in x
        idx = self.get_dict_vallist(id_dict, x_l)
        x_input = x_2D[idx, :]

        # id1000, id1001, id1002
        if y_l == 'ID1000': # S1_perm_EC
            model = self.Model.model1
            y = model.predict(x_input)
        elif y_l == 'ID1001': # perm_TOC
            model = self.Model.model2
            y = model.predict(x_input)
        elif y_l == 'ID1002': # RO fouling
            model = self.Model.FOULING
            y = model.predict(x_input)
        return y

    def constraint_function(self, x__):
        """
        calculate constraint function g(x).

        Parameters
        ----------
        x__ : double (num_feat*Time,)
            solution

        Returns
        -------
        y : double (g_num,)
            each g(x)
        """
        
        # reshape (dim) to (num_feat_total, Time)
        x_2D = x__.reshape(self.num_feat_total, self.Time)
        # execute prediction
        new_x_2D = self.get_prediction(x_2D)
        # 0 <= pred_ID1001[t], t = 1, 2,...,Time
        g = 0 - new_x_2D[1, :]
        return g