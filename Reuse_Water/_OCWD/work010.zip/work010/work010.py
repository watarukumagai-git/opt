# -*- coding: utf-8 -*-
import os
from os import path
import datetime

import numpy as np
import pandas as pd

from pkg.helper import Helper
from pkg.save_figure import SaveFigure

def make_save_dir(work_path):
    # makedirs
    Helper().my_makedirs(work_path)
    Helper().my_makedirs(work_path + '\\fig_validated')
    Helper().my_makedirs(work_path + '\\fig_optimized')
    Helper().my_makedirs(work_path + '\\file')

def index_to_datetime(df, ts_clm):
    df[ts_clm] = pd.to_datetime(df.index)
    df.set_index(ts_clm, inplace=True)
    return df


def figure_x_trend(fig_base, df_opt, df_master, tag_dict, LRV_dict, type_):
    labels = ['actual', type_, 'lower limit', 'upper limit']
    figure_label1 = ["Datetime", labels]
    figure_label2 = ["Datetime"]
    minmax_status = 'none'
    lang = 'eng'
    #dateformat = '%d-%b-%y %H'
    dateformat = '%d-%b-%y'
    id = list(tag_dict['Description'].keys())

    for i, _id in enumerate(id):
        tag = tag_dict['Description'][_id]
        tag_id = tag_dict['tag ID'][_id]
        if tag_dict['SeedMode'][_id] != '1':
            min_x = tag_dict['min'][_id]
            max_x = tag_dict['max'][_id]
            y_label = tag + ' [' + tag_dict['unit'][_id] + ']'
            figure_label1i = figure_label1 + [y_label, [float(min_x), float(max_x)]]
            fig_file_name = fig_base + '//' + tag + '_all.png'
            SaveFigure().trend_four(figure_label1i, 
                                    df_opt.index, 
                                    df_master.loc[:, tag_id], 
                                    df_opt.loc[:, tag], 
                                    fig_file_name,
                                    minmax_status,
                                    lang,
                                    dateformat,
                                    )
        else:
            y_label = tag + ' [' + tag_dict['unit'][_id] + ']'
            figure_label2i = figure_label2 + [y_label, [0, 100]]
            fig_file_name = fig_base + '//' + tag + '_all.png'
            SaveFigure().trend(figure_label2i, 
                                df_master.index, 
                                df_master.loc[:, tag_id], 
                                fig_file_name,
                                minmax_status,
                                lang,
                                dateformat,
                                )

    for key, val in LRV_dict.items():
        min_x = val['min']
        max_x = val['max']
        figure_label1i = figure_label1 + [key, [float(min_x), float(max_x)]]
        fig_file_name = fig_base + '//' + key + '_all.png'
        SaveFigure().trend_four(figure_label1i, 
                                df_opt.index, 
                                df_master.loc[:, key], 
                                df_opt.loc[:, key], 
                                fig_file_name,
                                minmax_status,
                                lang,
                                dateformat,
                                )

def to_datetime(str_):
    return datetime.datetime.strptime(str_, '%d/%m/%Y %H:%M:%S')

def calc_LRV(LRV_dict, tag_dict, act):
    LRV_ = np.zeros((2, len(act)))
    idx_list = []
    j = 0
    for key, val in LRV_dict.items():
        idx_list.append(key)
        input = act.loc[:, tag_dict['tag ID'][val['feed']]].T
        output = act.loc[:, tag_dict['tag ID'][val['perm']]].T
        LRV_[j, :] = np.log10(input) - np.log10(output)
        j = j + 1
    df_LRV = pd.DataFrame(LRV_, index = idx_list).T
    df_LRV.index = act.index
    return df_LRV


def main():
    dir_base = path.dirname( path.abspath(__file__) )

    # read file
    root_path = dir_base + '\\input'
    df_master = pd.read_csv(root_path + '\\OCWD_master_preprocessed.csv', index_col=0)
    df_master['timestamp'] = pd.to_datetime(df_master.index).tolist()
    df_master.set_index('timestamp',inplace=True)

    df_taglist = pd.read_csv(root_path + '\\taglist.csv', index_col=0)
    tag_dict = df_taglist.to_dict(orient='index')
    df_LRVlist = pd.read_csv(root_path + '\\LRVlist.csv', index_col=0)
    LRV_dict = df_LRVlist.to_dict()

    save_path = dir_base + '\\output'
    file_base = save_path + '\\file\\'
    make_save_dir(save_path)

    str_ = '20/5/2022 0:00:00'
    end_ = '24/6/2022 0:00:00'
    str_for = to_datetime(str_)
    end_for = to_datetime(end_)
    df_master = df_master.loc[str_for:end_for :]
    df_LRV = calc_LRV(LRV_dict, tag_dict, df_master)
    df_master = pd.concat([df_master, df_LRV], axis=1)

    # optimized
    print('optimized')
    for i in range(0, 5):        
        df_temp = pd.read_csv(dir_base + '\\output_'+ str(i+1) +'w\\file\\solution_LRV.csv', index_col=0)
        if i == 0:
            df_opt = df_temp.copy()
        else:
            df_opt = pd.concat([df_opt.iloc[:, :-1], df_temp], axis=1)
    df_opt = df_opt.T
    df_opt.rename(columns=tag_dict['Description'], inplace=True)
    df_opt.index = pd.date_range(start=str_, end=end_, freq='H')
    df_opt.to_csv(file_base + 'all_solution_optimized.csv')
    fig_base = save_path + '\\fig_optimized\\'
    figure_x_trend(fig_base, df_opt, df_master, tag_dict, LRV_dict, type_='optimized')

    # validated
    print('validated')
    for i in range(0, 5):        
        df_temp = pd.read_csv(dir_base + '\\output_val_'+ str(i+1) +'w\\file\\solution_LRV.csv', index_col=0)
        if i == 0:
            df_val = df_temp.copy()
        else:
            df_val = pd.concat([df_val.iloc[:, :-1], df_temp], axis=1)
    df_val = df_val.T
    df_val.rename(columns=tag_dict['Description'], inplace=True)
    df_val.index = pd.date_range(start=str_, end=end_, freq='H')
    df_val.to_csv(file_base + 'all_solution_validated.csv')
    fig_base = save_path + '\\fig_validated\\'
    figure_x_trend(fig_base, df_val, df_master, tag_dict, LRV_dict, type_='predicted')

    print('finish')

if __name__ == "__main__":
    main()