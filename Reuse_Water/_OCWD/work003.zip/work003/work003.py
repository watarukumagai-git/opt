# -*- coding: utf-8 -*-
import time
import math
import os
from os import path

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.inspection import PartialDependenceDisplay, permutation_importance
from sklearn.model_selection import GridSearchCV, KFold, cross_val_score
from sklearn.metrics import mean_squared_error, make_scorer
import matplotlib.pyplot as plt


if 'My Drive' in os.getcwd():
    separator = '/'
    work_path = os.getcwd()
else:
    separator = '\\'
    work_path = path.dirname( path.abspath(__file__) )
    os.chdir(work_path)


def make_setfile(dir_base, str_list, num_list):
    f = open(dir_base + separator + 'set_file.txt', 'w')
    for i in range(0,len(str_list)):
        f.write(str_list[i] + ' = ' + str(num_list[i]) + '\n')
    f.close()

    
def get_path():
    dir_base = work_path + separator + 'output'
    my_makedirs(dir_base)
    my_makedirs(dir_base + separator + 'file')
    my_makedirs(dir_base + separator + 'fig')
    return dir_base


def get_parameter():
    df1 = pd.read_csv(work_path + separator + 'input' + separator + 'master_preprocessed_edit.csv', header=0, index_col=0, dtype=str)
    df1_unit = df1["unit":]
    df1 = df1[:df1.index.get_loc('unit')] 
    df1.reset_index(inplace=True)
    df1['Date / Time'] = pd.to_datetime(df1['Date / Time'])
    df1.set_index("Date / Time",inplace=True)
    df1 = df1.astype('float')
    return df1

    
def my_makedirs(path):
    if not os.path.isdir(path):
        os.makedirs(path)


def split_data(df, x_list, y_list, tra_period, test_period):
    def _list_check(list1, list2):
        return set(list1).issubset(list2)

    def _select_idx_dataframe(df, clm, txt):
        if _list_check(clm, np.arange(len(df.columns.tolist())).tolist()):
            df = pd.concat([df.iloc[:, 0], df.iloc[:, clm]], axis=1)
        else:
            df = 0
            print('input data does not contain ' + txt + '.')
        return df

    def _select_clm_dataframe(df, period, txt):
        df_ = df.loc[period[0]:period[1], :]
        return df_
    
    #def my_index_multi(l, x):
    #return [i for i, _x in enumerate(l) if _x == x]

    #x_num = []
    #for x in x_list:
    #    x_num.append(my_index_multi(df.columns.tolist(), x))

    # x_select
    #x_list = list(map(lambda x: x+1, x_list))
    list_ = x_list.copy()
    list_.insert(0, y_list)
    #df = _select_idx_dataframe(df, list_, 'x_list')
    df = df.loc[:, list_]
    print('y = ', y_list)
    print('x = ', x_list)

    # split
    print('training period: ', tra_period)
    print('predict period: ', test_period)
    df_tra = _select_clm_dataframe(df, tra_period, 'training period')
    df_test = _select_clm_dataframe(df, test_period, 'predict period')
    print('traning data')
    print(df_tra.shape)
    print(df_tra.head())
    print('validation data')
    print(df_test.shape)
    print(df_test.head())
    return df_tra, df_test

class model_CV:
    def __init__(self, modeling_mode, df_tra, df_val):
        self.modeling_mode = modeling_mode
        self.X_tra = df_tra.values[:, 1:]
        self.y_tra = df_tra.values[:, 0]
        self.X_val = df_val.values[:, 1:]
        self.y_val = df_val.values[:, 0]
        self.df_tra = df_tra
        self.df_val = df_val
        self.param_grid = {'n_estimators': [5, 10, 30, 50, 100, 150],
                           #'max_features': ('sqrt', 'log2', None),  # ランダムに指定する特徴量の数
                           'max_depth':    (10, 20, 30, 40, 50, None)}

    def fit(self):
        if self.modeling_mode == 'MLR':
            self.model = LinearRegression()
        elif self.modeling_mode == 'RF':
            self.model = RandomForestRegressor(n_jobs=-1, random_state=2525, n_estimators=10)
        self.model.fit(self.X_tra, self.y_tra)

    def predict(self):
        def _unit_pre(df, model, X, y, prefix):
            y_pre = model.predict(X)
            y_array = np.vstack([y_pre, y]).T
            df_y_pre = pd.DataFrame(y_array, 
                                    index = df.index, 
                                    columns=[df.columns[0]+'_'+prefix, df.columns[0]+'_act'])
            print(df_y_pre.head())
            return df_y_pre
        
        df_y_pre = _unit_pre(self.df_val, self.model, self.X_val, self.y_val, 'pre')
        df_y_est = _unit_pre(self.df_tra, self.model, self.X_tra, self.y_tra, 'est')

        return df_y_pre, df_y_est

    def grid_search_CV(self):
        grid_search = GridSearchCV(self.model, self.param_grid, cv=5, scoring='neg_mean_squared_error')
        grid_search.fit(self.X_tra, self.y_tra)
        print('Training set score: {}'.format(grid_search.score(self.X_tra, self.y_tra)))
        print('Test set score: {}'.format(grid_search.score(self.X_val, self.y_val)))
        print('Best cross-validation: {}'.format(grid_search.best_score_))
        print('Best parameters: {}'.format(grid_search.best_params_))
        self.model = grid_search.best_estimator_


def draw_trend_chart(df, fig_file_name):
    fig = plt.figure(figsize=(6,4))
    fig.patch.set_facecolor('white')
    ax = fig.add_subplot(1,1,1)
    x = pd.to_datetime(df.index)
    print('from ', x[0])
    print('to ', x[-1])
    
    ax.plot(x, df.iloc[:, 0], "C1", label=df.columns[0], lw=0.5)
    ax.plot(x, df.iloc[:, 1], "C0", label=df.columns[1], lw=0.5)
    ax.set_xlabel('timestamp', fontsize=10)
    ax.set_ylabel('y predict/actual', fontsize=10)
    ax.legend(loc='center', bbox_to_anchor=(0.5, 1.1), ncol=2)
    ax.tick_params(direction = "in")

    labelss = ax.get_xticklabels()
    plt.setp(labelss, rotation=60)
    plt.tick_params(labelsize=8)
    plt.tight_layout()
    plt.savefig(fig_file_name, bbox_inches="tight")


def PDP(model, imp_X, imp_features, fig_file_name):
    plt.rcParams['font.size'] = 18 #matplotlib.pyplot の文字サイズ設定
    fig, axes = plt.subplots(figsize=(12, 6)) #matplotlib.pyplot の描画準備
    fig.subplots_adjust(hspace=0.6, wspace=0.1) #間隔の設定
    disp_RFC = PartialDependenceDisplay.from_estimator(model, imp_X, imp_features, ax=axes) #プロット
    for i in range(disp_RFC.lines_.shape[0]):
        disp_RFC.axes_[i, 0].set_ylabel('y') #縦軸ラベルの設定
    plt.tight_layout()
    plt.savefig(fig_file_name, bbox_inches="tight")


def imputation(use_data, x_taglist):
    def Hampel(x, k=24, thr=3):
        idx = np.arange(len(x))
        output_x = x.copy()
        output_Idx = np.zeros_like(x)
        print(idx)
    
        for i, ele in enumerate(x):
            x_kernel = x[np.where( (idx <= (idx[i] + k)) & (idx >= (idx[i] - k)), True, False)]
            median = np.median(x_kernel)
            std = math.sqrt(np.median(np.multiply((x_kernel - median),(x_kernel - median))))
            
            if np.abs(ele - median) > thr * std:
                output_Idx[i] = 1
                output_x[i] = median
                
        return output_x

    # 標準化
    def set_stds(data, variable):
        data = pd.DataFrame(StandardScaler().fit_transform(data), columns=variable, index=data.index)
        return data

    # 外れ値除去  median で補間 k=24 thr=3
    use_data = use_data.fillna(method='ffill').fillna(method='bfill')
    #use_data = use_data.apply(Hampel, k=24, thr=3)
    # 標準化
    #use_data[x_taglist] = set_stds(use_data[x_taglist], x_taglist)
    return use_data

def rmse(y_true, y_pred):
    return np.sqrt(mean_squared_error(y_true, y_pred)) 

def feature_importance(rf_reg, X_test, y_test, imp_features, fig_file_name):
    result = permutation_importance(
                                    rf_reg, X_test, y_test, n_repeats=10, random_state=42, n_jobs=2
                                    )
    df = pd.DataFrame(result.importances_mean, index=imp_features, columns=['Permutation Feature Importances'])
    df['Std'] = result.importances_std

    fig, ax = plt.subplots()
    df['Permutation Feature Importances'].plot.bar(yerr=df['Std'].values, ax=ax)
    ax.set_ylabel("Mean decrease in impurity")
    fig.tight_layout()
    plt.savefig(fig_file_name, bbox_inches="tight")
    return df


def main():
    # time start
    start_time = time.time()
    print ("calculation started.")
    print('-----------------------------------')

    # x list (column number)
    #x_list = [0,2,4,5]
    x_list = ["RO_B01 FW Press","RO_Feed Cond","RO_01_FirstStageFeedFlow","RO_Feed Temperature","RO_Feed Ph", "Sulfric Acid Usage","Threshold Inhibitor Usage"]
    y_list = 'RO_B01 Blank 1 Perm Cond'

    # training period
    #tra_period = ['2022/04/26 0:00','2022/05/19 23:30']
    tra_period = ['2022/04/26 0:00','2022/09/30 23:30']

    # predict period
    #pre_period = ['2022/05/20 0:00','2022/05/26 23:30']
    pre_period = ['2022/10/01 0:00','2022/11/20 23:30']

    # get path
    dir_base = get_path()
    df = get_parameter()

    df = imputation(df, x_list)


    # split train and test
    df_tra, df_val = split_data(df, x_list, y_list, tra_period, pre_period)

    # model instance

    modeling_mode = 'RF'
    model_CV_ = model_CV(modeling_mode, df_tra, df_val)
    model_CV_.fit()

    end_time = time.time()
    cal_time = end_time - start_time
    print('time = %f sec = %f min' % (cal_time, cal_time/60))

    model_CV_.grid_search_CV()
    df_y_pre, df_y_est = model_CV_.predict()
    model = model_CV_.model
    
    df_y_est.to_csv(dir_base + separator + "file" + separator + "estimate.csv")
    df_y_pre.to_csv(dir_base + separator + "file" + separator + "predict.csv")

    draw_trend_chart(df_y_est, dir_base + separator + "fig"+ separator + "estimate.png")
    draw_trend_chart(df_y_pre, dir_base + separator + "fig"+ separator + "predict.png")

    PDP(model, df_tra[x_list], x_list, dir_base + separator + "fig"+ separator + "PDP.png")
    df_feature = feature_importance(model, df_val.values[:, 1:], df_val.values[:, 0], x_list, dir_base + separator + "fig"+ separator + "feature_importance.png")
    df_feature.to_csv(dir_base + separator + "file" + separator + "feature_importance.csv")

    print ("figure saving finished.")

    # time finish
    end_time = time.time()
    cal_time = end_time - start_time
    print('time = %f sec = %f min' % (cal_time, cal_time/60))

    
if __name__ == "__main__":
    main()
