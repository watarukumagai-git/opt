#coding: utf-8
import configparser

#ErrMsg
GeneralErrMsg1 = 'The specified modeling-mode is not implemented.'

def read_config(param_file):
    def _read_period(ini_period):
        period = ini_period.split(', ')
        period = [period[0].split('[')[1], period[1].split(']')[0]]
        return period
    
    config_ini = configparser.ConfigParser() 
    config_ini.read(param_file, encoding='utf-8')
    read_default = config_ini['DEFAULT']
    plant_name = read_default.get('PlantName')
    time_span = read_default.get('TimeSpan')
    tra_period = _read_period(read_default.get('TraPeriod'))
    opt_period = _read_period(read_default.get('OptPeriod'))
    modeling_mode = read_default.get('ModelingMode')
    if modeling_mode == 'RF':
        read_modeling = config_ini['RANDOMFOREST']
        modeling_list = [read_modeling.get('NumTree'), read_modeling.get('MaxDepth'), read_modeling.get('MinSamplesSplit')]
    elif modeling_mode == 'PLS':
        read_modeling = config_ini['PLS']
        modeling_list = [read_modeling.get('NumLV')]
    elif modeling_mode == 'MLR' or modeling_mode == 'LightGBM' or modeling_mode == 'LinearTree':
        modeling_list = []
    else:
        print(GeneralErrMsg1)
    return plant_name, time_span, modeling_mode, tra_period, opt_period, modeling_list
