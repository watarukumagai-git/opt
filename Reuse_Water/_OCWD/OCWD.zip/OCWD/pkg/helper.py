# -*- coding: utf-8 -*-
import os
from os import path
import glob

class Helper:
    def __init__(self):
        if 'My Drive' in os.getcwd():
            self.SEPARATOR = '/'
        else:
            self.SEPARATOR = '\\'
    
    def get_workpath(self, abs, num=1):
        if abs == 'workdir':
            WORKPATH = path.dirname(path.abspath(__file__)) 
        elif abs == 'upperdir':
            #os.chdir(path.dirname(path.abspath(__file__)) )
            for i in range(num):
                if i == 0:
                    P = '..' + self.SEPARATOR
                else:
                    P += '..' + self.SEPARATOR
            WORKPATH = path.abspath(P)
        elif abs == 'cd':
            WORKPATH = os.getcwd()
        return WORKPATH

    def make_output_dir(self, WORKPATH, _l=[]):
        out_dir_base = WORKPATH + self.SEPARATOR + 'output'
        self.my_makedirs(out_dir_base)
        self.my_makedirs(out_dir_base + self.SEPARATOR + 'file')
        self.my_makedirs(out_dir_base + self.SEPARATOR + 'fig')
        if len(_l) >= 1:
            for i in _l:
                self.my_makedirs(out_dir_base + self.SEPARATOR + 'fig' + self.SEPARATOR + i)
        return out_dir_base

    def make_output_validate_dir(self, WORKPATH, _l=[]):
        out_dir_base = WORKPATH + self.SEPARATOR + 'output_val'
        self.my_makedirs(out_dir_base)
        self.my_makedirs(out_dir_base + self.SEPARATOR + 'file')
        self.my_makedirs(out_dir_base + self.SEPARATOR + 'fig')
        if len(_l) >= 1:
            for i in _l:
                self.my_makedirs(out_dir_base + self.SEPARATOR + 'fig' + self.SEPARATOR + i)
        return out_dir_base

    def make_setfile(self, dir_base, str_list, num_list):
        f = open(dir_base + self.SEPARATOR + 'set_file.txt', 'w')
        for i in range(0,len(str_list)):
            f.write(str_list[i] + ' = ' + str(num_list[i]) + '\n')
        f.close()

    def my_makedirs(self, path):
        if not os.path.isdir(path):
            os.makedirs(path)

    def get_file_dir_list(self, root_path, list_type):
        if list_type == 'dir':
            dir_list = [f for f in os.listdir(root_path) if os.path.isdir(os.path.join(root_path, f))]
            return dir_list
        elif list_type == 'file':
            file_list = glob.glob(root_path + '*.csv')
            file_name_list = [one_file.rsplit(self.SEPARATOR, 1)[1].split('.')[0] for one_file in file_list]
            return file_list, file_name_list

    def uni_list(self, l1, l2):
        l = list(set(l1) & set(l2))
        return l

    def flatten_list(self, l):
        for el in l:
            if isinstance(el, list):
                yield from self.flatten_list(el)
            else:
                yield el

    def list_check(list1, list2):
        return set(list1).issubset(list2)

    def rename_iaxis(self, dataframe, n, name,  axis = 0):
        # axis:0 => index, 1=> column
        if axis == 0:
            org_namelist = list(dataframe.index)
        elif axis == 1:
            org_namelist = list(dataframe.columns)
        
        # rename n-th index/column name to new name
        new_namelist = org_namelist
        new_namelist[n] = name
        dataframe = dataframe.set_axis(new_namelist, axis = axis, inplace = False)
        return dataframe
