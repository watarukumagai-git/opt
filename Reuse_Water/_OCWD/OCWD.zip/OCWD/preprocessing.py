import numpy as np
import pandas as pd

from pkg import helper

_helper = helper.Helper()
_helper.WORKPATH = _helper.get_workpath('cd')

def load_csv(DIR):
    def _index_to_datetime(_df, date_clm):
        _df['timestamp'] = pd.to_datetime(_df[date_clm])
        _df.set_index('timestamp',inplace=True)
        _df = _df.drop(date_clm, axis=1)
        return _df
    dir_base = DIR + _helper.SEPARATOR + 'input'
    _df1 = pd.read_csv(dir_base + _helper.SEPARATOR + 'master_2021_2022_30min_edit_ver2.csv', header=0, dtype=str)
    date_clm = 'Date / Time'    # timestamp clm name in masterfile
    date = _df1.loc[:, date_clm].tolist()
    # datetime transformation
    if '/' in date[0] and 'description' == date[-1]:
        _df1 = _index_to_datetime(_df1.iloc[:-2], date_clm)
    _df1 = _df1.astype('float')
    return _df1

def add_calculation_tag(_data):
    def _conc_flow(_df, feedflow, permeateflow):
        return _df[feedflow] - _df[permeateflow]
    def _conc_EC(_df, feedflow, feedEC, permeateflow, permeateEC, concflow):
        return (_df[feedflow]*_df[feedEC] - _df[permeateflow]*_df[permeateEC]) / _df[concflow]
    
    EPS = 0.0001
    _data["S1 Feed Flow Rate"] = _data[["RO_B01 Blank 1 Perm Flow","RO_B01 Blank 2 Perm Flow","RO_B01 Blank 3 Perm Flow","RO_B01 Conc Flow"]].sum(axis=1)
    _data[_data["S1 Feed Flow Rate"] < EPS] = EPS
    _data["S2 Feed Flow Rate_calc"] = _conc_flow(_data, "S1 Feed Flow Rate", "RO_B01 Blank 1 Perm Flow")
    _data[_data["S2 Feed Flow Rate_calc"] < EPS] = EPS
    _data["S3 Feed Flow Rate_calc"] = _conc_flow(_data, "S2 Feed Flow Rate_calc", "RO_B01 Blank 2 Perm Flow")
    _data[_data["S3 Feed Flow Rate_calc"] < EPS] = EPS
    _data["S2 Feed EC_calc"] = _conc_EC(_data, "S1 Feed Flow Rate", "RO_Feed Cond", "RO_B01 Blank 1 Perm Flow", "RO_B01 Blank 1 Perm Cond", "S2 Feed Flow Rate_calc")
    _data[_data["S2 Feed EC_calc"] < EPS] = EPS
    _data["S3 Feed EC_calc"] = _conc_EC(_data, "S2 Feed Flow Rate_calc", "S2 Feed EC_calc", "RO_B01 Blank 2 Perm Flow", "RO_B01 Blank 2 Perm Cond", "S3 Feed Flow Rate_calc")
    _data[_data["S3 Feed EC_calc"] < EPS] = EPS

    clm = ["Sulfric Acid Usage", "Threshold Inhibitor Usage"]
    delta_ = 30
    unit_ = 'min'
    if unit_ == 'day':
        _data[clm] = _data[clm]*delta_
    elif unit_ == 'hour':
        _data[clm] = _data[clm]*delta_/24
    elif unit_ == 'min':
        _data[clm] = _data[clm]*delta_/(24*60)
    _data[clm] = _data[clm].fillna(method='ffill')
    return _data

def preprocessing(_df):
    _df = _df.where(_df > 0, np.nan)
    _df = _df.interpolate('ffill').interpolate('bfill')
    return _df

def main():
    plant = 'OCWD'
    dir_base = _helper.WORKPATH + _helper.SEPARATOR + 'input'
    (master_df) = load_csv(_helper.WORKPATH)
    master_df = preprocessing(master_df)
    master_df = add_calculation_tag(master_df)

    filename = plant + '_master_preprocessed.csv'
    master_df.to_csv(dir_base + _helper.SEPARATOR + filename)

    print('data proprocessing has finished.')

if __name__ == "__main__":
    main()
