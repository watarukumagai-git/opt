#coding: utf-8
from os import path
import numpy as np
from .import_model import ImportedModel

class LoadProblemParam:
    def __init__(self, alltaglist_df, param_df, modellist_df):
        self.g_num = 0
        self.param_df = param_df
        self.modeldict = dict(zip(modellist_df.columns.tolist(), self.get_modellist(modellist_df)))

        alltaglist_df = alltaglist_df.fillna(-999)

        alltaglist_df.loc['Num', :] = range(0, len(alltaglist_df.columns))
        self.alltagdict = alltaglist_df.to_dict(orient='index')

        seedmode_df = alltaglist_df.loc['SeedMode', :]
        self.seedmode_dict = seedmode_df.to_dict()
        self.opt_taglist = seedmode_df[seedmode_df == '0'].index.tolist()
        self.fixed_taglist = seedmode_df[seedmode_df == '1'].index.tolist()
        self.inter_taglist = seedmode_df[seedmode_df == '2'].index.tolist()

        cost_df = alltaglist_df.loc['cost', :].astype(float)
        self.cost_dict = cost_df[cost_df != -999].to_dict()

        diff_df = alltaglist_df.loc[['diff_min', 'diff_max'], :].astype(float)
        diff_df = diff_df[diff_df != -999].dropna(axis=1)
        self.diff_dict = diff_df.to_dict()

        taglist_df = alltaglist_df.loc[:, self.opt_taglist]
        self.tagdict = taglist_df.to_dict(orient='index')

        self.delta_t = len(param_df)

        # idx for dict
        #L = self.alltagdict.keys()
        # id no for dict
        #L1 = self.alltagdict['Description'].keys()
        # description for dict
        #L2 = self.alltagdict['Description'].values()
        # SeedMode for dict
        #L3 = self.alltagdict['SeedMode'].values()
        self.ID_list = list(self.tagdict['Description'].keys())
        self.allID_list = list(self.alltagdict['Description'].keys())
        self.num_feat_total = len(self.ID_list)
        self.num_allfeat_total = len(self.allID_list)
        self.load_problem()

    def get_modellist(self, df_):
        df_ = df_.fillna(-999)
        l_ = [df_.loc[df_.loc[:, clm] >= 0, clm].sort_values(ascending=True).index.tolist() for clm in df_.columns.tolist()]
        return l_

    def load_problem(self):
        def set_minmax_all(Time_start, ID_list):
            self.bigbigN = len(ID_list) * self.delta_t

            # upper/lower/pattern
            min_clm = [i + '_Min' for i in ID_list]
            max_clm = [i + '_Max' for i in ID_list]
            if self.delta_t == 1:
                min_df = self.param_df.loc[Time_start, min_clm]
                max_df = self.param_df.loc[Time_start, max_clm]
            else:
                min_df = self.param_df.loc[Time_start:self.Time, min_clm]
                max_df = self.param_df.loc[Time_start:self.Time, max_clm]
            

            # [min, max]
            self.bigbigx_ul = np.ones((self.bigbigN, 2))
            self.bigbigx_ul[:,0] = min_df.values.T.reshape(self.bigbigN)
            self.bigbigx_ul[:,1] = max_df.values.T.reshape(self.bigbigN)


        def set_opt_minmaxpattern(Time_start, ID_list):
            self.bigN = self.num_feat_total * self.delta_t

            # upper/lower/pattern
            min_clm = [i + '_Min' for i in ID_list]
            max_clm = [i + '_Max' for i in ID_list]
            pattern_clm = [i + '_Pattern' for i in ID_list]
            seedflag_clm = [i + '_SeedFlag' for i in ID_list]
            if self.delta_t == 1:
                min_df = self.param_df.loc[Time_start, min_clm]
                max_df = self.param_df.loc[Time_start, max_clm]
                self.pattern = self.param_df.loc[Time_start, pattern_clm].values
                self.seedflag = self.param_df.loc[Time_start, seedflag_clm].values
            else:
                min_df = self.param_df.loc[Time_start:self.Time, min_clm]
                max_df = self.param_df.loc[Time_start:self.Time, max_clm]
                self.pattern = self.param_df.loc[Time_start:self.Time, pattern_clm].values
                self.seedflag = self.param_df.loc[Time_start:self.Time, seedflag_clm].values
            

            # index_array: (num_free, 2), [row_index, column_index] (num_feat, delta_t)
            index_array = list(zip(*np.where(self.seedflag.T==0)))
            self.N = len(index_array)

            # [x1[0],x1[1],x1[2],x2[0],x2[1],x2[1],....]
            self.pattern = self.pattern.T.reshape(self.bigN)
            self.seedflag = self.seedflag.T.reshape(self.bigN)

            # [min, max]
            self.bigx_ul = np.ones((self.bigN, 2))
            self.bigx_ul[:,0] = min_df.values.T.reshape(self.bigN)
            self.bigx_ul[:,1] = max_df.values.T.reshape(self.bigN)
            if np.any(self.seedflag==1):
                idx = np.where(self.seedflag == 0)
                self.x_ul = self.bigx_ul[idx,:][0]
            else:
                self.x_ul = self.bigx_ul


        def set_fixed_pattern(Time_start, ID_list):
            pattern_clm = [i + '_Pattern' for i in ID_list]
            if self.delta_t == 1:
                self.pattern_fixed = self.param_df.loc[Time_start, pattern_clm].values.T
            else:
                self.pattern_fixed = self.param_df.loc[Time_start:self.Time, pattern_clm].values.T
            

        def set_inter_minmaxpattern(Time_start, ID_list):
            bigN = len(ID_list) * self.delta_t

            # upper/lower/pattern
            min_clm = [i + '_Min' for i in ID_list]
            max_clm = [i + '_Max' for i in ID_list]
            pattern_clm = [i + '_Pattern' for i in ID_list]
            if self.delta_t == 1:
                min_df = self.param_df.loc[Time_start, min_clm]
                max_df = self.param_df.loc[Time_start, max_clm]
                self.pattern_inter = self.param_df.loc[Time_start, pattern_clm].values.T
            else:
                min_df = self.param_df.loc[Time_start:self.Time, min_clm]
                max_df = self.param_df.loc[Time_start:self.Time, max_clm]
                self.pattern_inter = self.param_df.loc[Time_start:self.Time, pattern_clm].values.T
            

            # [x1[0],x1[1],x1[2],x2[0],x2[1],x2[1],....]
            #self.pattern_inter = self.pattern_inter.T.reshape(bigN)

            # [min, max]
            self.x_ul_inter = np.ones((bigN, 2))
            self.x_ul_inter[:,0] = min_df.values.T.reshape(bigN)
            self.x_ul_inter[:,1] = max_df.values.T.reshape(bigN)



        Time_start = 0
        self.Time = self.delta_t-1 + Time_start
        print('delta_t =', self.delta_t)

        # all
        set_minmax_all(Time_start, self.allID_list)

        # optimization variable
        set_opt_minmaxpattern(Time_start, self.ID_list)

        # fixed parameter
        set_fixed_pattern(Time_start, self.fixed_taglist)

        # intermediate variable
        set_inter_minmaxpattern(Time_start, self.inter_taglist)


        def my_index(l, x, default=False):
            return l.index(x) if x in l else default

        # cost: (num_feat_total, Time)
        unit_cost = [0 if my_index(self.opt_taglist, cost_tag, -999) == -999 else self.cost_dict[cost_tag] for cost_tag in list(self.cost_dict.keys())]
        self.cost = np.ones((self.num_feat_total, self.delta_t)) * np.array(unit_cost).reshape(len(self.opt_taglist),1)


class OptProblem:
    """
    Objective and constraint functions.

    Attributes
    ----------
    Model : constructor
        model constructor using 'Model_class' at model_path
    """

    def __init__(self, load_pro, SEPARATOR):
        """
        initialization.

        Parameters
        ----------
        model_path : string 
            directory path including model class file 
        """
        self.load_pro = load_pro
        dirpath = path.dirname(path.abspath(__file__))
        self.Model = ImportedModel(SEPARATOR, dirpath)

        self.id_alldict = self.load_pro.alltagdict
        self.id_dict = self.load_pro.tagdict
        self.id_allnumdict = self.id_alldict['Num']
        self.id_numdict = self.id_dict['Num']
        self.id_alltagid = list(self.id_alldict['Description'].keys())
        self.id_allseedmode = list(self.id_alldict['SeedMode'].values())
        self.id_allnum = self.get_dict_vallist(self.id_allnumdict, self.id_alltagid)
        self.id_num = self.get_dict_vallist(self.id_numdict, self.load_pro.opt_taglist)
        self.init_big_x_2D = self.get_init_big_x_2D()

        self.modeldict = self.load_pro.modeldict

    def get_dict_vallist(self, d_, l_):
        return [d_[d] for d in l_]

    def get_init_big_x_2D(self):
        x_2D = np.zeros((len(self.id_alltagid), self.load_pro.delta_t))
        j = 0
        h = 0
        for clm, tagid in enumerate(self.id_alltagid):
            if self.id_allseedmode[clm] == '1':
                x_2D[clm, :] = self.load_pro.pattern_fixed[j, :].copy()
                j = j + 1
            elif self.id_allseedmode[clm] == '2':
                x_2D[clm, :] = self.load_pro.pattern_inter[h, :].copy()
                h = h + 1
        return x_2D

    def get_big_x_2D(self, x_2D):
        def _get_prediction(big_x_2D):
            y_list_pre = self.modeldict.keys()
            x_pre_2D = np.zeros((len(y_list_pre), self.load_pro.delta_t))
            for idx, yname in enumerate(y_list_pre):
                x_pre_2D[idx, :] = self.prediction(self.id_allnumdict, big_x_2D, self.modeldict[yname], yname)
                num = self.id_allnumdict[yname]
                big_x_2D[num, :] = x_pre_2D[idx, :].copy()
            return big_x_2D

        # initial copy
        big_x_2D = self.init_big_x_2D.copy()
        # seedmode = 0 clm is modified to variable
        for clm, idnum in enumerate(self.id_num):
            big_x_2D[idnum, :] = x_2D[clm, :].copy()

        # ID1000, ID1001, ID1002 (fouling) prediction
        #l = [S1_Feed_Pre, S3_Conc_Pre, S1_Perm_Flow, S2_Perm_Flow, S3_Perm_Flow, S3_Conc_Flow, UF_Filtrate_Total_Chlorine]
        # execute prediction and update to prediction
        big_x_2D = _get_prediction(big_x_2D)            
        return big_x_2D

    def prediction(self, id_dict, x_2D, x_l, y_l):
        """
        prediction using x_l and y_l variables.

        Parameters
        ----------
        id_dict : dictionary {id_num: tag_id} 
        x_2D : double (num_feat, Time)
            solution
        x_l : list of string (num_feat,)
            explanatory variable name (tag_id)
        y_l : string
            objective variable name (tag_id)

        Returns
        -------
        y : double (Time,)
            prediction value
        """
        
        # from tagID to index in x_2D (matrix)
        idx = self.get_dict_vallist(id_dict, x_l)
        x_input = x_2D[idx, :]
        if y_l == 'ID1000': # S1_perm_EC
            model = self.Model.S1_perm_EC_model
        elif y_l == 'ID2000': # S2_feed_EC
            model = self.Model.S2_feed_EC_model
        elif y_l == 'ID2001': # S2_perm_EC
            model = self.Model.S2_perm_EC_model
        elif y_l == 'ID3000': # S3_feed_EC
            model = self.Model.S3_feed_EC_model
        elif y_l == 'ID3001': # S3_perm_EC
            model = self.Model.S3_perm_EC_model
        elif y_l == 'ID4000': # perm_TOC
            model = self.Model.perm_TOC_model
        y = model.predict(x_input)
        #elif y_l == 'ID1002': # RO fouling
        #    # timestep 1 is initial fouling value because all initial values are fixed. 
        #    y = np.zeros(self.load_pro.delta_t)
        #    model = self.Model.FOULING
        #    y[1:] = model.predict(x_input[:, 1:])
        return y

    def convert_x_to_schedule(self, x_):
        # x: (N, 1)
        # schedule: (num_feat_total, delta_t)
        if np.any(self.load_pro.seedflag!=0):
            schedule = np.where(self.load_pro.seedflag, self.load_pro.pattern, -999)
            schedule[schedule == -999] = x_
        else:
            schedule = x_.copy()
        schedule = schedule.reshape(self.load_pro.num_feat_total, self.load_pro.delta_t)
        return schedule

    def convert_schedule_to_x(self, schedule):
        # schedule: (num_feat_total, delta_t)
        # x: (N, 1)
        x_ = schedule.reshape(self.load_pro.N)
        if np.any(self.load_pro.seedflag!=0):
            x_ = np.delete(x_, np.where(self.load_pro.seedflag!=0))
        return x_

    def basis_func(self, func_type, x, c):
        # x: (N,)
        # c: (N,) or (N+1,)
        # func_type 1: linear
        if func_type == 1:
            if x.ndim >= 1:
                if len(c) == len(x):
                    f =  np.sum(c*x)
                else:
                    f =  np.sum(c[:-1]*x) + c[-1]
            else:
                f = c*x
        return f

    def object_function(self, x__):
        # input
        # x__: (N_, )
        # output
        # f: float
        c = self.load_pro.cost.reshape(self.load_pro.bigN)
        x_2D = self.convert_x_to_schedule(x__)
        f = self.basis_func(1, x_2D.reshape(self.load_pro.bigN), c)
        return f

    def get_oneside_vio(self, g_equal, lower, upper):
        return np.where((lower + upper)/2>=g_equal, lower - g_equal, g_equal - upper)

    def relax_const(self, x, coef, lower, upper):
        """
        relax for constarint functions.

        Parameters
        ----------
        eval_const : object
            constraint function
        x : double (num_feat, Time)
            solution
        coef : double (num_feat+1,)
            coefficient and bias for x
        lower : double (Time,)
            lower for x
        upper : double (Time,)
            upper for x

        Returns
        -------
        g_inequal : double (Time,)
            inequality constarints relaxed by lower/upper
        """
        # g_equal: (Time,)
        if x.ndim > 1:
            if len(coef) == x.shape[0]:
                g_equal = np.dot(coef, x)
            elif len(coef) == x.shape[0]+1:
                g_equal = np.dot(coef[:-1], x) + coef[-1]
        else:
            if len(coef) == len(x):
                g_equal = coef*x
            elif len(coef) == len(x) + 1:
                g_equal = coef[:-1]*x + coef[-1]
        g_inequal = self.get_oneside_vio(g_equal, lower, upper)
        return g_inequal

    def get_vio_minmax(self, x__, min__, max__):
        # x__ : (N,)
        # min__ : (N,) self.load_pro.x_ul[:,0]
        # max__ : (N,) self.load_pro.x_ul[:,1]
        return self.get_oneside_vio(x__, min__, max__)

    def get_vio_fac(self, x_2D, coef, epsilon):
        # x_2D: (num_feat, Time)
        # coef: (num_feat+1,)
        lower = -epsilon*np.ones(x_2D.shape[1])
        upper = epsilon*np.ones(x_2D.shape[1])
        # g_inequal : (Time,)
        g_inequal = self.relax_const(x_2D, coef, lower, upper)
        return g_inequal

    def get_vio_demand(self, x_2D, coef, epsilon, demand):
        # x_2D: (num_feat, Time)
        # coef: (num_feat,)
        # demand: (Time,)
        lower = demand - epsilon[0]
        upper = demand + epsilon[0]
        #lower = np.array([demand[t] - epsilon[0] for t in range(0,self.load_pro.delta_t)])
        #upper = np.array([demand[t] + epsilon[0] for t in range(0,self.load_pro.delta_t)])
        # g_inequal : (Time,)
        g_inequal = self.relax_const(x_2D, coef, lower, upper)
        return g_inequal

    def get_vio_diff(self, x_diff, diff_minmax):
        # x_diff: (Time-1,)
        # diff_minmax: [diff_min, diff_max]
        lower = diff_minmax[0]*np.ones(len(x_diff))
        upper = diff_minmax[1]*np.ones(len(x_diff))
        # g_inequal : (Time-1,)
        g_inequal = self.get_oneside_vio(x_diff, lower, upper)
        return g_inequal

    def constraint_function(self, x__):
        def _get_const_diff(x_2D):
            if len(list(self.load_pro.diff_dict.keys())) < 1:
                return []
            else:
                for (j, id) in enumerate(self.load_pro.diff_dict.keys()):
                    idx = self.id_allnumdict[id]
                    x_diff = np.diff(x_2D[idx, :], n=1)
                    epsilon_diff = list(self.load_pro.diff_dict[id].values())
                    unit_diff = self.get_vio_diff(x_diff, epsilon_diff)
                    if j == 0:
                        g_diff = unit_diff
                    else:
                        g_diff = np.concatenate([g_diff, unit_diff])
                return g_diff
                
        def _get_minmax_inter(id_dict, x_2D, y_list_pre):
            idx = self.get_dict_vallist(id_dict, y_list_pre)
            x__ = x_2D[idx, :].reshape(-1)
            gminmax = self.get_vio_minmax(x__, self.load_pro.x_ul_inter[:,0], self.load_pro.x_ul_inter[:,1])
            return gminmax
        
        def _get_violation_limit_inter(x_2D):
            def _mod_lower(data, eps):
                if np.any(data <= eps):
                    data = np.where(data <= eps, eps, data)
                return data
            def _get_limit_inter(input, output, lower, upper):
                input = _mod_lower(input, 0.0001)
                output = _mod_lower(output, 0.0001)
                g_equal_rate = np.log10(input / output)
                return self.get_oneside_vio(g_equal_rate, lower, upper)
            lower = [1.5, 1.5]
            upper = [2.3, 2.5]
            feed_ = 'ID0002'
            perm_ = ['ID1000', 'ID2001', 'ID3001']
            Num_ = [self.id_allnumdict[p] for p in perm_]
            combined_perm_EC = x_2D[Num_, :].sum(axis=0)
            g_rate = [_get_limit_inter(x_2D[self.id_allnumdict[feed_], :], combined_perm_EC, lower[0], upper[0])]

            feed_ = 'ID0003'
            perm_ = 'ID4000'
            g_rate.append(_get_limit_inter(x_2D[self.id_allnumdict[feed_], :], x_2D[self.id_allnumdict[perm_], :], lower[1], upper[1]))
            g_rate = np.concatenate(g_rate).reshape(-1)
            return g_rate

        def _get_violation_order_inter(x_2D):
            feed = ['ID0002', 'ID2000', 'ID3000', 'ID0003']
            perm = ['ID1000', 'ID2001', 'ID3001', 'ID4000']
            g_order = [x_2D[self.id_allnumdict[feed_], :] - x_2D[self.id_allnumdict[perm[idx]], :] for idx, feed_ in enumerate(feed)]
            g_order = np.concatenate(g_order).reshape(-1)
            return g_order

        # (num_feat_total, delta_t)
        x_2D = self.convert_x_to_schedule(x__)
        big_x_2D = self.get_big_x_2D(x_2D)

        # min-max_violation for prediction
        g_minmax = _get_minmax_inter(self.id_allnumdict, big_x_2D, self.modeldict.keys())

        # prediction rate
        g_rate = _get_violation_limit_inter(big_x_2D)

        # order rate
        g_order = _get_violation_order_inter(big_x_2D)

        # diff_violation
        g_diff = _get_const_diff(big_x_2D)

        g = np.ravel(np.concatenate([g_minmax, g_rate, g_order, g_diff]))
        return g