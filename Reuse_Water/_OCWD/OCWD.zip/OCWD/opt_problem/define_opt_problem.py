#coding: utf-8
from os import path
import numpy as np
from .import_model import ImportedModel

class LoadProblemParam:
    def __init__(self, alltaglist_df, param_df, modellist_df):
        self.g_num = 0
        self.param_df = param_df
        self.modeldict = dict(zip(modellist_df.columns.tolist(), self.get_modellist(modellist_df)))

        alltaglist_df = alltaglist_df.fillna(-999)

        alltaglist_df.loc['Num', :] = range(0, len(alltaglist_df.columns))
        self.alltagdict = alltaglist_df.to_dict(orient='index')

        seedmode_df = alltaglist_df.loc['SeedMode', :]
        self.seedmode_dict = seedmode_df.to_dict()
        self.opt_taglist = seedmode_df[seedmode_df == '0'].index.tolist()
        self.fixed_taglist = seedmode_df[seedmode_df == '1'].index.tolist()
        self.inter_taglist = seedmode_df[seedmode_df == '2'].index.tolist()

        cost_df = alltaglist_df.loc['cost', :].astype(float)
        self.cost_dict = cost_df[cost_df != -999].to_dict()

        diff_df = alltaglist_df.loc[['diff_min', 'diff_max'], :].astype(float)
        diff_df = diff_df[diff_df != -999].dropna(axis=1)
        self.diff_dict = dict(zip(diff_df.columns.tolist(), [tuple(x) for x in diff_df.T.values]))

        taglist_df = alltaglist_df.loc[:, self.opt_taglist]
        self.tagdict = taglist_df.to_dict(orient='index')

        self.delta_t = len(param_df)

        # idx for dict
        #L = self.alltagdict.keys()
        # id no for dict
        #L1 = self.alltagdict['Description'].keys()
        # description for dict
        #L2 = self.alltagdict['Description'].values()
        # SeedMode for dict
        #L3 = self.alltagdict['SeedMode'].values()
        self.ID_list = list(self.tagdict['Description'].keys())
        self.allID_list = list(self.alltagdict['Description'].keys())
        self.num_feat_total = len(self.ID_list)
        self.num_allfeat_total = len(self.allID_list)

        self.load_problem()

    def get_modellist(self, df_):
        df_ = df_.fillna(-999)
        l_ = [df_.loc[df_.loc[:, clm] >= 0, clm].sort_values(ascending=True).index.tolist() for clm in df_.columns.tolist()]
        return l_

    def load_problem(self):
        def set_minmax_all(Time_start, ID_list):
            self.bigbigN = len(ID_list) * self.delta_t

            # upper/lower/pattern
            min_clm = [i + '_Min' for i in ID_list]
            max_clm = [i + '_Max' for i in ID_list]
            if self.delta_t == 1:
                min_df = self.param_df.loc[Time_start, min_clm]
                max_df = self.param_df.loc[Time_start, max_clm]
            else:
                min_df = self.param_df.loc[Time_start:self.Time, min_clm]
                max_df = self.param_df.loc[Time_start:self.Time, max_clm]
            

            # [min, max]
            self.bigbigx_ul = np.ones((self.bigbigN, 2))
            self.bigbigx_ul[:,0] = min_df.values.T.reshape(self.bigbigN)
            self.bigbigx_ul[:,1] = max_df.values.T.reshape(self.bigbigN)


        def set_opt_minmaxpattern(Time_start, ID_list):
            self.bigN = self.num_feat_total * self.delta_t

            # upper/lower/pattern
            min_clm = [i + '_Min' for i in ID_list]
            max_clm = [i + '_Max' for i in ID_list]
            pattern_clm = [i + '_Pattern' for i in ID_list]
            seedflag_clm = [i + '_SeedFlag' for i in ID_list]
            if self.delta_t == 1:
                min_df = self.param_df.loc[Time_start, min_clm]
                max_df = self.param_df.loc[Time_start, max_clm]
                self.pattern = self.param_df.loc[Time_start, pattern_clm].values
                self.seedflag = self.param_df.loc[Time_start, seedflag_clm].values
            else:
                min_df = self.param_df.loc[Time_start:self.Time, min_clm]
                max_df = self.param_df.loc[Time_start:self.Time, max_clm]
                self.pattern = self.param_df.loc[Time_start:self.Time, pattern_clm].values
                self.seedflag = self.param_df.loc[Time_start:self.Time, seedflag_clm].values
            

            # index_array: (num_free, 2), [row_index, column_index] (num_feat, delta_t)
            index_array = list(zip(*np.where(self.seedflag.T==0)))
            self.N = len(index_array)

            # [x1[0],x1[1],x1[2],x2[0],x2[1],x2[1],....]
            self.pattern = self.pattern.T.reshape(self.bigN)
            self.seedflag = self.seedflag.T.reshape(self.bigN)

            # [min, max]
            self.bigx_ul = np.ones((self.bigN, 2))
            self.bigx_ul[:,0] = min_df.values.T.reshape(self.bigN)
            self.bigx_ul[:,1] = max_df.values.T.reshape(self.bigN)
            if np.any(self.seedflag==1):
                idx = np.where(self.seedflag == 0)
                self.x_ul = self.bigx_ul[idx,:][0]
            else:
                self.x_ul = self.bigx_ul


        def set_fixed_pattern(Time_start, ID_list):
            pattern_clm = [i + '_Pattern' for i in ID_list]
            if self.delta_t == 1:
                self.pattern_fixed = self.param_df.loc[Time_start, pattern_clm].values.T
            else:
                self.pattern_fixed = self.param_df.loc[Time_start:self.Time, pattern_clm].values.T
            

        def set_inter_minmaxpattern(Time_start, ID_list):
            bigN = len(ID_list) * self.delta_t

            # upper/lower/pattern
            min_clm = [i + '_Min' for i in ID_list]
            max_clm = [i + '_Max' for i in ID_list]
            pattern_clm = [i + '_Pattern' for i in ID_list]
            if self.delta_t == 1:
                min_df = self.param_df.loc[Time_start, min_clm]
                max_df = self.param_df.loc[Time_start, max_clm]
                self.pattern_inter = self.param_df.loc[Time_start, pattern_clm].values.T
            else:
                min_df = self.param_df.loc[Time_start:self.Time, min_clm]
                max_df = self.param_df.loc[Time_start:self.Time, max_clm]
                self.pattern_inter = self.param_df.loc[Time_start:self.Time, pattern_clm].values.T
            

            # [x1[0],x1[1],x1[2],x2[0],x2[1],x2[1],....]
            #self.pattern_inter = self.pattern_inter.T.reshape(bigN)

            # [min, max]
            self.x_ul_inter = np.ones((bigN, 2))
            self.x_ul_inter[:,0] = min_df.values.T.reshape(bigN)
            self.x_ul_inter[:,1] = max_df.values.T.reshape(bigN)



        Time_start = 0
        self.Time = self.delta_t-1 + Time_start
        print('delta_t =', self.delta_t)

        # all
        set_minmax_all(Time_start, self.allID_list)

        # optimization variable
        set_opt_minmaxpattern(Time_start, self.ID_list)

        # fixed parameter
        set_fixed_pattern(Time_start, self.fixed_taglist)

        # intermediate variable
        set_inter_minmaxpattern(Time_start, self.inter_taglist)
        pattern_clm = [i + '_Pattern' for i in self.allID_list]
        if self.delta_t == 1:
            self.pattern_all = self.param_df.loc[Time_start, pattern_clm].values.T
        else:
            self.pattern_all = self.param_df.loc[Time_start:self.Time, pattern_clm].values.T


        def my_index(l, x, default=False):
            return l.index(x) if x in l else default

        # cost: (num_feat_total, Time)
        unit_cost = [0 if my_index(self.opt_taglist, cost_tag, -999) == -999 else self.cost_dict[cost_tag] for cost_tag in list(self.cost_dict.keys())]
        self.cost = np.ones((self.num_feat_total, self.delta_t)) * np.array(unit_cost).reshape(len(self.opt_taglist),1)


class OptProblem:
    """
    Objective and constraint functions.

    Attributes
    ----------
    Model : constructor
        model constructor using 'Model_class' at model_path
    """

    def __init__(self, load_pro, SEPARATOR):
        """
        initialization.

        Parameters
        ----------
        model_path : string 
            directory path including model class file 
        """
        self.load_pro = load_pro
        self.id_alldict = self.load_pro.alltagdict
        self.id_dict = self.load_pro.tagdict
        self.id_allnumdict = self.id_alldict['Num']
        self.id_numdict = self.id_dict['Num']
        self.id_num = self.get_dict_vallist(self.id_numdict, self.load_pro.opt_taglist)
        self.idx_optnum_all = self.get_dict_vallist(self.id_allnumdict, self.load_pro.opt_taglist)
        self.init_big_x_2D = self.get_init_big_x_2D()

        self.modeldict = self.load_pro.modeldict
        dirpath = path.dirname(path.abspath(__file__))
        self.Model = ImportedModel(SEPARATOR, dirpath)

    def get_dict_vallist(self, d_, l_):
        return [d_[d] for d in l_]

    def get_init_big_x_2D(self):
        x_2D = self.load_pro.pattern_all.copy()
        x_2D[self.idx_optnum_all, :] = 0
        return x_2D

    def get_big_x_2D(self, x_2D):
        if x_2D.ndim < 3:
            # initial copy
            big_x_2D = self.init_big_x_2D.copy()
            # seedmode = 0 clm is modified to variable
            big_x_2D[self.idx_optnum_all, :] = x_2D[self.id_num, :].copy()
            # execute prediction and update to prediction
            for yname, x_list in self.modeldict.items():
                big_x_2D[self.id_allnumdict[yname], :] = self.prediction(self.id_allnumdict, big_x_2D, x_list, yname)
        else:
            # initial copy
            big_x_2D = np.repeat(self.init_big_x_2D[None, :, :], x_2D.shape[0], axis=0)
            # seedmode = 0 clm is modified to variable
            big_x_2D[:, self.idx_optnum_all, :] = x_2D[:, self.id_num, :].copy()
            # execute prediction and update to prediction
            for i in range(0, x_2D.shape[0]):
                for yname, x_list in self.modeldict.items():
                    big_x_2D[i, self.id_allnumdict[yname], :] = self.prediction(self.id_allnumdict, big_x_2D[i, :, :], x_list, yname)
        return big_x_2D

    def prediction(self, id_dict, x_2D, x_l, y_l):
        """
        prediction using x_l and y_l variables.

        Parameters
        ----------
        id_dict : dictionary {id_num: tag_id} 
        x_2D : double (num_feat, Time)
            solution
        x_l : list of string (num_feat,)
            explanatory variable name (tag_id)
        y_l : string
            objective variable name (tag_id)

        Returns
        -------
        y : double (Time,)
            prediction value
        """
        
        # from tagID to index in x_2D (matrix)
        x_input = x_2D[self.get_dict_vallist(id_dict, x_l), :]
        if y_l == 'ID1000': # S1_perm_EC
            model = self.Model.S1_perm_EC_model
        elif y_l == 'ID2000': # S2_feed_EC
            model = self.Model.S2_feed_EC_model
        elif y_l == 'ID2001': # S2_perm_EC
            model = self.Model.S2_perm_EC_model
        elif y_l == 'ID3000': # S3_feed_EC
            model = self.Model.S3_feed_EC_model
        elif y_l == 'ID3001': # S3_perm_EC
            model = self.Model.S3_perm_EC_model
        elif y_l == 'ID4000': # perm_combined_EC
            model = self.Model.perm_combined_EC_model
        elif y_l == 'ID4001': # perm_TOC
            model = self.Model.perm_TOC_model
        y = model.predict(x_input)
        #elif y_l == 'ID1002': # RO fouling
        #    # timestep 1 is initial fouling value because all initial values are fixed. 
        #    y = np.zeros(self.load_pro.delta_t)
        #    model = self.Model.FOULING
        #    y[1:] = model.predict(x_input[:, 1:])
        return y

    def convert_x_to_schedule(self, x_):
        # x: (m, N) or (N,)
        # schedule: (num_feat_total, delta_t)
        if x_.ndim < 2:
            if np.any(self.load_pro.seedflag!=0):
                schedule = self.load_pro.pattern
                schedule[self.load_pro.seedflag == 0] = x_.copy()
            else:
                schedule = x_.copy()
            schedule = schedule.reshape(self.load_pro.num_feat_total, self.load_pro.delta_t)
        else:
            if np.any(self.load_pro.seedflag!=0):
                schedule = np.repeat(self.load_pro.pattern[None, :], x_.shape[0], axis=0)
                schedule[:, self.load_pro.seedflag == 0] = x_.copy()
            else:
                schedule = x_.copy()
            schedule = schedule.reshape(x_.shape[0], self.load_pro.num_feat_total, self.load_pro.delta_t)
        return schedule

    def convert_schedule_to_x(self, schedule):
        # schedule: (num_feat_total, delta_t)
        # x: (N, 1)
        x_ = schedule.reshape(schedule.size)
        if np.any(self.load_pro.seedflag!=0):
            x_ = np.delete(x_, np.where(self.load_pro.seedflag!=0))
        return x_

    def basis_func(self, x, c):
        # x: (m, N)
        # c: (N,)
        return np.dot(x, c)

    def get_pena(self, _x_2D):
        keys_ = list(self.load_pro.diff_dict.keys())
        epsilon_diff = [[-0.05,0.05],[-0.01,0.01]]
        if _x_2D.ndim < 3:
            x_diff = np.diff(_x_2D, n=1, axis=1)
            g_ = np.concatenate([self.get_vio_diff(x_diff[j, :], epsilon_diff[j]) for j in range(len(keys_))]).reshape(-1)
            P = np.where(g_<0, 0, g_).sum()
        else:
            x_diff = np.diff(_x_2D, n=1, axis=2)
            g_ = np.concatenate([self.get_vio_diff(x_diff[:, j, :], epsilon_diff[j]) for j in range(len(keys_))], axis=1)
            P = np.where(g_<0, 0, g_).sum(axis=1)
        return P

    def object_function(self, x__):
        # input
        # x__: (N_, )
        # output
        # f: float
        x_2D = self.convert_x_to_schedule(x__)
        if x__.ndim < 2:
            x_input = x_2D.reshape(self.load_pro.bigN)
        else:
            x_input = x_2D.reshape(x__.shape[0], self.load_pro.bigN)
        f = self.basis_func(x_input, self.load_pro.cost.reshape(self.load_pro.bigN))

        g_diff = self.get_pena(x_2D)
        EPS = 1
        f = f + EPS * g_diff
        return f

    def get_oneside_vio(self, g_equal, lower, upper):
        return np.where((lower + upper)/2>=g_equal, lower - g_equal, g_equal - upper)

    def get_vio_minmax(self, x__, min__, max__):
        # x__ : (m,N)
        # min__ : (N,) self.load_pro.x_ul[:,0]
        # max__ : (N,) self.load_pro.x_ul[:,1]
        return self.get_oneside_vio(x__, min__, max__)

    def get_vio_diff(self, x_diff, diff_minmax):
        # x_diff: (Time-1,)
        # diff_minmax: [diff_min, diff_max]
        if x_diff.ndim < 2:
            size = len(x_diff)
        else:
            size = x_diff.shape[1]
        lower = diff_minmax[0]*np.ones(size)
        upper = diff_minmax[1]*np.ones(size)
        # g_inequal : (Time-1,)
        g_inequal = self.get_oneside_vio(x_diff, lower, upper)
        return g_inequal


    def constraint_function(self, x__):
        def _get_const_diff(x_2D):
            keys_ = list(self.load_pro.diff_dict.keys())
            if len(keys_) < 1:
                return []
            else:
                epsilon_diff = list(self.load_pro.diff_dict.values())
                if x_2D.ndim < 3:
                    X = x_2D[self.get_dict_vallist(self.id_allnumdict, keys_), :]
                    x_diff = np.diff(X, n=1, axis=1)
                    return np.concatenate([self.get_vio_diff(x_diff[j, :], epsilon_diff[j]) for j in range(len(keys_))]).reshape(-1)
                else:
                    X = x_2D[:, self.get_dict_vallist(self.id_allnumdict, keys_), :]
                    x_diff = np.diff(X, n=1, axis=2)
                    g_diff = np.concatenate([self.get_vio_diff(x_diff[:, j, :], epsilon_diff[j]) for j in range(len(keys_))], axis=1)
                    return g_diff

        def _get_const_diff_std(x_2D):
            keys_ = list(self.load_pro.diff_dict.keys())
            if len(keys_) < 1:
                return []
            else:
                if x_2D.ndim < 3:
                    return np.std(x_2D[self.get_dict_vallist(self.id_allnumdict, keys_), :], axis=1) - 0.04
                else:
                    return np.std(x_2D[:, self.get_dict_vallist(self.id_allnumdict, keys_), :], axis=2) - 0.04
                
        def _get_minmax_inter(id_dict, x_2D, y_list_pre):
            idx = self.get_dict_vallist(id_dict, y_list_pre)
            if x_2D.ndim < 3:
                x__ = x_2D[idx, :].reshape(-1)
            else:
                x__ = x_2D[:, idx, :].reshape(x_2D.shape[0], -1)
            gminmax = self.get_vio_minmax(x__, self.load_pro.x_ul_inter[:,0], self.load_pro.x_ul_inter[:,1])
            return gminmax
        
        def _get_violation_limit_inter(x_2D):
            def _mod_lower(data, eps):
                if np.any(data <= eps):
                    data = np.where(data <= eps, eps, data)
                return data
            def _get_limit_inter(input, output, lower, upper):
                eps = 0.00001
                input = _mod_lower(input, eps)
                output = _mod_lower(output, eps)
                g_equal_rate = np.log10(input) - np.log10(output)
                return self.get_oneside_vio(g_equal_rate, lower, upper)
            lower = [1.5, 1.5]
            upper = [2.5, 3.0]
            feed = ['ID0002', 'ID0003']
            perm = ['ID4000', 'ID4001']
            g_rate = []
            if x_2D.ndim < 3:
                for i in range(len(perm)):
                    g_rate = np.concatenate([g_rate, _get_limit_inter(x_2D[self.id_allnumdict[feed[i]], :], x_2D[self.id_allnumdict[perm[i]], :], lower[i], upper[i])])
            else:
                for i in range(len(perm)):
                    g_unit = _get_limit_inter(x_2D[:, self.id_allnumdict[feed[i]], :], x_2D[:, self.id_allnumdict[perm[i]], :], lower[i], upper[i])
                    if i == 0:
                        g_rate = g_unit.copy()
                    else:
                        g_rate = np.concatenate([g_rate, g_unit], axis=1)
            return g_rate
        
        # (num_feat_total, delta_t)
        big_x_2D = self.get_big_x_2D(self.convert_x_to_schedule(x__))

        # min-max_violation for prediction
        g_minmax = _get_minmax_inter(self.id_allnumdict, big_x_2D, self.modeldict.keys())

        # prediction rate
        g_rate = _get_violation_limit_inter(big_x_2D)

        # diff_violation
        g_diff = _get_const_diff(big_x_2D)

        # diff_violation
        g_std = _get_const_diff_std(big_x_2D)

        if x__.ndim < 2:
            g = np.ravel(np.concatenate([g_minmax, g_rate, g_diff, g_std]))
        else:
            g = np.concatenate([g_minmax, g_rate, g_diff, g_std], axis=1)
        return g