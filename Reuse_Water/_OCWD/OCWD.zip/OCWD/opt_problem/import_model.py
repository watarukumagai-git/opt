#coding: utf-8
import pickle

from .model_quality.S1_perm_EC import S1_perm_EC_model
from .model_quality.S2_feed_EC import S2_feed_EC_model
from .model_quality.S2_perm_EC import S2_perm_EC_model
from .model_quality.S3_feed_EC import S3_feed_EC_model
from .model_quality.S3_perm_EC import S3_perm_EC_model
from .model_quality.perm_TOC import perm_TOC_model

class ImportedModel:
    """
    import models.

    Attributes
    ----------
    S1_perm_EC : constructor
        S1 permeate EC prediction model constructor from model_quality
    S2_feed_EC : constructor
        S2 feed EC prediction model constructor from model_quality
    S2_perm_EC : constructor
        S2 permeate EC prediction model constructor from model_quality
    S3_feed_EC : constructor
        S3 feed EC prediction model constructor from model_quality
    S3_perm_EC : constructor
        S3 permeate EC prediction model constructor from model_quality
    perm_TOC : constructor
        permeate TOC prediction model constructor from model_quality
    """
    def __init__(self, SEPARATOR, dirpath):
        self.SEPARATOR = SEPARATOR
        base_folder_path = dirpath + self.SEPARATOR + 'model_quality'
        (S1_perm_EC_modelparam, S2_perm_EC_modelparam, S3_perm_EC_modelparam, perm_TOC_modelparam) = self.import_quality(base_folder_path)
        # [RO Stage 1 Feed Pressure, RO Stage 1 feed EC, RO Stage 1 Feed Flow Rate (Cal), RO Feed Temperature, RO Feed pH, RO Feed Total Chlorine]
        self.S1_perm_EC_model = S1_perm_EC_model(S1_perm_EC_modelparam)
        # [RO Stage 1 feed Flow Rate, RO Stage 1 feed EC, RO Stage 1 perm Flow Rate, RO Stage 1 perm EC]
        self.S2_feed_EC_model = S2_feed_EC_model()
        # [RO Stage 2 Feed EC, RO Stage 2 Feed Flow Rate (Cal), RO Feed Temperature, RO Feed Total Chlorine]
        self.S2_perm_EC_model = S2_perm_EC_model(S2_perm_EC_modelparam)
        # [RO Stage 2 feed Flow Rate, RO Stage 2 feed EC, RO Stage 2 perm Flow Rate, RO Stage 2 perm EC]
        self.S3_feed_EC_model = S3_feed_EC_model()
        # [RO Stage 3 Feed Pressure, RO Stage 3 Feed EC, RO Stage 3 Feed Flow Rate (Cal), RO Feed Temperature ,RO Feed Total Chlorine]
        self.S3_perm_EC_model = S3_perm_EC_model(S3_perm_EC_modelparam)
        # [ RO Stage 1 Feed Pressure, RO Stage 3 Feed Pressure, RO Stage 1 feed EC, RO Stage 1 Feed Flow Rate (Cal), RO Feed Temperature, RO Feed ph, RO Feed TOC, RO Feed Total Chlorine]
        self.perm_TOC_model = perm_TOC_model(perm_TOC_modelparam)
        #base_folder_path = dirpath + self.SEPARATOR + 'model_fouling'
        #(est_rho_model, est_cl_model, loaded_scaler) = self.import_fouling(base_folder_path)
        #self.FOULING = fouling(est_rho_model, est_cl_model, loaded_scaler)

    def _import(self, file):
        return pickle.load(open(file, 'rb'))


    def import_quality(self, base_folder_path):
        First_Perm_Cond_model = self._import(base_folder_path + self.SEPARATOR + 'OCWD_1st_Cond_modelfile')
        First_Perm_Flow_model = self._import(base_folder_path + self.SEPARATOR + 'OCWD_1st_PermeateFlow_modelfile')
        Second_Perm_Cond_model = self._import(base_folder_path + self.SEPARATOR + 'OCWD_2nd_Cond_modelfile')
        Second_Perm_Flow_model = self._import(base_folder_path + self.SEPARATOR + 'OCWD_2nd_PermeateFlow_modelfile')
        Third_Perm_Cond_model = self._import(base_folder_path + self.SEPARATOR + 'OCWD_3rd_Cond_modelfile')
        Third_Perm_Flow_model = self._import(base_folder_path + self.SEPARATOR + 'OCWD_3rd_PermeateFlow_modelfile')
        TOC_model = self._import(base_folder_path + self.SEPARATOR + 'OCWD_TOC_modelfile')
        return First_Perm_Cond_model, Second_Perm_Cond_model, Third_Perm_Cond_model, TOC_model