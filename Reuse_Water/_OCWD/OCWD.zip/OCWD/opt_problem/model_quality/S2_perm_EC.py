#coding: utf-8
import numpy as np

class S2_perm_EC_model:
    """
    calulate S1 permeate EC.

    Attributes
    ----------
    model : constructor (coef_, intercept_)
        estimate EC value using x 
    """
    def __init__(self, modelparam):
        #self.model = linear_model.LinearRegression()
        #self.model.coef_ = np.ones(4)*0.0000001
        #self.model.intercept_ = 27.0
        self.model = modelparam
    
    def predict(self, x):
        """
        predict S1 permeate EC.

        Parameters
        ----------
        x : double (4, Time)
            RO Stage 2 Feed EC
            RO Stage 2 Feed Flow Rate (Cal)
            RO Feed Temperature
            RO Feed Total Chlorine

        Returns
        -------
        predicted value : double (Time,)
        """
        #return np.dot(x.T, self.model.coef_) + self.model.intercept_
        tmp = self.model.predict(x.T).reshape(-1)
        return np.where(tmp<0, 0, tmp)