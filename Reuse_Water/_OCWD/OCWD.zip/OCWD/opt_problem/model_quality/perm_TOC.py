#coding: utf-8
import numpy as np

class perm_TOC_model():
    """
    calulate permeate TOC.

    Attributes
    ----------
    model : constructor (coef_, intercept_)
        estimate TOC value using x 
    """
    def __init__(self, modelparam):
        #self.model = linear_model.LinearRegression()
        #self.model.coef_ = np.ones(8)*0.0000001
        #self.model.intercept_ = 0.1
        self.model = modelparam

    def predict(self, x):
        """
        predict permeate TOC.

        Parameters
        ----------
        x : double (8, Time)
            RO Stage 1 Feed Pressure
            RO Stage 3 Feed Pressure
            RO Stage 1 feed EC
            RO Stage 1 Feed Flow Rate (Cal)
            RO Feed Temperature
            RO Feed ph
            RO Feed TOC
            RO Feed Total Chlorine

        Returns
        -------
        predicted value : double (Time,)
        """
        #return np.dot(x.T, self.model.coef_) + self.model.intercept_
        tmp = self.model.predict(x.T).reshape(-1)
        return np.where(tmp<0, 0, tmp)    
