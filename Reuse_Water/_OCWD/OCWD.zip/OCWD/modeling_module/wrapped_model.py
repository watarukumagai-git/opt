class ModelStd:
    def __init__(self, model, stds):
        self.model = model
        self.stds = stds
    
    def predict(self, _x):
        return self.model.predict(self.stds.transform(_x))