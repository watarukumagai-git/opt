#coding: utf-8 
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.cross_decomposition import PLSRegression
from sklearn.linear_model import LinearRegression
from lineartree import LinearTreeRegressor
import lightgbm as lgb

#ErrMsg
GeneralErrMsg1 = 'Modeling-mode does not work.'
PLSErrMsg1 = 'PLS Error: NumLV should be integer number within the range [1, number of variables].'
RFErrMsg1 = 'RF Error: NumTree should be integer number and larger than 1.'
RFErrMsg2 = 'RF Error: MaxDepth should be None or integer number and larger than 1.'
RFErrMsg3 = 'RF Error: MinSamplesSplit should be integer number and larger than 2.'

class Model:
    def __init__(self, modeling_mode, modeling_list, mod_flag):
        self.modeling_mode = modeling_mode
        self.modeling_list = modeling_list
        self.mod_flag = mod_flag
        if modeling_mode == 'RF':
            self.mod_mode = False
            # default: 100
            NumTree = int(modeling_list[0])
            # default: None
            if modeling_list[1] == 'None':
                MaxDepth = None
            else:
                MaxDepth = int(modeling_list[1])
            # default: 2
            MinSamplesSplit = int(modeling_list[2])
            if int(self.modeling_list[0]) < 1:
                print(RFErrMsg1)
            if self.modeling_list[1] != 'None' and int(self.modeling_list[1]) < 1:
                print(RFErrMsg2)
            if int(self.modeling_list[2]) < 2:
                print(RFErrMsg3)
            self.model = RandomForestRegressor(n_estimators=NumTree, max_depth=MaxDepth, min_samples_split=MinSamplesSplit, n_jobs=-1, random_state=2525)
        elif modeling_mode == 'LightGBM':
            self.mod_mode = False
            self.model = lgb.LGBMRegressor()
        elif modeling_mode == 'LinearTree':
            sub_type = 'MLR'
            if sub_type == 'MLR':
                self.model = LinearTreeRegressor(base_estimator=LinearRegression())
        elif modeling_mode == 'PLS':
            NumLV = int(modeling_list[0])
            self.model = PLSRegression(n_components=NumLV)
        elif modeling_mode == 'MLR':
            self.model = LinearRegression()
        else:
            self.model = 0
            print(GeneralErrMsg1)

    def fit(self, X_tra, y_tra):
        if self.modeling_mode == 'PLS':
            if int(self.modeling_list[0]) > len(X_tra.shape[1]) or int(self.modeling_list[0]) < 1:
                print(PLSErrMsg1)
        elif (self.modeling_mode == 'RF' or self.modeling_mode == 'LightGBM') and y_tra.ndim >= 2:
            y_tra = y_tra.reshape(-1)
        self.model.fit(X_tra, y_tra)
        (self.y_max, self.y_min) = (y_tra.max(), y_tra.min())

    def predict(self, X_val):
        if self.modeling_mode == 'PLS':
            pre = self.model.predict(X_val).reshape(len(X_val))
        else:
            pre = self.model.predict(X_val)
        if self.mod_flag:
            pre = np.clip(pre, self.y_min, self.y_max)
        return pre