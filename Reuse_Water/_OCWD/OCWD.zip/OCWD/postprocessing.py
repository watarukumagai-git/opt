# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
import time
import concurrent.futures as confu

from pkg import get_opt_module_param, helper
from pkg.save_figure import SaveFigure
from opt_module.optimize import Optimize
from opt_problem.define_opt_problem import OptProblem, LoadProblemParam
from pkg.read_config import read_config

_helper = helper.Helper()
_helper.WORKPATH = _helper.get_workpath('cd')

def read_parameter_files(date_clm):
    dir_base = _helper.WORKPATH + _helper.SEPARATOR + 'input'
    df1 = pd.read_csv(dir_base + _helper.SEPARATOR + 'parameter.csv', header=0)
    df2 = pd.read_csv(dir_base + _helper.SEPARATOR + 'taglist.csv', header=0, index_col=0)
    df3 = pd.read_csv(dir_base + _helper.SEPARATOR + 'modellist.csv', header=0, index_col=0)
    df4 = pd.read_csv(dir_base + _helper.SEPARATOR + 'LRVlist.csv', header=0, index_col=0)
    timestamp = pd.to_datetime(df1.loc[:,date_clm]).tolist()
    df1 = df1.drop(date_clm, axis=1)
    return df1, df2, df3, df4, timestamp


def figure_x_trend(fig_base, prob, func, param_df, big_x_2D, df_LRV, timestamp):
    # runmax >= 2
    if big_x_2D.ndim >= 3:
        run_max = big_x_2D.shape[2]
    # runmax = 1
    else:
        run_max = 1

    min_x = prob.bigbigx_ul[:, 0].reshape(prob.num_allfeat_total, prob.delta_t)
    max_x = prob.bigbigx_ul[:, 1].reshape(prob.num_allfeat_total, prob.delta_t)
    labels = ['actual', 'optimized', 'lower limit', 'upper limit']
    figure_label1 = ["Datetime", labels]
    figure_label2 = ["Datetime"]
    id = list(prob.alltagdict['Description'].keys())

    # 'minmax'
    minmax_status = 'none'
    lang = 'eng'
    #dateformat = '%d-%b-%y %H'
    dateformat = '%d-%b-%y'

    # x trend
    for i, _id in enumerate(id):
        tag = prob.alltagdict['Description'][_id]
        if _id not in prob.fixed_taglist:
            figure_label1i = figure_label1 + [tag, [min_x[i, 0], max_x[i, 0]]]
            for run in range(0, run_max):
                if run_max >= 2:
                    x_2D = big_x_2D[i, :, run].copy()
                else:
                    x_2D = big_x_2D.loc[_id, :].copy()
                fig_file_name = fig_base + _helper.SEPARATOR + tag + '_run'+ str(run) + '.png'
                SaveFigure().trend_four(figure_label1i, 
                                        timestamp, 
                                        param_df.loc[:, _id + '_Pattern'], 
                                        x_2D, 
                                        fig_file_name,
                                        minmax_status,
                                        lang,
                                        dateformat,
                                        )

        else:
            figure_label2i = figure_label2 + [tag, [min_x[i, 0], max_x[i, 0]]]
            fig_file_name = fig_base + _helper.SEPARATOR + tag + '.png'
            SaveFigure().trend(figure_label2i, 
                                timestamp, 
                                param_df.loc[:, _id + '_Pattern'], 
                                fig_file_name,
                                minmax_status,
                                lang,
                                dateformat,
                                )
    # LRV trend
    for key, val in func.load_pro.LRVdict.items():
        act = df_LRV.loc[key + '_act'][:-1]
        opt = df_LRV.loc[key + '_opt'][:-1]
        figure_labeli = figure_label1 + [key, [float(val['min']), float(val['max'])]]
        fig_file_name = fig_base + _helper.SEPARATOR + key + '_run0.png'
        SaveFigure().trend_four(figure_labeli, 
                                timestamp, 
                                act, 
                                opt, 
                                fig_file_name,
                                minmax_status,
                                lang,
                                dateformat,
                                )



def calc_average(prob, func, act_df, opt, df_LRV, time_span):
    id_list = prob.opt_taglist + prob.inter_taglist
    id_list_pattern = [ll + '_Pattern' for ll in id_list]
    tag_list = func.get_dict_vallist(prob.alltagdict['Description'], id_list)

    df_ave = pd.DataFrame(np.zeros((2, len(tag_list))), index = ['actual ave.', 'optimized ave.'], columns = tag_list)
    df_ave.loc['actual ave.', tag_list] = act_df.loc[:, id_list_pattern].values.T.mean(axis=1)
    df_ave.loc['optimized ave.', tag_list] = opt.loc[id_list, :].mean(axis=1).values
    df_LRV.loc[:, 'average'] = df_LRV.mean(axis=1)
    df_ave.loc[:, list(func.load_pro.LRVdict.keys())] = 0
    for key, val in func.load_pro.LRVdict.items():
        for type_ in [('opt', 'optimized'), ('act', 'actual')]:
            df_ave.at[type_[1] + ' ave.', key] = df_LRV.at[key + '_' + type_[0], 'average']
    df_ave.loc['diff', :] = df_ave.loc['optimized ave.', :] - df_ave.loc['actual ave.', :]

    delta_ = time_span.split('min')[0]
    unit_ = time_span.split(delta_)[1]
    if unit_ == 'day':
        _coef = 1 / float(delta_)
    elif unit_ == 'hour':
        _coef = 24 / float(delta_)
    elif unit_ == 'min':
        _coef = 24*60 / float(delta_)
    df_ave.loc['diff / day', :] = df_ave.loc['diff', :] * _coef
    print(df_ave.round(3))
    return df_ave


def calc_LRV(func, act_df, opt):
    LRV_ = np.zeros((4, len(act_df)))
    idx_list = []
    j = 0
    for key, val in func.load_pro.LRVdict.items():
        for type_ in ['opt', 'act']:
            idx_list.append(key + '_' + type_)
            if type_ == 'act':
                input = act_df.loc[:, val['feed'] + '_Pattern'].T
                output = act_df.loc[:, val['perm'] + '_Pattern'].T
            else:
                input = opt.loc[val['feed'], :]
                output = opt.loc[val['perm'], :]
            LRV_[j, :] = np.log10(input) - np.log10(output)
            j = j + 1
    df_LRV = pd.DataFrame(LRV_, index = idx_list)
    return df_LRV

def get_LRV(func, file_base, param_df, df_big_x_2D):
    df_LRV = calc_LRV(func, param_df, df_big_x_2D)
    l_end = [s for s in list(df_LRV.index) if s.endswith('_opt')]
    a = df_LRV.loc[l_end, :]
    a.set_axis(list(func.load_pro.LRVdict.keys()), axis=0, inplace=True)
    df_big_x_2D_LRV = pd.concat([df_big_x_2D, a],  axis=0)
    df_big_x_2D_LRV.to_csv(file_base + "solution_LRV.csv")
    return df_LRV, df_big_x_2D_LRV

def main():
    start_time = time.time()

    # parameter setting
    (alg_para, run_max) = get_opt_module_param.get_opt_module_param(_helper.WORKPATH, _helper.SEPARATOR)
    (plant_name, time_span, modeling_mode, train_period, optimize_period, modeling_list) = read_config(_helper.WORKPATH + _helper.SEPARATOR + 'config.ini')

    date_clm = 'timestamp'
    (param_df, taglist_df, modellist_df, LRV_df, timestamp) = read_parameter_files(date_clm)
    # get path
    dir_base = _helper.make_output_dir(_helper.WORKPATH)
    file_base = dir_base + _helper.SEPARATOR + 'file' + _helper.SEPARATOR
    fig_base = dir_base + _helper.SEPARATOR + 'fig' + _helper.SEPARATOR

    prob = LoadProblemParam(taglist_df, param_df, modellist_df, LRV_df)
    func = OptProblem(prob, _helper.SEPARATOR)

    df_big_x_2D = pd.read_csv(file_base + 'x2D_gbest_final_run0.csv', index_col=0)
    df_big_x_2D.columns = df_big_x_2D.columns.astype(int)
    (df_LRV, df_big_x_2D_LRV) = get_LRV(func, file_base, param_df, df_big_x_2D)
    
    # average 
    df_ave = calc_average(prob, func, param_df, df_big_x_2D_LRV, df_LRV, time_span)
    df_ave.to_csv(file_base + "solution_ave.csv")
    figure_x_trend(fig_base, prob, func, param_df, df_big_x_2D_LRV, df_LRV, timestamp)
    print ("file saving finished.")

    # time finish
    end_time = time.time()
    cal_time = end_time - start_time
    print('time = %f sec = %f min' % (cal_time, cal_time/60))

    
if __name__ == "__main__":
    main()
