# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
import time
from os import path
import shutil
import pulp as pl

from pkg import get_opt_module_param, helper
from pkg.save_figure import SaveFigure
from opt_module.optimize import Optimize
from opt_module.get_eval import ViolationEvaluation
from opt_problem.define_opt_problem import OptProblem, OptProblemLP, LoadProblemParam

_helper = helper.Helper()
_helper.WORKPATH = _helper.get_workpath('cd')

def read_parameter_files(date_clm):
    dir_base = _helper.WORKPATH + _helper.SEPARATOR + 'input'
    df1 = pd.read_csv(dir_base + _helper.SEPARATOR + 'parameter.csv', header=0)
    df2 = pd.read_csv(dir_base + _helper.SEPARATOR + 'taglist.csv', header=0, index_col=0)
    df3 = pd.read_csv(dir_base + _helper.SEPARATOR + 'modellist.csv', header=0, index_col=0)
    df4 = pd.read_csv(dir_base + _helper.SEPARATOR + 'LRVlist.csv', header=0, index_col=0)
    timestamp = pd.to_datetime(df1.loc[:,date_clm]).tolist()
    df1 = df1.drop(date_clm, axis=1)
    return df1, df2, df3, df4, timestamp

def solve_LP(func, prob, start_time, filename):
    print ("problem started.")
    problem = pl.LpProblem(sense=pl.LpMinimize)
    (x,y) = func.def_problem(prob, problem)
    print(problem)
    f = open(filename, 'w')
    f.write(str(problem))
    f.close()

    print ("problem termenated.")

    print ("calculation started.")
    print('-----------------------------------')
    # default: problem.solver.name == 'PULP_CBC_CMD'
    status = problem.solve()
    now_time = time.time() 
    cal_time = now_time - start_time 
    time_box = np.array([cal_time, cal_time/60, cal_time/3600])
    x_box = np.array([pl.value(xxx) for xx in x for xxx in xx])
    y_box = np.array([pl.value(yyy) for yy in y for yyy in yy])
    obj_value = pl.value(problem.objective)
    print('-----------------------------------')
    print ("calculation finished")
    print('calculation time = %.3f sec = %.3f min' % (cal_time, cal_time/60))
    print('obj_value: ', obj_value)
    print('opt_variable_value:')
    print(x_box)
    print('intermid_variable_value:')
    print(y_box)
    print('Status:', pl.LpStatus[status])
    return [str(obj_value), pl.LpStatus[status]], x_box, y_box, time_box, problem


def loop_iteration(func, alg_para, run_max, start_time):
    iter_max = alg_para[0]
    # databox gene
    time_box = np.zeros((run_max+1, 3))
    # [gbest_obj, gbest_vio]
    obj_gbest_box = np.zeros((iter_max, 2, run_max))
    x_gbest_final_box = np.zeros((func.load_pro.N, run_max))

    # time start
    print ("calculation started.")
    print('-----------------------------------')
    unit_run = Optimize(func, alg_para)

    for run in range(0, run_max): 
        print('run/run_max = %d / %d' % (run+1, run_max))
        print('loop start')
        # get solution
        (obj_subbox, x_gbest, obj_gbest_subbox) = unit_run.main_loop()

        # save solution
        obj_gbest_box[:, :, run] = obj_gbest_subbox
        x_gbest_final_box[:, run] = x_gbest
        
        now_time = time.time() 
        loop_cal_time = now_time - start_time if run == 0 else now_time - cal_time - start_time 
        cal_time = now_time - start_time 
        time_box[run, :] = np.array([loop_cal_time, loop_cal_time/60, loop_cal_time/3600])
        print('calculation time = %.3f sec = %.3f min' % (cal_time, cal_time/60))
        print ("feas_gbest: ", np.round(obj_gbest_box[iter_max-1, :2, run], 3))
        print('loop end')
        print('-----------------------------------')

    print ("calculation finished")
    time_box[-1, :] = np.mean(time_box[:run_max, :], axis=0)
    time_box = np.round(time_box, decimals=4)
    print('mean time = %.3f sec = %.3f = min = %.3f = hour' % (time_box[-1, 0], time_box[-1, 1], time_box[-1, 2]))
    return obj_gbest_box, x_gbest_final_box, time_box


def get_result(obj_gbest_box):
    name_list = ["obj", "vio"]
    idx_list = ["ave", "std", "max", "min"]

    df_obj_gbest_final = pd.DataFrame(obj_gbest_box.T, columns=name_list)
    print(df_obj_gbest_final)

    df_result = pd.DataFrame(np.zeros((len(idx_list), len(name_list))), index=idx_list, columns=name_list)
    for i in name_list:
        df_result.at["ave", i] = df_obj_gbest_final.loc[:, i].mean()
        df_result.at["std", i] = df_obj_gbest_final.loc[:, i].std()
        df_result.at["max", i] = df_obj_gbest_final.loc[:, i].max()
        df_result.at["min", i] = df_obj_gbest_final.loc[:, i].min()

    print ("result=")
    print (df_result)
    return df_result, df_obj_gbest_final 


def figures(fig_base, obj_gbest_box):
    iter_max = obj_gbest_box.shape[0]
    run_max = obj_gbest_box.shape[2]
    obj_max = np.amax(obj_gbest_box[:, 0, :])
    vio_max = np.amax(obj_gbest_box[:, 1, :])
    minmax = [0, obj_max, 0, vio_max]

    legends1 = ["$f(x)$", "$v(x)$"]
    labels1 = ["$f(x)$", "$v(x)$"]
    figure_label1 = ["iteration: $k$", legends1, labels1, minmax]
    for run in range(0, run_max):
        # obj and vio gbest trend
        fig_file_name = fig_base + 'obj_vio_gbest_'+ str(run) + '.png'
        SaveFigure().double_trend(figure_label1, 
                                         range(0, iter_max), 
                                         obj_gbest_box[:, :, run],
                                         fig_file_name,
                                         scale1 = 'log',
                                         scale2 = 'log')

def get_modeling_mode():
    dirpath = path.dirname(path.abspath(__file__)) + _helper.SEPARATOR + 'opt_problem' + _helper.SEPARATOR + 'model_quality'
    filename = dirpath +  _helper.SEPARATOR + 'set_modeling_mode.txt'
    with open(filename) as f:
        for s_line in f:
            s = repr(s_line).split(':')
            if s[0].split('\'')[1] == 'modeling mode':
                modeling_mode = s[-1].split('\\')[0].split()[0]
                break
    return modeling_mode

def save_LP_result_file(filename, problem, status):
    slacks = []
    with open(filename, mode='w') as f:
        f.write('Used Solver: ' + problem.solver.name + '. \n')
        f.write('Optimization Results Status: ' + status + '. \n')
        if status == 'Infeasible':
            if problem.solver.name == 'PULP_CBC_CMD': # default
                for name, constraint in problem.constraints.items():
                    if ('<=' in str(constraint) and constraint.slack < 0) or (">=" in str(constraint) and constraint.slack > 0):
                        f.write('Constraint {}: {} is violating because slack value = {}. \n'.format(name, str(constraint), constraint.slack))
                        slacks.append(constraint.slack)
                f.write('Total constraints violation value: ' + str(np.abs(np.array(slacks)).sum()) + '. \n')
                f.write('Number of violating constraints: ' + str(len(slacks)) + '.')
            else:
                f.write('A solver other than PULP_CBC_CMD is used. \n')
                f.write('Constraints violation values cannot be displayed on log file.')
        else:
            f.write('Feasible.')


def main():
    # parameter setting
    (alg_para, run_max) = get_opt_module_param.get_opt_module_param(_helper.WORKPATH, _helper.SEPARATOR)
    #alg_para = [iter_max, population, "alg_name", **algorithm's other para.**]
    iter_max = alg_para[0]
    population = alg_para[1]

    date_clm = 'timestamp'
    (param_df, taglist_df, modellist_df, LRV_df, timestamp) = read_parameter_files(date_clm)
    print('start date = ', timestamp[0])
    print('end date = ', timestamp[-1])

    prob = LoadProblemParam(taglist_df, param_df, modellist_df, LRV_df)
    modeling_mode = get_modeling_mode()
    print('modeling mode: ' + modeling_mode)
    if modeling_mode in ['MLR','PLS']:
        func = OptProblemLP(prob, _helper.SEPARATOR)
        print('OptProblem: LP')
    else:
        func = OptProblem(prob, _helper.SEPARATOR)
        func.g_num = len(func.constraint_function(np.zeros(prob.N)))
        print('OptProblem: NLP or Black-box')
    print('Time = ', prob.Time)
    print('num_feat_total = ', prob.num_feat_total)


    # get path
    dir_base = _helper.make_output_dir(_helper.WORKPATH)
    file_base = dir_base + _helper.SEPARATOR + 'file' + _helper.SEPARATOR
    fig_base = dir_base + _helper.SEPARATOR + 'fig' + _helper.SEPARATOR
    
    # copy modeling mode file to other files
    new_path = shutil.copy(_helper.WORKPATH + _helper.SEPARATOR + 'opt_problem' + _helper.SEPARATOR + 'model_quality' + _helper.SEPARATOR + 'set_modeling_mode.txt', _helper.WORKPATH + _helper.SEPARATOR + 'output')

    param_df.index = timestamp
    param_df.to_csv(file_base + 'parameter.csv')


    # run loop    
    start_time = time.time()
    if modeling_mode in ['MLR','PLS']:
        filename = dir_base + _helper.SEPARATOR + 'problem.txt'
        (obj_gbest_box, x_gbest_final_box, inter_box, time_box, problem) = solve_LP(func, prob, start_time, filename)
    else:
        (obj_gbest_box, x_gbest_final_box, time_box) = loop_iteration(func, alg_para, run_max, start_time)

    if modeling_mode in ['MLR','PLS']:
        str_clm = ['all dimension', 'dimension', 'g_num']
        num_clm = [len(problem.variables()), x_gbest_final_box.shape[0], len(problem.constraints)]   
    else:
        str_clm = ['dimension', 'iter_max', 'population', 'run_max', 'g_num']
        num_clm = [prob.N, iter_max, population, run_max, func.g_num]   
    print(str_clm)
    print(num_clm)
    _helper.make_setfile(dir_base, str_clm, num_clm)


    # result save
    if modeling_mode in ['MLR','PLS']:
        save_LP_result_file(dir_base + _helper.SEPARATOR + 'optimization_result.txt', problem, obj_gbest_box[1])

        # df_result: [[ave, std, max, min], [obj, vio]]
        # df_obj_feas_gbest_final: [run_max, [obj, vio]]
        df_time = pd.DataFrame(time_box, index=['sec','min','hour'])
        df_time.to_csv(file_base + "time.csv")
        df_result = pd.DataFrame(obj_gbest_box, index=['obj', 'solution status'])
        df_result.T.to_csv(file_base + "result.csv")

        df_x_gbest_final = pd.DataFrame(x_gbest_final_box.reshape(prob.num_feat_total, prob.delta_t))
        df_x_gbest_final.T.to_csv(file_base + "x_gbest_final.csv")

        df_inter = pd.DataFrame(inter_box.reshape(len(prob.inter_taglist), prob.delta_t))
        df_solution = pd.DataFrame(np.zeros((len(prob.allID_list), prob.delta_t)), index=prob.allID_list)

        for i, id in enumerate(prob.allID_list):
            if prob.seedmode_dict[id] == '0':
                df_solution.loc[id, :] = df_x_gbest_final.iloc[i, :]
            elif prob.seedmode_dict[id] == '1':
                df_solution.loc[id, :] = param_df.loc[:, id + '_Pattern']
            elif prob.seedmode_dict[id] == '2':
                df_solution.loc[id, :] = df_inter.iloc[i-14, :]
        #x_feas_gbest_final_box = x_feas_cbest_gbest_final_box[1, :, :].reshape(prob.num_feat_total, prob.Time, run_max)
        #x_feas_gbest_final: (N, run_max)
        df_solution.to_csv(file_base + "x2D_gbest_final_run0.csv")
        print ("file saving finished.")

    else:
        # df_result: [[ave, std, max, min], [obj, vio]]
        # df_obj_feas_gbest_final: [run_max, [obj, vio]]
        run_idx = ['run'+str(i+1) for i in range(0, run_max)]
        df_time = pd.DataFrame(time_box, index=run_idx + ['average'], columns=['sec','min','hour'])
        df_time.to_csv(file_base + "time.csv")

        df_x_gbest_final = pd.DataFrame(x_gbest_final_box)
        df_x_gbest_final.to_csv(file_base + "x_gbest_final.csv")

        #x_feas_gbest_final_box = x_feas_cbest_gbest_final_box[1, :, :].reshape(prob.num_feat_total, prob.Time, run_max)
        #x_feas_gbest_final: (N, run_max)
        x_feas_gbest_final = x_gbest_final_box.reshape(-1, run_max)

        #x_2D_feas_gbest_final_box = x_feas_gbest_final.reshape(prob.num_feat_total, prob.delta_t, run_max)
        x_2D_feas_gbest_final_box = np.zeros((prob.num_feat_total, prob.delta_t, run_max))
        big_x_2D_feas_gbest_final_box = np.zeros((prob.num_allfeat_total, prob.delta_t, run_max))
        # param_box: ((iter_max, 2, m, run_max))
        for run in range(0, run_max):
            x_2D_feas_gbest_final_box[:, :, run] = func.convert_x_to_schedule(x_feas_gbest_final[:, run])
            big_x_2D_feas_gbest_final_box[:, :, run] = func.get_big_x_2D(x_2D_feas_gbest_final_box[:, :, run])
            df_x_2D_feas_gbest_final = pd.DataFrame(big_x_2D_feas_gbest_final_box[:, :, run], index=prob.allID_list)
            df_x_2D_feas_gbest_final.to_csv(file_base + "x2D_gbest_final_run" + str(run) + ".csv")
            df_feas_gbest = pd.DataFrame(obj_gbest_box[:, :, run], columns=['gbest_obj', 'gbest_vio'])
            df_feas_gbest.to_csv(file_base + "gbest_run" + str(run) + ".csv")

        (df_result, df_obj_feas_gbest_final) = get_result(obj_gbest_box[-1, :, :])
        df_result['cost'] = df_result['obj'] - func.get_pena(x_2D_feas_gbest_final_box[:, :, 0])
        df_result.to_csv(file_base + "result.csv")

        #x_each_vio_final: (v_num+1, run_max)
        each_vio_final = ViolationEvaluation().get_each_vio(func, x_feas_gbest_final.T).T
        v_num = len(each_vio_final)
        each_vio_final = np.append(each_vio_final, np.sum(each_vio_final, axis=0))
        ll = np.arange(v_num).tolist()
        ll = [str(n) for n in ll] + ['sum']
        df_each_vio_final = pd.DataFrame(each_vio_final, index=ll, columns=run_idx)
        df_each_vio_final.to_csv(file_base + "each_vio_final.csv")

        print ("file saving finished.")

        # figure save
        figures(fig_base, obj_gbest_box)
        print ("figure saving finished.")

    # time finish
    end_time = time.time()
    cal_time = end_time - start_time
    print('time = %f sec = %f min' % (cal_time, cal_time/60))

    
if __name__ == "__main__":
    main()
