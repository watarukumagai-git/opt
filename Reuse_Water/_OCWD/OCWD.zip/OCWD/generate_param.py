# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd

from pkg import helper

_helper = helper.Helper()
_helper.WORKPATH = _helper.get_workpath('cd')

def get_master(_masterfile, _dateclm):
    def _index_to_datetime(_df, ts_clm):
        _df.loc[:, ts_clm] = pd.to_datetime(_df.loc[:, ts_clm])
        _df.set_index(ts_clm, inplace=True)
        return _df
    dir_base = _helper.WORKPATH + _helper.SEPARATOR + 'input'
    df1 = pd.read_csv(dir_base + _helper.SEPARATOR + _masterfile, header=0)
    df2 = pd.read_csv(dir_base + _helper.SEPARATOR + 'taglist.csv', header=0, index_col=0)
    if _dateclm != 'timestamp':
        df1.rename(columns={_dateclm: 'timestamp'}, inplace=True)
    date = df1.loc[:, 'timestamp'].tolist()
    # datetime transformation
    if '/' in date[0] and 'description' == date[-1]:
        df1 = _index_to_datetime(df1.iloc[:-2], 'timestamp')
    df2 = df2.fillna(-999)
    return df1, df2, dir_base

def add_calculation_tag(_data):
    def _conc_flow(_df, feedflow, permeateflow):
        return _df[feedflow] - _df[permeateflow]
    def _conc_EC(_df, feedflow, feedEC, permeateflow, permeateEC, concflow):
        return (_df[feedflow]*_df[feedEC] - _df[permeateflow]*_df[permeateEC]) / _df[concflow]
        
    _data["S1 Feed Flow Rate"] = _data[["RO_B01 Blank 1 Perm Flow","RO_B01 Blank 2 Perm Flow","RO_B01 Blank 3 Perm Flow","RO_B01 Conc Flow"]].sum(axis=1)
    _data[_data["S1 Feed Flow Rate"] < 0.01] = 0.01
    _data["S2 Feed Flow Rate_calc"] = _conc_flow(_data, "S1 Feed Flow Rate", "RO_B01 Blank 1 Perm Flow")
    _data[_data["S2 Feed Flow Rate_calc"] < 0.01] = 0.01
    _data["S3 Feed Flow Rate_calc"] = _conc_flow(_data, "S2 Feed Flow Rate_calc", "RO_B01 Blank 2 Perm Flow")
    _data[_data["S3 Feed Flow Rate_calc"] < 0.01] = 0.01
    _data["S2 Feed EC_calc"] = _conc_EC(_data, "S1 Feed Flow Rate", "RO_Feed Cond", "RO_B01 Blank 1 Perm Flow", "RO_B01 Blank 1 Perm Cond", "S2 Feed Flow Rate_calc")
    _data[_data["S2 Feed EC_calc"] < 0.01] = 0.01
    _data["S3 Feed EC_calc"] = _conc_EC(_data, "S2 Feed Flow Rate_calc", "S2 Feed EC_calc", "RO_B01 Blank 2 Perm Flow", "RO_B01 Blank 2 Perm Cond", "S3 Feed Flow Rate_calc")
    _data[_data["S3 Feed EC_calc"] < 0.01] = 0.01
    clm = ["Sulfric Acid Usage", "Threshold Inhibitor Usage"]
    _data[clm] = (_data[clm]/48).fillna(method='ffill')
    return _data


def get_parambase(df_master, df_taglist):
    def _dict_to_list(dict_, clm_):
        return list(dict_[clm_].values())

    base_clm = ['Pattern', 'SeedFlag', 'Min', 'Max']

    dict_tag = df_taglist.to_dict(orient='index')
    tagid_list = _dict_to_list(dict_tag, 'tag ID')
    idno_list = dict_tag['Description'].keys()
    seedmode_list = list(np.float_(_dict_to_list(dict_tag, 'SeedMode')))
    min_list = list(np.float_(_dict_to_list(dict_tag, 'min')))
    max_list = list(np.float_(_dict_to_list(dict_tag, 'max')))

    df_master = df_master.loc[:, tagid_list]
    idx_list = df_master.index.tolist()
    clm_list = [no + '_' + base for no in idno_list for base in base_clm]
    
    df_param = pd.DataFrame(np.zeros((len(idx_list), len(clm_list))), columns = clm_list)
    df_param['timestamp'] = idx_list
    df_param.set_index('timestamp', inplace=True)

    for idx, id in enumerate(idno_list):
        # actual
        tag = tagid_list[idx]
        df_param.loc[:, id + '_Pattern'] = df_master.loc[:, tag]
        # seedflag
        df_param.loc[:, id + '_SeedFlag'] = seedmode_list[idx]
        if seedmode_list[idx] == 0:
            df_param.loc[idx_list[0], id + '_SeedFlag'] = 1
        # min
        if min_list[idx] == -999:
            df_param.loc[:, id + '_Min'] = df_master.loc[:, tag].min(axis=0)
        else:
            df_param.loc[:, id + '_Min'] = min_list[idx]
        # max
        if max_list[idx] == -999:
            df_param.loc[:, id + '_Max'] = df_master.loc[:, tag].max(axis=0)
        else:
            df_param.loc[:, id + '_Max'] = max_list[idx]
    df_param = df_param.fillna(method='ffill')
    return df_param



def main():
    print ('file reading.')

    ### INPUT ###
    date_str = '2022-05-20 00:00:00'
    date_end = '2022-05-27 00:00:00'
    masterfile = 'master_2021_2022_30min_edit_ver2.csv'
    date_clm = 'Date / Time'    # timestamp clm name in masterfile

    # read masterfile
    (df_master, df_taglist, dir_base) = get_master(masterfile, date_clm)
    df_master = df_master.loc[date_str:date_end,:]

    # add calc tagid
    df_master = add_calculation_tag(df_master)

    df_param = get_parambase(df_master, df_taglist)
    df_param.to_csv(dir_base + _helper.SEPARATOR + 'parameter.csv')
    print ('file saving finished.')


if __name__ == "__main__":
    main()
