# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd

from pkg import helper

_helper = helper.Helper()
_helper.WORKPATH = _helper.get_workpath('cd')

def get_master(_masterfile):
    dir_base = _helper.WORKPATH + _helper.SEPARATOR + 'input'
    df1 = pd.read_csv(dir_base + _helper.SEPARATOR + _masterfile, header=0, index_col=0)
    df2 = pd.read_csv(dir_base + _helper.SEPARATOR + 'taglist.csv', header=0, index_col=0)
    df2 = df2.fillna(-999)
    return df1, df2, dir_base

def get_parambase(df_master, df_taglist):
    def _dict_to_list(dict_, clm_):
        return list(dict_[clm_].values())

    base_clm = ['Pattern', 'SeedFlag', 'Min', 'Max']

    dict_tag = df_taglist.to_dict(orient='index')
    tagid_list = _dict_to_list(dict_tag, 'tag ID')
    idno_list = dict_tag['Description'].keys()
    seedmode_list = list(np.float_(_dict_to_list(dict_tag, 'SeedMode')))
    min_list = list(np.float_(_dict_to_list(dict_tag, 'min')))
    max_list = list(np.float_(_dict_to_list(dict_tag, 'max')))

    df_master = df_master.loc[:, tagid_list]
    idx_list = df_master.index.tolist()
    clm_list = [no + '_' + base for no in idno_list for base in base_clm]
    
    df_param = pd.DataFrame(np.zeros((len(idx_list), len(clm_list))), columns = clm_list)
    df_param['timestamp'] = idx_list
    df_param.set_index('timestamp', inplace=True)

    for idx, id in enumerate(idno_list):
        # actual
        tag = tagid_list[idx]
        df_param.loc[:, id + '_Pattern'] = df_master.loc[:, tag]
        # seedflag
        df_param.loc[:, id + '_SeedFlag'] = seedmode_list[idx]
        if seedmode_list[idx] == 0:
            df_param.loc[idx_list[0], id + '_SeedFlag'] = 1
        # min
        if min_list[idx] == -999:
            df_param.loc[:, id + '_Min'] = df_master.loc[:, tag].min(axis=0)
        else:
            df_param.loc[:, id + '_Min'] = min_list[idx]
        # max
        if max_list[idx] == -999:
            df_param.loc[:, id + '_Max'] = df_master.loc[:, tag].max(axis=0)
        else:
            df_param.loc[:, id + '_Max'] = max_list[idx]
    df_param = df_param.fillna(method='ffill')
    return df_param


def main():
    ### INPUT ###
    plant = 'OCWD'
    optimize_period = ['2022-05-20 00:00:00', '2022-05-27 00:00:00']
    masterfile = plant + '_master_preprocessed.csv'

    # read masterfile
    (df_master, df_taglist, dir_base) = get_master(masterfile)
    df_master = df_master.loc[optimize_period[0]:optimize_period[1]]

    df_param = get_parambase(df_master, df_taglist)
    df_param.to_csv(dir_base + _helper.SEPARATOR + 'parameter.csv')

    print('parameter file generation has finished.')

if __name__ == "__main__":
    main()
