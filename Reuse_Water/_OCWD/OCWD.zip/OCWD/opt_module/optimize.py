#coding: utf-8
import gc
import time
import numpy as np

from .modify_x import Modx
from .get_eval import Superior
from .SHADE.DE_update import SolutionUpdator
from .SHADE.update_param import ParamUpdator

class Optimize:
    def __init__(self, prob, alg_para):
        self.prob = prob
        self.alg_para = alg_para

    def main_loop(self):
        # get parameters
        # problem parameters
        N = self.prob.load_pro.N
        # algorithm parameters
        iter_max = self.alg_para[0]
        population = self.alg_para[1]

        # 1. databox gene
        obj_box = np.zeros((population, iter_max))
        # obj_gbest_box: [obj, vio_sum]
        obj_gbest_box = np.zeros((2, iter_max))

        # 2. initial solution
        data = np.random.rand(500, 1000)
        #x = data[0:m, 0:N]*(prob.xmax-prob.xmin) + prob.xmin
        # x_ul: (N, 2), [min, max]
        x = data[:population, :N]*(self.prob.load_pro.x_ul[:, 1]-self.prob.load_pro.x_ul[:, 0]) + self.prob.load_pro.x_ul[:, 0]

        del data
        gc.collect()

        # get obj: (m, 4)
        (obj, each_vio) = Superior().eval_scaler(self.prob, x)
        # get vio_sum: (m)
        # each_vio: (m, g_num)

        # vio = sigma_{j=1, L} orm_j
        # vio_eval = sigma_{j=1, L} orm_j
        # vio_eval = sigma_{j=1, L} (orm_max - orm_j / orm_max - orm_min)
        # orm_max = max_{i=1,...,m} orm_j
        # orm_min = min_{i=1,...,m} orm_j
        # orm_j : (m, L) [0, g_j(x)]

        # mod_type: round, reflect, torus
        mod_type = 'round'
        mod = Modx(self.prob.load_pro.x_ul, type_mod=mod_type)

        iter = 0

        idx_gbest = Superior().get_min_idx_array(obj)
        x_gbest = mod.modified_x(x[idx_gbest, :].copy())
        (obj_gbest, each_vio) = Superior().eval_scaler(self.prob, x_gbest)
        print(obj_gbest)

        # 3. iteration loop
        DE_x_update_instance = SolutionUpdator(population, N)
        DE_param_update_instance = ParamUpdator(population)
        s_F = []
        s_C = []
        (DE_x_update_instance.F, DE_x_update_instance.C) = DE_param_update_instance.update_param(s_F, s_C, iter)

        while (iter <= iter_max - 1):
            # 4. solution update
            (x, obj) = DE_x_update_instance.DE_update(self.prob, x, obj, mod)
            s_F = DE_x_update_instance.F[DE_x_update_instance.update_idx_]
            s_C = DE_x_update_instance.C[DE_x_update_instance.update_idx_]
            (DE_x_update_instance.F, DE_x_update_instance.C) = DE_param_update_instance.update_param(s_F, s_C, iter)
            idx_gbest = Superior().get_min_idx_array(obj)
            x_gbest = mod.modified_x(x[idx_gbest, :].copy())
            (obj_gbest, each_vio) = Superior().eval_scaler(self.prob, x_gbest)

            # other data update
            obj_box[:, iter] = obj[:, 1].copy()
            obj_gbest_box[:, iter] = obj_gbest.copy()

            iter = iter + 1

        return obj_box, x_gbest, obj_gbest_box