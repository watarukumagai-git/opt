#coding: utf-8
import os
import numpy as np
from ..get_eval import Superior
import concurrent.futures as confu

num_workers = os.cpu_count() // 2

def _gene_child(i, p, x, F):
    idx_ori = np.arange(x.shape[0])
    idx = np.delete(idx_ori, np.where(idx_ori == i))
    r = np.random.choice(idx, size=2, replace=False)
    return x[i, :] + F * (x[p, :] - x[i, :] + x[r[0], :] - x[r[1], :])

class SolutionUpdator:
    def __init__(self, population, N):
        self.population = population
        self.N = N
        self.RHO_MIN = 2/self.population
        self.RHO_MAX = 0.2

    def neighbor_gene(self, x_, obj_, mod):
        def _mutate(F, x_, idx_rank, num_better):
            # obj: (m,), rank
            child = np.copy(x_)
            p = [np.random.choice(idx_rank[:idx], replace=True) for idx in num_better]
            #task_list = ((i, p[i], x_, F[i]) for i in range(0, self.population))
            ii = [i for i in range(0, self.population)]
            pp = [p[i] for i in range(0, self.population)]
            xx = [x_ for i in range(0, self.population)]
            FF = [F[i] for i in range(0, self.population)]
            with confu.ProcessPoolExecutor(max_workers=num_workers) as executor:
            #    for i, result in enumerate(executor.map(_gene_child, task_list)):
                for i, result in enumerate(executor.map(_gene_child, ii, pp, xx, FF)):
                    child[i, :] = result
            return child

        def _xover(C, x1_, x2_):
            # theta: (m, N)
            theta = np.random.rand(self.population, self.N)
            lambda_ = np.random.randint(0, self.N, size=self.population)
            # binomial crossover
            child = np.copy(x1_)
            nidx = [np.where(theta[idx, :] <= c)[0] for (idx, c) in enumerate(C)]
            for i in range(0, self.population):
                child[i, nidx[i]] = x2_[i, nidx[i]]
                child[i, lambda_[i]] = x2_[i, lambda_[i]]
            return child

  	    # x_: (population, N)
	    # obj_: (population,)
        rho = np.random.rand(self.population)*(self.RHO_MAX-self.RHO_MIN) + self.RHO_MIN
        idx_rank = Superior().get_rank(obj_)
        # superior individual number in the range [2, m*rho]
        num_better = np.clip(self.population * rho, 2, None).astype(int)
        u = _mutate(self.F, x_, idx_rank, num_better)
        #crossover / modify
        return mod.modified_x(_xover(self.C, x_, u))


    def selection(self, x__, obj__, x_nei__, obj_nei__):
        update_idx_ = Superior().get_sup_idx_array(obj__, obj_nei__)
        if len(update_idx_) > 0:
            x__[update_idx_, :] = x_nei__[update_idx_, :].copy()
            obj__[update_idx_, :] = obj_nei__[update_idx_, :].copy()
        return x__, obj__, update_idx_

    def DE_update(self, prob, x, obj, mod):
        x_nei = self.neighbor_gene(x, obj, mod)
        (obj_nei, each_vio_nei) = Superior().eval_scaler(prob, x_nei)
        (x_, obj_, self.update_idx_) = self.selection(x, obj, x_nei, obj_nei)
        return x_, obj_