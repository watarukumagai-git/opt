#coding: utf-8
import numpy as np
from .DE_model import Crossover, Mutation
from ..get_eval import Superior

class SolutionUpdator:
    def __init__(self, population, N):
        self.population = population
        self.N = N
        self.mutation_type = 'CP1'
        self.crossover_type = 'binomial'
        self.rho_min = 2/self.population
        self.rho_max = 0.2

    def neighbor_gene(self, prob, x_, obj_, mod):
  	    # x_: (population, N)
	    # obj_: (population,)
        num_diff = 1
        
        #mutation
        mutate = Mutation(self.F, x_)
        if self.mutation_type == 'rand1':
            u = mutate.rand(num_diff=num_diff)
        elif self.mutation_type == 'CP1':
            rho = np.random.rand(self.population)*(self.rho_max-self.rho_min) + self.rho_min
            idx_rank = Superior().get_rank(obj_, 4)
            num_better = np.clip(self.population*rho, 2, None).astype(int)
            u = mutate.CP(idx_rank, num_better, num_diff=num_diff)

        #crossover
        xover = Crossover(self.C, x_, u)
        if self.crossover_type == 'binomial':
            u = xover.binomial()
        
        #modify
        mod_x = mod.modified_x(u)
        return mod_x


    def selection(self, prob, x__, obj__, x_nei__, obj_nei__):
        update_idx_ = Superior().get_sup_idx_array(obj__, obj_nei__, 4)
        if len(update_idx_) > 0:
            x__[update_idx_, :] = x_nei__[update_idx_, :].copy()
            obj__[update_idx_, :] = obj_nei__[update_idx_, :].copy()
        return x__, obj__, update_idx_

    def DE_update(self, prob, x, obj, mod):
        x_nei = self.neighbor_gene(prob, x, obj, mod)
        (obj_nei, each_vio_nei) = Superior().eval_scaler(prob, x_nei)
        (x_, obj_, update_idx_) = self.selection(prob, x, obj, x_nei, obj_nei)
        self.update_idx_ = update_idx_
        return x_, obj_