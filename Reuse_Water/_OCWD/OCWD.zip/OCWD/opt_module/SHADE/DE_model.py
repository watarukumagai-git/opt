#coding: utf-8
import numpy as np

class Mutation:
    def __init__(self, F, x_):
        self.x = x_.copy()
        (self.m, self.N) = x_.shape
        self.F = F*np.ones(self.m)

    def rand(self):
        child = np.zeros((self.m, self.N))
        r = np.zeros((self.m, 3)).astype(int)
        idx_ori = np.arange(self.m)
        for i in range(0, self.m):
            idx = np.delete(idx_ori, np.where(idx_ori == i))
            r[i, :] = np.random.choice(idx, size=3, replace=False)
        y = self.x[r[:, 0],:]
        u = self.x[r[:, 1],:] - self.x[r[:, 2],:]
        for i in range(0, self.m):
            child[i, :] = y[i, :] + self.F[i] * u[i, :]
        return child

    def CP(self, idx_rank, num_better):
        # obj: (m,), rank
        child = np.zeros((self.m, self.N))
        idx_ori = np.arange(self.m)
        if len(num_better) > 0:
            p = np.zeros(self.m).astype(int)
            for (i, idx) in enumerate(num_better):
                p[i] = np.random.choice(idx_rank[:idx], replace=True)
        else:
            p = np.random.choice(idx_rank[:num_better], size=self.m, replace=True)
        for i in range(0, self.m):
            idx = np.delete(idx_ori, np.where(idx_ori == i))
            r = np.random.choice(idx, size=2, replace=False)
            child[i, :] = self.x[i, :] + self.F[i] * (self.x[p[i],:] - self.x[i,:] + self.x[r[0],:] - self.x[r[1],:])
        return child
    
    
class Crossover:
    def __init__(self, C, x1_, x2_):
        self.x1 = x1_.copy()
        self.x2 = x2_.copy()
        (self.m, self.N) = x1_.shape
        self.C = C*np.ones(self.m)

    def binomial(self):
        # theta: (m, N)
        theta = np.random.rand(self.m, self.N)
        lambda_ = np.random.randint(0, self.N, size=self.m)
        # binomial crossover
        child = np.copy(self.x1)
        for i in range(0, self.m):
            nidx = np.where(theta[i, :] <= self.C[i])
            child[i, nidx] = self.x2[i, nidx]
            child[i, lambda_[i]] = self.x2[i, lambda_[i]]
        return child