#coding: utf-8
import numpy as np

class Modx:
    def __init__(self, x_ul, type_mod='round'):
        self.type_mod = type_mod
        self.x_ul = x_ul
            
    def modified_x(self, x_, ):
        def _mod(x_, x_ul, lowup, type_mod):
            if lowup == 'low':
                if type_mod == 'round':
                    return x_ul[:,0]
                elif type_mod == 'reflect':
                    return x_ul[:,0] + np.abs(x_-x_ul[:,0])
                elif type_mod == 'torus':
                    return x_ul[:,1] - np.abs(x_-x_ul[:,0])
            elif lowup == 'up':
                if type_mod == 'round':
                    return x_ul[:,1]
                elif type_mod == 'reflect':
                    return x_ul[:,1] - np.abs(x_ul[:,1]-x_)
                elif type_mod == 'torus':
                    return x_ul[:,0] + np.abs(x_ul[:,1]-x_)

        if self.type_mod == 'none':
            x_ = np.copy(x_)
        else:
            while (x_ < self.x_ul[:, 0]).any() or (x_ > self.x_ul[:, 1]).any():
                x_ = np.where(x_<self.x_ul[:,0], _mod(x_, self.x_ul, 'low', self.type_mod), x_)
                x_ = np.where(x_>self.x_ul[:,1], _mod(x_, self.x_ul, 'up', self.type_mod), x_)
        return x_