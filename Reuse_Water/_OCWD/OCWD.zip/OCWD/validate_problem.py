# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
import time

from pkg import helper
from pkg.save_figure import SaveFigure
from opt_module.get_eval import ViolationEvaluation
from opt_problem.define_opt_problem import OptProblem, LoadProblemParam

_helper = helper.Helper()
_helper.WORKPATH = _helper.get_workpath('cd')

def read_parameter_files(date_clm):
    dir_base = _helper.WORKPATH + _helper.SEPARATOR + 'input'
    df1 = pd.read_csv(dir_base + _helper.SEPARATOR + 'parameter.csv', header=0)
    df2 = pd.read_csv(dir_base + _helper.SEPARATOR + 'taglist.csv', header=0, index_col=0)
    df3 = pd.read_csv(dir_base + _helper.SEPARATOR + 'modellist.csv', header=0, index_col=0)
    timestamp = pd.to_datetime(df1.loc[:,date_clm]).tolist()
    df1 = df1.drop(date_clm, axis=1)
    return df1, df2, df3, timestamp


def figures(fig_base, prob, param_df, big_x_2D, timestamp):
    min_x = prob.bigbigx_ul[:, 0].reshape(prob.num_allfeat_total, prob.delta_t)
    max_x = prob.bigbigx_ul[:, 1].reshape(prob.num_allfeat_total, prob.delta_t)

    labels2 = ['actual', 'predicted', 'lower limit', 'upper limit']
    figure_label2 = ["Datetime", labels2]
    figure_label3 = ["Datetime"]
    id = list(prob.alltagdict['Description'].keys())

    # 'minmax'
    minmax_status = 'none'
    lang = 'eng'
    dateformat = '%d-%b-%y %H'
                
    # x trend
    for i, _id in enumerate(id):
        tag = prob.alltagdict['Description'][_id]
        fig_file_name = fig_base + _helper.SEPARATOR + tag + '.png'
        if _id in prob.inter_taglist:
            figure_label2i = figure_label2 + [tag, [min_x[i, 0], max_x[i, 0]]]
            SaveFigure().trend_four(figure_label2i, 
                                    timestamp, 
                                    param_df.loc[:, _id + '_Pattern'], 
                                    big_x_2D[i, :], 
                                    fig_file_name,
                                    minmax_status,
                                    lang,
                                    dateformat,
                                    )

        else:
            figure_label2i = figure_label3 + [tag, [min_x[i, 0], max_x[i, 0]]]
            SaveFigure().trend(figure_label2i, 
                                timestamp, 
                                param_df.loc[:, _id + '_Pattern'], 
                                fig_file_name,
                                minmax_status,
                                lang,
                                dateformat,
                                )



def main():
    date_clm = 'timestamp'
    (param_df, taglist_df, modellist_df, timestamp) = read_parameter_files(date_clm)
    print('start date = ', timestamp[0])
    print('end date = ', timestamp[-1])

    prob = LoadProblemParam(taglist_df, param_df, modellist_df)
    func = OptProblem(prob, _helper.SEPARATOR)
    func.g_num = len(func.constraint_function(np.zeros(prob.N)))
    print('Time = ', prob.Time)
    print('num_feat_total = ', prob.num_feat_total)


    # get path
    dir_base = _helper.make_output_validate_dir(_helper.WORKPATH)
    str_clm = ['dimension', 'g_num']
    num_clm = [prob.N, func.g_num]   
    print(str_clm)
    print(num_clm)
    _helper.make_setfile(dir_base, str_clm, num_clm)


    start_time = time.time()
    pattern_2D = prob.pattern_all.copy()[func.idx_optnum_all, :]
    x = func.convert_schedule_to_x(pattern_2D)
    obj = func.object_function(x)
    (vio, each_vio) = ViolationEvaluation().get_vio(func, x)
    print('obj = {0}, vio = {1}'.format(obj,vio))

    file_base = dir_base + _helper.SEPARATOR + 'file' + _helper.SEPARATOR
    fig_base = dir_base + _helper.SEPARATOR + 'fig' + _helper.SEPARATOR

    # result save
    big_x_2D = func.get_big_x_2D(func.convert_x_to_schedule(x))
    df_big_x_2D = pd.DataFrame(big_x_2D, index=prob.allID_list)
    df_big_x_2D.to_csv(file_base + "x2D_validation.csv")
    df_obj_vio = pd.DataFrame([obj, vio], index=['obj', 'vio'])
    df_obj_vio.to_csv(file_base + "obj_vio.csv")
    df_each_vio = pd.DataFrame(each_vio, columns=['each_vio'])
    df_each_vio.to_csv(file_base + "each_vio.csv")
    
    print ("file saving finished.")

    # figure save
    figures(fig_base, prob, param_df, big_x_2D, timestamp)
    print ("figure saving finished.")

    # time finish
    end_time = time.time()
    cal_time = end_time - start_time
    print('time = %f sec = %f min' % (cal_time, cal_time/60))

    
if __name__ == "__main__":
    main()
