#coding: utf-8 
import numpy as np
import datetime
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import matplotlib.cm as cm
plt.rcParams['font.family'] = 'Times New Roman'

class figure_save_class:
    def trend(self, figure_label, y1, fig_file_name):
        x_label_name = figure_label[0]
        y_label_name = figure_label[1]
        y1_legend_name = figure_label[2]

        fig = plt.figure(figsize=(6,4))
        ax = fig.add_subplot(1,1,1)
        ax.plot(y1, "C0", label=y1_legend_name, lw=0.5)
        ax.set_xlabel(x_label_name, fontsize=16)
        ax.set_ylabel(y_label_name, fontsize=16)
        ax.tick_params(direction = "in")
        ax.grid(linestyle='dashdot')

        ax.legend(loc='upper right')
        plt.tick_params(labelsize=12)
        plt.tight_layout()
        plt.savefig(fig_file_name, bbox_inches="tight")


    def trend1(self, figure_label, x, y1, y2, fig_file_name):
        x_label_name = figure_label[0]
        y_label_name = figure_label[1]
        y1_legend_name = figure_label[2]
        y2_legend_name = figure_label[3]
        (y_min, y_max) = figure_label[4]

        fig = plt.figure(figsize=(6,4))
        ax = fig.add_subplot(1,1,1)
        ax.plot(x, y1, "C0", label=y1_legend_name, lw=0.5)
        ax.plot(x, y2, "C1", label=y2_legend_name, lw=0.5)
        ax.set_xlabel(x_label_name, fontsize=16)
        ax.set_ylabel(y_label_name, fontsize=16)
        ax.tick_params(direction = "in")
        ax.grid(linestyle='dashdot')
        #ax.set_ylim([y_min, y_max])
        ax.set_ylim(bottom=y_min)
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%y-%m-%d'))

        ax.legend(loc='lower left')
        plt.tick_params(labelsize=12)
        plt.tight_layout()
        plt.savefig(fig_file_name, bbox_inches="tight")


    def scatter(self, figure_label, x1, x2, fig_file_name):
        x_label_name = figure_label[0]
        y_label_name = figure_label[1]
        (x_min, x_max) = figure_label[2]
        (y_min, y_max) = figure_label[3]
        R_squared = figure_label[4]*100
        _max = np.min([x1.max(), x2.max()])
        _min = np.max([x1.min(), x2.min()])

        fig = plt.figure(figsize=(5,5))
        ax = fig.add_subplot(1,1,1)
 
        ax.scatter(x1, x2, s=2, marker="o", edgecolors='C0', facecolor='None', linewidths=0.3)

        ax.set_xlabel(x_label_name, fontsize=16)
        ax.set_ylabel(y_label_name, fontsize=16)
        #ax.set_xlim([x_min, x_max])
        #ax.set_ylim([y_min, y_max])
        ax.tick_params(direction = "in")
        plt.arrow(_min, _min, _max - _min, _max - _min, color='black', lw=0.2)
        ax.text(x1.max()*0.8, x2.min()*1.05, '$R^{2}$ = ' + str(round(R_squared, 2)) + ' %', size = 'xx-large')

        plt.tick_params(labelsize=12)
        plt.tight_layout()
        plt.savefig(fig_file_name)

    def scatter2(self, figure_label, x, y1, y2, fig_file_name):
        x_label_name = figure_label[0]
        y_label_name = figure_label[1]
        y1_legend_name = figure_label[2]
        y2_legend_name = figure_label[3]
        x_min = figure_label[4][0]
        x_max = figure_label[4][1]
        y_min = figure_label[5][0]
        y_max = figure_label[5][1]

        fig = plt.figure(figsize=(5,5))
        ax = fig.add_subplot(1,1,1)
 
        ax.scatter(x, y1, s=2, facecolor='None', edgecolors='C0', marker="o", linewidths=0.3, label=y1_legend_name)
        ax.scatter(x, y2, s=2, facecolor='None', edgecolors='C1', marker="o", linewidths=0.3, label=y2_legend_name)

        ax.set_xlabel(x_label_name, fontsize=16)
        ax.set_ylabel(y_label_name, fontsize=16)
        #ax.set_xlim([x_min, x_max])
        #ax.set_ylim([y_min, y_max])
        ax.tick_params(direction = "in")
        ax.legend(loc='upper right')

        plt.tick_params(labelsize=12)
        plt.tight_layout()
        plt.savefig(fig_file_name)
