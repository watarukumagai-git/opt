# -*- coding: utf-8 -*-
import time
import math
import os
from os import path

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.inspection import PartialDependenceDisplay, permutation_importance
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import mean_squared_error, make_scorer
from lineartree import LinearTreeRegressor
import matplotlib.pyplot as plt


if 'My Drive' in os.getcwd():
    separator = '/'
    work_path = os.getcwd()
else:
    separator = '\\'
    work_path = path.dirname( path.abspath(__file__) )
    os.chdir(work_path)


def make_setfile(dir_base, str_list, num_list):
    f = open(dir_base + separator + 'set_file.txt', 'w')
    for i in range(0,len(str_list)):
        f.write(str_list[i] + ' = ' + str(num_list[i]) + '\n')
    f.close()

def X_y_split(data):  
    # data should be pd.DataFrame()
    docY = data.iloc[:, 0]
    docX = data.iloc[:, 1:]
    return docX, docY
    
def get_path():
    dir_base = work_path + separator + 'output'
    fig_base = dir_base + separator + 'fig'
    file_base = dir_base + separator + 'file'
    my_makedirs(dir_base)
    my_makedirs(fig_base)
    my_makedirs(file_base)
    return dir_base, fig_base, file_base


def get_parameter():
    df1 = pd.read_csv(work_path + separator + 'input' + separator + 'master_preprocessed_edit.csv', header=0, index_col=0, dtype=str)
    df1_unit = df1["unit":]
    df1 = df1[:df1.index.get_loc('unit')] 
    df1.reset_index(inplace=True)
    df1['Date / Time'] = pd.to_datetime(df1['Date / Time'])
    df1.set_index("Date / Time",inplace=True)
    df1 = df1.astype('float')
    return df1

    
def my_makedirs(path):
    if not os.path.isdir(path):
        os.makedirs(path)


def split_data(df, x_list, y_list, tra_period, test_period):
    def _list_check(list1, list2):
        return set(list1).issubset(list2)

    def _select_idx_dataframe(df, clm, txt):
        if _list_check(clm, np.arange(len(df.columns.tolist())).tolist()):
            df = pd.concat([df.iloc[:, 0], df.iloc[:, clm]], axis=1)
        else:
            df = 0
            print('input data does not contain ' + txt + '.')
        return df

    def _select_clm_dataframe(df, period, txt):
        df_ = df.loc[period[0]:period[1], :]
        return df_
    
    #def my_index_multi(l, x):
    #return [i for i, _x in enumerate(l) if _x == x]

    #x_num = []
    #for x in x_list:
    #    x_num.append(my_index_multi(df.columns.tolist(), x))

    # x_select
    #x_list = list(map(lambda x: x+1, x_list))
    list_ = x_list.copy()
    list_.insert(0, y_list)
    #df = _select_idx_dataframe(df, list_, 'x_list')
    df = df.loc[:, list_]
    print('y = ', y_list)
    print('x = ', x_list)

    # split
    print('training period: ', tra_period)
    print('predict period: ', test_period)
    df_tra = _select_clm_dataframe(df, tra_period, 'training period')
    df_test = _select_clm_dataframe(df, test_period, 'predict period')
    print('traning data')
    print(df_tra.shape)
    print(df_tra.head())
    print('validation data')
    print(df_test.shape)
    print(df_test.head())
    return df_tra, df_test

class Model:
    def __init__(self, model_mode = 'linear_tree'):
        if model_mode == 'linear_tree':
            sub_type = 'MLR'
            if sub_type == 'MLR':
                self.model = LinearTreeRegressor(base_estimator=LinearRegression())
        elif model_mode == 'RF':
                self.model = RandomForestRegressor(min_samples_split=2, random_state=1, n_estimators=50)
        else:
            self.model = 'ERROR'
        
    def fit(self, X, y):
        self.model.fit(X, y)

    def predict(self, X):
        return self.model.predict(X)
    
    def make_df(self, calc, df_, name):
        df_calc = pd.DataFrame(calc, index=df_.index, columns=[name])
        df_ = pd.concat([df_calc, df_], axis=1)
        df_.columns = [name, "actual"]
        print(df_)
        return df_

class model_CV:
    def __init__(self, modeling_mode, df_tra, df_val):
        self.modeling_mode = modeling_mode
        self.X_tra = df_tra.values[:, 1:]
        self.y_tra = df_tra.values[:, 0]
        self.X_val = df_val.values[:, 1:]
        self.y_val = df_val.values[:, 0]
        self.df_tra = df_tra
        self.df_val = df_val
        self.param_grid = {'n_estimators': [10, 30, 50, 100, 150, 200],
                           'max_features': ('sqrt', 'log2', None),  # ランダムに指定する特徴量の数
                          }

    def fit(self):
        if self.modeling_mode == 'MLR':
            self.model = LinearRegression()
        elif self.modeling_mode == 'RF':
            self.model = RandomForestRegressor(n_jobs=-1, 
                                               random_state=2525, 
                                               #max_depth=5
                                               )
        self.model.fit(self.X_tra, self.y_tra)

    def predict(self):
        def _unit_pre(df, model, X, y, prefix):
            y_pre = model.predict(X)
            y_array = np.vstack([y_pre, y]).T
            df_y_pre = pd.DataFrame(y_array, 
                                    index = df.index, 
                                    columns=[df.columns[0]+'_'+prefix, df.columns[0]+'_act'])
            print(df_y_pre.head())
            return df_y_pre
        
        df_y_pre = _unit_pre(self.df_val, self.model, self.X_val, self.y_val, 'pre')
        df_y_est = _unit_pre(self.df_tra, self.model, self.X_tra, self.y_tra, 'est')

        return df_y_pre, df_y_est

    def grid_search_CV(self):
        grid_search = GridSearchCV(self.model, self.param_grid, cv=5, scoring='neg_mean_squared_error')
        grid_search.fit(self.X_tra, self.y_tra)
        print('Training set score: {}'.format(grid_search.score(self.X_tra, self.y_tra)))
        print('Test set score: {}'.format(grid_search.score(self.X_val, self.y_val)))
        print('Best cross-validation: {}'.format(grid_search.best_score_))
        print('Best parameters: {}'.format(grid_search.best_params_))
        self.model = grid_search.best_estimator_
        df_params = pd.DataFrame.from_dict(grid_search.best_params_, orient='index')
        return df_params


def draw_trend_chart(df, fig_file_name):
    fig = plt.figure(figsize=(6,4))
    fig.patch.set_facecolor('white')
    ax = fig.add_subplot(1,1,1)
    x = pd.to_datetime(df.index)
    print('from ', x[0])
    print('to ', x[-1])
    
    ax.plot(x, df.iloc[:, 0], "C1", label=df.columns[0], lw=0.5)
    ax.plot(x, df.iloc[:, 1], "C0", label=df.columns[1], lw=0.5)
    ax.set_xlabel('timestamp', fontsize=10)
    ax.set_ylabel('y predict/actual', fontsize=10)
    ax.legend(loc='center', bbox_to_anchor=(0.5, 1.1), ncol=2)
    ax.tick_params(direction = "in")

    labelss = ax.get_xticklabels()
    plt.setp(labelss, rotation=60)
    plt.tick_params(labelsize=8)
    plt.tight_layout()
    plt.savefig(fig_file_name, bbox_inches="tight")


def PDP(model, imp_X, imp_features, fig_file_name):
    plt.rcParams['font.size'] = 18 #matplotlib.pyplot の文字サイズ設定
    fig, axes = plt.subplots(figsize=(12, 6)) #matplotlib.pyplot の描画準備
    fig.subplots_adjust(hspace=0.6, wspace=0.1) #間隔の設定
    disp_RFC = PartialDependenceDisplay.from_estimator(model, imp_X, imp_features, ax=axes) #プロット
    for i in range(disp_RFC.lines_.shape[0]):
        disp_RFC.axes_[i, 0].set_ylabel('y') #縦軸ラベルの設定
    plt.tight_layout()
    plt.savefig(fig_file_name, bbox_inches="tight")

def preprocessing(_df, span):
    _df = _df.where(_df > 0, np.nan)
    if span == 'daily' or span == '1day':
        _df = _df.resample('D').mean()
    else:
        _df = _df.resample(span).mean()
    _df = _df.interpolate('ffill').interpolate('bfill')
    return _df

def imputation(use_data, x_taglist):
    def Hampel(x, k=24, thr=3):
        idx = np.arange(len(x))
        output_x = x.copy()
        output_Idx = np.zeros_like(x)
        print(idx)
    
        for i, ele in enumerate(x):
            x_kernel = x[np.where( (idx <= (idx[i] + k)) & (idx >= (idx[i] - k)), True, False)]
            median = np.median(x_kernel)
            std = math.sqrt(np.median(np.multiply((x_kernel - median),(x_kernel - median))))
            
            if np.abs(ele - median) > thr * std:
                output_Idx[i] = 1
                output_x[i] = median
                
        return output_x

    # 標準化
    def set_stds(data, variable):
        data = pd.DataFrame(StandardScaler().fit_transform(data), columns=variable, index=data.index)
        return data

    # 外れ値除去  median で補間 k=24 thr=3
    use_data = use_data.fillna(method='ffill').fillna(method='bfill')
    #use_data = use_data.apply(Hampel, k=24, thr=3)
    # 標準化
    #use_data[x_taglist] = set_stds(use_data[x_taglist], x_taglist)
    return use_data

def rmse(y_true, y_pred):
    return np.sqrt(mean_squared_error(y_true, y_pred)) 

def feature_importance(rf_reg, X_test, y_test, imp_features, fig_file_name):
    result = permutation_importance(
                                    rf_reg, X_test, y_test, n_repeats=10, random_state=42, n_jobs=2
                                    )
    df = pd.DataFrame(result.importances_mean, index=imp_features, columns=['Permutation Feature Importances'])
    df['Std'] = result.importances_std

    fig, ax = plt.subplots()
    df['Permutation Feature Importances'].plot.bar(yerr=df['Std'].values, ax=ax)
    ax.set_ylabel("Mean decrease in impurity")
    fig.tight_layout()
    plt.savefig(fig_file_name, bbox_inches="tight")
    return df

def get_RMSE_MAPE(df_est, df_pre):
    # evaluation
    df_est.loc[:,"abs_error"] = df_est.loc[:,"actual"] - df_est.loc[:,"estimate"]
    df_est.loc[:,"abs_error"] = df_est.loc[:,"abs_error"].abs()
    df_est.loc[:,"rel_error"] = df_est.loc[:,"abs_error"] / (df_est.loc[:,"actual"].max() - df_est.loc[:,"actual"].min())
    df_pre.loc[:,"abs_error"] = df_pre.loc[:,"actual"] - df_pre.loc[:,"predict"]
    df_pre.loc[:,"abs_error"] = df_pre.loc[:,"abs_error"].abs()
    df_pre.loc[:,"rel_error"] = df_pre.loc[:,"abs_error"] / (df_pre.loc[:,"actual"])
    df_pre.loc[:,"rel_error"] = df_pre.loc[:,"abs_error"] / (df_pre.loc[:,"actual"].max() - df_pre.loc[:,"actual"].min())

    a = np.zeros((2, 2))
    df_MAPE_RMSE = pd.DataFrame(a, index=["est", "pre"], columns=["MAPE", "RMSE"])
    df_MAPE_RMSE.at["est","MAPE"] = df_est.loc[:, "rel_error"].mean()
    df_MAPE_RMSE.at["est","RMSE"] =  (df_est.loc[:, "abs_error"]**2).mean()**(0.5)
    df_MAPE_RMSE.at["pre","MAPE"] = df_pre.loc[:, "rel_error"].mean()
    df_MAPE_RMSE.at["pre","RMSE"] =  (df_pre.loc[:, "abs_error"]**2).mean()**(0.5)
    print (df_MAPE_RMSE)
    return df_est, df_pre, df_MAPE_RMSE


def main():
    # 'linear_tree', 'RF'
    modeling_mode = 'RF'
    grid_search_flag = False
    time_span = '60min'

    # time start
    print ("calculation started.")
    print('-----------------------------------')

    # x list (column number)
    #x_list = [0,2,4,5]
    x_list = ["RO_B01 FW Press",
              "RO_Feed Cond",
              "RO_01_FirstStageFeedFlow",
              "RO_Feed Temperature", 
              "RO_Feed Ph",
              "Sulfuric Acid Usage",
              "Threshold Inhibitor Usage",
              "RO_Feed Total Chlorine"
              ]
    y_list = 'RO_B01 Blank 1 Perm Cond'

    # training period
    #tra_period = ['2022/04/26 0:00','2022/05/19 23:30']
    tra_period = ['2022/04/26 0:00','2022/07/15 23:30']

    # predict period
    #pre_period = ['2022/05/20 0:00','2022/05/26 23:30']
    pre_period = ['2022/07/16 0:00','2022/11/20 23:30']

    # get path
    dir_base, fig_base, file_base = get_path()
    df = get_parameter()

    #df = imputation(df, x_list)
    df = preprocessing(df, time_span)


    # split train and test
    train, test = split_data(df, x_list, y_list, tra_period, pre_period)
    X_train, y_train = X_y_split(train)
    X_test, y_test = X_y_split(test)
    print("X_train: ", X_train.shape)
    print("y_train: ", y_train.shape)
    print("X_test: ", X_test.shape)
    print("y_test: ", y_test.shape)

    start_time = time.time()
    if grid_search_flag:
        # model instance
        model_ = model_CV(modeling_mode, train, test)
        model_.fit()
    else:
        model_ = Model(model_mode=modeling_mode)
        model_.fit(X_train, y_train)

    end_time = time.time()
    training_time = end_time - start_time
    print('training_time = {} sec = {} min'.format(training_time, training_time/60))

    start_time = time.time()
    if grid_search_flag:
        df_pre, df_est = model_.predict()
        end_time = time.time()
        df_params = model_.grid_search_CV()
        df_params.to_csv(file_base + separator + "best_params.csv")
    else:
        estimated = model_.predict(X_train)
        df_est = model_.make_df(estimated, y_train, 'estimate')
        predicted = model_.predict(X_test)
        end_time = time.time()
        df_pre = model_.make_df(predicted, y_test, 'predict')
    prediction_time = end_time - start_time
    print('prediction_time = {} sec = {} min'.format(prediction_time, prediction_time/60))

    df_est, df_pre, df_MAPE_RMSE = get_RMSE_MAPE(df_est, df_pre)    
    df_est.to_csv(file_base + separator + "estimate_" + modeling_mode + ".csv")
    df_pre.to_csv(file_base + separator + "predict_" + modeling_mode + ".csv")
    df_MAPE_RMSE.to_csv(file_base + separator + "result_" + modeling_mode + ".csv")
    df_time = pd.DataFrame(np.array([training_time, prediction_time]), index=['train', 'predict'])
    df_time.to_csv(file_base + separator + "calculation_time_" + modeling_mode + ".csv")

    draw_trend_chart(df_est, fig_base + separator + "estimate_" + modeling_mode + ".png")
    draw_trend_chart(df_pre, fig_base + separator + "predict_" + modeling_mode + ".png")

    #PDP(model_, train[x_list], x_list, fig_base + separator + "PDP_" + modeling_mode + ".png")
    #df_feature = feature_importance(model_, X_test, y_test, x_list, fig_base + separator + "feature_importance_" + modeling_mode + ".png")
    #df_feature.to_csv(file_base + separator + "feature_importance_" + modeling_mode + ".csv")

    print ("figure saving finished.")
    
if __name__ == "__main__":
    main()
