# -*- coding: utf-8 -*-
import time
import math
import os
from os import path

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score

from pkg.Model import Model, HyperSearch
from pkg.figure_save import figure_save_class


if 'My Drive' in os.getcwd():
    separator = '/'
    work_path = os.getcwd()
else:
    separator = '\\'
    work_path = path.dirname( path.abspath(__file__) )
    os.chdir(work_path)


def my_makedirs(DIR):
    if not os.path.exists(DIR):
        # ディレクトリが存在しない場合、ディレクトリを作成する
        os.makedirs(DIR)


def make_setfile(dir_base, str_list, num_list):
    f = open(dir_base + separator + 'set_file.txt', 'w')
    for i in range(0,len(str_list)):
        f.write(str_list[i] + ' = ' + str(num_list[i]) + '\n')
    f.close()

def X_y_split(data):  
    # data should be pd.DataFrame()
    docY = data.iloc[:, 0]
    docX = data.iloc[:, 1:]
    return docX, docY
    
def get_path():
    dir_base = work_path + separator + 'output'
    fig_base = dir_base + separator + 'fig'
    file_base = dir_base + separator + 'file'
    my_makedirs(dir_base)
    my_makedirs(fig_base)
    my_makedirs(file_base)
    fig_base = fig_base + separator
    file_base = file_base + separator
    return dir_base, fig_base, file_base


def get_parameter():
    df1 = pd.read_csv(work_path + separator + 'input' + separator + 'master_preprocessed_edit.csv', header=0, index_col=0, dtype=str)
    df1_unit = df1["unit":]
    df1 = df1[:df1.index.get_loc('unit')] 
    df1.reset_index(inplace=True)
    df1['Date / Time'] = pd.to_datetime(df1['Date / Time'])
    df1.set_index("Date / Time",inplace=True)
    df1 = df1.astype('float')
    return df1

    
def my_makedirs(path):
    if not os.path.isdir(path):
        os.makedirs(path)


def split_data(df, x_list, y_list, tra_period, test_period):
    def _list_check(list1, list2):
        return set(list1).issubset(list2)

    def _select_idx_dataframe(df, clm, txt):
        if _list_check(clm, np.arange(len(df.columns.tolist())).tolist()):
            df = pd.concat([df.iloc[:, 0], df.iloc[:, clm]], axis=1)
        else:
            df = 0
            print('input data does not contain ' + txt + '.')
        return df

    def _select_clm_dataframe(df, period, txt):
        df_ = df.loc[period[0]:period[1], :]
        return df_
    
    #def my_index_multi(l, x):
    #return [i for i, _x in enumerate(l) if _x == x]

    #x_num = []
    #for x in x_list:
    #    x_num.append(my_index_multi(df.columns.tolist(), x))

    # x_select
    #x_list = list(map(lambda x: x+1, x_list))
    list_ = x_list.copy()
    list_.insert(0, y_list)
    #df = _select_idx_dataframe(df, list_, 'x_list')
    df = df.loc[:, list_]
    print('y = ', y_list)
    print('x = ', x_list)

    # split
    print('training period: ', tra_period)
    print('predict period: ', test_period)
    df_tra = _select_clm_dataframe(df, tra_period, 'training period')
    df_test = _select_clm_dataframe(df, test_period, 'predict period')
    print('traning data')
    print(df_tra.shape)
    print(df_tra.head())
    print('validation data')
    print(df_test.shape)
    print(df_test.head())
    return df_tra, df_test




def preprocessing(_df, span):
    _df = _df.where(_df > 0, np.nan)
    if span == 'daily' or span == '1day':
        _df = _df.resample('D').mean()
    else:
        _df = _df.resample(span).mean()
    _df = _df.interpolate('ffill').interpolate('bfill')
    return _df

def imputation(use_data, x_taglist):
    def Hampel(x, k=24, thr=3):
        idx = np.arange(len(x))
        output_x = x.copy()
        output_Idx = np.zeros_like(x)
        print(idx)
    
        for i, ele in enumerate(x):
            x_kernel = x[np.where( (idx <= (idx[i] + k)) & (idx >= (idx[i] - k)), True, False)]
            median = np.median(x_kernel)
            std = math.sqrt(np.median(np.multiply((x_kernel - median),(x_kernel - median))))
            
            if np.abs(ele - median) > thr * std:
                output_Idx[i] = 1
                output_x[i] = median
                
        return output_x

    # 標準化
    def set_stds(data, variable):
        data = pd.DataFrame(StandardScaler().fit_transform(data), columns=variable, index=data.index)
        return data

    # 外れ値除去  median で補間 k=24 thr=3
    use_data = use_data.fillna(method='ffill').fillna(method='bfill')
    #use_data = use_data.apply(Hampel, k=24, thr=3)
    # 標準化
    #use_data[x_taglist] = set_stds(use_data[x_taglist], x_taglist)
    return use_data

def get_RMSE_MAPE(df_est, df_pre):
    a = np.zeros((2, 4))
    df_MAPE_RMSE = pd.DataFrame(a, index=["estimate", "predict"], columns=["MAPE", "RMSE", "RMSE rate","R-squared"])
    
    # evaluation
    for i, df_ in enumerate([df_est, df_pre]):
        name_ = df_MAPE_RMSE.index[i]
        df_.loc[:,"abs_error"] = df_.loc[:,"actual"] - df_.loc[:,name_]
        df_.loc[:,"abs_error"] = df_.loc[:,"abs_error"].abs()
        if 0 in df_.loc[:,"actual"]: 
            df_.loc[:,"rel_error"] = df_.loc[:,"abs_error"] / (df_.loc[:,"actual"].max() - df_.loc[:,"actual"].min())
        else:
            df_.loc[:,"rel_error"] = (df_.loc[:,"abs_error"] / df_.loc[:,"actual"]).abs()

        df_MAPE_RMSE.at[name_,"MAPE"] = df_.loc[:, "rel_error"].mean()
        df_MAPE_RMSE.at[name_,"RMSE"] =  (df_.loc[:, "abs_error"]**2).mean()**(0.5)
        df_MAPE_RMSE.at[name_,"RMSE rate"] =  (df_MAPE_RMSE.at[name_,"RMSE"])/df_.loc[:,"actual"].mean()
        df_MAPE_RMSE.at[name_,"R-squared"] = r2_score(df_.loc[:, 'actual'].values, df_.loc[:, name_].values)

    print (df_MAPE_RMSE)
    return df_est, df_pre, df_MAPE_RMSE

def get_init_params(modeling_mode):
    if modeling_mode == 'RF':
        # [NumTree=100, MaxDepth='None', MinSamplesSplit=2]
        init_params = {'n_estimators': 100, 
                       'max_depth': None, 
                       'min_samples_split': 2,
                       }
    elif modeling_mode == 'LinearTree':
        # [MaxBins=25, MaxDepth=5, MinSamplesSplit=6]
        init_params = {'max_bins': 25, 
                       'max_depth': 4, 
                       'min_samples_split': 6,
                       }
    elif modeling_mode == 'LightGBM':
        # [n_estimators=100, MaxDepth=-1, MinChildSamples=20]
        init_params = {'n_estimators': 100, 
                       'max_depth': -1, 
                       'min_child_samples': 20,
                       }
    else:
        init_params = []
    return init_params


def main():
    ii = 3
    modeling_modes = ['MLR', 'LinearTree', 'RF', 'LightGBM']
    modeling_mode = modeling_modes[ii]
    hyper_flag = False
    # 'grid search', 'optuna'
    search_mode = 'grid search'
    time_span = '60min'
    label = "S1_Conductivity"

    init_params = get_init_params(modeling_mode)

    # x list (column number)
    #x_list = [0,2,4,5]
    var_dict = {"S1_Conductivity": (["RO_B01 FW Press",
                "RO_Feed Cond",
                "RO_01_FirstStageFeedFlow",
                "RO_Feed Temperature", 
                "RO_Feed Ph",
                "Sulfuric Acid Usage",
                "Threshold Inhibitor Usage",
                "RO_Feed Total Chlorine"
                ],'RO_B01 Blank 1 Perm Cond'),
                }

    (x_list, y_list) = var_dict[label]

    # time start
    print ("calculation started.")
    print('-----------------------------------')

    # training period
    #tra_period = ['2022/04/26 0:00','2022/05/19 23:30']
    tra_period = ['2022/04/26 0:00','2022/07/31 23:30']

    # predict period
    #pre_period = ['2022/05/20 0:00','2022/05/26 23:30']
    pre_period = ['2022/08/01 0:00','2022/11/20 23:30']

    # get path
    dir_base, fig_base, file_base = get_path()
    df = get_parameter()

    #df = imputation(df, x_list)
    df = preprocessing(df, time_span)


    # split train and test
    train, test = split_data(df, x_list, y_list, tra_period, pre_period)
    X_train, y_train = X_y_split(train)
    X_test, y_test = X_y_split(test)
    print("X_train: ", X_train.shape)
    print("y_train: ", y_train.shape)
    print("X_test: ", X_test.shape)
    print("y_test: ", y_test.shape)

    time_start = time.perf_counter()
    model = Model(modeling_mode, init_params, False)
    model.fit(X_train, y_train)
    time_end = time.perf_counter()
    training_time = time_end - time_start
    print("training time = {:.2f} sec".format(training_time))

    # estimate / predict
    estimated = model.predict(X_train)
    df_est = model.make_df(estimated, y_train, 'estimate')
    time_start = time.perf_counter()
    predicted = model.predict(X_test)
    time_end = time.perf_counter()
    df_pre = model.make_df(predicted, y_test, 'predict')
    df_est, df_pre, df_MAPE_RMSE = get_RMSE_MAPE(df_est, df_pre)
    prediction_time = time_end - time_start
    print("prediction time = {:.2f} sec".format(prediction_time))

    # result save
    df_time = pd.DataFrame(np.array([training_time, prediction_time]), index=['train', 'predict'])
    #df_hyperparam = pd.DataFrame(best_params, index=['train', 'predict'])
    df_time.to_csv(file_base + "calculation_time_" + modeling_mode + ".csv")
    df_est.to_csv(file_base + "estimate_" + modeling_mode + ".csv")
    df_pre.to_csv(file_base + "predict_" + modeling_mode + ".csv")
    df_MAPE_RMSE.to_csv(file_base + "result_" + modeling_mode + ".csv")
    print ("file saving finished.")

    # figure save
    _name = ["estimate", "predict"]
    _df = [df_est, df_pre]
    for i, name in enumerate(_name):
        figure_label = ["DateTime", label, "actual value", name + "ed value", [0, _df[i].max()]]
        fig_file_name = fig_base + label + '_' + name + '_' + modeling_mode + '.png'
        figure_save_class().trend1(figure_label, _df[i].index, _df[i].loc[:,"actual"].values, _df[i].loc[:,name].values, fig_file_name)
        figure_label = ["y_actual", "y_" + name, [0, 100], [0, 20], float(df_MAPE_RMSE.at[name, "R-squared"])]
        fig_file_name = fig_base + label + '_' + name + '_scatter_' + modeling_mode + '.png'
        figure_save_class().scatter(figure_label, _df[i].loc[:,"actual"].values, _df[i].loc[:,name].values, fig_file_name)

    print ("figure saving finished.")
    
if __name__ == "__main__":
    main()
