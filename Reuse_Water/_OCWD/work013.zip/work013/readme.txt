work005
Random Forest
Fixed Parameter, without FeedTempe
window_size = 48