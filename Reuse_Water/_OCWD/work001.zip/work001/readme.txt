work001_1
- description
 generate parameter.csv from masterdata

work001
- description
 plant optimization (OCWD)

- prediction model
 stub, fouling

- algorithm
 SHADE

- variable: 3

- SeedMode
 0: Opt. Variable
 1: Fixed Parameter
 2: Intermediate Variable

- condition
 start 20220601 0:00 - 20220603 0:00 97step

- 
S1 perm EC [10, 95]
S2 perm EC [20, 200]
S3 perm EC [60, 350]
