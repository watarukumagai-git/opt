#coding: utf-8
import numpy as np
import random as rnd
import math

class LoadProblemClass:
    def __init__(self, alltaglist_df, param_df, modellist_df):
        self.g_num = 0
        self.param_df = param_df
        self.modeldict = dict(zip(modellist_df.columns.tolist(), self.get_modellist(modellist_df)))

        alltaglist_df.loc['Num', :] = range(0, len(alltaglist_df.columns))
        self.alltagdict = alltaglist_df.to_dict(orient='index')

        seedmode_df = alltaglist_df.loc['SeedMode', :]
        self.seedmode_dict = seedmode_df.to_dict()
        self.opt_taglist = seedmode_df[seedmode_df == '0'].index.tolist()
        self.fixed_taglist = seedmode_df[seedmode_df == '1'].index.tolist()
        self.inter_taglist = seedmode_df[seedmode_df == '2'].index.tolist()

        diff_df = alltaglist_df.loc[['diff_min', 'diff_max'], :].astype(float)
        diff_df = diff_df[diff_df != -999].dropna(axis=1)
        self.diff_dict = diff_df.to_dict()

        taglist_df = alltaglist_df.loc[:, self.opt_taglist]
        self.tagdict = taglist_df.to_dict(orient='index')

        self.delta_t = len(param_df)

        # idx for dict
        #L = self.alltagdict.keys()
        # id no for dict
        #L1 = self.alltagdict['Description'].keys()
        # description for dict
        #L2 = self.alltagdict['Description'].values()
        # SeedMode for dict
        #L3 = self.alltagdict['SeedMode'].values()
        self.ID_list = list(self.tagdict['Description'].keys())
        self.allID_list = list(self.alltagdict['Description'].keys())
        self.num_feat_total = len(self.ID_list)
        self.num_allfeat_total = len(self.allID_list)

    def get_modellist(self, df_):
        df_ = df_.fillna(-999)
        l_ = [df_.loc[df_.loc[:, clm] >= 0, clm].sort_values(ascending=True).index.tolist() for clm in df_.columns.tolist()]
        return l_

    def get_problem_parameter(self, Time_start):
        # x0: ID0000, x1: ID0001
        self.no_cost = ['ID0000', 'ID0001']

        # set timestep
        self.Time = self.delta_t-1 + Time_start
        print('delta_t =', self.delta_t)


    def load_problem(self):
        def set_minmax_all(Time_start, ID_list):
            self.bigbigN = len(ID_list) * self.delta_t

            # upper/lower/pattern
            min_clm = [i + '_Min' for i in ID_list]
            max_clm = [i + '_Max' for i in ID_list]
            if self.delta_t == 1:
                min_df = self.param_df.loc[Time_start, min_clm]
                max_df = self.param_df.loc[Time_start, max_clm]
            else:
                min_df = self.param_df.loc[Time_start:self.Time, min_clm]
                max_df = self.param_df.loc[Time_start:self.Time, max_clm]
            

            # [min, max]
            self.bigbigx_ul = np.ones((self.bigbigN, 2))
            self.bigbigx_ul[:,0] = min_df.values.T.reshape(self.bigbigN)
            self.bigbigx_ul[:,1] = max_df.values.T.reshape(self.bigbigN)


        def set_opt_minmaxpattern(Time_start, ID_list):
            self.bigN = self.num_feat_total * self.delta_t

            # upper/lower/pattern
            min_clm = [i + '_Min' for i in ID_list]
            max_clm = [i + '_Max' for i in ID_list]
            pattern_clm = [i + '_Pattern' for i in ID_list]
            seedflag_clm = [i + '_SeedFlag' for i in ID_list]
            if self.delta_t == 1:
                min_df = self.param_df.loc[Time_start, min_clm]
                max_df = self.param_df.loc[Time_start, max_clm]
                self.pattern = self.param_df.loc[Time_start, pattern_clm].values
                self.seedflag = self.param_df.loc[Time_start, seedflag_clm].values
            else:
                min_df = self.param_df.loc[Time_start:self.Time, min_clm]
                max_df = self.param_df.loc[Time_start:self.Time, max_clm]
                self.pattern = self.param_df.loc[Time_start:self.Time, pattern_clm].values
                self.seedflag = self.param_df.loc[Time_start:self.Time, seedflag_clm].values
            

            # index_array: (num_free, 2), [row_index, column_index] (num_feat, delta_t)
            index_array = list(zip(*np.where(self.seedflag.T==0)))
            self.N = len(index_array)

            # [x1[0],x1[1],x1[2],x2[0],x2[1],x2[1],....]
            self.pattern = self.pattern.T.reshape(self.bigN)
            self.seedflag = self.seedflag.T.reshape(self.bigN)

            # [min, max]
            self.bigx_ul = np.ones((self.bigN, 2))
            self.bigx_ul[:,0] = min_df.values.T.reshape(self.bigN)
            self.bigx_ul[:,1] = max_df.values.T.reshape(self.bigN)
            if np.any(self.seedflag==1):
                idx = np.where(self.seedflag == 0)
                self.x_ul = self.bigx_ul[idx,:][0]
            else:
                self.x_ul = self.bigx_ul


        def set_fixed_pattern(Time_start, ID_list):
            pattern_clm = [i + '_Pattern' for i in ID_list]
            if self.delta_t == 1:
                self.pattern_fixed = self.param_df.loc[Time_start, pattern_clm].values.T
            else:
                self.pattern_fixed = self.param_df.loc[Time_start:self.Time, pattern_clm].values.T
            

        def set_inter_minmaxpattern(Time_start, ID_list):
            bigN = len(ID_list) * self.delta_t

            # upper/lower/pattern
            min_clm = [i + '_Min' for i in ID_list]
            max_clm = [i + '_Max' for i in ID_list]
            pattern_clm = [i + '_Pattern' for i in ID_list]
            if self.delta_t == 1:
                min_df = self.param_df.loc[Time_start, min_clm]
                max_df = self.param_df.loc[Time_start, max_clm]
                self.pattern_inter = self.param_df.loc[Time_start, pattern_clm].values.T
            else:
                min_df = self.param_df.loc[Time_start:self.Time, min_clm]
                max_df = self.param_df.loc[Time_start:self.Time, max_clm]
                self.pattern_inter = self.param_df.loc[Time_start:self.Time, pattern_clm].values.T
            

            # [x1[0],x1[1],x1[2],x2[0],x2[1],x2[1],....]
            #self.pattern_inter = self.pattern_inter.T.reshape(bigN)

            # [min, max]
            self.x_ul_inter = np.ones((bigN, 2))
            self.x_ul_inter[:,0] = min_df.values.T.reshape(bigN)
            self.x_ul_inter[:,1] = max_df.values.T.reshape(bigN)



        Time_start = 0
        self.get_problem_parameter(Time_start)


        # all
        set_minmax_all(Time_start, self.allID_list)

        # optimization variable
        set_opt_minmaxpattern(Time_start, self.ID_list)

        # fixed parameter
        set_fixed_pattern(Time_start, self.fixed_taglist)

        # intermediate variable
        set_inter_minmaxpattern(Time_start, self.inter_taglist)

        # cost: (num_feat_total, Time)
        # ['ID0000', 'ID0001']
        c = np.zeros((self.num_feat_total, self.delta_t))
        c[0,:] = 1000
        c[1,:] = 1000

        return c


