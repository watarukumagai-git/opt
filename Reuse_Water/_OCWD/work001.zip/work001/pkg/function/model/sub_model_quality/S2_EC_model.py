#coding: utf-8
import numpy as np
from sklearn import linear_model

class S2_EC_model:
    def __init__(self):
        self.model = linear_model.LinearRegression()
        self.model.coef_ = np.array([0.0000001, 0.0049530])
        self.model.intercept_ = 18.4720
    
    def predict(self, x):
        return np.dot(x.T, self.model.coef_) + self.model.intercept_
    # Y = 0.0000001 * ID000 + 0.0049530 * ID001 + 18.4720
