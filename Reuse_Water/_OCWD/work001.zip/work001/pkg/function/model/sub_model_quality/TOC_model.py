#coding: utf-8
import numpy as np
import itertools
from sklearn import linear_model

class TOC():
    def __init__(self, modelparam):
        #self.model = linear_model.LinearRegression()
        #self.model.coef_ = np.array([0.0000001, 0.00759418])
        #self.model.intercept_ = 0.024452
        self.model = modelparam

    def predict(self, x):
        return list(itertools.chain.from_iterable(self.model.predict(x.T)))
