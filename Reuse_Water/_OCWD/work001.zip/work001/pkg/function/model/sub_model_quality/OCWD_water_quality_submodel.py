import numpy as np
import math
import pandas as pd
from sklearn.preprocessing import StandardScaler

def set_x_variable():
    x_1st_Cond_varialbe = ["RO_B01 FW Press","RO_Feed Cond","RO_01_FirstStageFeedFlow","RO_Feed Temperature","RO_Feed Ph", "Sulfric Acid Usage","Threshold Inhibitor Usage"]
    x_2nd_Cond_varialbe = ["RO_B01 FW B2 Press","RO_01_SecondStageFeedConductivity", "RO_01_SecondStageFeedFlow", "RO_Feed Temperature", "Sulfric Acid Usage","Threshold Inhibitor Usage"]
    x_3rd_Cond_varialbe = ["RO_01_ThirdStageFeedConductivity","RO_01_ThirdStageFeedFlow", "RO_Feed Temperature", "Sulfric Acid Usage","Threshold Inhibitor Usage"]
    x_1st_PermeateFlow_varialbe = ["RO_B01 FW Press","RO_Feed Cond","RO_01_FirstStageFeedFlow","RO_Feed Temperature","RO_Feed Ph", "Sulfric Acid Usage","Threshold Inhibitor Usage"]
    x_2nd_PermeateFlow_varialbe = ["RO_B01 FW B2 Press","RO_01_SecondStageFeedConductivity", "RO_01_SecondStageFeedFlow", "RO_Feed Temperature", "Sulfric Acid Usage","Threshold Inhibitor Usage"]
    x_3rd_PermeateFlow_varialbe = ["RO_01_ThirdStageFeedConductivity","RO_01_ThirdStageFeedFlow", "RO_Feed Temperature", "Sulfric Acid Usage","Threshold Inhibitor Usage"]
    x_TOC_varialbe = ["RO_B01 FW Press","RO_B01 FW B2 Press","RO_Feed Cond","RO_01_FirstStageFeedFlow","RO_Feed Temperature","RO_Feed Ph","RO_Feed TOC", "Sulfric Acid Usage","Threshold Inhibitor Usage"]
    x_taglist = list(set(x_1st_Cond_varialbe + x_2nd_Cond_varialbe + x_3rd_Cond_varialbe + x_1st_PermeateFlow_varialbe + x_2nd_PermeateFlow_varialbe + x_3rd_PermeateFlow_varialbe + x_TOC_varialbe))
    return x_taglist, x_1st_Cond_varialbe, x_2nd_Cond_varialbe, x_3rd_Cond_varialbe, x_1st_PermeateFlow_varialbe, x_2nd_PermeateFlow_varialbe, x_3rd_PermeateFlow_varialbe, x_TOC_varialbe

def set_drug_variable():
    variable = ["Sulfric Acid Usage","Threshold Inhibitor Usage"]
    return variable

def set_y_variable():
    y_1st_Cond_varialbe = ['RO_B01 Blank 1 Perm Cond'] 
    y_2nd_Cond_varialbe = ['RO_B01 Blank 2 Perm Cond'] 
    y_3rd_Cond_varialbe = ['RO_B01 Blank 3 Perm Cond'] 
    y_1st_PermeateFlow_varialbe = ['RO_B01 Blank 1 Perm Flow'] 
    y_2nd_PermeateFlow_varialbe = ['RO_B01 Blank 2 Perm Flow'] 
    y_3rd_PermeateFlow_varialbe = ['RO_B01 Blank 3 Perm Flow'] 
    y_TOC_varialbe = ['RO_Permeat TOC']
    y_taglist = list((y_1st_Cond_varialbe + y_2nd_Cond_varialbe + y_3rd_Cond_varialbe + y_1st_PermeateFlow_varialbe + y_2nd_PermeateFlow_varialbe + y_3rd_PermeateFlow_varialbe + y_TOC_varialbe))
    return y_taglist, y_1st_Cond_varialbe, y_2nd_Cond_varialbe, y_3rd_Cond_varialbe, y_1st_PermeateFlow_varialbe, y_2nd_PermeateFlow_varialbe, y_3rd_PermeateFlow_varialbe, y_TOC_varialbe

# 計算値追加
def data_addition(data,data_unit):
    
    # 投入側流量
    data["RO_01_FirstStageFeedFlow"] = data["RO_B01 Blank 1 Perm Flow"] + data["RO_B01 Blank 2 Perm Flow"] + data["RO_B01 Blank 3 Perm Flow"] + data["RO_B01 Conc Flow"]
    data["RO_01_SecondStageFeedFlow"] = data["RO_01_FirstStageFeedFlow"] - data["RO_B01 Blank 1 Perm Flow"]
    data["RO_01_ThirdStageFeedFlow"] = data["RO_01_SecondStageFeedFlow"] - data["RO_B01 Blank 2 Perm Flow"]
    
    # 透過側イオン量
    data["RO_01_FirstStagePermeateIonVolume"]  = data["RO_B01 Blank 1 Perm Flow"] * data["RO_B01 Blank 1 Perm Cond"]
    data["RO_01_SecondStagePermeateIonVolume"] = data["RO_B01 Blank 2 Perm Flow"] * data["RO_B01 Blank 2 Perm Cond"]
    data["RO_01_ThirdStagePermeateIonVolume"]  = data["RO_B01 Blank 3 Perm Flow"] * data["RO_B01 Blank 3 Perm Cond"]
    
    # 投入側イオン量
    data["RO_01_FirstStageFeedIonVolume"]  = data["RO_01_FirstStageFeedFlow"] * data["RO_Feed Cond"]
    data["RO_01_SecondStageFeedIonVolume"] = data["RO_01_FirstStageFeedIonVolume"] - data["RO_01_FirstStagePermeateIonVolume"]
    data["RO_01_ThirdStageFeedIonVolume"]  = data["RO_01_SecondStageFeedIonVolume"] - data["RO_01_SecondStagePermeateIonVolume"]
    
    # 投入側導電率
    data["RO_01_SecondStageFeedConductivity"] = data["RO_01_SecondStageFeedIonVolume"] / data["RO_01_SecondStageFeedFlow"]
    data["RO_01_ThirdStageFeedConductivity"] = data["RO_01_ThirdStageFeedIonVolume"] / data["RO_01_ThirdStageFeedFlow"]
    
    data_unit["RO_01_SecondStageFeedFlow"] = ["gpm","RO_B01 B2 Feed Flow"] 
    data_unit["RO_01_ThirdStageFeedFlow"] = ["gpm","RO_B01 B3 Feed Flow"] 
    data_unit["RO_01_FirstStagePermeateIonVolume"] = ["","RO_B01 B1 Permeate Ion Volume"] 
    data_unit["RO_01_SecondStagePermeateIonVolume"] = ["","RO_B01 B2 Permeate Ion Volume"] 
    data_unit["RO_01_ThirdStagePermeateIonVolume"] = ["","RO_B01 B3 Permeate Ion Volume"] 
    data_unit["RO_01_FirstStageFeedIonVolume"] = ["","RO_B01 B1 Feed Ion Volume"] 
    data_unit["RO_01_SecondStageFeedIonVolume"] = ["","RO_B01 B2 Feed Ion Volume"] 
    data_unit["RO_01_ThirdStageFeedIonVolume"] = ["","RO_B01 B3 Feed Ion Volume"] 
    data_unit["RO_01_SecondStageFeedConductivity"] = ["muS/cm","RO_B01 B2 Feed Conductivity"] 
    data_unit["RO_01_ThirdStageFeedConductivity"] = ["muS/cm","RO_B01 B3 Feed Conductivity"] 
    return data, data_unit

# 外れ値除去  median で補間 k=24 thr=3
def Hampel(x,k,thr):    
    # print(x.name)
    arraySize = len(x)
    idx = np.arange(arraySize)
    output_x = x.copy()
    output_Idx = np.zeros_like(x)
 
    for i in range(arraySize):
        kernel = np.where( (idx <= (idx[i] + k)) & (idx >= (idx[i] - k)),True, False)
        median = np.median(x[kernel])
        std = math.sqrt(np.median(np.multiply((x[kernel] - median),(x[kernel] - median))))
        
        if np.abs(x[i] - median) > thr * std:
            output_Idx[i] = 1
            output_x[i] = median
            
    return output_x

# 標準化
def set_stds(data, variable):
    stds = StandardScaler() 
    data = pd.DataFrame(stds.fit_transform(data), columns=variable, index=data.index)
    return data
