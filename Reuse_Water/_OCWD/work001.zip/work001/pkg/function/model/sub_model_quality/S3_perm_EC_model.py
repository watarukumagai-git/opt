#coding: utf-8
import numpy as np

class S3_perm_EC:
    def __init__(self, modelparam):
        self.model = modelparam
    
    def predict(self, x):
        tmp = self.model.predict(x.T).reshape(-1)
        return np.where(tmp<0, 0, tmp)