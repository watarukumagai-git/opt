#coding: utf-8
import numpy as np
import itertools
from sklearn import linear_model

class S1_perm_EC:
    def __init__(self, modelparam):
        #self.model = linear_model.LinearRegression()
        #self.model.coef_ = np.array([0.0000001, 0.0049530])
        #self.model.intercept_ = 18.4720
        self.model = modelparam
    
    def predict(self, x):
        return list(itertools.chain.from_iterable(self.model.predict(x.T)))
        # Y = 0.0000001 * ID000 + 0.0049530 * ID001 + 18.4720
