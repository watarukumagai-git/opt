#coding: utf-8
import pickle
import os
from os import path

from .sub_model_fouling.fouling_submodel import FOULING
from .sub_model_quality.OCWD_water_quality_submodel import S1_EC_model, S2_EC_model, S3_EC_model, S1_Flow_model, S2_EC_model, TOC_model

if 'My Drive' in os.getcwd():
    separator = '/'
    work_path = os.getcwd()
else:
    separator = '\\'
    work_path = path.dirname( path.abspath(__file__) )
    os.chdir(work_path)

class Model_class:
    """
    import models.

    Attributes
    ----------
    Model1 : constructor
        S1 permeate EC prediction model constructor from sub_model_quality
    Model2 : constructor
        permeate TOC prediction model constructor from sub_model_quality
    FOULING : constructor
        permeate EC prediction model constructor from sub_model_fouling
    """
    def __init__(self, base_path):
        base_folder_path = base_path + separator + 'sub_model_quality'
        (S1_Perm_EC_model, S1_Perm_Flow_model, S2_Perm_EC_model, S2_Perm_Flow_model, S3_Perm_EC_model, S3_Perm_Flow_model, TOC_model) = self.import_quality(base_folder_path)
        self.S1_Perm_Flow_model = S1_Perm_Flow_model()
        self.S2_Perm_Flow_model = S2_Perm_Flow_model()
        self.S3_Perm_Flow_model = S3_Perm_Flow_model()
        self.Feed_Flow_model = S1_Perm_Flow_model.predict() + S1_Perm_Flow_model.predict() + S1_Perm_Flow_model.predict()
        self.S1_EC_model = S1_Perm_EC_model()
        self.S2_EC_model = S2_Perm_EC_model()
        self.S3_EC_model = S3_Perm_EC_model()
        self.TOC_model = TOC_model()
        base_folder_path = base_path + separator + 'sub_model_fouling'
        (est_rho_model, est_cl_model, loaded_scaler) = self.import_fouling(base_folder_path)
        self.FOULING = FOULING(est_rho_model, est_cl_model, loaded_scaler)

    def import_quality(self, base_folder_path):
        filename = 'OCWD_1st_Cond_modelfile'
        First_Perm_Cond_model = pickle.load(open(base_folder_path + filename, 'rb'))
        filename = 'OCWD_1st_PermeateFlow_modelfile'
        First_Perm_Flow_model = pickle.load(open(base_folder_path + filename, 'rb'))
        filename = 'OCWD_2nd_Cond_modelfile'
        Second_Perm_Cond_model = pickle.load(open(base_folder_path + filename, 'rb'))
        filename = 'OCWD_2nd_PermeateFlow_modelfile'
        Second_Perm_Flow_model = pickle.load(open(base_folder_path + filename, 'rb'))
        filename = 'OCWD_3rd_Cond_modelfile'
        Third_Perm_Cond_model = pickle.load(open(base_folder_path + filename, 'rb'))
        filename = 'OCWD_3rd_PermeateFlow_modelfile'
        Third_Perm_Flow_model = pickle.load(open(base_folder_path + filename, 'rb'))
        filename = 'OCWD_TOC_modelfile'
        TOC_model = pickle.load(open(base_folder_path + filename, 'rb'))        
        return First_Perm_Cond_model, First_Perm_Flow_model, Second_Perm_Cond_model, Second_Perm_Flow_model, Third_Perm_Cond_model, Third_Perm_Flow_model, TOC_model


    def import_fouling(self, base_folder_path):
        rho_model_filename = base_folder_path + separator + 'est_rho_model.sav'
        cl_model_filename = base_folder_path + separator + 'est_cl_model.sav'
        scaler_filename = base_folder_path + separator + 'fouling_scaler.sav'
        est_rho_model = pickle.load(open(rho_model_filename, 'rb'))
        est_cl_model = pickle.load(open(cl_model_filename, 'rb'))
        loaded_scaler = pickle.load(open(scaler_filename, 'rb'))
        return est_rho_model, est_cl_model, loaded_scaler
