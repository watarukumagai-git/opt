#coding: utf-8
import pickle
import os
from os import path

from .sub_model_fouling.fouling_submodel import FOULING
from .sub_model_quality import S1_perm_EC_model, S2_perm_EC_model, S3_perm_EC_model, S2_feed_EC_model, S3_feed_EC_model, TOC_model

if 'My Drive' in os.getcwd():
    separator = '/'
    work_path = os.getcwd()
else:
    separator = '\\'
    work_path = path.dirname( path.abspath(__file__) )
    os.chdir(work_path)

class Model_class:
    """
    import models.

    Attributes
    ----------
    Model1 : constructor
        S1 permeate EC prediction model constructor from sub_model_quality
    Model2 : constructor
        permeate TOC prediction model constructor from sub_model_quality
    FOULING : constructor
        permeate EC prediction model constructor from sub_model_fouling
    """
    def __init__(self, base_path):
        base_folder_path = base_path + separator + 'sub_model_quality'
        (S1_perm_EC_modelparam, S2_perm_EC_modelparam, S3_perm_EC_modelparam, TOC_modelparam) = self.import_quality(base_folder_path)
        #self.S1_Perm_Flow_model = S1_Perm_Flow_model()
        #self.S2_Perm_Flow_model = S2_Perm_Flow_model()
        #self.S3_Perm_Flow_model = S3_Perm_Flow_model()
        #self.Feed_Flow_model = S1_Perm_Flow_model.predict() + S1_Perm_Flow_model.predict() + S1_Perm_Flow_model.predict()
        # ["S1 Feed Press","S1 Feed EC","S1 Feed Flow","Feed Temperature","Feed Ph", "Sulfric Acid", "Inhibitor"]
        self.S1_perm_EC_model = S1_perm_EC_model.S1_perm_EC(S1_perm_EC_modelparam)
        # ["S1 Feed Flow","S1 Feed EC","S1 perm Flow","S1 perm EC",]
        self.S2_feed_EC_model = S2_feed_EC_model.S2_feed_EC()
        # ["S2 Feed Press","S2 Feed EC", "S2 Feed Flow", "Feed Temperature", "Sulfric Acid","Inhibitor"]
        self.S2_perm_EC_model = S2_perm_EC_model.S2_perm_EC(S2_perm_EC_modelparam)
        # ["S2 Feed Flow","S2 Feed EC","S2 perm Flow","S2 perm EC",]
        self.S3_feed_EC_model = S3_feed_EC_model.S3_feed_EC()
        # ["S3 Feed EC","S3 Feed Flow", "Feed Temperature", "Sulfric Acid","Inhibitor"]
        self.S3_perm_EC_model = S3_perm_EC_model.S3_perm_EC(S3_perm_EC_modelparam)
        # ["S1 Feed Press","S2 Feed Press","S1 Feed Cond","S1 Feed Flow","Feed Temperature","Feed Ph","Feed TOC", "Sulfric Acid","Inhibitor"]
        self.perm_TOC_model = TOC_model.TOC(TOC_modelparam)
        #base_folder_path = base_path + separator + 'sub_model_fouling'
        #(est_rho_model, est_cl_model, loaded_scaler) = self.import_fouling(base_folder_path)
        #self.FOULING = FOULING(est_rho_model, est_cl_model, loaded_scaler)

    def _import(self, file):
        return pickle.load(open(file, 'rb'))

    def import_quality(self, base_folder_path):
        First_Perm_Cond_model = self._import(base_folder_path + separator + 'OCWD_1st_Cond_modelfile')
        First_Perm_Flow_model = self._import(base_folder_path + separator + 'OCWD_1st_PermeateFlow_modelfile')
        Second_Perm_Cond_model = self._import(base_folder_path + separator + 'OCWD_2nd_Cond_modelfile')
        Second_Perm_Flow_model = self._import(base_folder_path + separator + 'OCWD_2nd_PermeateFlow_modelfile')
        Third_Perm_Cond_model = self._import(base_folder_path + separator + 'OCWD_3rd_Cond_modelfile')
        Third_Perm_Flow_model = self._import(base_folder_path + separator + 'OCWD_3rd_PermeateFlow_modelfile')
        TOC_model = self._import(base_folder_path + separator + 'OCWD_TOC_modelfile')
        return First_Perm_Cond_model, Second_Perm_Cond_model, Third_Perm_Cond_model, TOC_model

    def import_fouling(self, base_folder_path):
        est_rho_model = self._import(base_folder_path + separator + 'est_rho_model.sav')
        est_cl_model = self._import(base_folder_path + separator + 'est_cl_model.sav')
        loaded_scaler = self._import(base_folder_path + separator + 'fouling_scaler.sav')
        return est_rho_model, est_cl_model, loaded_scaler
