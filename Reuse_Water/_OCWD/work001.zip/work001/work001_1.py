# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
import os
from os import path


if 'My Drive' in os.getcwd():
    separator = '/'
    work_path = os.getcwd()
else:
    separator = '\\'
    work_path = path.dirname( path.abspath(__file__) )
    os.chdir(work_path)



def my_makedirs(path):
    if not os.path.isdir(path):
        os.makedirs(path)

def dict_to_list(dict_, clm_):
    return list(dict_[clm_].values())

def make_setfile(dir_base, str_list, num_list):
    f = open(dir_base + separator + 'set_file.txt', 'w')
    for i in range(0,len(str_list)):
        f.write(str_list[i] + ' = ' + str(num_list[i]) + '\n')
    f.close()

def index_to_datetime(df, ts_clm):
    df[ts_clm] = pd.to_datetime(df[ts_clm])
    df.set_index(ts_clm, inplace=True)
    return df

def get_master(masterfile, dateclm):
    dir_base = work_path + separator + 'input'
    df1 = pd.read_csv(dir_base + separator + masterfile, header=0)
    df2 = pd.read_csv(dir_base + separator + 'taglist.csv', header=0, index_col=0)
    date = df1.loc[:, dateclm].tolist()
    # datetime transformation
    if '/' in date[0] and 'description' == date[-1]:
        df1 = index_to_datetime(df1.iloc[:-2], dateclm)
    return df1, df2, dir_base

def add_calc(data):
    data["S1 Feed Flow Rate"] = data["RO_B01 Blank 1 Perm Flow"] + data["RO_B01 Blank 2 Perm Flow"] + data["RO_B01 Blank 3 Perm Flow"] + data["RO_B01 Conc Flow"]
    data[data["S1 Feed Flow Rate"] < 0.01] = 0.01
    data["S2 Feed Flow Rate"] = data["S1 Feed Flow Rate"] - data["RO_B01 Blank 1 Perm Flow"]
    data[data["S2 Feed Flow Rate"] < 0.01] = 0.01
    data["S3 Feed Flow Rate"] = data["S2 Feed Flow Rate"] - data["RO_B01 Blank 2 Perm Flow"]
    data[data["S3 Feed Flow Rate"] < 0.01] = 0.01
    data["S2 Feed EC"] = data["S1 Feed Flow Rate"]*data["RO_Feed Cond"] - data["RO_B01 Blank 1 Perm Flow"]*data["RO_B01 Blank 1 Perm Cond"] / data["S2 Feed Flow Rate"]
    data[data["S2 Feed EC"] < 0.01] = 0.01
    data["S3 Feed EC"] = data["S2 Feed Flow Rate"]*data["S2 Feed EC"] - data["RO_B01 Blank 2 Perm Flow"]*data["RO_B01 Blank 2 Perm Cond"] / data["S3 Feed Flow Rate"]
    data[data["S3 Feed EC"] < 0.01] = 0.01
    clm = ["Sulfric Acid Usage", "Threshold Inhibitor Usage"]
    data[clm] = (data[clm]/48).fillna(method='ffill')
    return data

def get_parambase(df_master, df_taglist, dateclm):
    base_clm = ['Pattern', 'SeedFlag', 'Min', 'Max']

    dict_tag = df_taglist.to_dict(orient='index')
    tagid_list = dict_to_list(dict_tag, 'tag ID')
    idno_list = dict_tag['Description'].keys()
    seedmode_list = list(np.float_(dict_to_list(dict_tag, 'SeedMode')))
    min_list = list(np.float_(dict_to_list(dict_tag, 'min')))
    max_list = list(np.float_(dict_to_list(dict_tag, 'max')))

    df_master = df_master.loc[:, tagid_list]
    idx_list = df_master.index.tolist()
    clm_list = [no + '_' + base for no in idno_list for base in base_clm]
    
    df_param = pd.DataFrame(np.zeros((len(idx_list), len(clm_list))), columns = clm_list)
    df_param[dateclm] = idx_list
    df_param.set_index(dateclm, inplace=True)

    for idx, id in enumerate(idno_list):
        # actual
        tag = tagid_list[idx]
        df_param.loc[:, id + '_Pattern'] = df_master.loc[:, tag]
        # seedflag
        df_param.loc[:, id + '_SeedFlag'] = seedmode_list[idx]
        if seedmode_list[idx] == 0:
            df_param.loc[idx_list[0], id + '_SeedFlag'] = 1
        # min
        if min_list[idx] == -999:
            df_param.loc[:, id + '_Min'] = df_master.loc[:, tag].min(axis=0)
        else:
            df_param.loc[:, id + '_Min'] = min_list[idx]
        # max
        if max_list[idx] == -999:
            df_param.loc[:, id + '_Max'] = df_master.loc[:, tag].max(axis=0)
        else:
            df_param.loc[:, id + '_Max'] = max_list[idx]
    
    df_param = df_param.fillna(method='ffill')
    return df_param



def main():
    date_str = '2022-06-01 00:00:00'
    date_end = '2022-06-03 00:00:00'

    # read masterfile
    masterfile = 'master_2021_2022_30min_edit_ver2.csv'
    dateclm = 'timestamp'
    dateclm = 'Date / Time'
    (df_master, df_taglist, dir_base) = get_master(masterfile, dateclm)
    df_master = df_master.loc[date_str:date_end,:]

    # add calc tagid
    df_master = add_calc(df_master)

    df_param = get_parambase(df_master, df_taglist, dateclm)
    df_param.to_csv(dir_base + separator + 'parameter.csv')
    print ("file saving finished.")
    
if __name__ == "__main__":
    main()
