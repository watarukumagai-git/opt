import subprocess
_list = ['calc_optimization.py',
         'postprocessing.py',
         ]

print('|==================|')
for _l in _list:
    print('start: ', _l)
    subprocess.call('python %s' % _l)
    print('end: ', _l)
    print('|==================|')