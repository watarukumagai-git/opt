# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
import time
import picos as pic

from pkg import get_opt_module_param, helper
from pkg.save_figure import SaveFigure
from opt_module.optimize import Optimize
from opt_module.get_eval import ViolationEvaluation
from opt_problem.define_opt_problem import OptProblem, LoadProblemParam

_helper = helper.Helper()
_helper.WORKPATH = _helper.get_workpath('cd')

def read_parameter_files(date_clm):
    dir_base = _helper.WORKPATH + _helper.SEPARATOR + 'input'
    df1 = pd.read_csv(dir_base + _helper.SEPARATOR + 'parameter.csv', header=0)
    df2 = pd.read_csv(dir_base + _helper.SEPARATOR + 'taglist.csv', header=0, index_col=0)
    df3 = pd.read_csv(dir_base + _helper.SEPARATOR + 'modellist.csv', header=0, index_col=0)
    df4 = pd.read_csv(dir_base + _helper.SEPARATOR + 'LRVlist.csv', header=0, index_col=0)
    timestamp = pd.to_datetime(df1.loc[:,date_clm]).tolist()
    df1 = df1.drop(date_clm, axis=1)
    return df1, df2, df3, df4, timestamp

def loop_iteration2(func, prob, start_time):
    def get_prob(func, prob, problem):
        num_fixed = len(prob.fixed_taglist)
        num_inter = len(prob.inter_taglist)
        num_feat_total = prob.num_feat_total

        coef0 = func.Model.S1_perm_EC_model.model.model.model.coef_[0]
        #coef1 = func.Model.S2_feed_EC_model.model.model.model.coef_[0]
        coef2 = func.Model.S2_perm_EC_model.model.model.model.coef_[0]
        #coef3 = func.Model.S3_feed_EC_model.model.model.model.coef_[0]
        coef4 = func.Model.S3_perm_EC_model.model.model.model.coef_[0]
        #coef5 = func.Model.perm_combined_EC_model.model.model.model.coef_[0]
        coef6 = func.Model.perm_TOC_model.model.model.model.coef_[0]
        coef = np.ones((num_inter, num_feat_total + num_fixed))
        coef[0, :len(coef0)] = coef0
        coef[2, :len(coef2)] = coef2
        coef[4, :len(coef4)] = coef4
        coef[6, :len(coef6)] = coef6


        x = pic.RealVariable('x', (num_feat_total, prob.delta_t))
        y = pic.RealVariable('y', (num_inter, prob.delta_t))

        lower = func.load_pro.x_ul_inter[:,0]
        upper = func.load_pro.x_ul_inter[:,1]
        lower_x = np.ones((num_feat_total, prob.delta_t))
        upper_x = np.ones((num_feat_total, prob.delta_t))
        lower_y = np.ones((num_inter, prob.delta_t))
        upper_y = np.ones((num_inter, prob.delta_t))
        lower_x[0,:] = 0.1
        upper_x[0,:] = 0.8
        lower_x[1,:] = 0.02
        upper_x[1,:] = 0.08
        lower_y[0,:] = 0
        upper_y[0,:] = 100
        lower_y[1,:] = 0
        upper_y[1,:] = 4000
        lower_y[2,:] = 0
        upper_y[2,:] = 200
        lower_y[3,:] = 0
        upper_y[3,:] = 8000
        lower_y[4,:] = 0
        upper_y[4,:] = 350
        lower_y[5,:] = 0
        upper_y[5,:] = 50
        lower_y[6,:] = 0
        upper_y[6,:] = 0.15

        cost = pic.Constant('cost', prob.cost)
        p = pic.Constant('pattern', prob.pattern_fixed)
        coef = pic.Constant('coef', coef)
        lower_x = pic.Constant('lower_x', lower_x)
        upper_x = pic.Constant('upper_x', upper_x)
        lower_y = pic.Constant('lower_y', lower_y)
        upper_y = pic.Constant('upper_y', upper_y)

        # lower and upper bounds
        problem.add_constraint(lower_x <= x)
        problem.add_constraint(x <= upper_x)
        problem.add_constraint(lower_y[0, :] <= y[0, :])
        #problem.add_constraint(lower_y <= y)
        #problem.add_constraint(y <= upper_y)

        # intermid variable 
        for i, x_list in enumerate(func.modeldict.values()):
            index_ = func.get_dict_vallist(func.id_allnumdict, x_list)
            if i == 0:
                problem.add_constraint(y[i,:] == sum([coef[i, j]*p[index_[j]-2,:] for j in range(5)]) + coef[i, 5]*x[0,:] + coef[i, 6]*x[1,:])
            elif i == 1:
                problem.add_list_of_constraints(y[i,t] == (p[6,t]*p[0,t] - p[7,t]*y[0,t]) / (p[6,t] - p[7,t]) for t in range(prob.delta_t))
            elif i == 2:
                problem.add_constraint(y[i,:] == coef[i, 0]*p[index_[0]-2,:] + coef[i, 1]*y[1,:] + sum([coef[i, j]*p[index_[j]-2,:] for j in range(2, 4)]) + coef[i, 4]*x[0,:] + coef[i, 5]*x[1,:])
            elif i == 3:
                problem.add_list_of_constraints(y[i,t] == (p[9,t]*y[1,t] - p[10,t]*y[2,t]) / (p[9,t] - p[10,t]) for t in range(prob.delta_t))
            elif i == 4:
                problem.add_constraint(y[i,:] == coef[i, 0]*y[3,:] + sum([coef[i, j]*p[index_[j]-2,:] for j in range(1, 3)]) + coef[i, 3]*x[0,:] + coef[i, 4]*x[1,:])
            elif i == 5:
                problem.add_list_of_constraints(y[i,t] == (p[6,t]*y[0,t] + p[9,t]*y[2,t] + p[11,t]*y[4,t]) / (p[6,t] + p[9,t] + p[11,t]) for t in range(prob.delta_t))
            elif i == 6:
                problem.add_constraint(y[i,:] == sum([coef[i, j]*p[index_[j]-2,:] for j in range(7)]) + coef[i, 7]*x[0,:] + coef[i, 8]*x[1,:])

        #problem.add_constraint(A.T*x<b)

        # objective function
        objective = sum([cost[i,:]*x[i,:].T for i in range(prob.num_feat_total)])
        problem.set_objective('min', objective)
        return x, y

    # databox gene
    time_box = np.zeros((1, 3))

    print ("problem started.")
    problem = pic.Problem()
    (x,y) = get_prob(func, prob, problem)

    print(problem)
    print(problem.type)
    print ("problem termenated.")

    print ("calculation started.")
    print('-----------------------------------')
    sol = problem.solve()
    now_time = time.time() 
    cal_time = now_time - start_time 
    time_box[0, :] = np.array([cal_time, cal_time/60, cal_time/3600])
    x_box = np.array(x.value)
    y_box = np.array(y.value)
    obj_value = sol.value
    print('-----------------------------------')
    print ("calculation finished")
    print('cal_time[sec] = ', cal_time)
    print(obj_value)
    print(x_box)
    print(y_box)
    #if x_box == None:
    #    x_box = np.ones((prob.delta_t, 2))*(-999)
    #if y_box == None:
    #    y_box = np.ones((prob.delta_t, 2))*(-999)
    if obj_value == None:
        obj_value = -999
    return obj_value, x_box, y_box, time_box


def loop_iteration(func, alg_para, run_max, start_time):
    iter_max = alg_para[0]
    # databox gene
    time_box = np.zeros((run_max+1, 3))
    # [gbest_obj, gbest_vio]
    obj_gbest_box = np.zeros((iter_max, 2, run_max))
    x_gbest_final_box = np.zeros((func.load_pro.N, run_max))

    # time start
    print ("calculation started.")
    print('-----------------------------------')
    unit_run = Optimize(func, alg_para)

    for run in range(0, run_max): 
        print('run/run_max = %d / %d' % (run+1, run_max))
        print('loop start')
        # get solution
        (obj_subbox, x_gbest, obj_gbest_subbox) = unit_run.main_loop()

        # save solution
        obj_gbest_box[:, :, run] = obj_gbest_subbox
        x_gbest_final_box[:, run] = x_gbest
        
        now_time = time.time() 
        loop_cal_time = now_time - start_time if run == 0 else now_time - cal_time - start_time 
        cal_time = now_time - start_time 
        time_box[run, :] = np.array([loop_cal_time, loop_cal_time/60, loop_cal_time/3600])
        print('calculation time = %.3f sec = %.3f min' % (cal_time, cal_time/60))
        print ("feas_gbest: ", np.round(obj_gbest_box[iter_max-1, :2, run], 3))
        print('loop end')
        print('-----------------------------------')

    print ("calculation finished")
    time_box[-1, :] = np.mean(time_box[:run_max, :], axis=0)
    time_box = np.round(time_box, decimals=4)
    print('mean time = %.3f sec = %.3f = min = %.3f = hour' % (time_box[-1, 0], time_box[-1, 1], time_box[-1, 2]))
    return obj_gbest_box, x_gbest_final_box, time_box


def get_result(obj_gbest_box):
    name_list = ["obj", "vio"]
    idx_list = ["ave", "std", "max", "min"]

    df_obj_gbest_final = pd.DataFrame(obj_gbest_box.T, columns=name_list)
    print(df_obj_gbest_final)

    df_result = pd.DataFrame(np.zeros((len(idx_list), len(name_list))), index=idx_list, columns=name_list)
    for i in name_list:
        df_result.at["ave", i] = df_obj_gbest_final.loc[:, i].mean()
        df_result.at["std", i] = df_obj_gbest_final.loc[:, i].std()
        df_result.at["max", i] = df_obj_gbest_final.loc[:, i].max()
        df_result.at["min", i] = df_obj_gbest_final.loc[:, i].min()

    print ("result=")
    print (df_result)
    return df_result, df_obj_gbest_final 


def figures(fig_base, obj_gbest_box):
    iter_max = obj_gbest_box.shape[0]
    run_max = obj_gbest_box.shape[2]
    obj_max = np.amax(obj_gbest_box[:, 0, :])
    vio_max = np.amax(obj_gbest_box[:, 1, :])
    minmax = [0, obj_max, 0, vio_max]

    legends1 = ["$f(x)$", "$v(x)$"]
    labels1 = ["$f(x)$", "$v(x)$"]
    figure_label1 = ["iteration: $k$", legends1, labels1, minmax]
    for run in range(0, run_max):
        # obj and vio gbest trend
        fig_file_name = fig_base + 'obj_vio_gbest_'+ str(run) + '.png'
        SaveFigure().double_trend(figure_label1, 
                                         range(0, iter_max), 
                                         obj_gbest_box[:, :, run],
                                         fig_file_name,
                                         scale1 = 'log',
                                         scale2 = 'log')


def main():
    # parameter setting
    (alg_para, run_max) = get_opt_module_param.get_opt_module_param(_helper.WORKPATH, _helper.SEPARATOR)
    #alg_para = [iter_max, population, "alg_name", **algorithm's other para.**]
    iter_max = alg_para[0]
    population = alg_para[1]

    date_clm = 'timestamp'
    (param_df, taglist_df, modellist_df, LRV_df, timestamp) = read_parameter_files(date_clm)
    print('start date = ', timestamp[0])
    print('end date = ', timestamp[-1])

    prob = LoadProblemParam(taglist_df, param_df, modellist_df, LRV_df)
    func = OptProblem(prob, _helper.SEPARATOR)
    func.g_num = len(func.constraint_function(np.zeros(prob.N)))
    print('Time = ', prob.Time)
    print('num_feat_total = ', prob.num_feat_total)


    # get path
    dir_base = _helper.make_output_dir(_helper.WORKPATH)
    str_clm = ['dimension', 'g_num']
    num_clm = [prob.N, func.g_num]   
    print(str_clm)
    print(num_clm)
    _helper.make_setfile(dir_base, str_clm, num_clm)


    # run loop    
    start_time = time.time()
    #(obj_gbest_box, x_gbest_final_box, time_box) = loop_iteration(func, alg_para, run_max, start_time)
    (obj_gbest_box, x_gbest_final_box, inter_box, time_box) = loop_iteration2(func, prob, start_time)
    file_base = dir_base + _helper.SEPARATOR + 'file' + _helper.SEPARATOR
    fig_base = dir_base + _helper.SEPARATOR + 'fig' + _helper.SEPARATOR

    # result save
    # df_result: [[ave, std, max, min], [obj, vio]]
    # df_obj_feas_gbest_final: [run_max, [obj, vio]]
    df_time = pd.DataFrame(time_box, index=['average'], columns=['sec','min','hour'])
    df_time.to_csv(file_base + "time.csv")

    df_x_gbest_final = pd.DataFrame(x_gbest_final_box)
    df_x_gbest_final.to_csv(file_base + "x_gbest_final.csv")
    df_solution = pd.concat([df_x_gbest_final, pd.DataFrame(inter_box)], axis=0)
    df_solution.to_csv(file_base + "solution.csv")

    #x_feas_gbest_final_box = x_feas_cbest_gbest_final_box[1, :, :].reshape(prob.num_feat_total, prob.Time, run_max)
    #x_feas_gbest_final: (N, run_max)
    x_feas_gbest_final = x_gbest_final_box.reshape(-1, run_max)

    #x_2D_feas_gbest_final_box = x_feas_gbest_final.reshape(prob.num_feat_total, prob.delta_t, run_max)
    x_2D_feas_gbest_final_box = np.zeros((prob.num_feat_total, prob.delta_t, run_max))
    big_x_2D_feas_gbest_final_box = np.zeros((prob.num_allfeat_total, prob.delta_t, run_max))
    # param_box: ((iter_max, 2, m, run_max))


    #x_each_vio_final: (v_num+1, run_max)
    print ("file saving finished.")

    # figure save
    #figures(fig_base, obj_gbest_box)
    print ("figure saving finished.")

    # time finish
    end_time = time.time()
    cal_time = end_time - start_time
    print('time = %f sec = %f min' % (cal_time, cal_time/60))

    
if __name__ == "__main__":
    main()
