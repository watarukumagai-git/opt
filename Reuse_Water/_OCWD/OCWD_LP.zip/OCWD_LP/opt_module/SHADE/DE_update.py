#coding: utf-8
import time
import numpy as np
from ..get_eval import Superior

class SolutionUpdator:
    def __init__(self, population, N):
        self.population = population
        self.N = N
        self.RHO_MIN = 2/self.population
        self.RHO_MAX = 0.2

    def neighbor_gene(self, x_, obj_, mod):
        def _mutate(F, x_, idx_rank, num_better):
            # obj: (m,), rank
            child = np.copy(x_)
            idx_ori = np.arange(self.population)
            p = [np.random.choice(idx_rank[:idx], replace=True) for idx in num_better]
            for i in range(0, self.population):
                idx = np.delete(idx_ori, np.where(idx_ori == i))
                r = np.random.choice(idx, size=2, replace=False)
                child[i, :] = x_[i, :] + F[i] * (x_[p[i],:] - x_[i,:] + x_[r[0],:] - x_[r[1],:])
            return child

        def _xover(C, x1_, x2_):
            # theta: (m, N)
            theta = np.random.rand(self.population, self.N)
            lambda_ = np.random.randint(0, self.N, size=self.population)
            # binomial crossover
            child = np.copy(x1_)
            nidx = [np.where(theta[idx, :] <= c)[0] for (idx, c) in enumerate(C)]
            for i in range(0, self.population):
                child[i, nidx[i]] = x2_[i, nidx[i]]
                child[i, lambda_[i]] = x2_[i, lambda_[i]]
            return child

  	    # x_: (population, N)
	    # obj_: (population,)
        rho = np.random.rand(self.population)*(self.RHO_MAX-self.RHO_MIN) + self.RHO_MIN
        idx_rank = Superior().get_rank(obj_)
        # superior individual number in the range [2, m*rho]
        num_better = np.clip(self.population * rho, 2, None).astype(int)
        u = _mutate(self.F, x_, idx_rank, num_better)
        #crossover / modify
        return mod.modified_x(_xover(self.C, x_, u))


    def selection(self, x__, obj__, x_nei__, obj_nei__):
        update_idx_ = Superior().get_sup_idx_array(obj__, obj_nei__)
        if len(update_idx_) > 0:
            x__[update_idx_, :] = x_nei__[update_idx_, :].copy()
            obj__[update_idx_, :] = obj_nei__[update_idx_, :].copy()
        return x__, obj__, update_idx_

    def DE_update(self, prob, x, obj, mod):
        x_nei = self.neighbor_gene(x, obj, mod)
        (obj_nei, each_vio_nei) = Superior().eval_scaler(prob, x_nei)
        (x_, obj_, self.update_idx_) = self.selection(x, obj, x_nei, obj_nei)
        return x_, obj_