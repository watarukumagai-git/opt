import subprocess
_list = ['preprocessing.py',
         'generate_model.py',
         'generate_param.py',
         'validate_problem.py',
         ]

print('|==================|')
for _l in _list:
    print('start: ', _l)
    subprocess.call('python %s' % _l)
    print('end: ', _l)
    print('|==================|')