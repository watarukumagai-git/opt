import pickle

class Pickle:
    def __init__(self):
        pass

    def _trans(self,mode):
        if mode == 'save':
            return 'wb'
        elif mode == 'load':
            return 'rb'

    def save_model(self, filename, obj):
        with open(filename, mode=self._trans('save')) as f:
            pickle.dump(obj, f)
            
    def load_model(self, filename):
        with open(filename, mode=self._trans('load')) as f:
            model = pickle.load(f)
        return model