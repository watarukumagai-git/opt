#coding: utf-8
import numpy as np

class perm_combined_EC_model():
    """
    calulate permeate EC.

    Attributes
    ----------
    model : constructor (coef_, intercept_)
        estimate EC value using x 
    """
    def __init__(self):
        pass

    def predict(self, x):
        """
        predict permeate EC.

        Parameters
        ----------
        x : double (6, Time)
            RO Stage 1 perm Flow Rate
            RO Stage 1 perm EC
            RO Stage 2 perm Flow Rate
            RO Stage 2 perm EC
            RO Stage 3 perm Flow Rate
            RO Stage 3 perm EC

        Returns
        -------
        predicted value : double (Time,)
        """
        tmp = ((x[0,:]*x[1,:] + x[2,:]*x[3,:] + x[4,:]*x[5,:]) / (x[0,:] + x[2,:] + x[4,:])).reshape(-1)
        return np.where(tmp<0, 0, tmp)