#coding: utf-8
import pickle
import os
from os import path

from .sub_model_quality.S1_perm_EC import S1_perm_EC_model
from .sub_model_quality.S2_feed_EC import S2_feed_EC_model
from .sub_model_quality.S2_perm_EC import S2_perm_EC_model
from .sub_model_quality.S3_feed_EC import S3_feed_EC_model
from .sub_model_quality.S3_perm_EC import S3_perm_EC_model
from .sub_model_quality.perm_TOC import perm_TOC_model
from .sub_model_fouling.fouling_submodel import fouling

if 'My Drive' in os.getcwd():
    separator = '/'
    work_path = os.getcwd()
else:
    separator = '\\'
    work_path = path.dirname( path.abspath(__file__) )
    os.chdir(work_path)

class Model_class:
    """
    import models.

    Attributes
    ----------
    Model1 : constructor
        S1 permeate EC prediction model constructor from sub_model_quality
    Model2 : constructor
        permeate TOC prediction model constructor from sub_model_quality
    FOULING : constructor
        permeate EC prediction model constructor from sub_model_fouling
    """
    def __init__(self, base_path):
        base_folder_path = base_path + separator + 'sub_model_quality'
        (S1_perm_EC_modelparam, S2_perm_EC_modelparam, S3_perm_EC_modelparam, perm_TOC_modelparam) = self.import_quality(base_folder_path)
        self.S1_perm_EC_model = S1_perm_EC_model(S1_perm_EC_modelparam)
        self.S2_feed_EC_model = S2_feed_EC_model()
        self.S2_perm_EC_model = S2_perm_EC_model(S2_perm_EC_modelparam)
        self.S3_feed_EC_model = S3_feed_EC_model()
        self.S3_perm_EC_model = S3_perm_EC_model(S3_perm_EC_modelparam)
        self.perm_TOC_model = perm_TOC_model(perm_TOC_modelparam)
        #base_folder_path = base_path + separator + 'sub_model_fouling'
        #(est_rho_model, est_cl_model, loaded_scaler) = self.import_fouling(base_folder_path)
        #self.FOULING = fouling(est_rho_model, est_cl_model, loaded_scaler)

    def import_quality(self, base_folder_path):
        model1 = ''
        model2 = ''
        model3 = ''
        model4 = ''
        return model1, model2, model3, model4

    def import_fouling(self, base_folder_path):
        rho_model_filename = base_folder_path + separator + 'est_rho_model.sav'
        cl_model_filename = base_folder_path + separator + 'est_cl_model.sav'
        scaler_filename = base_folder_path + separator + 'fouling_scaler.sav'
        est_rho_model = pickle.load(open(rho_model_filename, 'rb'))
        est_cl_model = pickle.load(open(cl_model_filename, 'rb'))
        loaded_scaler = pickle.load(open(scaler_filename, 'rb'))
        return est_rho_model, est_cl_model, loaded_scaler
