#coding: utf-8
import numpy as np
from sklearn import linear_model

class perm_TOC_model():
    """
    calulate permeate TOC.

    Attributes
    ----------
    model : constructor (coef_, intercept_)
        estimate TOC value using x 
    """
    def __init__(self, modelparam):
        self.model = linear_model.LinearRegression()
        self.model.coef_ = np.array([0.0000001, 0.0000001, 0.0000001, 0.0000001, 0.0000001, 0.0000001, 0.0000001])
        self.model.intercept_ = 0.1

    def predict(self, x):
        """
        predict permeate TOC.

        Parameters
        ----------
        x : double (7, Time)
            RO Stage 1 Sulfuric Acid Dosing
            RO Stage 1 feed TOC
            RO Stage 1 Sulfuric Acid Dosing
            RO Stage 1 feed TOC
            RO Stage 1 Sulfuric Acid Dosing
            RO Stage 1 feed TOC
            RO Stage 1 feed TOC

        Returns
        -------
        predicted value : double (Time,)
        """
        return np.dot(x.T, self.model.coef_) + self.model.intercept_
        # Y = 0.0000001 * ID000 + 0.00759418 * ID002 + 0.024452
