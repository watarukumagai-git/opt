#coding: utf-8
import numpy as np
from sklearn import linear_model

class S2_feed_EC_model:
    """
    calulate S2 feed EC.

    Attributes
    ----------
    model : constructor (coef_, intercept_)
        estimate EC value using x 
    """
    def __init__(self):
        self.model = linear_model.LinearRegression()
    
    def predict(self, x):
        """
        predict S2 feed EC.

        Parameters
        ----------
        x : double (4, Time)
            RO Stage 1 feed Flow Rate
            RO Stage 1 feed EC
            RO Stage 1 perm Flow Rate
            RO Stage 1 perm EC

        Returns
        -------
        predicted value : double (Time,)
        """
        return (x[0,:]*x[1,:] - x[2,:]*x[3,:]) / (x[0,:] - x[2,:])
