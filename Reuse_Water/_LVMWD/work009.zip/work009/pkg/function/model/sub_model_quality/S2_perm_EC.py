#coding: utf-8
import numpy as np
from sklearn import linear_model

class S2_perm_EC_model:
    """
    calulate S1 permeate EC.

    Attributes
    ----------
    model : constructor (coef_, intercept_)
        estimate EC value using x 
    """
    def __init__(self, modelparam):
        self.model = linear_model.LinearRegression()
        self.model.coef_ = np.array([0.0000001, 0.0000001, 0.0000001, 0.0000001])
        self.model.intercept_ = 27.0
    
    def predict(self, x):
        """
        predict S1 permeate EC.

        Parameters
        ----------
        x : double (4, Time)
            RO Stage 1 Sulfuric Acid Dosing
            RO Stage 1 feed EC
            RO Stage 1 Sulfuric Acid Dosing
            RO Stage 1 feed EC

        Returns
        -------
        predicted value : double (Time,)
        """
        return np.dot(x.T, self.model.coef_) + self.model.intercept_
        # Y = 0.0000001 * ID000 + 0.0049530 * ID001 + 18.4720
