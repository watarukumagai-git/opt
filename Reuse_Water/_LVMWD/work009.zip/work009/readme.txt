work009_1
- description
 generate parameter.csv from masterdata

work009
- description
 plant optimization (LVMWD)

- prediction model
 stub, fouling

- algorithm
 SHADE

- variable: 3

- SeedMode
 0: Opt. Variable
 1: Fixed Parameter
 2: Intermediate Variable

- condition
 start 20220601 0:00 - 20220603 0:00 97step

- limit
 S1 perm EC [0, 50]
 S2 feed EC [0, 30]
 S2 perm EC [0, 50]
 S3 feed EC [0, 50]
 S3 perm EC [0, 60]
 perm TOC [0, 0.15]
