# -*- coding: utf-8 -*-
import os
from os import path

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
import plotly.io as pio
import plotly.figure_factory as ff
import streamlit as st

from pkg.helper import helper_class

def make_save_dir(work_path):
    # makedirs
    helper_class().my_makedirs(work_path)
    helper_class().my_makedirs(work_path + '\\fig')
    helper_class().my_makedirs(work_path + '\\file')

def index_to_datetime(df, ts_clm):
    df[ts_clm] = pd.to_datetime(df.index)
    df.set_index(ts_clm, inplace=True)
    return df

def split_df(df):
    df_unit = df.loc[['unit', 'description'], :]
    print(df_unit)
    df = df.drop(['unit', 'description'])
    df = index_to_datetime(df, 'timestamp')
    df = df.astype(float)
    return df, df_unit

def _scatter_streamlit_select(_df, _df_ratio, _df_loading, categories, tag_dict):
    def find_index(_series, item):
        return _series.where(_series == item).first_valid_index()

    def get_key_from_value(d, val):
        keys = [k for k, v in d.items() if v == val]
        if keys:
            return keys[0]
        return None

    id_list = np.sort(_df[categories].unique())
    l_ = list(_df.columns)
    l_.remove(categories)
    tag_tuple = tuple(l_)

    _df['timestamp'] = _df.index

    st.header('LVMWD Data PCA Plot')
    st.subheader('ncomp = ' + str(len(l_)))
    x_ = st.selectbox('Please select x-axis', tag_tuple)
    y_ = st.selectbox('Please select y-axis', tag_tuple)

    fig = go.Figure()
    for id in id_list:
        _df2 = _df[_df[categories]==id]
        fig.add_trace(go.Scatter(x=_df2[x_], y=_df2[y_], 
                                name='id: ' + str(id), mode='markers', marker_size=4,
                                marker_symbol = 'circle-open', marker_line_width=0.3,
                                text=_df2['timestamp']
                                )
                    )
    fig.update_xaxes(title=x_, titlefont_size=18, tickfont=dict(size=18), showgrid=True, griddash='dash')
    fig.update_yaxes(title=y_, titlefont_size=18, tickfont=dict(size=18), showgrid=True, griddash='dash')
    fig.update_layout(margin=dict(t=10, b=0))


    fig2 = go.Figure()
    fig2.add_trace(go.Scatter(x=_df_loading[x_], y=_df_loading[y_], 
                            mode='markers', marker_size=10,
                            #marker_symbol = 'circle-open', 
                            #marker_line_width=0.3,
                            text=_df_loading.index
                            )
                )
    _min = _df_loading.min().min()
    _max = _df_loading.max().max()
    delta = 0.1
    fig2.update_xaxes(title=x_, titlefont_size=18, tickfont=dict(size=18), range=[_min-delta, _max+delta], showgrid=True, griddash='dash')
    fig2.update_yaxes(title=y_, titlefont_size=18, tickfont=dict(size=18), range=[_min-delta, _max+delta], showgrid=True, griddash='dash')
    fig2.update_layout(margin=dict(t=10, b=0),
                       width=500, height=500)

    fig3 = ff.create_table(_df_ratio.round(), index=True)
    fig3.update_layout(margin=dict(t=10, b=0))

    fig4 = ff.create_table(_df_loading.round(2), index=True)
    fig4.update_layout(margin=dict(t=10, b=0))

    st.subheader('Scatter Chart for Principal Component: {x_axis} vs {y_axis}'.format(x_axis=x_, y_axis=y_))
    st.plotly_chart(fig)
    st.subheader('Scatter Chart for Loading: {x_axis} vs {y_axis}'.format(x_axis=x_, y_axis=y_))
    st.plotly_chart(fig2)
    st.subheader('Contribution Ratio')
    st.plotly_chart(fig3)
    st.subheader('Loading')
    st.plotly_chart(fig4)


def main():
    dir_base = path.dirname( path.abspath(__file__) )

    # read file
    parent_dir = os.path.abspath(os.path.join(dir_base, os.pardir))
    save_path = parent_dir + '\\output'
    df_master = pd.read_csv(save_path + '\\file\\result.csv', index_col=0)
    df_score = pd.read_csv(save_path + '\\file\\pca_score.csv', index_col=0)
    df_ratio = pd.read_csv(save_path + '\\file\\pca_ratio.csv', index_col=0)
    df_loading = pd.read_csv(save_path + '\\file\\pca_loading.csv', index_col=0)
    make_save_dir(save_path)

    (df_master, df_unit) = split_df(df_master)
    tag_list = df_unit.loc['description', :]
    tag_dict = df_unit.to_dict()

    print(tag_list)
    print('all features = ', len(tag_list))

    categories = 'clusterId'
    print(tag_list)
    tag_list = tag_list.drop(categories)
    df_loading.index = tag_list.values

    _scatter_streamlit_select(df_score, df_ratio, df_loading, categories, tag_dict)
    
    print('all pages finish')

if __name__ == "__main__":
    main()