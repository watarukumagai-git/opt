# -*- coding: utf-8 -*-
import os
from os import path

import numpy as np
import pandas as pd
#import cufflinks as cf
import plotly
import plotly.express as px
import plotly.io as pio
import streamlit as st

from pkg.helper import helper_class
from pkg.figure_save import figure_save_class
#cf.go_offline()
#cf.set_config_file(offline=True, theme="white", offline_show_link=False)

def _scatter_plotly(_df, clm, label, categories, fig_file_name):
    _df['timestamp'] = _df.index
    fig = px.scatter(_df, x=clm[0], y=clm[1], 
                     color=categories,
                     hover_data='timestamp',
                     )
    fig.update_traces(marker={'size': 2})
    fig.update_xaxes(title_text=label[0])
    fig.update_yaxes(title_text=label[1])
    pio.write_html(fig, f"{fig_file_name}.html")
    pio.write_image(fig, f"{fig_file_name}.png")

def _scatter_streamlit(_df, categories, save_path, tag_list):
    _df['timestamp'] = _df.index
    l_ = [tag_list[i] + '_' + tag_list[j] for i in range(0, len(tag_list)-1) for j in range(i+1, len(tag_list)-1)]
    tablist = st.tabs(l_)
    k = 0
    for i in range(0, len(tag_list)-1):
        for j in range(i+1, len(tag_list)-1):
            if tag_list[i] != 'clusterId' or tag_list[j] != 'clusterId':
                fig = px.scatter(_df, x=tag_list.index[i], y=tag_list.index[j], 
                                color=categories,
                                hover_data='timestamp',
                                )
                fig.update_traces(marker={'size': 2})
                fig.update_xaxes(title_text=tag_list[i])
                fig.update_yaxes(title_text=tag_list[j])
                tablist[k].plotly_chart(fig)
            k = k + 1

def _plotly2(_df, clm, label, categories, fig_file_name):
    import plotly.graph_objects as go
    fig = go.Figure()
    fig.add_trace(
        go.Scatter(x = _df[clm[0]], y = _df[clm[1]],
                   mode = 'markers',
                   marker = dict(size=2),
                   customdata=_df.index,
                   #fillcolor=categories, 
                   hovertemplate=(
                   # brタグで改行
                   # %を使うとx, yの各値を指定可能
                   'x = %{x}<br>'\
                   'y = %{y}<br>'\
                   # マジックアンダースコア（もしくはdict）を使う引数はピリオドで対応可能
                   'timestamp = %{customdata}'
                   )
        )
    )
    fig.update_xaxes(title_text=label[0])
    fig.update_yaxes(title_text=label[1])
    #plotly.offline.plot(fig)
    pio.write_html(fig, f"{fig_file_name}.html",)
    #pio.write_image(fig, f"{fig_file_name}.png")

def make_save_dir(work_path):
    # makedirs
    helper_class().my_makedirs(work_path)
    helper_class().my_makedirs(work_path + '\\fig')
    helper_class().my_makedirs(work_path + '\\file')

def index_to_datetime(df, ts_clm):
    df[ts_clm] = pd.to_datetime(df.index)
    df.set_index(ts_clm, inplace=True)
    return df

def split_df(df):
    df_unit = df.loc[['unit', 'description'], :]
    print(df_unit)
    df = df.drop(['unit', 'description'])
    df = index_to_datetime(df, 'timestamp')
    df = df.astype(float)
    return df, df_unit


class tag_chart:
    def __init__(self, _df, _save_path, tag_dict):
        self.minmax = [_df.index[0], _df.index[-1], 0, 1]
        self.minmax_status = 'none'
        self.tag_dict = tag_dict
        self.save_path = _save_path
        self.taglist = _df.columns.tolist()
        self.taglist.remove('clusterId')

    def trend_chart(self, _df):
        for i, tag in enumerate(self.taglist):
            name = self.tag_dict[tag]['description']
            unit = self.tag_dict[tag]['unit']
            figure_label = ['DateTime', name + ' [' + unit +']', self.minmax]
            fig_file_name = self.save_path + name + '_gmm_trend.png'
            y = pd.concat([_df.loc[:, tag], _df.loc[:, 'clusterId']], axis=1)
            figure_save_class().scatter_trend(fig_file_name, figure_label, _df.index, y)

def pca_scatter(_df, clm, label, fig_file_name):
    minmax = [0, 1, 0, 1]
    figure_label = [label[0], label[1], minmax]
    figure_save_class().draw_scatter_id(fig_file_name, figure_label, _df.loc[:, clm[0]], _df.loc[:, clm[1]], _df.loc[:, 'clusterId'])

def main():
    dir_base = path.dirname( path.abspath(__file__) )

    # read file
    save_path = dir_base + '\\output'
    df_master = pd.read_csv(save_path + '\\file\\result.csv', index_col=0)
    make_save_dir(save_path)

    (df_master, df_unit) = split_df(df_master)
    tag_list = df_unit.loc['description', :]
    tag_dict = df_unit.to_dict()

    print(tag_list)
    print('all features = ', len(tag_list))

    #for i in range(len(tag_list)-1):
    #    if 'clusterId' != tag_list[i] and 'clusterId' != tag_list[i+1]:
    #        num = [tag_list.index[i], tag_list.index[i+1]]
    #        label = [tag_list[i], tag_list[i+1]]
    #        pca_scatter(df_master, num, label, save_path + '\\fig\\scatter_' + tag_list[i] + '_' + tag_list[i+1] + '.png')

    categories = 'clusterId'
    #for i in range(len(tag_list)-1):
    #    if 'clusterId' != tag_list[i] and 'clusterId' != tag_list[i+1]:
    #        num = [tag_list.index[i], tag_list.index[i+1]]
    #        label = [tag_list[i], tag_list[i+1]]
    #        fig_file_name = save_path + '\\fig\\scatter_' + tag_list[i] + '_' + tag_list[i+1]
    _scatter_streamlit(df_master, categories, save_path + '\\fig', tag_list)

    
    print('finish')

if __name__ == "__main__":
    main()