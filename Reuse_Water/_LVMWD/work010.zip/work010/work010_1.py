# -*- coding: utf-8 -*-
import os
from os import path

import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

from pkg.helper import helper_class

def make_save_dir(work_path):
    # makedirs
    helper_class().my_makedirs(work_path)
    helper_class().my_makedirs(work_path + '\\fig')
    helper_class().my_makedirs(work_path + '\\file')

def index_to_datetime(df, ts_clm):
    df[ts_clm] = pd.to_datetime(df.index)
    df.set_index(ts_clm, inplace=True)
    return df

def split_df(df):
    df_unit = df.loc[['unit', 'description'], :]
    print(df_unit)
    df = df.drop(['unit', 'description'])
    df = index_to_datetime(df, 'timestamp')
    df = df.astype(float)
    return df, df_unit

def pca(_x, _nComponent):
    pca = PCA(n_components=_nComponent)
    std_x = StandardScaler().fit_transform(_x)
    pca.fit(std_x)
    transformed_X = pca.transform(std_x)
    return pca, transformed_X

def main():
    dir_base = path.dirname( path.abspath(__file__) )

    # read file
    save_path = dir_base + '\\output'
    df_master = pd.read_csv(save_path + '\\file\\result.csv', index_col=0)
    make_save_dir(save_path)

    (df_master, df_unit) = split_df(df_master)
    tag_list = df_unit.loc['description', :]
    tag_dict = df_unit.to_dict()

    print(tag_list)
    print('all features = ', len(tag_list))
    
    print(df_master.shape)
    print(df_master.head(2))
    print(df_master.tail(2))

    categories = 'clusterId'
    df_y = df_master.drop(categories, axis=1)
    pca_comp = 4
    (pca_model, pca_score)= pca(df_y, pca_comp)

    score_df = pd.DataFrame(pca_score, index=df_master.index, columns=['PC_'+str(p) for p in range(pca_comp)])    
    score_df = pd.concat([score_df, df_master[categories]], axis=1)
    print(score_df)

    ratio_df = pd.DataFrame(pca_model.explained_variance_ratio_*100, index = ['PC_'+str(p) for p in range(pca_comp)], columns=['contribution ratio [%]'])
    ratio_df['cumlative contribution ratio [%]'] = np.cumsum(pca_model.explained_variance_ratio_)*100
    print(ratio_df)

    eigen_vector = pca_model.components_
    eigen_value = pca_model.explained_variance_
    loading = eigen_vector*np.c_[np.sqrt(eigen_value)]
    loading_df = pd.DataFrame(loading, index = ['PC_'+str(p) for p in range(pca_comp)], columns=df_y.columns)
    loading_df = loading_df.T
    print(loading_df)

    score_df.to_csv(save_path + '\\file\\pca_score.csv')
    ratio_df.to_csv(save_path + '\\file\\pca_ratio.csv')
    loading_df.to_csv(save_path + '\\file\\pca_loading.csv')
    
    print('finish')

if __name__ == "__main__":
    main()