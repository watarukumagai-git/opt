# -*- coding: utf-8 -*-
import os
from os import path

import numpy as np
import pandas as pd
import streamlit as st

from pkg.helper import helper_class


def make_save_dir(work_path):
    # makedirs
    helper_class().my_makedirs(work_path)
    helper_class().my_makedirs(work_path + '\\fig')
    helper_class().my_makedirs(work_path + '\\file')

def index_to_datetime(df, ts_clm):
    df[ts_clm] = pd.to_datetime(df.index)
    df.set_index(ts_clm, inplace=True)
    return df

def split_df(df):
    df_unit = df.loc[['unit', 'description'], :]
    print(df_unit)
    df = df.drop(['unit', 'description'])
    df = index_to_datetime(df, 'timestamp')
    df = df.astype(float)
    return df, df_unit


def main():
    dir_base = path.dirname( path.abspath(__file__) )

    # read file
    save_path = dir_base + '\\output'
    df_master = pd.read_csv(save_path + '\\file\\result.csv', index_col=0)
    make_save_dir(save_path)

    (df_master, df_unit) = split_df(df_master)
    tag_list = df_unit.loc['description', :]
    tag_dict = df_unit.to_dict()

    print(tag_list)
    print('all features = ', len(tag_list))

    st.header('LVMWD Data Analysis Dashbord')
    
    print('main page finish')

if __name__ == "__main__":
    main()