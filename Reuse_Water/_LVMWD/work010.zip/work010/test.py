import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
#from scipy import linalg
from sklearn import mixture, datasets
from sklearn.decomposition import PCA

def plot_contour(clf, x, y, labels):
    def _get_grid(sample_):
        _x = np.linspace(0., 10.)
        _y = np.linspace(0., 10.)
        X, Y = np.meshgrid(_x, _y)
        XX = np.array([X.ravel(), Y.ravel()]).T
        Z = -sample_(XX).reshape(X.shape)
        return X, Y, Z

    (X,Y,Z) = _get_grid(clf.score_samples)
    (fig, ax) = plt.subplots(dpi=150,figsize=(5,4))
    CS = ax.contourf(X, Y, Z, norm=LogNorm(vmin=1.0, vmax=1000.0),
                    levels=np.logspace(0, 3, 10),alpha=0.8)
    CB = plt.colorbar(CS, shrink=0.95,label='Negative log-likelihood predicted')
    ax.scatter(x, y, s=1, c=labels)
    plt.savefig("gmm.png",dpi=130)

# iris
dataset = datasets.load_iris()
dic = {}
for k,v in zip(dataset.feature_names,dataset.data.T):
    dic[k] = v
df = pd.DataFrame(dic)
X = df.iloc[:, :2].values

# Fit a Gaussian mixture with EM
nComponentsRange = range(1, 7)
cvTypes = ['spherical', 'tied', 'diag', 'full']
nInit = 10
nComponent = nComponentsRange[5]
cvType = cvTypes[0]

gmm = mixture.GaussianMixture(n_components=nComponent,
                                covariance_type=cvType,n_init =nInit)
gmm.fit(X)
gmm.bic(X)

varNames = df.columns
# normalization
dfScaled = df.copy()[varNames]
dfScaled = (dfScaled - dfScaled.mean())/dfScaled.std()

# principal components analysis
pca = PCA(n_components=3)
trans= pca.fit_transform(dfScaled[varNames])
df["clusterId"] = gmm.predict(X)

x = X[:, 0]
y = X[:, 1]
plot_contour(gmm, x, y, df["clusterId"])

print(df["clusterId"])
print(X)