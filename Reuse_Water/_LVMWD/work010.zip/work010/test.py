import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
#from scipy import linalg
from sklearn import mixture, datasets
from sklearn.decomposition import PCA

# iris
dataset = datasets.load_iris()
dic = {}
for k,v in zip(dataset.feature_names,dataset.data.T):
    dic[k] = v
df = pd.DataFrame(dic)
X = df.values

# Fit a Gaussian mixture with EM
nComponentsRange = range(1, 7)
cvTypes = ['spherical', 'tied', 'diag', 'full']
nInit = 10
nComponent = nComponentsRange[5]
cvType = cvTypes[0]

gmm = mixture.GaussianMixture(n_components=nComponent,
                                covariance_type=cvType,n_init =nInit)
gmm.fit(X)
gmm.bic(X)

varNames = df.columns
# normalization
dfScaled = df.copy()[varNames]
dfScaled = (dfScaled - dfScaled.mean())/dfScaled.std()

# principal components analysis
pca = PCA(n_components=3)
trans= pca.fit_transform(dfScaled[varNames])
df["clusterId"] = gmm.predict(X)

clusterPCAPlot(trans,dfScaled)

print(df["clusterId"])
print(X)