# -*- coding: utf-8 -*-
import os
from os import path

import numpy as np
import pandas as pd
from sklearn import mixture

from pkg.helper import helper_class
from pkg.figure_save import figure_save_class

def make_save_dir(work_path):
    # makedirs
    helper_class().my_makedirs(work_path)
    helper_class().my_makedirs(work_path + '\\fig')
    helper_class().my_makedirs(work_path + '\\file')

def index_to_datetime(df, ts_clm):
    df[ts_clm] = pd.to_datetime(df.index)
    df.set_index(ts_clm, inplace=True)
    return df

def split_df(df):
    df_unit = df.loc[['unit', 'description'], :]
    print(df_unit)
    df = df.drop(['unit', 'description'])
    df = index_to_datetime(df, 'timestamp')
    df = df.astype(float)
    return df, df_unit

def gmm(_X, _nComponent):
    gmm = mixture.GaussianMixture(n_components=_nComponent)
    gmm.fit(_X)
    y = gmm.predict(_X)
    return gmm, y

def preprocessing(df_master, df_unit):
    tag_list = ['PT_41095',
                'PT_41347',
                'TIT_40005',
                'AI_31094',
                'AIT_40006',
                'AIT_41092',
                'AIT_41292',
                #'AIT_41392',
                'AIT_40010',
                'AIT_41810',
                #'RO_01_FirstStageFeedFlow',
                #'RO_01_SecondStageFeedFlow',
                #'RO_01_ThirdStageFeedFlow',
                #'FIT_41074',
                #'FIT_41274',
                #'FIT_41374',
                #'RO_01_SecondStageFeedConductivity',
                #'RO_01_ThirdStageFeedConductivity',
                ]
    df_master = df_master.loc[:, tag_list]
    df_unit = df_unit.loc[:, tag_list]
    tag_list = df_unit.loc['description', :]
    tag_dict = df_unit.to_dict()

    # y
    df_y = df_master.loc['2021/7/1  0:00:00':, ]

    clm = list(df_y.columns.tolist())
    clm.remove('AI_31094')
    clm.remove('AIT_41810')
    print(clm)
    for c in clm:
        df_y.loc[(df_y.loc[:, c]<=2), c] = np.nan
    
    if 'RO_01_ThirdStageFeedConductivity' in df_y.columns:
        clm = 'RO_01_ThirdStageFeedConductivity'
        df_y.loc[(df_y.loc[:, clm]>=10000), clm] = np.nan

    df_y = df_y.fillna(method='ffill').fillna(method='bfill')

    print(df_y.shape)
    print(df_y.head(2))
    print(df_y.tail(2))
    return df_y, tag_dict, tag_list, df_unit


class tag_chart:
    def __init__(self, _df, _save_path, tag_dict):
        self.minmax = [_df.index[0], _df.index[-1], 0, 1]
        self.minmax_status = 'none'
        self.tag_dict = tag_dict
        self.save_path = _save_path
        self.taglist = _df.columns.tolist()
        self.taglist.remove('clusterId')

    def trend_chart(self, _df):
        for i, tag in enumerate(self.taglist):
            name = self.tag_dict[tag]['description']
            unit = self.tag_dict[tag]['unit']
            figure_label = ['DateTime', name + ' [' + unit +']', self.minmax]
            fig_file_name = self.save_path + name + '_gmm_trend.png'
            y = pd.concat([_df.loc[:, tag], _df.loc[:, 'clusterId']], axis=1)
            figure_save_class().scatter_trend(fig_file_name, figure_label, _df.index, y)

def main():
    dir_base = path.dirname( path.abspath(__file__) )

    # read file
    root_path = dir_base + '\\input'
    df_master = pd.read_csv(root_path + '\\master_30min_preprocessed_edit.csv', index_col=0)

    save_path = dir_base + '\\output'
    make_save_dir(save_path)

    (df_master, df_unit) = split_df(df_master)
    (df_y, tag_dict, tag_list, df_unit) = preprocessing(df_master, df_unit)    

    print(tag_list)
    print('all features = ', len(tag_list))
    ncom_gmm = 9
    (gmm_model, clusterid) = gmm(df_y.values, ncom_gmm)
    print('gmm modeling finish')

    df_y.loc[:, 'clusterId'] = clusterid
    graph = tag_chart(df_y, save_path + '\\fig\\', tag_dict)
    graph.trend_chart(df_y)
    df_count = df_y.groupby('clusterId').count()
    print('gmm graph finish')

    df_unit.loc['description', 'clusterId'] = 'clusterId'
    df_unit.loc['unit', 'clusterId'] = '-'
    df_y = pd.concat([df_y, df_unit],axis=0)
    df_y.to_csv(save_path + '\\file\\result.csv')
    df_count.to_csv(save_path + '\\file\\num_cluster.csv')
    print('finish')

if __name__ == "__main__":
    main()