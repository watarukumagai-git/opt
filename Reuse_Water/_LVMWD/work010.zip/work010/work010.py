# -*- coding: utf-8 -*-
import os
from os import path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from statsmodels import api as sm

from pkg.helper import helper_class
from pkg.get_param import get_param_class
from pkg.figure_save import figure_save_class

def make_save_dir(work_path):
    # makedirs
    helper_class().my_makedirs(work_path)
    helper_class().my_makedirs(work_path + '\\fig')
    helper_class().my_makedirs(work_path + '\\file')

def index_to_datetime(df, ts_clm):
    df[ts_clm] = pd.to_datetime(df.index)
    df.set_index(ts_clm, inplace=True)
    return df

def split_df(df):
    df_unit = df.loc[['unit', 'description'], :]
    print(df_unit)
    df = df.drop(['unit', 'description'])
    df = index_to_datetime(df, 'timestamp')
    df = df.astype(float)
    return df, df_unit

def shift_df(df, low_up_dict):
    df_ = df.copy()
    for key, values in low_up_dict.items():
        df_[key + '_t-1'] = df_[key].shift(freq='30min')
    return df_

def calc_corr_df(df, id_list):
    df_ = df.copy()
    id_list += [id + '_t-1' for id in id_list]
    print(id_list)
    df_corr = df_.loc[:, id_list].corr()
    return df_corr

def self_correlation(df, df_des, save_path, nlags):
    for i, tag in enumerate(df.columns):
        df_acf = sm.tsa.stattools.acf(df[tag], nlags=nlags)
        fig = plt.figure(figsize=(12,8))
        fig = sm.graphics.tsa.plot_acf(df[tag], lags=nlags)
        plt.savefig(save_path + '\\' + df_des[tag] + '_selfcorrelation_30min.png', bbox_inches="tight")
    return df_acf

def decompose(df, df_des, save_path, lang='jpn'):
    x = df.index
    x_label_name = 'DATE'
    y_label_list = ['Observed', 'Trend', 'Seasonal', 'Residual']
    for i, tag in enumerate(df.columns):
        # model: additive, multiplicative
        res = sm.tsa.seasonal_decompose(df[tag].values, period=2000, model='additive')
        #res = sm.tsa.seasonal_decompose(df[tag], model='additive')
        #fig = plt.figure(figsize=(8,8))
        fig, axes = plt.subplots(nrows=4, ncols=1, figsize=(6, 6), sharex=True)
        fig.patch.set_facecolor('white')
        #axes = fig.add_subplot(4,1,1, sharex=True)

        axes[0].set_xlim([x[0], x[-1]])
        for i in range(4):
            if i==0:
                a = res.observed
            elif i==1:
                a = res.trend
            elif i==2:
                a = res.seasonal
            elif i==3:
                a = res.resid
            axes[i].plot(x, a, lw=0.5)
            axes[i].set_ylabel(y_label_list[i], fontsize=14)
            axes[i].grid(linestyle='dashed', linewidth=0.2)

        axes[3].set_xlabel(x_label_name, fontsize=14)
        axes[3].tick_params(labelsize=12)
        if lang == 'eng':
            # Sep/15/2020 20:30
            #formatter = mdates.DateFormatter('%b/%d/%Y %H:%M')
            formatter = mdates.DateFormatter('%m/%Y')
            axes[0].xaxis.set_major_formatter(formatter)
        plt.tick_params(direction = "in")
        plt.tight_layout()
        plt.savefig(save_path + '\\' + df_des[tag] + '_decompose_30min.png', bbox_inches="tight")
    return res, y_label_list

class tag_chart:
    def __init__(self, df, df_unit, tag_list):
        self.xmin = 0
        self.xmax = 1
        self.ymin = 0
        self.ymax = 1
        self.minmax_status = 'min'
        self.df_unit = df_unit
        self.tag_list = tag_list

    def tag_scatter(self, df, fig_name_list):
        for i, tag in enumerate(self.tag_list):
            x = df.loc[:, tag + '_t-1'].values
            y = df.loc[:, tag].values
            self.xmax = y.max()
            self.ymax = y.max()
            title = self.df_unit.loc['description', tag] + ' [' + self.df_unit.loc['unit',tag] + ']'
            figure_label = ['t-1', 't', [self.xmin, self.xmax, self.ymin, self.ymax], title]
            figure_save_class().draw_scatter(fig_name_list[i], figure_label, x, y, self.minmax_status)


def main():
    dir_base = path.dirname( path.abspath(__file__) )

    # read file
    root_path = dir_base + '\\input'
    df_master = pd.read_csv(root_path + '\\master_30min_preprocessed_edit.csv', index_col=0)

    save_path = dir_base + '\\output'
    make_save_dir(save_path)

    # select tag and pre-processing
    low_up_dict = {'AIT_40006': [250, 2000],
                   'AIT_41092': [7, 40], 
                   'AIT_41292': [5, 45], 
                   'AIT_41392': [10, 50], 
                   'AIT_41892': [5, 48]}
    status_id = 'RO_Status'

    (df_master, df_unit) = split_df(df_master)
   
    # y
    tag_id_list = list(low_up_dict.keys())
    df_y = df_master.loc[:, tag_id_list]
    print(df_y.shape)
    print(df_y.head(2))
    print(df_y.tail(2))

    lang = 'eng'
    # self_correlation
    #df_acf = self_correlation(df_y, df_unit.loc['description', :], save_path + '\\fig', 48)
    (result, y_label_list) = decompose(df_y, df_unit.loc['description', :], save_path + '\\fig', lang=lang)

    df = pd.DataFrame(np.zeros((len(df_y.index),4)), index=df_y.index ,columns=y_label_list)
    df.loc[:, y_label_list[0]] = result.observed
    df.loc[:, y_label_list[1]] = result.trend
    df.loc[:, y_label_list[2]] = result.seasonal
    df.loc[:, y_label_list[3]] = result.resid
    df.to_csv(save_path + '\\file\\result.csv')
    print(df)

    print('finish')

if __name__ == "__main__":
    main()
