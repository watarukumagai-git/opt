work010
30min edit data => decomposition by gmm

https://www.ourpureh2o.com/home/showpublisheddocument/14646/638095655200130000
表5-4に”Dates”の期間と、"CIP Interval"は対応していそうですね。
もしかすると、この境目の日がCIPのタイミングだと捉えられるかもしれません。