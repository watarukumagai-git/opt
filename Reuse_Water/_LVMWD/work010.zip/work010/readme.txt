work010
30min edit data => clutering by gmm

work010_1
scatter chart including cluterId by plotly

work010_2
decomposition by pca

https://www.ourpureh2o.com/home/showpublisheddocument/14646/638095655200130000
表5-4に”Dates”の期間と、"CIP Interval"は対応していそうですね。
もしかすると、この境目の日がCIPのタイミングだと捉えられるかもしれません。

https://pbpython.com/plotly-look.html
https://docs.streamlit.io/library/api-reference/charts/st.plotly_chart
https://discuss.streamlit.io/t/include-an-existing-html-file-in-streamlit-app/5655
https://github.com/streamlit/streamlit/issues/611