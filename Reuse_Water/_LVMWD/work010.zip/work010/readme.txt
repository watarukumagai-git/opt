work006
30min edit data => decomposition