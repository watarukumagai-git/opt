# -*- coding: utf-8 -*-
import os
import matplotlib.pyplot as plt
plt.rcParams['font.family'] = 'Times New Roman'

class figure_save_class:
    def draw_trend(self, fig_file_name, figure_label, x, y, labels, minmax_status='none'):
        x_label_name = figure_label[0]
        y_label_name = figure_label[1]
        (x_min, x_max, y_min, y_max) = figure_label[2]

        fig = plt.figure(figsize=(6,4))
        fig.patch.set_facecolor('white')
        ax = fig.add_subplot(1,1,1)
        ax.plot(x, y, 'C0', lw=0.5)
        ax.plot(x, labels, marker='o',
                markeredgecolor='blue',
                markeredgewidth=1,
                fillstyle='none',
                markersize=20,
                lw=0)
        ax.set_xlabel(x_label_name, fontsize=12)
        ax.set_ylabel(y_label_name, fontsize=12)
        ax.tick_params(labelsize=10)
        ax.set_xlim([x_min, x_max])
        if minmax_status == 'minmax':
            ax.set_ylim([y_min, y_max])
        elif minmax_status == 'max':
            ax.set_ylim(top=y_max)
        elif minmax_status == 'min':
            ax.set_ylim(bottom=y_min)

        plt.grid(linestyle='dashed', linewidth=0.2)
        plt.xticks(rotation=90)
        plt.tick_params(labelsize=10, direction = "in")
        plt.tight_layout()
        plt.savefig(fig_file_name, bbox_inches="tight")

    def draw_scatter(self, fig_file_name, figure_label, x, y, minmax_status='none'):
        x_label_name = figure_label[0]
        y_label_name = figure_label[1]
        (x_min, x_max, y_min, y_max) = figure_label[2]
        title = figure_label[3]

        fig = plt.figure(figsize=(6,6))
        fig.patch.set_facecolor('white')
        ax = fig.add_subplot(1,1,1)
        ax.scatter(x, y, s=0.5)
        ax.set_xlabel(x_label_name, fontsize=12)
        ax.set_ylabel(y_label_name, fontsize=12)
        ax.tick_params(labelsize=10)
        if minmax_status == 'minmax':
            ax.set_xlim([x_min, x_max])
            ax.set_ylim([y_min, y_max])
        elif minmax_status == 'max':
            ax.set_xlim(right=x_max)
            ax.set_ylim(top=y_max)
        elif minmax_status == 'min':
            ax.set_xlim(left=x_min)
            ax.set_ylim(bottom=y_min)

        ax.set_title(title, fontsize=10)

        plt.tick_params(labelsize=10, direction = "in")
        plt.tight_layout()
        plt.savefig(fig_file_name, bbox_inches="tight")

    def draw_double_trend(self, fig_file_name, figure_label, x, y, minmax_status='none'):
        x_label_name = figure_label[0]
        y_label_name = figure_label[1]
        legend1_name = figure_label[2]
        legend2_name = figure_label[3]
        (x_min, x_max, y_min, y_max) = figure_label[4]

        fig = plt.figure(figsize=(6,4))
        fig.patch.set_facecolor('white')
        ax = fig.add_subplot(1,1,1)
        ax.plot(x, y[:, 0], "C0", label=legend1_name, lw=0.5)
        ax.plot(x, y[:, 1], "C1", label=legend2_name, lw=0.5)

        ax.set_xlabel(x_label_name, fontsize=12)
        ax.set_ylabel(y_label_name, fontsize=12)
        ax.tick_params(labelsize=10)
        #ax.set_xlim([x_min, x_max])
        if minmax_status == 'minmax':
            ax.set_ylim([y_min, y_max])
        elif minmax_status == 'max':
            ax.set_ylim(top=y_max)
        elif minmax_status == 'min':
            ax.set_ylim(bottom=y_min)

        ax.legend(loc='lower left')
        plt.xticks(rotation=90)
        plt.tick_params(labelsize=10, direction = "in")
        plt.tight_layout()
        plt.savefig(fig_file_name, bbox_inches="tight")

    def draw_multi_trend(self, fig_file_name, figure_label, x, y, minmax_status='none'):
        x_label_name = figure_label[0]
        y_label_name = figure_label[1]
        legend_name = figure_label[2]
        (x_min, x_max, y_min, y_max) = figure_label[3]
        num_data = y.shape[1]

        fig = plt.figure(figsize=(6,4))
        fig.patch.set_facecolor('white')
        ax = fig.add_subplot(1,1,1)
        for i in range(num_data):
            ax.plot(x, y[:, i], "C" + str(i), label=legend_name[i], lw=0.5)

        ax.set_xlabel(x_label_name, fontsize=12)
        ax.set_ylabel(y_label_name, fontsize=12)
        ax.tick_params(labelsize=10)
        #ax.set_xlim([x_min, x_max])
        if minmax_status == 'minmax':
            ax.set_ylim([y_min, y_max])
        elif minmax_status == 'max':
            ax.set_ylim(top=y_max)
        elif minmax_status == 'min':
            ax.set_ylim(bottom=y_min)

        plt.grid(linestyle='dashed', linewidth=0.2)
        ax.legend(loc='lower left')
        plt.xticks(rotation=90)
        plt.tick_params(labelsize=10, direction = "in")
        plt.tight_layout()
        plt.savefig(fig_file_name, bbox_inches="tight")


    def double_trend(self, figure_label, x, y, fig_file_name, scale1='linear', scale2='linear'):
        def _yscale(ax, scale, y_min, y_max, mask_type):
            if scale == 'linear':
                ax.set_ylim([y_min, y_max])
            elif scale == 'log':
                if (mask_type) and ("My Drive" not in os.getcwd()):
                    ax.set_yscale(value=scale, nonpositive='mask')
                else:
                    ax.set_yscale(value=scale)

        x_label_name = figure_label[0]
        (y1_label_name, y2_label_name) = figure_label[1]
        (legend_name1, legend_name2) = figure_label[2]
        (y1_min, y1_max, y2_min, y2_max) = figure_label[3]

        fig = plt.figure(figsize=(6,4))
        fig.patch.set_facecolor('white')
        ax1 = fig.add_subplot(1,1,1)
        ax1.plot(x, y[:,0], "C0", label=legend_name1, lw=0.5)
        ax1.set_xlabel(x_label_name, fontsize=16)
        ax1.set_ylabel(y1_label_name, fontsize=16)
        ax1.tick_params(labelsize=12)
        #ax.set_xlim([x_min, x_max])
        #_yscale(ax1, scale1, y1_min, y1_max, mask_type=True)

        ax2 = ax1.twinx()
        ax2.plot(x, y[:,1], "C1", label=legend_name2, lw=0.5)
        ax2.set_ylabel(y2_label_name, fontsize=16)
        #_yscale(ax2, scale2, y2_min, y2_max, mask_type=False)

        
        h1, l1 = ax1.get_legend_handles_labels()
        h2, l2 = ax2.get_legend_handles_labels()
        ax1.legend(h1+h2, l1+l2, loc='upper right')


        plt.tick_params(labelsize=12, direction = "in")
        plt.tight_layout()
        plt.savefig(fig_file_name, bbox_inches="tight")
