# -*- coding: utf-8 -*-
import os
from os import path

import numpy as np
import pandas as pd

from pkg.helper import helper_class
from pkg.figure_save import figure_save_class

def make_save_dir(work_path):
    # makedirs
    helper_class().my_makedirs(work_path)
    helper_class().my_makedirs(work_path + '\\fig')
    helper_class().my_makedirs(work_path + '\\file')

def index_to_datetime(df, ts_clm):
    df[ts_clm] = pd.to_datetime(df.index)
    df.set_index(ts_clm, inplace=True)
    return df

def split_df(df):
    df_unit = df.loc[['unit', 'description'], :]
    print(df_unit)
    df = df.drop(['unit', 'description'])
    df = index_to_datetime(df, 'timestamp')
    df = df.astype(float)
    return df, df_unit

def pca(_x, _nComponent):
    pca = PCA(n_components=_nComponent)
    std_x = StandardScaler().fit_transform(_x)
    pca.fit(std_x)
    transformed_X = pca.transform(std_x)
    return pca, transformed_X


def pca_scatter(_df, clm, label, fig_file_name):
    minmax = [0, 1, 0, 1]
    figure_label = [label[0], label[1], minmax]
    figure_save_class().draw_scatter_id(fig_file_name, figure_label, _df.loc[:, clm[0]], _df.loc[:, clm[1]], _df.loc[:, 'clusterId'])

def main():
    dir_base = path.dirname( path.abspath(__file__) )

    # read file    
    save_path = dir_base + '\\output'
    df_master = pd.read_csv(save_path + '\\file\\result.csv', index_col=0)
    make_save_dir(save_path)

    (df_master, df_unit) = split_df(df_master)
    tag_list = df_unit.loc['description', :]
    tag_dict = df_unit.to_dict()
    print(df_master.shape)
    print(df_master.head(2))
    print(df_master.tail(2))

    (pca_model, )= pca(_x, _nComponent)
    pca = PCA(n_components=_nComponent)
    std_x = StandardScaler().fit_transform(_x)
    pca.fit(std_x)
    transformed_X = pca.transform(std_x)
    return pca, transformed_X

    clm = ['PT_41095', 'PT_41347']
    label = [tag_dict[c]['description'] for c in clm]
    categories = 'clusterId'
    #fig = df_master.iplot(kind="scatter",                    # 種類=散布図
    #                x=clm[0], y=clm[1],                # x軸をデータフレームの"X"列に、 y軸をデータフレームの"Y"列に
    #                xTitle=label[0], yTitle=label[1],  # プロットのx軸とy軸の名前の指定
    #                categories=categories,             # カテゴリを表す列を指定。ここの指定に合わせてグラフ中の各データの色が変わります
    #                )
    _plotly(df_master, clm, label, categories)
    print('finish')

if __name__ == "__main__":
    main()