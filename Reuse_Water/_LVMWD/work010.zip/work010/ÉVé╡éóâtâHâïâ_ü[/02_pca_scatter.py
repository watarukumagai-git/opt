# -*- coding: utf-8 -*-
import os
from os import path

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
import plotly.io as pio
import streamlit as st


def make_save_dir(work_path):
    # makedirs
    helper_class().my_makedirs(work_path)
    helper_class().my_makedirs(work_path + '\\fig')
    helper_class().my_makedirs(work_path + '\\file')

def index_to_datetime(df, ts_clm):
    df[ts_clm] = pd.to_datetime(df.index)
    df.set_index(ts_clm, inplace=True)
    return df

def split_df(df):
    df_unit = df.loc[['unit', 'description'], :]
    print(df_unit)
    df = df.drop(['unit', 'description'])
    df = index_to_datetime(df, 'timestamp')
    df = df.astype(float)
    return df, df_unit


def main():
    dir_base = path.dirname( path.abspath(__file__) )

    # read file
    save_path = dir_base + '\\output'
    df_master = pd.read_csv(save_path + '\\file\\result.csv', index_col=0)
    make_save_dir(save_path)

    (df_master, df_unit) = split_df(df_master)
    tag_list = df_unit.loc['description', :]
    tag_dict = df_unit.to_dict()

    print(tag_list)
    print('all features = ', len(tag_list))

    #for i in range(len(tag_list)-1):
    #    if 'clusterId' != tag_list[i] and 'clusterId' != tag_list[i+1]:
    #        num = [tag_list.index[i], tag_list.index[i+1]]
    #        label = [tag_list[i], tag_list[i+1]]
    #        pca_scatter(df_master, num, label, save_path + '\\fig\\scatter_' + tag_list[i] + '_' + tag_list[i+1] + '.png')

    categories = 'clusterId'
    #for i in range(len(tag_list)-1):
    #    if 'clusterId' != tag_list[i] and 'clusterId' != tag_list[i+1]:
    #        num = [tag_list.index[i], tag_list.index[i+1]]
    #        label = [tag_list[i], tag_list[i+1]]
    #        fig_file_name = save_path + '\\fig\\scatter_' + tag_list[i] + '_' + tag_list[i+1]
    _scatter_streamlit_select(df_master, categories, save_path + '\\fig', tag_list)

    
    print('finish')

if __name__ == "__main__":
    main()