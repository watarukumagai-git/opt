# -*- coding: utf-8 -*-
import os
from os import path

import numpy as np
import pandas as pd

from pkg.helper import helper_class

def make_save_dir(work_path):
    # makedirs
    helper_class().my_makedirs(work_path)
    helper_class().my_makedirs(work_path + '\\fig')
    helper_class().my_makedirs(work_path + '\\file')

def index_to_datetime(df, ts_clm):
    df[ts_clm] = pd.to_datetime(df.index)
    df.set_index(ts_clm, inplace=True)
    return df

def split_df(df):
    df_unit = df.loc[['unit', 'description'], :]
    print(df_unit)
    df = df.drop(['unit', 'description'])
    df = index_to_datetime(df, 'timestamp')
    df = df.astype(float)
    return df, df_unit

def df_resample(_df, clm_ts, span):
    _df.set_index(clm_ts, inplace=True)
    _df = index_to_datetime(_df, clm_ts)
    _df = _df.resample(span).mean()
    return _df

def main():
    dir_base = path.dirname( path.abspath(__file__) )

    # read file    
    root_path = dir_base + '\\input'
    df_master = pd.read_csv(root_path + '\\master_30min_preprocessed_edit.csv', index_col=0)
    df_flux_feature = pd.read_csv(root_path + '\\flux_feature_10min.csv', index_col=0, header=0)
    add_clm = df_flux_feature.columns.tolist()

    (df_master, df_unit) = split_df(df_master)
    df_unit.loc['unit', add_clm] = '%'
    df_unit.loc['description', add_clm] = add_clm

    df_flux_feature = df_resample(df_flux_feature, 'timestamp', '30min')

    df_master = pd.concat([df_master, df_flux_feature], axis=1)
    print(df_master.shape)
    print(df_master.head(2))
    print(df_master.tail(2))

    df_master = pd.concat([df_master, df_unit], axis=0)
    df_master = df_master.dropna(axis=1)
    df_master.to_csv(root_path + '\\master_30min_preprocessed_concat.csv')

    print('finish')

if __name__ == "__main__":
    main()