# -*- coding: utf-8 -*-
import os
from os import path

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
import plotly.io as pio
import streamlit as st

def _scatter_plotly(_df, clm, label, categories, fig_file_name):
    _df['timestamp'] = _df.index
    fig = px.scatter(_df, x=clm[0], y=clm[1], 
                     color=categories,
                     hover_data='timestamp',
                     )
    fig.update_traces(marker={'size': 2})
    fig.update_xaxes(title_text=label[0])
    fig.update_yaxes(title_text=label[1])
    pio.write_html(fig, f"{fig_file_name}.html")
    pio.write_image(fig, f"{fig_file_name}.png")

def _scatter_streamlit_tabs(_df, categories, save_path, tag_list):
    _df['timestamp'] = _df.index
    l_ = [tag_list[i] + '_' + tag_list[j] for i in range(0, len(tag_list)-1) for j in range(i+1, len(tag_list)-1)]
    tablist = st.tabs(l_)
    k = 0
    for i in range(0, len(tag_list)-1):
        for j in range(i+1, len(tag_list)-1):
            if tag_list[i] != 'clusterId' or tag_list[j] != 'clusterId':
                fig = px.scatter(_df, x=tag_list.index[i], y=tag_list.index[j], 
                                color=categories,
                                hover_data='timestamp',
                                )
                fig.update_traces(marker={'size': 2})
                fig.update_xaxes(title_text=tag_list[i])
                fig.update_yaxes(title_text=tag_list[j])
                tablist[k].plotly_chart(fig)
            k = k + 1


def _scatter_streamlit_select(_df, tag_dict, plant):
    def find_index(_series, item):
        return _series.where(_series == item).first_valid_index()

    def get_key_from_value(d, val):
        keys = [k for k, v in d.items() if v == val]
        if keys:
            return keys[0]
        return None

    _df['timestamp'] = _df.index

    l_ = list(tag_dict['description'].values())
    tag_tuple = tuple(l_)

    st.header(plant + ' Data Chart Plot')
    st.write('all features = ' + str(len(l_)))

    #fig = px.scatter(_df, x=find_index(tag_list, x_), y=find_index(tag_list, y_), 
    #                color=categories,
    #                hover_data='timestamp',
    #                )
    st.subheader('Chart Plot')
    x_ = st.selectbox('Please select x-axis', tag_tuple)
    y_ = st.selectbox('Please select y-axis', tag_tuple)
    xname = get_key_from_value(tag_dict['description'], x_)
    yname = get_key_from_value(tag_dict['description'], y_)

    fig1 = go.Figure()
    fig2 = go.Figure()
    fig3 = go.Figure()

    fig1.add_trace(go.Scatter(x=_df[xname], y=_df[yname], 
                            name='id: ' + str(id), mode='markers', marker_size=4,
                            marker_symbol = 'circle-open', marker_line_width=0.3,
                            text=_df['timestamp']
                            )
                )
    fig2.add_trace(go.Scatter(x=_df['timestamp'], y=_df[xname], 
                            name='id: ' + str(id), mode='markers', marker_size=4,
                            marker_symbol = 'circle-open', marker_line_width=0.3,
                            )
                )
    fig3.add_trace(go.Scatter(x=_df['timestamp'], y=_df[yname], 
                            name='id: ' + str(id), mode='markers', marker_size=4,
                            marker_symbol = 'circle-open', marker_line_width=0.3,
                            )
                )
    x_unit = ' [' + tag_dict['unit'][xname] + ']'
    y_unit = ' [' + tag_dict['unit'][yname] + ']'
    fig1.update_xaxes(title=x_ + x_unit, titlefont_size=18, tickfont=dict(size=18), showgrid=True, griddash='dash')
    fig1.update_yaxes(title=y_ + y_unit, titlefont_size=18, tickfont=dict(size=18), showgrid=True, griddash='dash')
    fig1.update_layout(margin=dict(t=10, b=0), legend=dict(font=dict(size=18)), hoverlabel=dict(font_size=16))

    fig2.update_xaxes(title='DateTime', titlefont_size=18, tickfont=dict(size=16), showgrid=True, griddash='dash', tickangle=-90)
    fig2.update_yaxes(title=x_ + x_unit, titlefont_size=18, tickfont=dict(size=18), showgrid=True, griddash='dash')
    fig2.update_layout(margin=dict(t=10, b=0), legend=dict(font=dict(size=18)), hoverlabel=dict(font_size=16))

    fig3.update_xaxes(title='DateTime', titlefont_size=18, tickfont=dict(size=16), showgrid=True, griddash='dash', tickangle=-90)
    fig3.update_yaxes(title=y_ + y_unit, titlefont_size=18, tickfont=dict(size=18), showgrid=True, griddash='dash')
    fig3.update_layout(margin=dict(t=10, b=0), legend=dict(font=dict(size=18)), hoverlabel=dict(font_size=16))

    st.subheader('Scatter Chart: {x_axis} vs {y_axis}'.format(x_axis=x_, y_axis=y_))
    st.plotly_chart(fig1)
    st.subheader('Chart Trend x-axis: {x_axis}'.format(x_axis=x_))
    st.plotly_chart(fig2)
    st.subheader('Chart Trend y-axis: {y_axis}'.format(y_axis=y_))
    st.plotly_chart(fig3)

def _plotly2(_df, clm, label, categories, fig_file_name):
    import plotly.graph_objects as go
    fig = go.Figure()
    fig.add_trace(
        go.Scatter(x = _df[clm[0]], y = _df[clm[1]],
                   mode = 'markers',
                   marker = dict(size=2),
                   customdata=_df.index,
                   #fillcolor=categories, 
                   hovertemplate=(
                   # brタグで改行
                   # %を使うとx, yの各値を指定可能
                   'x = %{x}<br>'\
                   'y = %{y}<br>'\
                   # マジックアンダースコア（もしくはdict）を使う引数はピリオドで対応可能
                   'timestamp = %{customdata}'
                   )
        )
    )
    fig.update_xaxes(title_text=label[0])
    fig.update_yaxes(title_text=label[1])
    #plotly.offline.plot(fig)
    pio.write_html(fig, f"{fig_file_name}.html",)
    #pio.write_image(fig, f"{fig_file_name}.png")

def index_to_datetime(df, ts_clm):
    df[ts_clm] = pd.to_datetime(df.index)
    df.set_index(ts_clm, inplace=True)
    return df

def split_df(df):
    df_unit = df.loc[['unit', 'description'], :]
    print(df_unit)
    df = df.drop(['unit', 'description'])
    df = index_to_datetime(df, 'timestamp')
    df = df.astype(float)
    return df, df_unit

def main():
    dir_base = path.dirname( path.abspath(__file__) )

    # read file
    parent_dir = os.path.abspath(os.path.join(dir_base, os.pardir))
    save_path = parent_dir + '\\input'
    df_master = pd.read_csv(save_path + '\\master_30min_preprocessed_concat.csv', index_col=0)

    (df_master, df_unit) = split_df(df_master)
    tag_list = df_unit.loc['description', :]
    tag_dict = df_unit.to_dict(orient='index')
    plant = 'LVMWD'

    print(tag_list)

    df_y = df_master.loc['2021/7/1  0:00:00':, :]
    _scatter_streamlit_select(df_y, tag_dict, plant)


    print('1st page finish')

if __name__ == "__main__":
    main()