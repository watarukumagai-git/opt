# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
import time

from pkg import helper
from pkg.save_figure import SaveFigure
from opt_module.get_eval import ViolationEvaluation
from opt_problem.define_opt_problem import OptProblem, LoadProblemParam

_helper = helper.Helper()
_helper.WORKPATH = _helper.get_workpath('cd')

def read_parameter_files(date_clm):
    dir_base = _helper.WORKPATH + _helper.SEPARATOR + 'input'
    df1 = pd.read_csv(dir_base + _helper.SEPARATOR + 'parameter.csv', header=0)
    df2 = pd.read_csv(dir_base + _helper.SEPARATOR + 'taglist.csv', header=0, index_col=0)
    df3 = pd.read_csv(dir_base + _helper.SEPARATOR + 'modellist.csv', header=0, index_col=0)
    df4 = pd.read_csv(dir_base + _helper.SEPARATOR + 'LRVlist.csv', header=0, index_col=0)
    timestamp = pd.to_datetime(df1.loc[:,date_clm]).tolist()
    df1 = df1.drop(date_clm, axis=1)
    return df1, df2, df3, df4, timestamp


def figure_x_trend(fig_base, prob, func, param_df, big_x_2D, df_LRV, timestamp):
    min_x = prob.bigbigx_ul[:, 0].reshape(prob.num_allfeat_total, prob.delta_t)
    max_x = prob.bigbigx_ul[:, 1].reshape(prob.num_allfeat_total, prob.delta_t)

    labels2 = ['actual', 'predicted', 'lower limit', 'upper limit']
    figure_label2 = ["Datetime", labels2]
    figure_label3 = ["Datetime"]
    id = list(prob.alltagdict['Description'].keys())

    # 'minmax'
    minmax_status = 'none'
    lang = 'eng'
    #dateformat = '%d-%b-%y %H'
    dateformat = '%d-%b-%y'
                
    # x trend
    for i, _id in enumerate(id):
        tag = prob.alltagdict['Description'][_id]
        fig_file_name = fig_base + _helper.SEPARATOR + tag + '.png'
        if _id in prob.inter_taglist:
            figure_label2i = figure_label2 + [tag, [min_x[i, 0], max_x[i, 0]]]
            SaveFigure().trend_four(figure_label2i, 
                                    timestamp, 
                                    param_df.loc[:, _id + '_Pattern'], 
                                    big_x_2D[i, :], 
                                    fig_file_name,
                                    minmax_status,
                                    lang,
                                    dateformat,
                                    )

        else:
            figure_label2i = figure_label3 + [tag, [min_x[i, 0], max_x[i, 0]]]
            SaveFigure().trend(figure_label2i, 
                                timestamp, 
                                param_df.loc[:, _id + '_Pattern'], 
                                fig_file_name,
                                minmax_status,
                                lang,
                                dateformat,
                                )

    # LRV trend
    for key, val in func.load_pro.LRVdict.items():
        act = df_LRV.loc[key + '_act'][:-1]
        opt = df_LRV.loc[key + '_opt'][:-1]
        figure_labeli = figure_label2 + [key, [float(val['min']), float(val['max'])]]
        fig_file_name = fig_base + _helper.SEPARATOR + key + '.png'
        SaveFigure().trend_four(figure_labeli, 
                                timestamp, 
                                act, 
                                opt, 
                                fig_file_name,
                                minmax_status,
                                lang,
                                dateformat,
                                )


def calc_average(prob, func, act_df, opt, df_LRV):
    #id = list(prob.alltagdict['Description'].keys())
    id_list = prob.opt_taglist + prob.inter_taglist
    id_list_pattern = [ll + '_Pattern' for ll in id_list]
    tag_list = func.get_dict_vallist(prob.alltagdict['Description'], id_list)

    df_ave = pd.DataFrame(np.zeros((2, len(tag_list))), index = ['actual ave.', 'optimized ave.'], columns = tag_list)
    df_ave.loc['actual ave.', tag_list] = act_df.loc[:, id_list_pattern].values.T.mean(axis=1)
    df_ave.loc['optimized ave.', tag_list] = opt.loc[id_list, :].mean(axis=1).values
    df_LRV.loc[:, 'average'] = df_LRV.mean(axis=1)
    df_ave.loc[:, list(func.load_pro.LRVdict.keys())] = 0
    for key, val in func.load_pro.LRVdict.items():
        for type_ in [('opt', 'optimized'), ('act', 'actual')]:
            df_ave.at[type_[1] + ' ave.', key] = df_LRV.at[key + '_' + type_[0], 'average']

    df_ave.loc['diff', :] = df_ave.loc['optimized ave.', :] - df_ave.loc['actual ave.', :]
    print(df_ave.round(3))
    return df_ave


def calc_LRV(func, act_df, opt):
    LRV_ = np.zeros((4, len(act_df)))
    idx_list = []
    j = 0
    for key, val in func.load_pro.LRVdict.items():
        for type_ in ['opt', 'act']:
            idx_list.append(key + '_' + type_)
            if type_ == 'act':
                input = act_df.loc[:, val['feed'] + '_Pattern'].T
                output = act_df.loc[:, val['perm'] + '_Pattern'].T
            else:
                input = opt.loc[val['feed'], :]
                output = opt.loc[val['perm'], :]
            LRV_[j, :] = np.log10(input) - np.log10(output)
            j = j + 1
    df_LRV = pd.DataFrame(LRV_, index = idx_list)
    return df_LRV

def get_LRV(func, file_base, param_df, df_big_x_2D):
    df_LRV = calc_LRV(func, param_df, df_big_x_2D)
    l_end = [s for s in list(df_LRV.index) if s.endswith('_opt')]
    a = df_LRV.loc[l_end, :]
    a.set_axis(list(func.load_pro.LRVdict.keys()), axis=0, inplace=True)
    df_big_x_2D_LRV = pd.concat([df_big_x_2D, a],  axis=0)
    df_big_x_2D_LRV.to_csv(file_base + "solution_LRV.csv")
    return df_LRV, df_big_x_2D_LRV


def main():
    date_clm = 'timestamp'
    (param_df, taglist_df, modellist_df, LRV_df, timestamp) = read_parameter_files(date_clm)
    print('start date = ', timestamp[0])
    print('end date = ', timestamp[-1])

    prob = LoadProblemParam(taglist_df, param_df, modellist_df, LRV_df)
    func = OptProblem(prob, _helper.SEPARATOR)
    func.g_num = len(func.constraint_function(np.zeros(prob.N)))
    print('Time = ', prob.Time)
    print('num_feat_total = ', prob.num_feat_total)


    # get path
    dir_base = _helper.make_output_validate_dir(_helper.WORKPATH)
    str_clm = ['dimension', 'g_num']
    num_clm = [prob.N, func.g_num]   
    print(str_clm)
    print(num_clm)
    _helper.make_setfile(dir_base, str_clm, num_clm)


    start_time = time.time()
    pattern_2D = prob.pattern_all.copy()[func.idx_optnum_all, :]
    x = func.convert_schedule_to_x(pattern_2D)
    obj = func.object_function(x)
    (vio, each_vio) = ViolationEvaluation().get_vio(func, x)
    print('obj = {0}, vio = {1}'.format(obj,vio))

    file_base = dir_base + _helper.SEPARATOR + 'file' + _helper.SEPARATOR
    fig_base = dir_base + _helper.SEPARATOR + 'fig' + _helper.SEPARATOR

    # result save
    big_x_2D = func.get_big_x_2D(func.convert_x_to_schedule(x))
    df_big_x_2D = pd.DataFrame(big_x_2D, index=prob.allID_list)
    df_big_x_2D.to_csv(file_base + "x2D_validation.csv")
    df_obj_vio = pd.DataFrame([obj, vio], index=['obj', 'vio'])
    df_obj_vio.to_csv(file_base + "obj_vio.csv")
    df_each_vio = pd.DataFrame(each_vio, columns=['each_vio'])
    df_each_vio.to_csv(file_base + "each_vio.csv")
    
    # LRV
    (df_LRV, df_big_x_2D_LRV) = get_LRV(func, file_base, param_df, df_big_x_2D)

    # average 
    df_ave = calc_average(prob, func, param_df, df_big_x_2D_LRV, df_LRV)
    df_ave.to_csv(file_base + "solution_ave.csv")
    print ("file saving finished.")

    # figure save
    figure_x_trend(fig_base, prob, func, param_df, big_x_2D, df_LRV, timestamp)
    print ("figure saving finished.")

    # time finish
    end_time = time.time()
    cal_time = end_time - start_time
    print('time = %f sec = %f min' % (cal_time, cal_time/60))

    
if __name__ == "__main__":
    main()
