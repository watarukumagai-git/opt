- generate_param.py
   - generate input/parameter.csv from input/masterdata(LVMWD) and taglist.
   - this gets actual data from master data in the optimization period.
   - parameter.csv has 4 columns Pattern/SeedMode/Min/Max in each variable. 
      - Pattern data is fixed value and determined from actual data.
      - Min/Max data is lower/upper limit (ideal is below) and determined from taglist.
         S1 perm EC [0, 50]
         S2 feed EC [0, 30]
         S2 perm EC [0, 50]
         S3 feed EC [0, 50]
         S3 perm EC [0, 60]
         perm combined EC [0, 50]
         perm TOC [0, 0.15]
      - SeedMode data is variable mode and determined from taglist.
         0: Opt. Variable
         1: Fixed Parameter
         2: Intermediate Variable (predictive variable)
   - taglist.csv defines scheduling optimization parameters as follows. 
         ID No.: define each variable id
         Description: define variablename
         SeedMode: define SeedMode
         tag ID: define keyname at masterdata
         minmax: define lower/upper limit (-999 is defined automatically as min/max value from actual data)
         diff_min/diff_max: define fluctuation limit at one step (-999 is nothing definition)
   - optimization period is defined at "generate_param.py"
      training period: 20220307 0:00 - 20220313 0:00
      optimization period: 20220314 0:00 - 20220316 0:00

- optimize_schedule.py
   - plant optimization (LVMWD)
   - calculate based on modellist.csv, parameter.csv, and taglist.csv.
      - prediction model: water quality prediction model based on multi linear regression
      - optimization algorithm: SHADE and Feasibility Rule
      - variable: 1 * num_steps
      - num_steps: 97step
   - modellist.csv defines input and output variables for each prediction model. 
      - coulmn name is output variable name
      - row name is input variable name
      - if the cell corresponding vertical and horizontal is empty, it's row name is not input variable.
      - if the cell corresponding vertical and horizontal has number, it's row name is input variable.
      - each number shows order of model arguments.
         - e.g., if ID0000 is 0, ID0002 is 2, and ID0010 is 1 for predicting ID1000, the ID1000 predict model has (ID0000, ID0010, ID0002) arguments.
   - alg_param.init defines optimization algorithm parameters. 
      - Calulation times depends on the following params, but run max basically independent of the quality of the solution.
         - population size is number of search points.  
         - iteration counter max is number of iterations. 
         - run max is number of trials.