#coding: utf-8 
import re

def get_opt_module_param(WORKPATH, SEPARATOR):
    param_file = WORKPATH + SEPARATOR + "alg_param.ini"
    with open(param_file, 'r') as f:
        for line in f:
            line = re.sub(r'\s|\n', '', line)
            if len(line) == 0 or line[0] == '#':
                continue
            line = line.split("=")
            
            if line[0] == 'population':
                # population size
                population = int(line[1])
            elif line[0] == 'iter_max':
                # iteration counter max
                iter_max = int(line[1])
            elif line[0] == 'run_max':
                # loop max
                run_max = int(line[1])
            else:
                raise 'invalid keyword: ' + line[0]
        
    # re-define
    #[iter_max, m, **algorithm's other para.**]
    alg_para = []
    alg_para.append(iter_max)
    alg_para.append(population)
    return alg_para, run_max