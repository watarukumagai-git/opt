#coding: utf-8
from operator import itemgetter
import pandas as pd
from opt_problem.model_quality.wrapped_model import ModelStd
from pkg import helper
from opt_problem.wrapped_pickle import Pickle

_helper = helper.Helper()
_helper.WORKPATH = _helper.get_workpath('cd')

def fit_model(X, y, model_filename):
    from sklearn import preprocessing
    from sklearn.linear_model import LinearRegression

    # standardization model
    stds = preprocessing.StandardScaler()
    stds.fit(X)
    x_scaled = stds.transform(X)

    # prediction model
    lr_model = LinearRegression()
    lr_model.fit(x_scaled, y)
    pred = lr_model.predict(x_scaled) # input scaled data into original model

    model = ModelStd(lr_model, stds) # define new model saved attributes of standardization and prediction model
    Pickle().save_model(model_filename, model) # Serialize prediction model
    return pred

def load_csv(DIR, masterfile):
    dir_base = DIR + _helper.SEPARATOR + 'input'
    _df1 = pd.read_csv(dir_base + _helper.SEPARATOR + masterfile, header=0, index_col=0, dtype=str)
    _df2 = pd.read_csv(dir_base + _helper.SEPARATOR + 'taglist.csv', header=0, index_col=0)
    _df3 = pd.read_csv(dir_base + _helper.SEPARATOR + 'modellist.csv', header=0, index_col=0)
    return _df1, _df2, _df3

def get_dict_vallist(d_, l_):
    return [d_[d] for d in l_]

def get_taglist(_df, taglist_df):
    def _get_modellist(df_):
        df_ = df_.fillna(-999)
        l_ = [df_.loc[df_.loc[:, clm] >= 0, clm].sort_values(ascending=True).index.tolist() for clm in df_.columns.tolist()]
        return l_

    def _get_list(dict):
        _taglist = []
        for val in dict.values():
            _taglist += val[0] + val[1]
        _taglist = list(set(_taglist))
        return _taglist

    def _get_dict(taglist_df, _df, pre_dict):
        tagdict = taglist_df.to_dict(orient='index')
        x_list = [get_dict_vallist(tagdict['tag ID'], x) for x in _get_modellist(_df)]
        y_list = [tagdict['tag ID'][y] for y in _df.columns.tolist()]
        idx_list = [y_list.index(val) for val in pre_dict.values() if val in y_list]
        x_list = [x_list[idx] for idx in idx_list]
        y_list = [[y_list[idx]] for idx in idx_list]
        var_dict = dict(zip(list(pre_dict.keys()), [i for i in zip(x_list, y_list)]))
        return var_dict

    pre_dict = {'1st_Cond':'AIT_41092', 
                '2nd_Cond':'AIT_41292', 
                '3rd_Cond':'AIT_41392', 
                'TOC':'AIT_41810'}

    taglist_df = taglist_df.fillna(-999)
    var_dict = _get_dict(taglist_df, _df, pre_dict)

    #var_dict = {'1st_Cond': (["PT_41095","AIT_40006","RO_01_FirstStageFeedFlow","TIT_40005","AIT_40008","AI_31094"], ['AIT_41092']),
    #            '2nd_Cond': (["RO_01_SecondStageFeedConductivity", "RO_01_SecondStageFeedFlow","TIT_40005","AI_31094"], ['AIT_41292']),
    #            '3rd_Cond': (["PT_41347","RO_01_ThirdStageFeedConductivity","RO_01_ThirdStageFeedFlow","TIT_40005","AI_31094"], ['AIT_41392']),
    #            'TOC': (["PT_41095","PT_41347","AIT_40006","RO_01_FirstStageFeedFlow","TIT_40005","AIT_40008","AIT_40010","AI_31094"], ['AIT_41810']),
    #            }
    tag_list = _get_list(var_dict)
    return tag_list, var_dict

def main():
    plant = 'LVMWD'
    masterfile = plant + '_master_preprocessed.csv'
    dir_base = _helper.WORKPATH + _helper.SEPARATOR + 'opt_problem' + _helper.SEPARATOR + 'model_quality'
    train_priod = ["2022-03-07 00:00:00","2022-03-13 23:30:00"]

    (master_df, taglist_df, modellist_df) = load_csv(_helper.WORKPATH, masterfile)
    (tag_list, tag_dict) = get_taglist(modellist_df, taglist_df)

    master_df = master_df.loc[:, tag_list]
    tra_df = master_df.loc[train_priod[0]:train_priod[1]]
    print(tra_df.head(2))
    print(tra_df.tail(2))
    print('training data size = ', len(tra_df))

    for name in tag_dict.keys():
        filename = plant + '_' + name + '_modelfile'
        estimate = fit_model(tra_df.loc[:,tag_dict[name][0]].values,\
                            tra_df.loc[:,tag_dict[name][1]].values,\
                            dir_base + _helper.SEPARATOR + filename)
        print(name)

    print('prediction model generation has finished.')

if __name__ == "__main__":
    main()