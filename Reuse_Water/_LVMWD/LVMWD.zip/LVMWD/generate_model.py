#coding: utf-8
import pandas as pd
from opt_problem.model_quality.wrapped_model import ModelStd
from pkg import helper
from opt_problem.wrapped_pickle import Pickle

_helper = helper.Helper()
_helper.WORKPATH = _helper.get_workpath('cd')

def fit_model(X, y, model_filename):
    from sklearn import preprocessing
    from sklearn.linear_model import LinearRegression

    # standardization model
    stds = preprocessing.StandardScaler()
    stds.fit(X)
    x_scaled = stds.transform(X)

    # prediction model
    lr_model = LinearRegression()
    lr_model.fit(x_scaled, y)
    pred = lr_model.predict(x_scaled) # input scaled data into original model

    model = ModelStd(lr_model, stds) # define new model saved attributes of standardization and prediction model
    Pickle().save_model(model_filename, model) # Serialize prediction model
    return pred

def load_csv(DIR, masterfile):
    dir_base = DIR + _helper.SEPARATOR + 'input'
    _df1 = pd.read_csv(dir_base + _helper.SEPARATOR + masterfile, header=0, index_col=0, dtype=str)
    _df2 = pd.read_csv(dir_base + _helper.SEPARATOR + 'taglist.csv', header=0, index_col=0)
    _df3 = pd.read_csv(dir_base + _helper.SEPARATOR + 'modellist.csv', header=0, index_col=0)
    return _df1, _df2, _df3


def get_taglist(_df):
    def _get_modellist(df_):
        df_ = df_.fillna(-999)
        l_ = [df_.loc[df_.loc[:, clm] >= 0, clm].sort_values(ascending=True).index.tolist() for clm in df_.columns.tolist()]
        return l_

    def _get_list(dict):
        _taglist = []
        for val in dict.values():
            _taglist += val[0] + val[1]
        _taglist = list(set(_taglist))
        return _taglist

    #var_dict = dict(zip(_df.columns.tolist(), _get_modellist(_df)))
    var_dict = {'1st_Cond': (["RO_B01 FW Press","RO_Feed Cond","S1 Feed Flow Rate","RO_Feed Temperature","RO_Feed Ph", "Sulfric Acid Usage","Threshold Inhibitor Usage"], ['RO_B01 Blank 1 Perm Cond']),
                '2nd_Cond': (["RO_B01 FW B2 Press","S2 Feed EC_calc", "S2 Feed Flow Rate_calc", "RO_Feed Temperature", "Sulfric Acid Usage","Threshold Inhibitor Usage"], ['RO_B01 Blank 2 Perm Cond'] ),
                '3rd_Cond': (["S3 Feed EC_calc","S3 Feed Flow Rate_calc", "RO_Feed Temperature", "Sulfric Acid Usage","Threshold Inhibitor Usage"], ['RO_B01 Blank 3 Perm Cond'] ),
                'TOC': (["RO_B01 FW Press","RO_B01 FW B2 Press","RO_Feed Cond","S1 Feed Flow Rate","RO_Feed Temperature","RO_Feed Ph","RO_Feed TOC", "Sulfric Acid Usage","Threshold Inhibitor Usage"], ['RO_Permeat TOC']),
                }
    tag_list = _get_list(var_dict)
    return tag_list, var_dict

def main():
    plant = 'OCWD'
    masterfile = plant + '_master_preprocessed.csv'
    dir_base = _helper.WORKPATH + _helper.SEPARATOR + 'opt_problem' + _helper.SEPARATOR + 'model_quality'
    train_priod = ["2022-05-13 00:00:00","2022-05-19 23:30:00"]

    (master_df, taglist_df, modellist_df) = load_csv(_helper.WORKPATH, masterfile)
    (tag_list, tag_dict) = get_taglist(modellist_df)

    master_df = master_df.loc[:, tag_list]
    tra_df = master_df.loc[train_priod[0]:train_priod[1]]
    print(tra_df.head(2))
    print(tra_df.tail(2))
    print('training data size = ', len(tra_df))

    for name in tag_dict.keys():
        filename = plant + '_' + name + '_modelfile'
        estimate = fit_model(tra_df.loc[:,tag_dict[name][0]].values,\
                            tra_df.loc[:,tag_dict[name][1]].values,\
                            dir_base + _helper.SEPARATOR + filename)
        print(name)

    print('prediction model generation has finished.')

if __name__ == "__main__":
    main()