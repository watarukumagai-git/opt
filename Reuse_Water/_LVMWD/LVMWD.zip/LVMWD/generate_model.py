#coding: utf-8

import pandas as pd

from modeling_module.wrapped_model import ModelStd
from pkg import helper
from pkg.read_config import read_config
from opt_problem.wrapped_pickle import Pickle

_helper = helper.Helper()
_helper.WORKPATH = _helper.get_workpath('cd')


def fit_model(X, y, model_filename, modeling_list_, modeling_mode_ = 'MLR', std_flag = True):
    from sklearn import preprocessing
    from modeling_module.modeling import Model

    if std_flag:
        stds = preprocessing.StandardScaler() # standardization model
        stds.fit(X)
        X= stds.transform(X)

    model = Model(modeling_mode_, modeling_list_)
    model.fit(X, y)
    pred = model.predict(X)
    print(model.model.coef_)

    if std_flag:
        model = ModelStd(model, stds) # define new model saved attributes of standardization and prediction model

    Pickle().save_model(model_filename, model) # Serialize prediction model
    return pred

def load_csv(DIR, masterfile):
    dir_base = DIR + _helper.SEPARATOR + 'input'
    _df1 = pd.read_csv(dir_base + _helper.SEPARATOR + masterfile, header=0, index_col=0, dtype=str)
    _df2 = pd.read_csv(dir_base + _helper.SEPARATOR + 'taglist.csv', header=0, index_col=0)
    _df3 = pd.read_csv(dir_base + _helper.SEPARATOR + 'modellist.csv', header=0, index_col=0)
    return _df1, _df2, _df3

def get_dict_vallist(d_, l_):
    return [d_[d] for d in l_]

def get_taglist(_df, taglist_df):
    def _get_modellist(df_):
        df_ = df_.fillna(-999)
        l_ = [df_.loc[df_.loc[:, clm] >= 0, clm].sort_values(ascending=True).index.tolist() for clm in df_.columns.tolist()]
        return l_

    def _get_list(dict):
        _taglist = []
        for val in dict.values():
            _taglist += val[0] + val[1]
        _taglist = list(set(_taglist))
        return _taglist

    def _get_dict(taglist_df, _df, pre_dict):
        tagdict = taglist_df.to_dict(orient='index')
        x_list = [get_dict_vallist(tagdict['tag ID'], x) for x in _get_modellist(_df)]
        y_list = [tagdict['tag ID'][y] for y in _df.columns.tolist()]
        idx_list = [y_list.index(val) for val in pre_dict.values() if val in y_list]
        x_list = [x_list[idx] for idx in idx_list]
        y_list = [[y_list[idx]] for idx in idx_list]
        var_dict = dict(zip(list(pre_dict.keys()), [i for i in zip(x_list, y_list)]))
        return var_dict

    pre_dict = {'1st_Cond':'AIT_41092', 
                '2nd_Cond':'AIT_41292', 
                '3rd_Cond':'AIT_41392', 
                'TOC':'AIT_41810'}

    taglist_df = taglist_df.fillna(-999)
    var_dict = _get_dict(taglist_df, _df, pre_dict)
    tag_list = _get_list(var_dict)
    return tag_list, var_dict

def main():
    (plant_name, time_span, modeling_mode, train_period, optimize_period, modeling_list) = read_config(_helper.WORKPATH + _helper.SEPARATOR + 'config.ini')

    masterfile = plant_name + '_master_preprocessed.csv'
    dir_base = _helper.WORKPATH + _helper.SEPARATOR + 'opt_problem' + _helper.SEPARATOR + 'model_quality'

    (master_df, taglist_df, modellist_df) = load_csv(_helper.WORKPATH, masterfile)
    (tag_list, tag_dict) = get_taglist(modellist_df, taglist_df)

    tra_df = master_df.loc[train_period[0]:train_period[1], tag_list]
    print(tra_df.astype(float).round(2).head(2))
    print(tra_df.astype(float).round(2).tail(2))
    print('training data shape = ', tra_df.shape)

    for name in tag_dict.keys():
        print(name)
        print(tag_dict[name][0])
        filename = plant_name + '_' + name + '_modelfile'
        estimate = fit_model(tra_df.loc[:,tag_dict[name][0]].values,\
                            tra_df.loc[:,tag_dict[name][1]].values,\
                            dir_base + _helper.SEPARATOR + filename,
                            modeling_list_ = modeling_list,
                            modeling_mode_ = modeling_mode,
                            std_flag = True)

    print('prediction model generation has finished.')

if __name__ == "__main__":
    main()