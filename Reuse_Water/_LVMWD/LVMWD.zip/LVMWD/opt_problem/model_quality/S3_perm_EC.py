#coding: utf-8
import numpy as np
from sklearn import preprocessing

class S3_perm_EC_model:
    """
    calulate S1 permeate EC.

    Attributes
    ----------
    model : constructor (coef_, intercept_)
        estimate EC value using x 
    """
    def __init__(self, modelparam):
        self.model = modelparam
        self.stds = preprocessing.StandardScaler()
    
    def predict(self, x):
        """
        predict S1 permeate EC.

        Parameters
        ----------
        x : double (5, Time)
            RO Stage 3 Feed Pressure
            RO Stage 3 Feed EC
            RO Stage 3 Feed Flow Rate (Cal)
            RO Feed Temperature
            RO Feed Total Chlorine

        Returns
        -------
        predicted value : double (Time,)
        """
        tmp = self.model.predict(self.stds.fit_transform(x).T).reshape(-1)
        return np.where(tmp<0, 0, tmp)