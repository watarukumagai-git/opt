#coding: utf-8
import numpy as np
from sklearn import preprocessing

class S2_perm_EC_model:
    """
    calulate S1 permeate EC.

    Attributes
    ----------
    model : constructor (coef_, intercept_)
        estimate EC value using x 
    """
    def __init__(self, modelparam, x):
        self.model = modelparam
        self.stds = preprocessing.StandardScaler()
        self.stds.fit(x.T)
    
    def predict(self, x):
        """
        predict S1 permeate EC.

        Parameters
        ----------
        x : double (4, Time)
            RO Stage 2 Feed EC
            RO Stage 2 Feed Flow Rate (Cal)
            RO Feed Temperature
            RO Feed Total Chlorine

        Returns
        -------
        predicted value : double (Time,)
        """
        tmp = self.model.predict(self.stds.transform(x.T)).reshape(-1)
        return np.where(tmp<0, 0, tmp)