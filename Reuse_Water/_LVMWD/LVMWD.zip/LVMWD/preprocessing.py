import numpy as np
import pandas as pd

from pkg import helper

_helper = helper.Helper()
_helper.WORKPATH = _helper.get_workpath('cd')

def load_csv(DIR, masterfile):
    def _index_to_datetime(_df, date_clm):
        _df['timestamp'] = pd.to_datetime(_df[date_clm])
        _df.set_index('timestamp',inplace=True)
        return _df
    dir_base = DIR + _helper.SEPARATOR + 'input'
    _df1 = pd.read_csv(dir_base + _helper.SEPARATOR + masterfile, header=0, dtype=str)
    date_clm = 'timestamp'    # timestamp clm name in masterfile
    date = _df1.loc[:, date_clm].tolist()
    # datetime transformation
    if '/' in date[0] and 'description' == date[-1]:
        _df1 = _index_to_datetime(_df1.iloc[:-2], date_clm)
        _df1 = _df1.drop(date_clm, axis=1)
    else:
        _df1 = _index_to_datetime(_df1, date_clm)
    _df1 = _df1.astype('float')
    return _df1

def add_calculation_tag(_data):
    def _conc_flow(_df, feedflow, permeateflow):
        return _df[feedflow] - _df[permeateflow]
    def _conc_EC(_df, feedflow, feedEC, permeateflow, permeateEC, concflow):
        return (_df[feedflow]*_df[feedEC] - _df[permeateflow]*_df[permeateEC]) / _df[concflow]
    
    EPS = 0.0001
    _data[_data["RO_01_FirstStageFeedFlow"] < EPS] = EPS
    _data["S2 Feed Flow Rate_calc"] = _conc_flow(_data, "RO_01_FirstStageFeedFlow", "FIT_41074")
    _data[_data["S2 Feed Flow Rate_calc"] < EPS] = EPS
    _data["S3 Feed Flow Rate_calc"] = _conc_flow(_data, "S2 Feed Flow Rate_calc", "FIT_41274")
    _data[_data["S3 Feed Flow Rate_calc"] < EPS] = EPS
    _data["S2 Feed EC_calc"] = _conc_EC(_data, "RO_01_FirstStageFeedFlow", "AIT_40006", "FIT_41074", "AIT_41092", "S2 Feed Flow Rate_calc")
    _data[_data["S2 Feed EC_calc"] < EPS] = EPS
    _data["S3 Feed EC_calc"] = _conc_EC(_data, "S2 Feed Flow Rate_calc", "S2 Feed EC_calc", "FIT_41274", "AIT_41292", "S3 Feed Flow Rate_calc")
    _data[_data["S3 Feed EC_calc"] < EPS] = EPS

    #clm = ["Sulfric Acid Usage", "Threshold Inhibitor Usage"]
    #delta_ = 30
    #unit_ = 'min'
    #if unit_ == 'day':
    #    _data[clm] = _data[clm]*delta_
    #elif unit_ == 'hour':
    #    _data[clm] = _data[clm]*delta_/24
    #elif unit_ == 'min':
    #    _data[clm] = _data[clm]*delta_/(24*60)
    #_data[clm] = _data[clm].fillna(method='ffill')
    return _data

def preprocessing(_df):
    _df = _df.where(_df > 0, np.nan)
    _df = _df.dropna(how='all', axis=1)
    _df = _df.interpolate('ffill').interpolate('bfill')
    return _df

def main():
    plant = 'LVMWD'
    dir_base = _helper.WORKPATH + _helper.SEPARATOR + 'input'
    filename = plant + '_master_30min_preprocessed.csv'
    (master_df) = load_csv(_helper.WORKPATH, filename)
    master_df = preprocessing(master_df)
    master_df = add_calculation_tag(master_df)

    filename = plant + '_master_preprocessed.csv'
    master_df.to_csv(dir_base + _helper.SEPARATOR + filename)

    print('data proprocessing has finished.')

if __name__ == "__main__":
    main()
