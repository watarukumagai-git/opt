# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
import time

from pkg import get_opt_module_param, helper
from pkg.save_figure import SaveFigure
from opt_module.optimize import Optimize
from opt_module.get_eval import ViolationEvaluation
from opt_problem.define_opt_problem import OptProblem, LoadProblemParam

_helper = helper.Helper()
_helper.WORKPATH = _helper.get_workpath('cd')

def read_parameter_files(date_clm):
    dir_base = _helper.WORKPATH + _helper.SEPARATOR + 'input'
    df1 = pd.read_csv(dir_base + _helper.SEPARATOR + 'parameter.csv', header=0)
    df2 = pd.read_csv(dir_base + _helper.SEPARATOR + 'taglist.csv', header=0, index_col=0)
    df3 = pd.read_csv(dir_base + _helper.SEPARATOR + 'modellist.csv', header=0, index_col=0)
    timestamp = pd.to_datetime(df1.loc[:,date_clm]).tolist()
    df1 = df1.drop(date_clm, axis=1)
    return df1, df2, df3, timestamp


def loop_iteration(func, alg_para, run_max, start_time):
    iter_max = alg_para[0]
    # databox gene
    time_box = np.zeros((run_max+1, 3))
    # [gbest_obj, gbest_vio]
    obj_gbest_box = np.zeros((iter_max, 2, run_max))
    x_gbest_final_box = np.zeros((func.load_pro.N, run_max))

    # time start
    print ("calculation started.")
    print('-----------------------------------')
    unit_run = Optimize(func, alg_para)

    for run in range(0, run_max): 
        print('run/run_max = %d / %d' % (run+1, run_max))
        print('loop start')
        # get solution
        (obj_subbox, x_gbest, obj_gbest_subbox) = unit_run.main_loop()

        # save solution
        obj_gbest_box[:, :, run] = obj_gbest_subbox.T
        x_gbest_final_box[:, run] = x_gbest
        
        now_time = time.time() 
        if run == 0:
            loop_cal_time = now_time - start_time
        else:
            loop_cal_time = now_time - cal_time - start_time
        cal_time = now_time - start_time 
        time_box[run, :] = np.array([loop_cal_time, loop_cal_time/60, loop_cal_time/3600])
        print('calculation time = %.3f sec = %.3f min' % (cal_time, cal_time/60))
        print ("feas_gbest: ", np.round(obj_gbest_box[iter_max-1, :2, run], 3))
        print('loop end')
        print('-----------------------------------')

    print ("calculation finished")
    time_box[-1, :] = np.mean(time_box[:run_max, :], axis=0)
    time_box = np.round(time_box, decimals=4)
    print('mean time = %.3f sec = %.3f = min = %.3f = hour' % (time_box[-1, 0], time_box[-1, 1], time_box[-1, 2]))
    return obj_gbest_box, x_gbest_final_box, time_box


def get_result(obj_gbest_box):
    name_list = ["obj", "vio"]
    idx_list = ["ave", "std", "max", "min"]

    df_obj_gbest_final = pd.DataFrame(obj_gbest_box.T, columns=name_list)
    print(df_obj_gbest_final)

    df_result = pd.DataFrame(np.zeros((len(idx_list), len(name_list))), index=idx_list, columns=name_list)
    for i in name_list:
        df_result.at["ave", i] = df_obj_gbest_final.loc[:, i].mean()
        df_result.at["std", i] = df_obj_gbest_final.loc[:, i].std()
        df_result.at["max", i] = df_obj_gbest_final.loc[:, i].max()
        df_result.at["min", i] = df_obj_gbest_final.loc[:, i].min()

    print ("result=")
    print (df_result)
    return df_result, df_obj_gbest_final 

def figures(fig_base, prob, param_df, obj_gbest_box, big_x_2D_feas_gbest_final_box, timestamp):
    iter_max = obj_gbest_box.shape[0]
    run_max = obj_gbest_box.shape[2]
    obj_max = np.amax(obj_gbest_box[:, 0, :])
    vio_max = np.amax(obj_gbest_box[:, 1, :])
    minmax = [0, obj_max, 0, vio_max]

    min_x = prob.bigbigx_ul[:, 0].reshape(prob.num_allfeat_total, prob.delta_t)
    max_x = prob.bigbigx_ul[:, 1].reshape(prob.num_allfeat_total, prob.delta_t)

    legends1 = ["$f(x)$", "$v(x)$"]
    labels1 = ["$f(x)$", "$v(x)$"]
    figure_label1 = ["iteration: $k$", legends1, labels1, minmax]
    labels2 = ['actual', 'optimized', 'lower limit', 'upper limit']
    figure_label2 = ["Datetime", labels2]
    figure_label3 = ["Datetime"]
    id = list(prob.alltagdict['Description'].keys())

    # 'minmax'
    minmax_status = 'none'
    lang = 'eng'
    dateformat = '%d-%b-%y %H'

    for run in range(0, run_max):
        # obj and vio gbest trend
        fig_file_name = fig_base + 'obj_vio_gbest_'+ str(run) + '.png'
        SaveFigure().double_trend(figure_label1, 
                                         range(0, iter_max), 
                                         obj_gbest_box[:, :, run],
                                         fig_file_name,
                                         scale1 = 'log',
                                         scale2 = 'log')
                
        # x trend
        for i, _id in enumerate(id):
            if _id not in prob.fixed_taglist:
                tag = prob.alltagdict['Description'][_id]
                figure_label2i = figure_label2 + [tag, [min_x[i, 0], max_x[i, 0]]]
                fig_file_name = fig_base + _helper.SEPARATOR + tag + '_run'+ str(run) + '.png'
                SaveFigure().trend_four(figure_label2i, 
                                        timestamp, 
                                        param_df.loc[:, _id + '_Pattern'], 
                                        big_x_2D_feas_gbest_final_box[i, :, run], 
                                        fig_file_name,
                                        minmax_status,
                                        lang,
                                        dateformat,
                                        )

    for i, _id in enumerate(id):
        if _id in prob.fixed_taglist:
            tag = prob.alltagdict['Description'][_id]
            figure_label2i = figure_label3 + [tag, [min_x[i, 0], max_x[i, 0]]]
            fig_file_name = fig_base + _helper.SEPARATOR + tag + '.png'
            SaveFigure().trend(figure_label2i, 
                                timestamp, 
                                param_df.loc[:, _id + '_Pattern'], 
                                fig_file_name,
                                minmax_status,
                                lang,
                                dateformat,
                                )


def main():
    # parameter setting
    (alg_para, run_max) = get_opt_module_param.get_opt_module_param(_helper.WORKPATH, _helper.SEPARATOR)
    #alg_para = [iter_max, population, "alg_name", **algorithm's other para.**]
    iter_max = alg_para[0]
    population = alg_para[1]

    date_clm = 'timestamp'
    (param_df, taglist_df, modellist_df, timestamp) = read_parameter_files(date_clm)
    print('start date = ', timestamp[0])
    print('end date = ', timestamp[-1])

    prob = LoadProblemParam(taglist_df, param_df, modellist_df)
    func = OptProblem(prob, _helper.SEPARATOR)
    func.g_num = len(func.constraint_function(np.zeros(prob.N)))
    print('Time = ', prob.Time)
    print('num_feat_total = ', prob.num_feat_total)


    # get path
    dir_base = _helper.make_output_dir(_helper.WORKPATH)
    str_clm = ['dimension', 'iter_max', 'population', 'run_max', 'g_num']
    num_clm = [prob.N, iter_max, population, run_max, func.g_num]   
    print(str_clm)
    print(num_clm)
    _helper.make_setfile(dir_base, str_clm, num_clm)


    # run loop    
    start_time = time.time()
    (obj_gbest_box, x_gbest_final_box, time_box) = loop_iteration(func, alg_para, run_max, start_time)
    file_base = dir_base + _helper.SEPARATOR + 'file' + _helper.SEPARATOR
    fig_base = dir_base + _helper.SEPARATOR + 'fig' + _helper.SEPARATOR

    # result save
    # df_result: [[ave, std, max, min], [obj, vio]]
    # df_obj_feas_gbest_final: [run_max, [obj, vio]]
    run_idx = ['run'+str(i+1) for i in range(0, run_max)]
    df_time = pd.DataFrame(time_box, index=run_idx + ['average'], columns=['sec','min','hour'])
    df_time.to_csv(file_base + "time.csv")

    (df_result, df_obj_feas_gbest_final) = get_result(obj_gbest_box[-1, :, :])
    df_result.to_csv(file_base + "result.csv")

    df_x_gbest_final = pd.DataFrame(x_gbest_final_box)
    df_x_gbest_final.to_csv(file_base + "x_gbest_final.csv")

    #x_feas_gbest_final_box = x_feas_cbest_gbest_final_box[1, :, :].reshape(prob.num_feat_total, prob.Time, run_max)
    #x_feas_gbest_final: (N, run_max)
    x_feas_gbest_final = x_gbest_final_box.reshape(-1, run_max)

    #x_2D_feas_gbest_final_box = x_feas_gbest_final.reshape(prob.num_feat_total, prob.delta_t, run_max)
    x_2D_feas_gbest_final_box = np.zeros((prob.num_feat_total, prob.delta_t, run_max))
    big_x_2D_feas_gbest_final_box = np.zeros((prob.num_allfeat_total, prob.delta_t, run_max))
    # param_box: ((iter_max, 2, m, run_max))
    for run in range(0, run_max):
        x_2D_feas_gbest_final_box[:, :, run] = func.convert_x_to_schedule(x_feas_gbest_final[:, run])
        big_x_2D_feas_gbest_final_box[:, :, run] = func.get_big_x_2D(x_2D_feas_gbest_final_box[:, :, run])
        df_x_2D_feas_gbest_final = pd.DataFrame(big_x_2D_feas_gbest_final_box[:, :, run], index=func.id_alltagid)
        df_x_2D_feas_gbest_final.to_csv(file_base + "x2D_gbest_final_run" + str(run) + ".csv")
        df_feas_gbest = pd.DataFrame(obj_gbest_box[:, :, run], columns=['gbest_obj', 'gbest_vio'])
        df_feas_gbest.to_csv(file_base + "gbest_run" + str(run) + ".csv")


    #x_each_vio_final: (v_num+1, run_max)
    each_vio_final = ViolationEvaluation().get_each_vio(func, x_feas_gbest_final.T).T
    v_num = len(each_vio_final)
    each_vio_final = np.append(each_vio_final, np.sum(each_vio_final, axis=0))
    ll = np.arange(v_num).tolist()
    ll = [str(n) for n in ll] + ['sum']
    df_each_vio_final = pd.DataFrame(each_vio_final, index=ll, columns=run_idx)
    df_each_vio_final.to_csv(file_base + "each_vio_final.csv")
    
    print ("file saving finished.")


    # figure save
    figures(fig_base, prob, param_df, obj_gbest_box, big_x_2D_feas_gbest_final_box, timestamp)
    print ("figure saving finished.")

    # time finish
    end_time = time.time()
    cal_time = end_time - start_time
    print('time = %f sec = %f min' % (cal_time, cal_time/60))

    
if __name__ == "__main__":
    main()
